import 'package:flutter/material.dart';

import 'color_manger.dart';
import 'font_manger.dart';
import 'strings_manager.dart';
import 'styles_manger.dart';

class RouteName {
  static const String register = '/';
}

class RouteManger {
  static Route route(RouteSettings settings) {
    switch (settings.name) {
      // case RouteName.register:
      // return MaterialPageRoute(builder: (context)=>const RegisterView());

      default:
        return MaterialPageRoute(
            builder: (_) => Material(
                  color: Colors.white,
                  child: Center(
                    child: Text(
                      StringsManager.noRootFound,
                      style: StylesManger.rich(),
                    ),
                  ),
                ));
    }
  }
}
