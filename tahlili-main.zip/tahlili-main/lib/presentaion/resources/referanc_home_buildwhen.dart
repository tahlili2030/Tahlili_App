// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:tahlili/presentaion/home/cubit/home_cubit.dart';
// import 'package:tahlili/presentaion/home/view/widgest/category_widget.dart';
// import 'package:tahlili/presentaion/home/view/widgest/deals_widget.dart';
// import 'package:tahlili/presentaion/home/view/widgest/feedback_widget.dart';
// import 'package:tahlili/presentaion/home/view/widgest/genetics_widget.dart';
// import 'package:tahlili/presentaion/home/view/widgest/insurances_widget.dart';
// import 'package:tahlili/presentaion/home/view/widgest/lab_widget.dart';
// import 'package:tahlili/presentaion/home/view/widgest/packages_widget.dart';

// class HomeView extends StatefulWidget {
//   const HomeView({super.key});

//   @override
//   State<HomeView> createState() => _HomeViewState();
// }

// class _HomeViewState extends State<HomeView> {
//   @override
//   void initState() {
//     context.read<HomeCubit>().start();
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(),
//       body: ListView(
//         children: [
//           Column(
//             children: [
//               Text(
//                 "Insurances",
//                 style: Theme.of(context).textTheme.bodyLarge,
//               ),
//               InkWell(
//                 onTap: (){
//                   // showCupertinoDialog(context: context, builder: builder),
//                   // showDialog(context: context, builder: builder)
//                 },
//                 child: const SizedBox(
//                   height: 10,
//                 ),
//               ),
//               BlocBuilder<HomeCubit, HomeState>(
//                   buildWhen: (previous, current) {
//                     return current is SuccessGetHomeInsurancesState ||
//                         current is FailureGetHomeInsurancesState;
//                   },
//                   builder: (context, state) =>
//                       state is SuccessGetHomeInsurancesState
//                           ? InsurancesWidget(insurances: state.insurances)
//                           : state is FailureGetHomeInsurancesState
//                               ? Center(
//                                   child: Text(state.error),
//                                 )
//                               : const Center(
//                                   child: CircularProgressIndicator(),
//                                 )),
//             ],
//           ),
//           const SizedBox(
//             height: 30,
//           ),
//           Column(
//             children: [
//               Text(
//                 "Today deals",
//                 style: Theme.of(context).textTheme.bodyLarge,
//               ),
//               const SizedBox(
//                 height: 10,
//               ),
//               BlocBuilder<HomeCubit, HomeState>(
//                   buildWhen: (previous, current) {
//                     return current is SuccessGetShownDealsState ||
//                         current is FailureGetShwonDealsState;
//                   },
//                   builder: (context, state) =>
//                       state is SuccessGetShownDealsState
//                           ? DealsWidget(deals: state.deals)
//                           : state is FailureGetShwonDealsState
//                               ? Center(
//                                   child: Text(state.error),
//                                 )
//                               : const Center(
//                                   child: CircularProgressIndicator(),
//                                 )),
//             ],
//           ),
//           const SizedBox(
//             height: 30,
//           ),
//           Column(
//             children: [
//               Text(
//                 "Category",
//                 style: Theme.of(context).textTheme.bodyLarge,
//               ),
//               const SizedBox(
//                 height: 10,
//               ),
//               BlocBuilder<HomeCubit, HomeState>(
//                   buildWhen: (previous, current) {
//                     return current is SuccessGetHomeCategoriesState ||
//                         current is FailureGetHomeCategoriesState;
//                   },
//                   builder: (context, state) =>
//                       state is SuccessGetHomeCategoriesState
//                           ? CategoryWidget(categories: state.categories)
//                           : state is FailureGetHomeCategoriesState
//                               ? Center(
//                                   child: Text(state.error),
//                                 )
//                               : const Center(
//                                   child: CircularProgressIndicator(),
//                                 )),
//             ],
//           ),
//           const SizedBox(
//             height: 30,
//           ),
//           Column(
//             children: [
//               Text(
//                 "Genetics",
//                 style: Theme.of(context).textTheme.bodyLarge,
//               ),
//               const SizedBox(
//                 height: 10,
//               ),
//               BlocBuilder<HomeCubit, HomeState>(
//                   buildWhen: (previous, current) {
//                     return current is SuccessGetGeneticTestsState ||
//                         current is FailureGetGeneticTestsState;
//                   },
//                   builder: (context, state) =>
//                       state is SuccessGetGeneticTestsState
//                           ? GeneticsWidget(genetics: state.genetics)
//                           : state is FailureGetGeneticTestsState
//                               ? Center(
//                                   child: Text(state.error),
//                                 )
//                               : const Center(
//                                   child: CircularProgressIndicator(),
//                                 )),
//             ],
//           ),
//           const SizedBox(
//             height: 30,
//           ),
//           Column(
//             children: [
//               Text(
//                 "Labs",
//                 style: Theme.of(context).textTheme.bodyLarge,
//               ),
//               const SizedBox(
//                 height: 10,
//               ),
//               BlocBuilder<HomeCubit, HomeState>(
//                   buildWhen: (previous, current) {
//                     return current is SuccessGetHomeLabState ||
//                         current is FailureGetHomeLabState;
//                   },
//                   builder: (context, state) => state is SuccessGetHomeLabState
//                       ? LabsWidget(homeLabs: state.homeLabs)
//                       : state is FailureGetHomeLabState
//                           ? Center(
//                               child: Text(state.error),
//                             )
//                           : const Center(
//                               child: CircularProgressIndicator(),
//                             )),
//             ],
//           ),
//           const SizedBox(
//             height: 30,
//           ),
//           const SizedBox(
//             height: 30,
//           ),
//           Column(
//             children: [
//               Text(
//                 "Packages",
//                 style: Theme.of(context).textTheme.bodyLarge,
//               ),
//               const SizedBox(
//                 height: 10,
//               ),
//               BlocBuilder<HomeCubit, HomeState>(
//                   buildWhen: (previous, current) {
//                     return current is SuccessGetHomeRecommendedPackagesState ||
//                         current is FailureGetHomeRecommendedPackagesState;
//                   },
//                   builder: (context, state) =>
//                       state is SuccessGetHomeRecommendedPackagesState
//                           ? PackagesWidget(homePackages: state.homePackages)
//                           : state is FailureGetHomeRecommendedPackagesState
//                               ? Center(
//                                   child: Text(state.error),
//                                 )
//                               : const Center(
//                                   child: CircularProgressIndicator(),
//                                 )),
//             ],
//           ),
//           const SizedBox(
//             height: 30,
//           ),
//           Column(
//             children: [
//               Text(
//                 "FeedBack",
//                 style: Theme.of(context).textTheme.bodyLarge,
//               ),
//               const SizedBox(
//                 height: 10,
//               ),
//               BlocBuilder<HomeCubit, HomeState>(
//                   buildWhen: (previous, current) {
//                     return current is SuccessGetHomeFeedBackState ||
//                         current is FailureGetHomeFeedBackState;
//                   },
//                   builder: (context, state) =>
//                       state is SuccessGetHomeFeedBackState
//                           ? FeedBackWidget(homeFeedbacks: state.homeFeedbacks)
//                           : state is FailureGetHomeFeedBackState
//                               ? Center(
//                                   child: Text(state.error),
//                                 )
//                               : const Center(
//                                   child: CircularProgressIndicator(),
//                                 )),
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   // Widget switchState({
//   //   required HomeState state,
//   //   required HomeState loadState,
//   //   required HomeState successState,
//   //   required HomeState failureState,
//   //   required Widget successWidget,
//   //   required Widget failureWidget,
//   // }) {
//   //   if (state.runtimeType == loadState.runtimeType) {
//   //     return const Center(
//   //       child: CircularProgressIndicator(),
//   //     );
//   //   } else if (state.runtimeType == successState.runtimeType) {
//   //     return successWidget;
//   //   } else {
//   //     return failureWidget;
//   //   }
//   // }
// }
