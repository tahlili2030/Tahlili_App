


// Define breakpoints for different screen sizes
final double breakpointSmall = 600.0;
final double breakpointMedium = 900.0;