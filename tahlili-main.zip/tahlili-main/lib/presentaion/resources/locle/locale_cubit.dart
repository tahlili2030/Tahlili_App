import 'package:bloc/bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';
import 'package:tahlili/app/pref_manager.dart';

part 'locale_state.dart';

class LocaleCubit extends Cubit<LocaleState> {
  LocaleCubit(this._preferancesManager) : super(LocaleInitial());
  Locale? locale;
  final PreferancesManager _preferancesManager;
  getLocale({required BuildContext context}) {
    locale = context.locale;
    debugPrint(locale.toString());
    
    emit(GetLocaleState());
  }

 Future changeLocle({required Locale lang, required BuildContext context})async {
    locale=lang;
  await  context.setLocale(locale!);
  await _preferancesManager.saveData(key: prefsKeyLang, value: locale!.languageCode);
    emit(ChangeLocaleState());
  }
}
