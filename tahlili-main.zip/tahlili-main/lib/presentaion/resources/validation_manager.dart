import 'package:email_validator/email_validator.dart';

class ValidationManager {
  static bool emailValidation({required String email}) {
    if (EmailValidator.validate(email.trim())) {
      return true;
    }
    return false;
  }

  static bool lengthValidation({required String text, required int length}) {
    if (text.length >= length) {
      return true;
    }
    return false;
  }

  static bool phoneNumberValidation({required String phone}) {
    var regx = RegExp(r'^\+?[0-9\- ]+$');
    if (regx.hasMatch(phone)) {
      return true;
    }
    return false;
  }

  static bool passwordConfirmationValidation(
      {required String password, required String confirmPassword}) {
    if (password == confirmPassword) {
      return true;
    }
    return false;
  }
  static bool numberValidation({
    required String number
  }){
    final regx=RegExp(r'^[0-9]+$');
    if (regx.hasMatch(number)) {
      return true;
      
    }
    return false;
  }
}