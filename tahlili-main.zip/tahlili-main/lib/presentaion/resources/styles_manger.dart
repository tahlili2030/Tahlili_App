import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';

class StylesManger {
  static TextStyle rich() => GoogleFonts.vazirmatn(
      fontSize: 16.sp,
      fontWeight: FontWeight.w700,
      color: ColorManger.blueBlack);

  static TextStyle medium() => GoogleFonts.vazirmatn(
      fontSize: 14.sp,
      fontWeight: FontWeight.w500,
      color: ColorManger.blueBlack);

  static TextStyle small() => GoogleFonts.vazirmatn(
      fontSize: 12.sp,
      fontWeight: FontWeight.w400,
      color: ColorManger.blueBlack);

  static TextStyle extremelySmall() => GoogleFonts.vazirmatn(
      fontSize: 8.sp,
      fontWeight: FontWeight.w700,
      color: ColorManger.blueBlack);
}
