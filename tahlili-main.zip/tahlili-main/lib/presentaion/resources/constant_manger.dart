import 'package:flutter_screenutil/flutter_screenutil.dart';

class ConstantManger {
  static const int emptyInt = 0;
  static const String empyString = '';
  static const double vat = 15;
  static double borderRadius = 10.r;
  static List<String> splitTelda(String combinedName) {
    List<String> parts = combinedName.trim().split('~');
    return parts;
  }
}
