import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../app/end_points.dart';
import '../../../data/requests/order/request_order.dart';
import '../../../data/requests/wishlist/request_wishlist.dart';
import '../../../data/response/home/response_home.dart';
import '../../account/cubit/account_cubit.dart';
import '../../home/cubit/home_cubit.dart';
import '../../wishlist/cubit/wishlist_cubit.dart';
import '../color_manger.dart';
import '../styles_manger.dart';
import 'app_button.dart';
import 'quick_order_dialog.dart';

class ViewDetailsTestWidget extends StatelessWidget {
  final bool fromCart;
  const ViewDetailsTestWidget({
    super.key,
    required this.test,
    required this.fromCart,
  });

  final ResponseTestDetails test;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10.h),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Align(
              alignment: AlignmentDirectional.topEnd,
              child: InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: const Icon(
                    Icons.close,
                    color: Colors.grey,
                  )),
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              children: [
                Container(
                  height: 35,
                  width: 52,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      image: DecorationImage(
                          image: CachedNetworkImageProvider(
                              context.locale.languageCode == 'ar'
                                  ? EndPoints.baseImageUrl +
                                      context
                                          .read<HomeCubit>()
                                          .testDetails!
                                          .test!
                                          .image!
                                  : EndPoints.baseImageUrl +
                                      context
                                          .read<HomeCubit>()
                                          .testDetails!
                                          .test!
                                          .image!))),
                ),
                const SizedBox(
                  width: 10,
                ),
                Expanded(
                  child: Text(
                    context.locale.languageCode == 'ar'
                        ? context.read<HomeCubit>().testDetails!.test!.nameAr!
                        : context.read<HomeCubit>().testDetails!.test!.nameEn!,
                    style: StylesManger.rich().copyWith(color: Colors.black),
                  ),
                )
              ],
            ),
            SizedBox(
              height: 16.h,
            ),
            Text(
              "${test.price!} ${"SAR".tr()}",
              style: StylesManger.rich().copyWith(
                color: Colors.black,
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            if (!fromCart)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 50,
                    width: 140,
                    child: AppButton(
                        textSize: 12,
                        color: ColorManger.primary,
                        name: 'OrderNow'.tr(),
                        onPressed: () {
                          showDialog(
                              context: context,
                              builder: (context) => QuickOrderDialog(
                                    orderData: RequestOrderData(
                                        test.partnerId!,
                                        test.test!.nameEn!,
                                        test.price!,
                                        test.testId!,
                                        true),
                                  ));
                        }),
                  ),
                  SizedBox(
                    width: 15,
                  ),
                  SizedBox(
                    height: 50,
                    width: 140,
                    child: AppButton(
                        textColor: ColorManger.primary,
                        textSize: 11,
                        color: Colors.white,
                        name: 'AddToWishlist'.tr(),
                        onPressed: () {
                          context
                              .read<WishlistCubit>()
                              .addToWishlit(
                                  wishlist: RequestWishlist(
                                context
                                    .read<AccountCubit>()
                                    .userModel!
                                    .entityId!,
                                test.partnerId!,
                                test.testId!,
                              ))
                              .whenComplete(() => Navigator.pop(context));
                        }),
                  )
                ],
              )
          ],
        ),
      ),
    );
  }
}
