import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:tahlili/data/requests/order/request_order.dart';

import '../../orders/view/home/home_order_first_page.dart';
import '../../orders/view/lab/lab_order_page.dart';
import '../color_manger.dart';
import '../styles_manger.dart';
import 'app_button.dart';

class QuickOrderDialog extends StatelessWidget {
  final RequestOrderData orderData;
  const QuickOrderDialog({
    super.key, required this.orderData,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      actionsPadding: EdgeInsets.zero,
      actions: [
        Material(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)),
            child: SizedBox(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Align(
                      alignment: AlignmentDirectional.topEnd,
                      child: InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: const Icon(Icons.close,color: Colors.grey,)),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    Text("Site of the service".tr(),style: StylesManger.rich().copyWith(
                      color: Colors.black
                    ),),
                     const SizedBox(
                      height: 20,
                    ),
                    Row(
                      mainAxisAlignment:
                          MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(

                            child: SizedBox(
                                 height: 40,
                              child: AppButton(

                                  color: ColorManger.primary,
                                  name:  "At Home".tr(),
                                  onPressed: () {
                                    Navigator.pop(context);
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                 HomeOrderFirstPage(orderData: orderData,)));
                                  }),
                            )),
                           const SizedBox(width: 10,),
                        Expanded(


                            child: SizedBox(
                                 height: 40,
                              child: AppButton(

                                  color: Colors.white,
                                  textColor: ColorManger.primary,
                                  name: "AtLab".tr(),
                                  onPressed: () {
                                    Navigator.pop(context);
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                 LabOrderPage(orderData: orderData,)));
                                  }),
                            )),
                      ],
                    ),

                  ],
                ),
              ),
            ),
          )
      ],
    );
  }
}
