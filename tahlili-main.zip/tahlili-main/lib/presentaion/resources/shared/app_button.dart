import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../color_manger.dart';
import '../styles_manger.dart';

// ignore: must_be_immutable
class AppButton extends StatelessWidget {
  final String name;
  final VoidCallback onPressed;
  Color? textColor;
  double? radius;
  double? textSize;
  Color? borderSide;

  AppButton({
    super.key,
    required this.color,
    this.textColor,
    this.radius,
    required this.name,
    this.borderSide,
    this.textSize,
    required this.onPressed,
  });
  final Color color;

  @override
  Widget build(BuildContext context) {
    textColor ??= Colors.white;
    radius ??= 15.0;
    borderSide ??= ColorManger.newPrimary;
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
            minimumSize: Size(double.infinity, 48.h),
            backgroundColor: color,
            shape: RoundedRectangleBorder(
              side: BorderSide(color: borderSide!),
              borderRadius: BorderRadius.circular(radius!),
            )),
        onPressed: onPressed,
        child: Center(
          child: Text(
            name,
            style: StylesManger.rich()
                .copyWith(color: textColor, fontSize: textSize),
          ),
        ));
  }
}
