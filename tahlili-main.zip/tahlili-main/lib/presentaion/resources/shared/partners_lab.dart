import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

class PartnerDialog extends StatelessWidget {
  const PartnerDialog(
      {super.key,
      required this.labName,
      required this.labImage,
      required this.nOfPackages,
      required this.nOftests,
      required this.packageBtn,
      required this.testBtn});
  final String labName;
  final String labImage;
  final int nOfPackages;
  final int nOftests;
  final VoidCallback packageBtn;
  final VoidCallback testBtn;

  @override
  Widget build(BuildContext context) {
    return Container(
      // height: 270.h,
      width: double.infinity,
      padding: EdgeInsets.symmetric(vertical: 8.h),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Material(
              elevation: 1,
              color: Colors.white,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      labName,
                      style: StylesManger.rich().copyWith(color: Colors.black),
                    ),
                    InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: const Icon(
                          Icons.close,
                          color: Colors.grey,
                        )),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 8.h,
            ),
            InkWell(
              onTap: testBtn,
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: 16.w),
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                    border: Border.all(
                      color: ColorManger.newPrimary,
                    ),
                    borderRadius: BorderRadius.circular(5.r)),
                child: Row(
                  children: [
                    Container(
                      height: 50.h,
                      width: 50.w,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              fit: BoxFit.fill,
                              image: CachedNetworkImageProvider(
                                  EndPoints.baseImageUrl + labImage))),
                    ),
                    SizedBox(
                      width: 8.h,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Tests".tr(),
                          style:
                              StylesManger.rich().copyWith(color: Colors.black),
                        ),
                        SizedBox(
                          height: 8.h,
                        ),
                        Text(
                          nOftests.toString(),
                          style: StylesManger.medium()
                              .copyWith(color: ColorManger.newPrimary),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 8.h,
            ),
            InkWell(
              onTap: packageBtn,
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: 16.w),
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                    border: Border.all(
                      color: ColorManger.newPrimary,
                    ),
                    borderRadius: BorderRadius.circular(5.r)),
                child: Row(
                  children: [
                    Container(
                      height: 50.h,
                      width: 50.w,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              fit: BoxFit.fill,
                              image: CachedNetworkImageProvider(
                                  EndPoints.baseImageUrl + labImage))),
                    ),
                    SizedBox(
                      width: 16.w,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Packages".tr(),
                          style:
                              StylesManger.rich().copyWith(color: Colors.black),
                        ),
                        SizedBox(
                          height: 8.h,
                        ),
                        Text(
                          nOfPackages.toString(),
                          style: StylesManger.medium()
                              .copyWith(color: ColorManger.newPrimary),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
