
// import 'package:easy_localization/easy_localization.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:flutter_svg/flutter_svg.dart';

// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:tahlili/presentaion/home/cubit/home_cubit.dart';

// import '../color_manger.dart';
// import '../styles_manger.dart';

// class ChangeFilterWidget extends StatelessWidget {
//   const ChangeFilterWidget({Key? key, required this.unitTypeId})
//       : super(key: key);
//   final int? unitTypeId;
//   @override
//   Widget build(BuildContext context) {
//     final cubit = context.read<HomeCubit>();
//     return Container(
//       padding: const EdgeInsets.symmetric(
//         vertical: 5,
//       ),
//       decoration: const BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.only(
//               topLeft: Radius.circular(20), topRight: Radius.circular(20))),
//       child: Column(
//         mainAxisSize: MainAxisSize.min,
//         crossAxisAlignment: CrossAxisAlignment.center,
//         children: <Widget>[
//           const SizedBox(height: 10),
//           const SizedBox(width: 10),

//           BlocBuilder<HomeCubit, HomeState>(
//             builder: (context, state) {
//               return Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Padding(
//                     padding: const EdgeInsets.symmetric(vertical: 10.0),
//                     child: Container(
//                       width: 40,
//                       height: 5,
//                       decoration: BoxDecoration(
//                         color: ColorManger.primary,
//                         borderRadius: BorderRadius.circular(10),
//                       ),
//                     ),
//                   ),
//                   Row(
//                     children: [
//                       Radio(
//                           value: 0,
//                           groupValue: cubit.radioType,
//                           onChanged: (value) {
//                             cubit.selectRadio(value);
//                             if (cubit.unitName!.trim().isNotEmpty) {
//                               cubit.getUnitNameSearch(
//                                   unitName: cubit.unitName!.trim(),
//                                   unitTypeId: null,
//                                   ascOrDesc: 'asc');
//                             }

//                             Navigator.pop(context);
//                           }),
//                       SizedBox(
//                         width: 5.w,
//                       ),
//                       Text(
//                         "From lowest price to highest".tr(),
//                         style: StylesManger.mediumFont(),
//                       )
//                     ],
//                   ),
//                   SizedBox(
//                     height: 10.h,
//                   ),
//                   Row(
//                     children: [
//                       Radio(
//                           value: 1,
//                           groupValue: cubit.radioType,
//                           onChanged: (value) {
//                             cubit.selectRadio(value);
//                                if (cubit.unitName!.trim().isNotEmpty) {
//                             cubit.getUnitNameSearch(
//                                 unitName: cubit.unitName!.trim(),
//                                 unitTypeId: null,
//                                 ascOrDesc: 'desc');
//                                }
//                             Navigator.pop(context);
//                           }),
//                       SizedBox(
//                         width: 5.w,
//                       ),
//                       Text(
//                         "From highest price to lowest".tr(),
//                         style: StylesManger.mediumFont(),
//                       )
//                     ],
//                   ),
//                   SizedBox(
//                     height: 10.h,
//                   ),
//                   Row(
//                     children: [
//                       Radio(
//                           value: 2,
//                           groupValue: cubit.radioType,
//                           onChanged: (value) {
//                             cubit.selectRadio(value);
//                                if (cubit.unitName!.trim().isNotEmpty) {
//                             cubit.getUnitNameSearch(
//                                 unitTypeId: unitTypeId,
//                                 unitName: cubit.unitName!.trim(),
//                                 ascOrDescEval: "asc");
//                                }
//                             Navigator.pop(context);
//                           }),
//                       SizedBox(
//                         width: 5.w,
//                       ),
//                       Text(
//                         "From highest rating to lowest".tr(),
//                         style: StylesManger.mediumFont(),
//                       )
//                     ],
//                   ),
//                   SizedBox(
//                     height: 10.h,
//                   ),
//                   Row(
//                     children: [
//                       Radio(
//                           value: 3,
//                           groupValue: cubit.radioType,
//                           onChanged: (value) {
//                             cubit.selectRadio(value);
//                                if (cubit.unitName!.trim().isNotEmpty) {
//                             cubit.getUnitNameSearch(
//                                 unitTypeId: unitTypeId,
//                                 unitName: cubit.unitName!.trim(),
//                                 lat: context
//                                     .read<MapCubit>()
//                                     .userLocation!
//                                     .latitude,
//                                 long: context
//                                     .read<MapCubit>()
//                                     .userLocation!
//                                     .longitude);
//                                }
//                             Navigator.pop(context);
//                           }),
//                       SizedBox(
//                         width: 5.w,
//                       ),
//                       Text(
//                         "From closest to farthest".tr(),
//                         style: StylesManger.mediumFont(),
//                       )
//                     ],
//                   )
//                 ],
//               );
//             },
//           ),
//           const SizedBox(height: 10),
//         ],
//       ),
//     );
//   }
// }
