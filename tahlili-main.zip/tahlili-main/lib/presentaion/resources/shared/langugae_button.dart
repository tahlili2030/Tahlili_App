
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../locle/locale_cubit.dart';

class ChangelanguageWidget extends StatelessWidget {
  const ChangelanguageWidget({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {

    return Container(
       padding: const EdgeInsets.symmetric(

        vertical: 10,
      ),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20)
        )
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,

        children: <Widget>[
          const SizedBox(height: 10),
          const SizedBox(width: 10),
          Text(
            'Select Language',
            style: StylesManger.rich().copyWith(
              color: Colors.black
            )
            ,
          ),
          const SizedBox(height: 10),
          BlocBuilder<LocaleCubit, LocaleState>(
            builder: (context, state) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 25),
                    color: Colors.white,
                    child: RadioListTile<Locale?>(
                      dense: true,
                      controlAffinity: ListTileControlAffinity.trailing,
                      activeColor: ColorManger.primary,
                      value: context.supportedLocales[1],
                      title: Row(
                        children: [
                          SvgPicture.asset('assets/images/arabic.svg',height: 20,width: 10,fit: BoxFit.fill,),
                          const SizedBox(width: 10,),
                          Text("العربية",style: StylesManger.rich().copyWith(
                            color: Colors.black
                          ),)
                        ],
                      ),
                      //set English language if no language is selected
                      groupValue: context.read<LocaleCubit>().locale,
                      onChanged: (value) {
                        context.read<LocaleCubit>().changeLocle(lang: value!,context: context);
                      },
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    height: 1,
                    color: Colors.grey,
                  ),
                  Container(
                     padding: const EdgeInsets.symmetric(horizontal: 25),
                    color: Colors.white,
                    child: RadioListTile<Locale?>(
                      dense: true,
                      controlAffinity: ListTileControlAffinity.trailing,
                      activeColor: ColorManger.primary,
                      value: context.supportedLocales[0],
                      title:  Row(
                        children: [
                          SvgPicture.asset('assets/images/english.svg',height: 15,width: 10,fit: BoxFit.fill,),
                          const SizedBox(width: 10,),
                          Text("English",style: StylesManger.rich().copyWith(
                            color: Colors.black
                          ),)
                        ],
                      ),
                      //set English language if no language is selected
                      groupValue:context.read<LocaleCubit>().locale,
                      onChanged: (value) {
                        context.read<LocaleCubit>().changeLocle(lang: value!,context: context);
                      },
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    height: 1,
                    color: Colors.grey,
                  )
                ],
              );
            },
          ),
          const SizedBox(height: 10),

        ],
      ),
    );
  }
}
