import 'package:cached_network_image/cached_network_image.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/app/end_points.dart';

import '../color_manger.dart';
import '../styles_manger.dart';

class AppDropdown extends StatelessWidget {
  AppDropdown(
      {Key? key,
      required this.value,
      required this.hintText,
      required this.list,
      this.buttonDecoration,
      this.activated = false,
      this.onRadioChange,
      this.groupValue,
      this.isNetworkImage,
      this.prfoileImage,
      required this.onChange})
      : super(key: key);
  final List<String> list;
  final String hintText;
  final int? value;
  final Function onChange;
  final void Function(String?)? onRadioChange;
  final bool activated;
  final String? groupValue;
  final List<String>? prfoileImage;
  BoxDecoration? buttonDecoration;
  bool? isNetworkImage;
  @override
  Widget build(BuildContext context) {
    return DropdownButtonHideUnderline(
      child: DropdownButton2(
        value: value,
        hint: Text(
          hintText,
          style: StylesManger.medium().copyWith(color: ColorManger.grey),
        ),

        iconStyleData: const IconStyleData(
          icon: Icon(
            Icons.keyboard_arrow_down,
            size: 15,
            color: Colors.grey,
          ),
        ),

        isExpanded: true,

        buttonStyleData: ButtonStyleData(
          height: 40.h,
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: buttonDecoration,
        ),
        dropdownStyleData: DropdownStyleData(
          width: 220.w,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          elevation: 8,
          maxHeight: 200,
          decoration: BoxDecoration(
            border: Border.all(
              color: ColorManger.lightBlack,
            ),
            borderRadius: BorderRadius.circular(10),
            color: Colors.grey.shade100,
          ),
        ),

        // scrollbarRadius: const Radius.circular(40),
        // scrollbarThickness: 6,
        // scrollbarAlwaysShow: true,

        items: List.generate(
            list.length,
            (index) => DropdownMenuItem(
                  value: index,
                  child: Row(
                    children: [
                      if (prfoileImage!.isNotEmpty)
                        isNetworkImage != null
                            ? Container(
                                width: 8.w,
                                height: 10.h,
                                decoration: BoxDecoration(
                                    image: DecorationImage(
                                  fit: BoxFit.fill,
                                  image: AssetImage(prfoileImage![index]),
                                )),
                              )
                            : CircleAvatar(
                                backgroundImage: CachedNetworkImageProvider(
                                    EndPoints.baseImageUrl +
                                        prfoileImage![index]),
                                radius: 15,
                              ),
                      SizedBox(
                        width: 8.w,
                      ),
                      Text(
                        list[index],
                        style: StylesManger.extremelySmall().copyWith(
                            color: Color(0xff525252),
                            fontSize: 10.sp,
                            fontWeight: FontWeight.w500),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      )
                    ],
                  ),
                )),
        onChanged: (int? value) {
          onChange(value!);
        },
      ),
    );
  }
}
