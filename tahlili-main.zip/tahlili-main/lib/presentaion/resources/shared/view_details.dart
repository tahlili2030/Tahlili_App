import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/app/extenstions.dart';

import '../../../app/end_points.dart';
import '../../../data/requests/order/request_order.dart';
import '../../../data/requests/wishlist/request_wishlist.dart';
import '../../../data/response/home/response_home.dart';
import '../../account/cubit/account_cubit.dart';
import '../../home/cubit/home_cubit.dart';
import '../../wishlist/cubit/wishlist_cubit.dart';
import '../color_manger.dart';
import '../styles_manger.dart';
import 'app_button.dart';
import 'quick_order_dialog.dart';

class ViewDetailsWidget extends StatelessWidget {
  final bool fromCart;
  const ViewDetailsWidget({
    super.key,
    required this.deals,
    required this.fromCart,
  });

  final ResponsePackageDetails deals;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height > 800 ? 250.h : 300.h,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Align(
                    alignment: AlignmentDirectional.topEnd,
                    child: InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: const Icon(
                          Icons.close,
                          color: Colors.grey,
                        )),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Container(
                        height: 35,
                        width: 52,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            image: DecorationImage(
                                image: CachedNetworkImageProvider(
                                    context.locale.languageCode == 'ar'
                                        ? EndPoints.baseImageUrl +
                                            context
                                                .read<HomeCubit>()
                                                .dealsDetails
                                                .first
                                                .package!
                                                .imageAR!
                                        : EndPoints.baseImageUrl +
                                            context
                                                .read<HomeCubit>()
                                                .dealsDetails
                                                .first
                                                .package!
                                                .imageEN!))),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: Text(
                          context.locale.languageCode == 'ar'
                              ? context
                                  .read<HomeCubit>()
                                  .dealsDetails
                                  .first
                                  .package!
                                  .nameAr!
                              : context
                                  .read<HomeCubit>()
                                  .dealsDetails
                                  .first
                                  .package!
                                  .nameEn!,
                          style:
                              StylesManger.rich().copyWith(color: Colors.black),
                        ),
                      )
                    ],
                  ),
                  Column(
                    children: [
                      ...List.generate(
                          context
                              .read<HomeCubit>()
                              .dealsDetails
                              .first
                              .package!
                              .packagesTests!
                              .length,
                          (index) => Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 5),
                                child: Row(
                                  children: [
                                    Text(
                                      '-',
                                      style: StylesManger.medium()
                                          .copyWith(color: Colors.black),
                                    ),
                                    const SizedBox(
                                      width: 5,
                                    ),
                                    Expanded(
                                      child: Text(
                                        context.locale.languageCode == 'ar'
                                            ? context
                                                .read<HomeCubit>()
                                                .dealsDetails
                                                .first
                                                .package!
                                                .packagesTests![index]
                                                .testNameAr
                                                .orEmpty()
                                            : context
                                                .read<HomeCubit>()
                                                .dealsDetails
                                                .first
                                                .package!
                                                .packagesTests![index]
                                                .testNameEn
                                                .orEmpty(),
                                        style: StylesManger.medium()
                                            .copyWith(color: Colors.black),
                                      ),
                                    )
                                  ],
                                ),
                              )),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                ],
              ),
            ),
          ),
          SizedBox(
            height: 16.h,
          ),
          if (!fromCart)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  height: 50,
                  width: 140,
                  child: AppButton(
                      textSize: 12,
                      color: ColorManger.primary,
                      name: 'OrderNow'.tr(),
                      onPressed: () {
                        showDialog(
                            context: context,
                            builder: (context) => QuickOrderDialog(
                                  orderData: RequestOrderData(
                                      deals.partnerId!,
                                      deals.package!.nameEn!,
                                      deals.price!,
                                      deals.packageId!,
                                      false),
                                ));
                      }),
                ),
                SizedBox(
                  width: 15,
                ),
                SizedBox(
                  height: 50,
                  width: 140,
                  child: AppButton(
                      textColor: ColorManger.primary,
                      textSize: 11,
                      color: Colors.white,
                      name: 'AddToWishlist'.tr(),
                      onPressed: () {
                        context
                            .read<WishlistCubit>()
                            .addToWishlit(
                                wishlist: RequestWishlist(
                              context.read<AccountCubit>().userModel!.entityId!,
                              deals.partnerId!,
                              null,
                            ))
                            .whenComplete(() => Navigator.pop(context));
                      }),
                )
              ],
            )
        ],
      ),
    );
  }
}
