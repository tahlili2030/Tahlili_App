import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';

import '../styles_manger.dart';

Future<bool?> toast(
        {required String text,
        required Color color,
        gravity = ToastGravity.BOTTOM}) =>
    Fluttertoast.showToast(
        msg: text,
        toastLength: Toast.LENGTH_LONG,
        gravity: gravity,
        timeInSecForIosWeb: 1,
        backgroundColor: color,
        textColor: Colors.white,
        fontSize: 16.0);
SizedBox v(double height) {
  return SizedBox(
    height: height,
  );
}

Widget authForm(
    {required String hintText,
    required String title,
    int? maxLines,
    TextInputType? keyboardType,
    required TextEditingController controller,
    required String? Function(String?)? validator,
    bool? isRequired}) {
  return Padding(
    padding: EdgeInsets.symmetric(vertical: 12.h),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              title,
              style: StylesManger.medium().copyWith(
                  color: Colors.black.withOpacity(.7),
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w700),
            ),
          ],
        ),
        SizedBox(
          height: 8.h,
        ),
        TextFormField(
          keyboardType: keyboardType,
          maxLines: maxLines,
          validator: validator,
          controller: controller,
          cursorColor: ColorManger.newPrimary,
          decoration: InputDecoration(
              contentPadding:
                  EdgeInsets.symmetric(vertical: 11.h, horizontal: 16.w),
              focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: ColorManger.lightBlack),
                  borderRadius: BorderRadius.circular(5)),
              enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: ColorManger.lightBlack),
                  borderRadius: BorderRadius.circular(5)),
              hintText: hintText,
              border: OutlineInputBorder(
                  borderSide: BorderSide(color: ColorManger.lightBlack),
                  borderRadius: BorderRadius.circular(5))),
        ),
      ],
    ),
  );
}
