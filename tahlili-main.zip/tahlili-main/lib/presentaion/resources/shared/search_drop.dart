
import 'dart:developer';

import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';

import '../../auth/cubit/auth_cubit.dart';
import '../styles_manger.dart';

class SearchDrop extends StatelessWidget {
  final String title;
 final List<String> items;
final String ?value;
final void Function(String?) onChanged;

final TextEditingController searchController;

  const SearchDrop({super.key, required this.items, this.value,required this.onChanged,required this.searchController, required this.title,});

  @override
  Widget build(BuildContext context) {
  //  log(cubit.nationalities.toString());
    return Padding(
     padding: const EdgeInsets.symmetric(vertical: 15),
      child: Column(
                  children: [
                    Row(
                      children: [
                        Text(
                          title,
                          style: StylesManger.medium().copyWith(
                              color: Colors.black,
                              fontSize: 16,
                              fontWeight: FontWeight.w500),
                        ),
                        Text(
                          "*",
                          style:
                              StylesManger.rich().copyWith(color: Colors.red),
                        )
                      ],
                    ),

                    DropdownButtonHideUnderline(
                      child: DropdownButtonFormField2<String>(
                        hint: Text(
                          "Nationality".tr(),
                          style: StylesManger.medium()
                              .copyWith(color: ColorManger.grey),
                        ),

                        iconStyleData:const IconStyleData(
                          icon:  Icon(
                            Icons.keyboard_arrow_down,
                            size: 30,
                            color: Colors.grey,
                          ),
                        ),

                        isExpanded: true,
                        buttonStyleData: ButtonStyleData(
                            height: 65,
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                border: Border.all(color: Colors.black))),
                        dropdownStyleData: DropdownStyleData(
                          width: 300,
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          elevation: 8,
                          maxHeight: 200,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: ColorManger.grey,
                            ),
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.grey.shade100,
                          ),
                        ),
                        items:items

                            .map((item) => DropdownMenuItem(
                                  value: item.toString(),
                                  child: Text(
                                    item,
                                    style: const TextStyle(
                                      fontSize: 14,
                                    ),
                                  ),
                                ))
                            .toList(),
                        value: value,
                        onChanged: onChanged,
                        decoration:
                            const InputDecoration(border: InputBorder.none),

                        autovalidateMode: AutovalidateMode.onUserInteraction,

                        dropdownSearchData: DropdownSearchData(
                          searchController: searchController,
                          searchInnerWidgetHeight: 50,
                          searchInnerWidget: Container(
                            height: 50,
                            padding: const EdgeInsets.only(
                              top: 8,
                              bottom: 4,
                              right: 8,
                              left: 8,
                            ),
                            child: TextFormField(
                              textCapitalization: TextCapitalization.words,
                              expands: true,
                              maxLines: null,
                              controller: searchController,
                              decoration: InputDecoration(
                                isDense: true,
                                contentPadding:
                                    const EdgeInsets.symmetric(horizontal: 10),
                                hintText: "Search".tr(),
                                hintStyle: const TextStyle(fontSize: 12),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                            ),
                          ),
                          searchMatchFn: (item, searchValue) {
                            return item.value!
                                .toLowerCase()
                                .toString()
                                .contains(searchValue.toLowerCase());
                          },
                        ),
                        //This to clear the search value when you close the menu
                        onMenuStateChange: (isOpen) {
                          if (!isOpen) {
                            searchController!.clear();
                          }
                        },
                      ),
                    ),
                  ],
                ),
    );
  }
}
