import 'dart:developer';

import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';

import '../../auth/cubit/auth_cubit.dart';
import '../styles_manger.dart';

class NationalityDrop extends StatelessWidget {
  final AuthCubit cubit;
  const NationalityDrop({super.key, required this.cubit});

  @override
  Widget build(BuildContext context) {
    //  log(cubit.arNationalities.toString());
    log(cubit.enNationalities.toString());
    return Column(
      children: [
        Row(
          children: [
            Text(
              "Nationality".tr(),
              style: StylesManger.medium()
                  .copyWith(fontSize: 12.sp, fontWeight: FontWeight.w700),
            ),
          ],
        ),
        DropdownButtonHideUnderline(
          child: DropdownButtonFormField2<String>(
            hint: Text(
              "Nationality".tr(),
              style: StylesManger.medium().copyWith(color: ColorManger.grey),
            ),

            iconStyleData: const IconStyleData(
              icon: Icon(
                Icons.keyboard_arrow_down,
                size: 30,
                color: Colors.grey,
              ),
            ),

            isExpanded: true,
            buttonStyleData: ButtonStyleData(
                height: 40.h,
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(color: ColorManger.lightBlack))),
            dropdownStyleData: DropdownStyleData(
              width: 300,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              elevation: 8,
              maxHeight: 200,
              decoration: BoxDecoration(
                border: Border.all(
                  color: ColorManger.grey,
                ),
                borderRadius: BorderRadius.circular(10),
                color: Colors.grey.shade100,
              ),
            ),
            items: (context.locale.languageCode == 'ar'
                    ? cubit.arNationalities
                    : cubit.enNationalities)
                .map((item) => DropdownMenuItem(
                      value: item.toString(),
                      child: Text(
                        item,
                        style: const TextStyle(
                          fontSize: 14,
                        ),
                      ),
                    ))
                .toList(),
            value: cubit.nationality,
            onChanged: (value) {
              cubit.setNationality(value);
            },
            decoration: const InputDecoration(border: InputBorder.none),

            autovalidateMode: AutovalidateMode.onUserInteraction,

            dropdownSearchData: DropdownSearchData(
              searchController: cubit.searchController,
              searchInnerWidgetHeight: 50,
              searchInnerWidget: Container(
                height: 50,
                padding: const EdgeInsets.only(
                  top: 8,
                  bottom: 4,
                  right: 8,
                  left: 8,
                ),
                child: TextFormField(
                  textCapitalization: TextCapitalization.words,
                  expands: true,
                  maxLines: null,
                  controller: cubit.searchController,
                  decoration: InputDecoration(
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 10),
                    hintText: "Search".tr(),
                    hintStyle: const TextStyle(fontSize: 12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
              ),
              searchMatchFn: (item, searchValue) {
                return item.value!
                    .toLowerCase()
                    .toString()
                    .contains(searchValue.toLowerCase());
              },
            ),
            //This to clear the search value when you close the menu
            onMenuStateChange: (isOpen) {
              if (!isOpen) {
                cubit.searchController.clear();
              }
            },
          ),
        ),
      ],
    );
  }
}
