import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pinput/pinput.dart';

import '../color_manger.dart';
import '../constant_manger.dart';

class AppPinField extends StatelessWidget {
  final Function validator;
  final dynamic formKey;
  final FocusNode focusNode;
  const AppPinField({
    super.key,
    required this.validator,
    this.formKey,
    required this.focusNode,
  });

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Pinput(
          focusNode: focusNode,
          autofocus: true,
          length: 4,
          defaultPinTheme: PinTheme(
              width: 70,
              height: 70,
              textStyle: TextStyle(
                  fontSize: 20,
                  color: ColorManger.blueBlack,
                  fontWeight: FontWeight.w600),
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xffCDF7FB)),
                borderRadius: BorderRadius.circular(16.r),
              )),
          followingPinTheme: PinTheme(
              width: 70,
              height: 70,
              textStyle: TextStyle(
                  fontSize: 20,
                  color: ColorManger.blueBlack,
                  fontWeight: FontWeight.w600),
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xffE2E6E9)),
                borderRadius: BorderRadius.circular(16.r),
              )),
          errorPinTheme: PinTheme(
              width: 70,
              height: 50,
              textStyle: TextStyle(
                  fontSize: 20,
                  color: ColorManger.blueBlack,
                  fontWeight: FontWeight.w600),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.red),
                borderRadius: BorderRadius.circular(10),
              )),
          pinputAutovalidateMode: PinputAutovalidateMode.onSubmit,
          validator: (value) => validator(value)),
    );
  }
}
