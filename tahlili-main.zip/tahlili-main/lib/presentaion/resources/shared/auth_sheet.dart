import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';

import '../../auth/cubit/auth_cubit.dart';

class AuthSheet extends StatelessWidget {
  const AuthSheet({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AuthCubit>();

    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          width: double.infinity,
          decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20), topRight: Radius.circular(20))),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                height: 24.h,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10.0),
                child: Container(
                  width: 60,
                  height: 5,
                  decoration: BoxDecoration(
                    color: ColorManger.blueBlack,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              SizedBox(
                height: 24.h,
              ),
              BlocBuilder<AuthCubit, AuthState>(
                builder: (context, state) {
                  return SizedBox(
                    height: cubit.pageSize,
                    // 700,
                    child: PageView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        controller: cubit.pageController,
                        itemCount: cubit.authPages.length,
                        itemBuilder: (context, index) =>
                            cubit.authPages[index]),
                  );
                },
              ),
            ],
          )),
    );
  }
}
