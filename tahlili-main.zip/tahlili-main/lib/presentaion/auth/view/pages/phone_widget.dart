import 'package:country_code_picker/country_code_picker.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/presentaion/auth/cubit/auth_cubit.dart';
import 'package:tahlili/presentaion/bnb/view/bnb_view.dart';

import '../../../resources/color_manger.dart';
import '../../../resources/shared/app_button.dart';
import '../../../resources/strings_manager.dart';
import '../../../resources/styles_manger.dart';
import '../../../resources/validation_manager.dart';

class PhoneWidget extends StatelessWidget {
  const PhoneWidget(
      {super.key, required this.controller, required this.onPressed});
  final TextEditingController controller;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AuthCubit>();
    return SingleChildScrollView(
      child: Form(
        key: cubit.phoneForm,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Enter Mobile Number".tr(),
              style: StylesManger.rich(),
            ),
            SizedBox(
              height: 24.h,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text("Phone".tr(),
                        style: StylesManger.rich()
                            .copyWith(fontWeight: FontWeight.w500)),
                  ],
                ),
                SizedBox(
                  height: 16.h,
                ),
                TextFormField(
                  validator: (value) {
                    if (value != null && value.isNotEmpty) {
                      if (!ValidationManager.phoneNumberValidation(
                          phone: value)) {
                        return "Please enter a valid phone number".tr();
                      }
                    } else {
                      return StringsManager.fieldRequierd;
                    }
                    return null;
                  },
                  keyboardType: TextInputType.number,
                  controller: controller,
                  decoration: InputDecoration(
                      contentPadding: EdgeInsets.symmetric(vertical: 16.h),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                              BorderSide(color: ColorManger.lightBlack)),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                              BorderSide(color: ColorManger.lightBlack)),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                              BorderSide(color: ColorManger.lightBlack)),
                      prefixIcon: SizedBox(
                        width: 100,
                        child: CountryCodePicker(
                          padding: EdgeInsets.zero,
                          onChanged: (countryCode) {
                            cubit.setCountryCode(countryCode);
                          },
                          // Initial selection and favorite can be one of code ('IT') OR dial_code('+39')
                          initialSelection: cubit.country,

                          // flag can be styled with BoxDecoration's `borderRadius` and `shape` fields
                          flagDecoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      )),
                ),
              ],
            ),
            SizedBox(
              height: 24.h,
            ),
            BlocBuilder<AuthCubit, AuthState>(
              builder: (context, state) {
                return state is LoadLoginState
                    ? Center(
                        child: CircularProgressIndicator(),
                      )
                    : AppButton(
                        radius: 24.r,
                        color: Colors.white,
                        textColor: ColorManger.newPrimary,
                        name: "التالي".tr(),
                        onPressed: onPressed);
              },
            ),
            SizedBox(
              height: 26.h,
            ),
            InkWell(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => BNBView()));
              },
              child: Row(
                children: [
                  Text(
                    "اكمل الدخول".tr(),
                    style: StylesManger.rich().copyWith(
                        color: Color(0xffA5A5A5), fontWeight: FontWeight.w400),
                  ),
                  SizedBox(
                    width: 4.w,
                  ),
                  Text(
                    "كذائر",
                    style: StylesManger.rich().copyWith(
                        color: ColorManger.newPrimary,
                        fontWeight: FontWeight.w400),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 24.h,
            ),
            Text(
              "بالنقر فوق متابعه فإنك توافق على الشروط والأحكام وسياسة الخصوصية",
              style: TextStyle(
                fontSize: 16.sp,
                fontWeight: FontWeight.w400,
                color: Color(0xff3D85C7),
              ),
              textAlign: TextAlign.start,
            ),
            SizedBox(
              height: 24.h,
            ),
          ],
        ),
      ),
    );
  }
}
