import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/presentaion/auth/cubit/auth_cubit.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';

import '../../../resources/color_manger.dart';
import '../../../resources/shared/app_pin_field.dart';
import '../../../resources/strings_manager.dart';
import '../../../resources/styles_manger.dart';

class OtpWidget extends StatefulWidget {
  const OtpWidget({
    super.key,
    required this.confirmOtp,
  });
  final VoidCallback confirmOtp;

  @override
  State<OtpWidget> createState() => _OtpWidgetState();
}

class _OtpWidgetState extends State<OtpWidget> {
  int _start = 60; // 1 minutes in seconds
  late Timer _timer;
  final FocusNode focusNode = FocusNode();

  @override
  void initState() {
    super.initState();

    startTimer();
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  void startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (Timer timer) {
      setState(() {
        if (_start == 0) {
          _timer.cancel();
        } else {
          _start--;
        }
      });
    });
  }

  void resetTimer() {
    setState(() {
      _start = 300; // Reset to 5 minutes in seconds
      // Cancel the existing timer before starting a new one
      if (_timer.isActive) {
        _timer.cancel();
      }
      startTimer();
    });
  }

  String formatTime(int seconds) {
    final int minutes = seconds ~/ 60;
    final int remainingSeconds = seconds % 60;
    // Format the time to always show two digits for both minutes and seconds
    final String formattedTime =
        "${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}";
    return formattedTime;
  }

  @override
  Widget build(BuildContext context) {
    FocusScope.of(context).requestFocus(focusNode);

    final cubit = context.read<AuthCubit>();
    return SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            height: 16.h,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Number Verification".tr(),
                style:
                    StylesManger.rich().copyWith(color: ColorManger.blueBlack),
              )
            ],
          ),
          SizedBox(
            height: 24.h,
          ),
          AppPinField(
            focusNode: focusNode,
            formKey: cubit.otpForm,
            validator: (value) {
              if (value != null && value.isNotEmpty) {
                if (value != cubit.otp) {
                  return StringsManager.codeNotMatch;
                }
              } else {
                return StringsManager.fieldRequierd;
              }
              return null;
            },
          ),
          const SizedBox(
            height: 24,
          ),
          Text(
            "Please enter verification code that sent to your mobile number",
            style: StylesManger.medium().copyWith(color: ColorManger.grey),
          ),
          Row(
            children: [
              Text(
                "${cubit.countryCode}${cubit.phoneController.text}.",
                style: StylesManger.medium().copyWith(color: Colors.black),
              ),
              const SizedBox(
                width: 5,
              ),
              InkWell(
                onTap: () {
                  cubit.pageController.previousPage(
                      duration: const Duration(milliseconds: 500),
                      curve: Curves.easeInOut);
                },
                child: Text(
                  "Edit".tr(),
                  style: StylesManger.medium()
                      .copyWith(color: ColorManger.buttonColor),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 24.h,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              InkWell(
                onTap: () {
                  if (_start == 0) {
                    cubit.login(context, true);
                    resetTimer();
                  }
                },
                child: Text(
                  "Resend".tr(),
                  style: StylesManger.rich().copyWith(
                    color: ColorManger.buttonColor,
                  ),
                ),
              ),
              const SizedBox(
                width: 5,
              ),
              Text(
                "Conde on ${formatTime(_start)}",
                style: StylesManger.rich().copyWith(color: Colors.black),
              )
            ],
          ),
          SizedBox(
            height: 24.h,
          ),
          BlocBuilder<AuthCubit, AuthState>(
            builder: (context, state) {
              return state is LoadVerifyOtpState
                  ? Center(
                      child: CircularProgressIndicator(),
                    )
                  : AppButton(
                      radius: 24.r,
                      color: ColorManger.newPrimary,
                      name: "Confirm".tr(),
                      onPressed: widget.confirmOtp);
            },
          ),
          SizedBox(
            height: 16.h,
          )
        ],
      ),
    );
  }
}
