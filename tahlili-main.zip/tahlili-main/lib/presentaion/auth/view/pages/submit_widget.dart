import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../resources/color_manger.dart';
import '../../../resources/shared/app_button.dart';
import '../../../resources/shared/shared_widgets.dart';
import '../../../resources/strings_manager.dart';
import '../../../resources/styles_manger.dart';
import '../../cubit/auth_cubit.dart';

class SubmitWidget extends StatelessWidget {
  const SubmitWidget({super.key, required this.submit, required this.previous});

  final VoidCallback submit;
  final VoidCallback previous;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AuthCubit>();

    return BlocBuilder<AuthCubit, AuthState>(
      builder: (context, state) {
        return Form(
          key: cubit.submitForm,
          child: Column(
            children: [
              const SizedBox(
                height: 16,
              ),
              Text(
                "Identity Information".tr(),
                style: StylesManger.rich().copyWith(color: Colors.black),
              ),
              const SizedBox(
                height: 24,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                      width: MediaQuery.of(context).size.width * .4,
                      child: AppButton(
                          textColor: ColorManger.primary,
                          color: Colors.white,
                          name: "Previous".tr(),
                          onPressed: previous)),
                  SizedBox(
                      width: MediaQuery.of(context).size.width * .4,
                      child: AppButton(
                          color: ColorManger.primary,
                          name: "Submit".tr(),
                          onPressed: submit))
                ],
              )
            ],
          ),
        );
      },
    );
  }
}
