import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:tahlili/presentaion/auth/cubit/auth_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import '../../../resources/shared/app_drop_down.dart';
import '../../../resources/shared/nationality_drop.dart';
import '../../../resources/shared/shared_widgets.dart';
import '../../../resources/strings_manager.dart';
import '../../../resources/styles_manger.dart';
import '../../../resources/validation_manager.dart';

class InfoWidget extends StatelessWidget {
  const InfoWidget({
    super.key,
    required this.onPressed,
  });

  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AuthCubit>();
    cubit.createCapitcha();
    return SingleChildScrollView(
      child: Form(
        key: cubit.infoForm,
        child: BlocBuilder<AuthCubit, AuthState>(
          builder: (context, state) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 16.h,
                ),
                Align(
                  alignment: AlignmentDirectional.center,
                  child: Text(
                    "Personal Information".tr(),
                    style: StylesManger.rich()
                        .copyWith(color: ColorManger.blueBlack),
                  ),
                ),
                SizedBox(
                  height: 24.h,
                ),
                authForm(
                    isRequired: true,
                    title: "FirstName".tr(),
                    hintText: "FirstName".tr(),
                    controller: cubit.fNameController,
                    validator: (value) {
                      if (value != null && value.isNotEmpty) {
                        if (!ValidationManager.lengthValidation(
                            text: value, length: 2)) {
                          return StringsManager.nameValid;
                        }
                      } else {
                        return StringsManager.fieldRequierd;
                      }
                      return null;
                    }),
                authForm(
                    isRequired: true,
                    title: "LastName".tr(),
                    hintText: "LastName".tr(),
                    controller: cubit.lNameController,
                    validator: (value) {
                      if (value != null && value.isNotEmpty) {
                        if (!ValidationManager.lengthValidation(
                            text: value, length: 2)) {
                          return StringsManager.nameValid;
                        }
                      } else {
                        return StringsManager.fieldRequierd;
                      }
                      return null;
                    }),
                authForm(
                    isRequired: true,
                    title: "Email".tr(),
                    hintText: "Email".tr(),
                    controller: cubit.emailController,
                    validator: (value) {
                      if (value != null && value.isNotEmpty) {
                        if (!ValidationManager.emailValidation(email: value)) {
                          return StringsManager.numberValid;
                        }
                      } else {
                        return StringsManager.fieldRequierd;
                      }
                      return null;
                    }),
                SizedBox(
                  height: 12.h,
                ),
                Row(
                  children: [
                    Text(
                      "Gender".tr(),
                      style: StylesManger.medium().copyWith(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w500),
                    ),
                    Text(
                      "*",
                      style: StylesManger.rich().copyWith(color: Colors.red),
                    )
                  ],
                ),
                SizedBox(
                  height: 8.h,
                ),
                AppDropdown(
                    prfoileImage: [],
                    buttonDecoration: BoxDecoration(
                        border: Border.all(color: Color(0xffE2E6E9)),
                        borderRadius: BorderRadius.circular(8.r)),
                    value: cubit.gender,
                    hintText: "Gender".tr(),
                    list: cubit.gendersName,
                    onChange: (value) {
                      cubit.setGender(value);
                    }),
                SizedBox(
                  height: 24.h,
                ),
                NationalityDrop(
                  cubit: cubit,
                ),
                SizedBox(
                  height: 24.h,
                ),
                BlocBuilder<AuthCubit, AuthState>(
                  builder: (context, state) {
                    return Row(
                      children: [
                        Text(
                          "DateOfBirth".tr(),
                          style: StylesManger.medium().copyWith(
                              color: Colors.black,
                              fontSize: 16,
                              fontWeight: FontWeight.w500),
                        ),
                        Text(
                          "*",
                          style:
                              StylesManger.rich().copyWith(color: Colors.red),
                        )
                      ],
                    );
                  },
                ),
                SizedBox(
                  height: 8.h,
                ),
                GestureDetector(
                  onTap: () async {
                    final result = await showDatePicker(
                        initialEntryMode: DatePickerEntryMode.calendarOnly,
                        currentDate: cubit.currentDate,
                        context: context,
                        firstDate: DateTime(1945, 1, 1),
                        lastDate: DateTime.now());
                    if (result != null) {
                      cubit.setDate(DateFormat('dd-MM-yyyy').format(result));
                      cubit.setCurrentDate(result);
                    }
                  },
                  child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 5),
                      child: TextFormField(
                        validator: (value) {
                          if (value != null && value.isNotEmpty) {
                          } else {
                            return StringsManager.fieldRequierd;
                          }
                          return null;
                        },
                        controller: cubit.dateController,
                        enabled: false,
                        decoration: const InputDecoration(
                            suffixIcon: Icon(
                          Icons.date_range,
                          color: Colors.grey,
                        )),
                      )),
                ),
                authForm(
                    title: "IdNumber".tr(),
                    hintText: "IdNumber".tr(),
                    controller: cubit.nationalIDController,
                    validator: (value) {
                      // if (value != null && value.isNotEmpty) {
                      //   if (!ValidationManager.lengthValidation(
                      //       text: value, length: 2)) {
                      //     return StringsManager.nameValid;
                      //   }
                      // } else {
                      //   return StringsManager.fieldRequierd;
                      // }
                      return null;
                    }),
                authForm(
                    title: "Captcha".tr(),
                    hintText: "1234",
                    isRequired: true,
                    controller: cubit.captchaController,
                    validator: (value) {
                      if (value != null && value.isNotEmpty) {
                        if (value != cubit.captcha.toString()) {
                          return "ً${"Incorrect Captcha. Please try again.".tr()}";
                        }
                      } else {
                        return StringsManager.fieldRequierd;
                      }
                      return null;
                    }),
                Row(
                  children: [
                    if (cubit.captcha != null)
                      Text(
                        "${cubit.captcha}",
                        style: StylesManger.medium()
                            .copyWith(color: Colors.black, fontSize: 15),
                      ),
                    IconButton(
                        onPressed: () {
                          cubit.createCapitcha();
                        },
                        icon: const Icon(
                          Icons.loop,
                          color: Colors.black,
                        ))
                  ],
                ),
                const SizedBox(
                  height: 16,
                ),
                SizedBox(
                  height: 24.h,
                ),
                BlocBuilder<AuthCubit, AuthState>(
                  builder: (context, state) {
                    return state is LoadRegisterState
                        ? Center(
                            child: CircularProgressIndicator(),
                          )
                        : AppButton(
                            radius: 24.r,
                            textColor: ColorManger.newPrimary,
                            color: Colors.white,
                            name: "تسجيل الدخول".tr(),
                            onPressed: onPressed);
                  },
                ),
                const SizedBox(
                  height: 36,
                )
              ],
            );
          },
        ),
      ),
    );
  }
}
