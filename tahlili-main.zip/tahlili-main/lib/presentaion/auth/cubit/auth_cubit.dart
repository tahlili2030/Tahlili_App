import 'dart:math';
import 'package:bloc/bloc.dart';
import 'package:country_code_picker/country_code_picker.dart';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:meta/meta.dart';
import 'package:tahlili/app/di.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/app/pref_manager.dart';
import 'package:tahlili/data/network/error_handler.dart';
import 'package:tahlili/data/response/auth/response_auth.dart';
import 'package:tahlili/data/response/home/response_home.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/auth/view/pages/info_widget.dart';
import 'package:tahlili/presentaion/auth/view/pages/otp_widget.dart';
import 'package:tahlili/presentaion/auth/view/pages/phone_widget.dart';
import 'package:tahlili/presentaion/auth/view/pages/submit_widget.dart';
import 'package:tahlili/presentaion/bnb/cubit/bnb_cubit.dart';
import 'package:tahlili/presentaion/bnb/view/bnb_view.dart';
import '../../../data/network/dio_factory.dart';
import '../../../data/requests/auth/request_auth.dart';
import '../../../data/response/account/reponse_account.dart';
import '../../../domain/repository/auth/auth.dart';
import '../../map/cubit/map_cubit.dart';
import '../../resources/constant_manger.dart';
import '../../resources/shared/shared_widgets.dart';
import '../../wishlist/cubit/wishlist_cubit.dart';

part 'auht_state.dart';

class AuthCubit extends Cubit<AuthState> {
  AuthCubit(this._authRepository, this._preferancesManager)
      : super(AuthInitial());

  final BaseAuthRepository _authRepository;
  final PreferancesManager _preferancesManager;

  final PageController pageController = PageController();

  start() {
    getLanguages();
    getNationalties();
    getGenders();

    getRelationships();
    getComplaintsTypes();
  }

  List<Widget> authPages = [];
  double pageSize = 400;
  changePageSized(double size) {
    pageSize = size;
    emit(ChangePageSizedState());
  }

  int? captcha;
  createCapitcha() {
    var random = Random();

    // Generate a random 4-digit number
    int min = 1000; // minimum 4-digit number
    int max = 9999; // maximum 4-digit number
    captcha = min + random.nextInt(max - min);
    emit(SetCpaichaState());
  }

  setDate(String date) {
    dateController.text = date;

    emit(SetDateState());
  }

  initAuthPages(context, AuthCubit cubit) {
    // changePageSized(400);
    authPages = [
      PhoneWidget(
          controller: phoneController,
          onPressed: () async {
            if (phoneForm.currentState!.validate()) {
              FocusScope.of(context).unfocus();
              login(context, false);
            }
          }),
      OtpWidget(
        confirmOtp: () {
          if (otpForm.currentState!.validate()) {
            print("object");
            verifyOtp(context);
          }
        },
      ),
      InfoWidget(
        onPressed: () {
          if (infoForm.currentState!.validate()) {
            if (genderID != null) {
              if (nationalityID != null) {
                register(context: context);
                // changePageSized(500);
                // pageController.nextPage(
                //     duration: const Duration(milliseconds: 500),
                //     curve: Curves.easeInOut);
              } else {
                toast(text: "Choose Nationality", color: Colors.red);
              }
            } else {
              toast(text: "Choose Gender", color: Colors.red);
            }
          }
        },
      ),
      SubmitWidget(
        submit: () {
          if (submitForm.currentState!.validate()) {
            // if (captcha.toString() == captchaController.text) {

            // } else {
            //   toast(text: "ًWrong Captcha", color: Colors.red);
            // }
          }
        },
        previous: () {
          changePageSized(700);
          pageController.previousPage(
              duration: const Duration(milliseconds: 500),
              curve: Curves.easeInOut);
        },
      )
    ];
  }

  register({required BuildContext context}) async {
    final phoneNumber = (countryCode + phoneController.text.trim())
        .replaceAll(RegExp(r'\s+'), '');
    emit(LoadRegisterState());

    try {
      final result = await _authRepository.register(
          register: RequestRegister(
              phone: phoneNumber,
              email: emailController.text.trim(),
              idNumber: nationalIDController.text.trim(),
              nationalityID: nationalityID.toString(),
              fName: fNameController.text,
              lName: lNameController.text,
              genderID: genderID.toString(),
              languageID: languagesID!.toString(),
              birhthDate: dateController.text,
              userID: userID));
      result.fold((failure) async {
        debugPrint(failure);
        await handleSuccessMessages(
            failure, context.locale.languageCode, Colors.red);
        emit(FailureRegisterState());
      }, (objRegister) {
        otp = objRegister.message;

        verifyOtp(context);
        emit(SuccessRegisterState());
      });
    } catch (e) {}
  }

  String? otp;
  login(BuildContext context, bool fromOtp) async {
    emit(LoadLoginState());
    if (phoneController.text[0] == "0") {
      String nonZero = phoneController.text;
      print(true);
      phoneController = TextEditingController.fromValue(
          TextEditingValue(text: nonZero.substring(1)));
      print(phoneController.text);
    }
    final phoneNumber = (countryCode + phoneController.text.trim())
        .replaceAll(RegExp(r'\s+'), '');
    debugPrint(phoneNumber);
    try {
      final result =
          await _authRepository.login(login: RequestLogin(phoneNumber));
      result.fold((failure) async {
        changePageSized(450.h);
        debugPrint(failure);
        await handleSuccessMessages(
            failure, context.locale.languageCode, Colors.red);

        pageController.jumpToPage(2);
        emit(FailureLoginState(failure));
      }, (login) async {
        debugPrint(login.message);
        await handleSuccessMessages(
            login.message.orEmpty(), context.locale.languageCode, Colors.green);

        if (!fromOtp) {
          pageController.nextPage(
              duration: const Duration(milliseconds: 500),
              curve: Curves.easeInOut);
        }

        otp = login.message;
        toast(text: login.message!, color: Colors.green);

        emit(SuccessLoginState(login.message.orEmpty()));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureLoginState(e.toString()));
    }
  }

  String countryCode = "+966";
  String country = "SA";
  setCountryCode(CountryCode countryCode) {
    this.countryCode = countryCode.dialCode!;
    country = countryCode.code!;
    emit(SetCountryCodeState());
  }

  verifyOtp(BuildContext context) async {
    emit(LoadVerifyOtpState());
    try {
      final phoneNumber = (countryCode + phoneController.text.trim())
          .replaceAll(RegExp(r'\s+'), '');
      final result = await _authRepository.verifyOtp(
          requestOtp: RequestOtp(phone: phoneNumber, otp: otp!));
      result.fold((failure) async {
        debugPrint(failure);
        await handleSuccessMessages(
            failure, context.locale.languageCode, Colors.red);
        emit(FailureVerifyOtpState(failure));
      }, (otp) async {
        debugPrint(otp.token);
        debugPrint(otp.userId);
        await _preferancesManager.saveData(key: userToken, value: otp.token);
        await _preferancesManager.saveData(key: userID, value: otp.userId);
        final authenticatedDioInstance = await instance<DioFactory>().getDio();

        /// We set [BaseOptions] of Dio Singleton instance that used by [AppServiceClint]
        /// with [authenticatedDioInstance.options].
        instance<Dio>().options = authenticatedDioInstance.options;

        context.read<AuthCubit>().start();
        context.read<MapCubit>().start();

        context.read<AccountCubit>().start();
        context.read<WishlistCubit>().getWishlist();
        context.read<BnbCubit>().setIndex(0, context);
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (context) => const BNBView(),
            ),
            (route) => false);
        emit(SuccessVerifyOtpState(otp));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureVerifyOtpState(e.toString()));
    }
  }

  int? gender;
  int? genderID;
  List<String> gendersName = [];
  List<LookUpToggle> genders = [];
  getGenders() async {
    gendersName.clear();
    genders.clear();
    emit(LoadGetLookUpState());
    try {
      final result = await _authRepository.getLookUp(tableName: 'genders');
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetLookUpState());
      }, (data) {
        debugPrint(data.length.toString());
        List.generate(
            data.length, (index) => gendersName.add(data[index].name!));
        List.generate(
            data.length,
            (index) => genders
                .add(LookUpToggle(data[index].id, data[index].name, false)));
        emit(SuccessGetLookUpState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetLookUpState());
    }
  }

  setGender(value) {
    gender = value;
    for (var i = 0; i < gendersName.length; i++) {
      if (gendersName[value] == genders[i].name) {
        genderID = genders[i].id!;
        debugPrint(genderID.toString());
      }
    }
    emit(SetGenderState());
  }

  final TextEditingController searchController = TextEditingController();
  List<String> enNationalities = [];
  List<String> arNationalities = [];
  List<ResponseLookup> nationalitiesLookUp = [];
  String? nationality;
  int? nationalityID;
  getNationalties() async {
    enNationalities.clear();
    nationalitiesLookUp.clear();
    emit(LoadGetLookUpState());
    try {
      final result =
          await _authRepository.getLookUp(tableName: 'nationalities');
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetLookUpState());
      }, (data) {
        debugPrint(data.length.toString());
        for (var i = 0; i < data.length; i++) {
          List<String> day = ConstantManger.splitTelda(data[i].name!);
          enNationalities.add(day[0]);
          arNationalities.add(day[1]);
        }
        // List.generate(
        //     data.length, (index) => nationalities.add(data[index].name!));
        List.generate(
            data.length, (index) => nationalitiesLookUp.add(data[index]));
        emit(SuccessGetLookUpState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetLookUpState());
    }
  }

  setNationality(value) {
    nationality = value;
    for (var i = 0; i < enNationalities.length; i++) {
      if (nationalitiesLookUp[i].name!.contains(value)) {
        nationalityID = nationalitiesLookUp[i].id!;
        debugPrint(nationalityID.toString());
      }
    }
    emit(SetNationalityState());
  }

  List<String> relationships = [];
  List<ResponseLookup> relationshipsLookUp = [];
  int? relationship;
  int? relationshipID;
  getRelationships() async {
    relationships.clear();
    relationshipsLookUp.clear();
    emit(LoadGetLookUpState());
    try {
      final result =
          await _authRepository.getLookUp(tableName: 'Relationships');
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetLookUpState());
      }, (data) {
        debugPrint(data.length.toString());
        List.generate(
            data.length, (index) => relationships.add(data[index].name!));
        List.generate(
            data.length, (index) => relationshipsLookUp.add(data[index]));
        emit(SuccessGetLookUpState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetLookUpState());
    }
  }

  setRelationship(value) {
    relationship = value;
    for (var i = 0; i < relationships.length; i++) {
      if (relationships[value] == relationshipsLookUp[i].name) {
        relationshipID = relationshipsLookUp[i].id!;
        debugPrint(relationshipID.toString());
      }
    }
    emit(SetRelationShipState());
  }

  bool? validGender;
  validGenderality() {
    if (gender != null) {
      validGender = true;
    } else {
      validGender = false;
    }
    emit(RegisterNonFormValidState());
  }

  bool? validRelation;
  validRelationShip() {
    if (relationship != null) {
      validRelation = true;
    } else {
      validRelation = false;
    }
    emit(RegisterNonFormValidState());
  }

  bool? validNational;
  validNationality() {
    if (nationalityID != null) {
      validNational = true;
    } else {
      validNational = false;
    }
    emit(RegisterNonFormValidState());
  }

  bool? validLangauge;
  validLanguages() {
    if (languagesID != null) {
      validLangauge = true;
    } else {
      validLangauge = false;
    }
    emit(RegisterNonFormValidState());
  }

  bool? validDate;
  validUserDate() {
    if (userDate != null) {
      validDate = true;
    } else {
      validDate = false;
    }
    emit(RegisterNonFormValidState());
  }

  checkValidaty() {
    validGenderality();
    validNationality();
    validLanguages();
    validRelationShip();
    // validUserDate();
  }

  bool validaty() {
    if (validDate! && validGender! && validLangauge! && validNational!) {
      return true;
    } else {
      return false;
    }
  }

  List<String> languages = ["English", 'عربي'];
  List<String> languagesFlags = [
    'assets/images/eng.png',
    'assets/images/ar.png',
  ];
  List<ResponseLookup> languagesLookUp = [];
  int? language;
  int? languagesID;

  getLanguages() async {
    emit(LoadGetLookUpState());
    try {
      final result = await _authRepository.getLookUp(tableName: 'languages');
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetLookUpState());
      }, (data) {
        debugPrint(data.length.toString());
        //    List.generate(data.length, (index) => languages.add(data[index].name!));
        List.generate(data.length, (index) => languagesLookUp.add(data[index]));
        setLanguages(0);
        emit(SuccessGetLookUpState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetLookUpState());
    }
  }

  setLanguages(value) {
    language = value;
    for (var i = 0; i < languages.length; i++) {
      if (languages[value] == languagesLookUp[i].name) {
        languagesID = languagesLookUp[i].id!;
        debugPrint(languagesID.toString());
      }
    }
    emit(SetNationalityState());
  }

  String? userDate;
  getUserDate(DateTime date) {
    userDate = DateFormat('dd-MM-yyyy').format(date);
    emit(FormatUserDateState());
  }

  TextEditingController phoneController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController fNameController = TextEditingController();
  TextEditingController mNameController = TextEditingController();
  TextEditingController lNameController = TextEditingController();
  TextEditingController nationalIDController = TextEditingController();
  TextEditingController captchaController = TextEditingController();
  TextEditingController dateController = TextEditingController();
  final infoForm = GlobalKey<FormState>();
  final submitForm = GlobalKey<FormState>();
  final otpForm = GlobalKey<FormState>();
  final profileForm = GlobalKey<FormState>();
  final phoneForm = GlobalKey<FormState>();

  List<ResponseLookup> complaintsTypes = [];
  List<String> complaints = [];

  getComplaintsTypes() async {
    emit(LoadGetLookUpState());
    try {
      final result =
          await _authRepository.getLookUp(tableName: 'ComplaintsTypes');
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetLookUpState());
      }, (data) {
        debugPrint(data.length.toString());
        List.generate(
            data.length, (index) => complaints.add(data[index].name!));
        List.generate(data.length, (index) => complaintsTypes.add(data[index]));

        emit(SuccessGetLookUpState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetLookUpState());
    }
  }

  int? complaintID;

  int? complaint;

  setComplaint(value) {
    complaint = value;
    for (var i = 0; i < complaintsTypes.length; i++) {
      if (complaints[value] == complaintsTypes[i].name) {
        complaintID = complaintsTypes[i].id!;
        debugPrint(complaintID.toString());
      }
    }
    emit(SetNationalityState());
  }

  int? patientEntityId;
  String? userProfile;
  initProfile(BuildContext context) {
    final cubit = context.read<AccountCubit>();

    fNameController = TextEditingController.fromValue(
        TextEditingValue(text: cubit.patient.first.firstName!));
    mNameController = TextEditingController.fromValue(
        TextEditingValue(text: cubit.patient.first.middleName!));

    lNameController = TextEditingController.fromValue(
        TextEditingValue(text: cubit.patient.first.lastName!));

    emailController = TextEditingController.fromValue(
        TextEditingValue(text: cubit.patient.first.email!));
    nationalIDController = TextEditingController.fromValue(
        TextEditingValue(text: cubit.patient.first.nationalityId!.toString()));
    phoneController = TextEditingController.fromValue(
        TextEditingValue(text: cubit.patient.first.phone!));
    genderID = cubit.patient.first.gender!.id;
    for (var i = 0; i < gendersName.length; i++) {
      if (gendersName[i] == cubit.patient.first.gender!.name) {
        gender = i;
      }
    }

    nationalityID = cubit.patient.first.nationality!.id;
    for (var i = 0; i < enNationalities.length; i++) {
      if (cubit.patient.first.nationality!.name!.contains(enNationalities[i])) {
        nationality = enNationalities[i];
      }
    }

    relationshipID = cubit.patient.first.relationshipId!;
    for (var i = 0; i < relationshipsLookUp.length; i++) {
      if (relationshipsLookUp[i].id == cubit.patient.first.relationshipId) {
        relationship = i;
      }
    }
    patientEntityId = cubit.patient.first.id;
    languagesID = cubit.patient.first.languageId;
    dateController = TextEditingController.fromValue(
        TextEditingValue(text: cubit.patient.first.birthDate!));
    emit(InitPrfileState());
  }

  initEditProfile(BuildContext context, ResponsePatientProfile profile) {
    fNameController = TextEditingController.fromValue(
        TextEditingValue(text: profile.firstName!));

    mNameController = TextEditingController.fromValue(
        TextEditingValue(text: profile.middleName!));

    lNameController = TextEditingController.fromValue(
        TextEditingValue(text: profile.lastName!));

    emailController =
        TextEditingController.fromValue(TextEditingValue(text: 'TODO'));

    nationalIDController = TextEditingController.fromValue(
        TextEditingValue(text: profile.nationalityId!.toString()));

    phoneController = TextEditingController.fromValue(
        TextEditingValue(text: profile.phone.orEmpty()));

    genderID = profile.genderId;

    for (var i = 0; i < gendersName.length; i++) {
      if (gendersName[i] == profile.gender) {
        gender = i;
      }
    }

    nationalityID = profile.nationalityId;
    for (var i = 0; i < enNationalities.length; i++) {
      if (nationalitiesLookUp[i].id == profile.nationalityId) {
        if (context.locale.languageCode == 'ar') {
          nationality = arNationalities[i];
        } else {
          nationality = enNationalities[i];
        }
      }
    }

    relationshipID = profile.relationshipId!;
    for (var i = 0; i < relationshipsLookUp.length; i++) {
      if (relationshipsLookUp[i].id == profile.relationshipId) {
        relationship = i;
      }
    }
    dateController = TextEditingController.fromValue(
        TextEditingValue(text: profile.birthDate!));

    languagesID = profile.languageId;
    emit(InitEditPrfileState());
  }

  DateTime? currentDate;
  setCurrentDate(DateTime dateTime) {
    currentDate = dateTime;
    emit(SetCurrentDateState());
  }

  resetProfileData() {
    fNameController.clear();
    lNameController.clear();
    mNameController.clear();
    phoneController.clear();
    nationalIDController.clear();
    emailController.clear();
    nationality = null;
    nationalityID = null;
    gender = null;
    genderID = null;
    relationship = null;
    relationshipID = null;
    emit(ResetProfileDateState());
  }
}

class LookUpToggle {
  final int? id;
  final String? name;
  final bool? value;

  LookUpToggle(this.id, this.name, this.value);
}
