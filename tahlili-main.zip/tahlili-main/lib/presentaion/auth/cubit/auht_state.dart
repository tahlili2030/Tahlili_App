part of 'auth_cubit.dart';

@immutable
sealed class AuthState {}

final class AuthInitial extends AuthState {}

class LoadLoginState extends AuthState{}

class SuccessLoginState extends AuthState{
  final String otp;

  SuccessLoginState(this.otp);
}

class FailureLoginState extends AuthState{
  final String error;

  FailureLoginState(this.error);
}


class LoadVerifyOtpState extends AuthState{}

class SuccessVerifyOtpState extends AuthState{
  final ResponseOtp responseOtp;

  SuccessVerifyOtpState(this.responseOtp);
}

class FailureVerifyOtpState extends AuthState{
  final String error;

  FailureVerifyOtpState(this.error);
}


class LoadGetLookUpState extends AuthState{}


class SuccessGetLookUpState extends AuthState{}


class FailureGetLookUpState extends AuthState{}

class SetGenderState extends AuthState{}

class SetNationalityState extends AuthState{}

class SetRelationShipState extends AuthState{}

class FormatUserDateState extends AuthState{}

class RegisterNonFormValidState extends AuthState{}

class InitPrfileState extends AuthState{}

class ChangePageSizedState extends AuthState{}

class SetDateState extends AuthState{}

class SetCpaichaState extends AuthState{}

class LoadRegisterState extends AuthState{}

class SuccessRegisterState extends AuthState{}

class FailureRegisterState extends AuthState{}

class SetCountryCodeState extends AuthState{}

class ResetProfileDateState extends AuthState{}

class InitEditPrfileState extends AuthState{}

class SetCurrentDateState extends AuthState{}