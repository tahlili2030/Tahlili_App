import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:tahlili/presentaion/bnb/cubit/bnb_cubit.dart';

import '../../resources/color_manger.dart';
import '../../resources/locle/locale_cubit.dart';

class BNBView extends StatelessWidget {
  const BNBView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<BnbCubit>();
    return BlocBuilder<BnbCubit, BnbState>(
      builder: (context, state) {
        return Scaffold(
          body: cubit.appScreens[cubit.screenIndex],
          bottomNavigationBar: BlocBuilder<LocaleCubit, LocaleState>(
            builder: (context, state) {
              return BottomNavigationBar(
                selectedLabelStyle: TextStyle(color: ColorManger.newPrimary),
                unselectedLabelStyle: TextStyle(color: Color(0xff242B60)),
                selectedItemColor: ColorManger.newPrimary,
                unselectedItemColor: Color(0xff242B60),
                showUnselectedLabels: true,
                currentIndex: cubit.screenIndex,
                onTap: (index) {
                  cubit.setIndex(index, context);
                },
                items: [
                  BottomNavigationBarItem(
                    icon: Icon(
                      Icons.home,
                      color: cubit.screenIndex == 0
                          ? ColorManger.newPrimary
                          : Color(0xff242B60),
                      size: 25,
                    ),
                    label: 'HomeMobile'.tr(),
                  ),
                  BottomNavigationBarItem(
                    icon: SvgPicture.asset(
                      'assets/images/bnb/fav.svg',
                      color: cubit.screenIndex == 1
                          ? ColorManger.newPrimary
                          : Color(0xff242B60),
                      height: 25,
                      width: 25,
                    ),
                    label: 'Wishlist'.tr(),
                  ),
                  BottomNavigationBarItem(
                      icon: SvgPicture.asset(
                        'assets/images/bnb/cart.svg',
                        color: cubit.screenIndex == 2
                            ? ColorManger.newPrimary
                            : Color(0xff242B60),
                        height: 25,
                        width: 25,
                      ),
                      label: "Cart".tr()),
                  BottomNavigationBarItem(
                    icon: Icon(
                      Icons.date_range,
                      color: cubit.screenIndex == 3
                          ? ColorManger.newPrimary
                          : Color(0xff242B60),
                      size: 25,
                    ),
                    label: 'Appointments'.tr(),
                  ),
                  BottomNavigationBarItem(
                    icon: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 25),
                        child: FaIcon(
                          FontAwesomeIcons.circle,
                          color: cubit.screenIndex == 4
                              ? ColorManger.newPrimary
                              : Color(0xff242B60),
                          size: 25,
                        )),
                    label: 'more'.tr(),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}
