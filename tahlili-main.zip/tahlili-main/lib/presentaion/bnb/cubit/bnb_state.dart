part of 'bnb_cubit.dart';

@immutable
sealed class BnbState {}

final class BnbInitial extends BnbState {}

class ChangeScreenIndexState extends BnbState{}
