import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';
import 'package:tahlili/presentaion/home/view/home_view.dart';
import 'package:tahlili/presentaion/resources/shared/cart_dialog.dart';
import 'package:tahlili/presentaion/wishlist/view/wishlist_view.dart';

import '../../../app/di.dart';
import '../../../app/pref_manager.dart';
import '../../account/view/account_view.dart';
import '../../lab_appointments/view/reservation.dart';

part 'bnb_state.dart';

class BnbCubit extends Cubit<BnbState> {
  BnbCubit(this._manager) : super(BnbInitial());
  final PreferancesManager _manager;

  List<Widget> appScreens = [
    HomeView(instance()),
    const WishlistView(),
    const SizedBox(),
    const Reservation(),
    AccountView(instance())
  ];
  int screenIndex = 0;
  setIndex(int index, context) {
    final token = _manager.getData(key: userToken);
    if (token != null) {
      screenIndex = index;
      if (index == 2) {
        showDialog(context: context, builder: (context) => const CartDialog());
      }
      emit(ChangeScreenIndexState());
    }
  }
}
