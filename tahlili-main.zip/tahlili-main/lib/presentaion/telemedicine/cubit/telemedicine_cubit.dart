import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:http_parser/http_parser.dart' show MediaType;
import 'package:bloc/bloc.dart';
import 'package:calendar_date_picker2/calendar_date_picker2.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:meta/meta.dart';
import 'package:tahlili/data/requests/order/request_order.dart';
import 'package:tahlili/domain/repository/orders/orders.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/payment/view/payment_view.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../app/end_points.dart';
import '../../../app/pref_manager.dart';
import '../../../data/response/home/response_home.dart';
import '../../../data/response/orders/response_order.dart';
import '../../resources/color_manger.dart';
import 'package:http/http.dart' as http;
part 'telemedicine_state.dart';

class TelemedicineCubit extends Cubit<TelemedicineState> {
  TelemedicineCubit(this._ordersRepository, this._preferancesManager)
      : super(TelemedicineInitial());
  final BaseOrdersRepository _ordersRepository;
  final PreferancesManager _preferancesManager;
  List<ResponseLookup> departments = [];
  List<String> departmentsAr = [];
  List<String> departmentsEn = [];
  getDepartments({required String filterQuery}) async {
    departments.clear();
    departmentsAr.clear();
    departmentsEn.clear();
    emit(LoadGetDepartmentsState());
    try {
      final result =
          await _ordersRepository.getDepartments(filterQuery: filterQuery);
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetDepartmentsState());
      }, (departments) {
        debugPrint(departments.length.toString());
        this.departments.addAll(departments);
        for (var i = 0; i < departments.length; i++) {
          List<String> names = ConstantManger.splitTelda(departments[i].name!);

          departmentsAr.add(names[1].trim());
          departmentsEn.add(names[0].trim());
        }

        emit(SuccessGetDepartmentsState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetDepartmentsState());
    }
  }

  List<TeleMedDoctor> dates = [];
  List<String> enDegrees = [];
  List<String> arDegrees = [];
  List<ResponseTeleDoctor> teleDocotors = [];
  getTeleDoctors({required int departmentId}) async {
    teleDocotors.clear();
    dates.clear();
    enDegrees.clear();
    arDegrees.clear();
    emit(LoadGetTeleDoctorsState());
    try {
      final result = await _ordersRepository.getTeleDoctors(filterQuery: '');
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetTeleDoctorsState());
      }, (teleDocotors) {
        debugPrint(teleDocotors.length.toString());
        for (var i = 0; i < teleDocotors.length; i++) {
          if (teleDocotors[i].department!.first.departmentId == departmentId) {
            this.teleDocotors.add(teleDocotors[i]);
            List<String> names =
                ConstantManger.splitTelda(teleDocotors[i].degree!.name!);

            enDegrees.add(names[0]);
            arDegrees.add(names[1]);
          }
        }

        for (var i in this.teleDocotors) {
          List<TeleMedDates> teleMedDates = [];
          for (var j in i.doctorsWorkingTimes!) {
            teleMedDates.add(TeleMedDates(
                weekDay: j.weekDay!.name!,
                dates:
                    generateTimeSlots(j.startTime!, j.endTime!, currentDate!)));
          }

          dates.add(TeleMedDoctor(doctorId: i.id!, teledates: teleMedDates));
        }
        for (var i = 0; i < dates.length; i++) {
          print(dates[i].teledates.first.dates);
        }
        calcBusyTimes(initialDay!);
        emit(SuccessGetTeleDoctorsState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetTeleDoctorsState());
    }
  }

  List<ResponseBusyTelemedicnice> busyTele = [];
  getBusyTele({required String date}) async {
    busyTele.clear();
    emit(LoadGetBusyTeleState());
    try {
      final result = await _ordersRepository.getBusyTele(date: date);

      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetBusyTeleState());
      }, (busyTele) {
        debugPrint(busyTele.length.toString());
        this.busyTele.addAll(busyTele);
        emit(SuccessGetBusyTeleState());
      });
    } catch (e) {
      debugPrint(e.toString());

      emit(FailureGetBusyTeleState());
    }
  }

  List<DateTime> calender = [];
  initCalender() {
    initialDay = DateTime.now();
    currentDate = DateTime.now();
    calender.clear();
    for (var i = 0; i < 30; i++) {
      calender.add(DateTime.now().add(Duration(days: i)));
    }
    emit(InitCalenderState());
  }

  setCurentDay(DateTime dateTime, bool fromList, int index, String languageCode,
      int departmentId) {
    if (!fromList) {
      selectedDay = index;
      currentDate = calender[index];
      selectedDate = languageCode == 'ar'
          ? DateFormat('EEE, dd MMM', 'ar').format(currentDate!)
          : DateFormat('EEE, dd MMM', 'en').format(currentDate!);
      getTeleDoctors(departmentId: departmentId);
    } else {
      currentDate = dateTime;
      selectedDate = languageCode == 'ar'
          ? DateFormat('EEE, dd MMM', 'ar').format(currentDate!)
          : DateFormat('EEE, dd MMM', 'en').format(currentDate!);
      for (var i = 0; i < calender.length; i++) {
        if (calender[i].year == dateTime.year &&
            calender[i].month == dateTime.month &&
            calender[i].day == dateTime.day) {
          selectedDay = i;
          print("selectedDay" + selectedDay.toString());
        }
      }
    }
    emit(SetCurentDayState());
  }

  String? selectedDate;
  DateTime? initialDay;
  DateTime? currentDate;
  Future<List<DateTime?>?> datePicker(BuildContext context) async {
    return await showCalendarDatePicker2Dialog(
      context: context,
      config: CalendarDatePicker2WithActionButtonsConfig(
          okButton: TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text("Pick Day")),
          cancelButton: const SizedBox(),
          calendarType: CalendarDatePicker2Type.single,
          dayTextStyle: const TextStyle(
              color: Colors.black, fontWeight: FontWeight.w500, fontSize: 16),
          selectedDayTextStyle: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.w500, fontSize: 16),
          selectedDayHighlightColor: ColorManger.primary,
          weekdayLabelTextStyle: const TextStyle(
              color: Colors.black, fontWeight: FontWeight.w500, fontSize: 16),
          yearTextStyle: const TextStyle(
              color: Colors.black, fontWeight: FontWeight.w500, fontSize: 16),
          buttonPadding: EdgeInsets.zero),
      dialogSize: const Size(325, 400),
      borderRadius: BorderRadius.circular(15),
    );

    // final busyDay = DateFormat('MM-dd-yyyy').format(result.first!);

    //   emit(SelectDateState());
  }

  calcBusyTimes(DateTime dateTime) async {
    final busyDay = DateFormat('MM-dd-yyyy', 'en').format(dateTime);
    final day = DateFormat('EEEE').format(dateTime);
    await getBusyTele(date: busyDay);
    if (busyTele.isNotEmpty) {
      for (var element in busyTele) {
        for (var e in dates) {
          if (element.doctorId == e.doctorId) {
            findDay(day);

            e.teledates[dayIndex!].dates.removeWhere((ele) {
              String updatedTime =
                  element.time.substring(0, element.time.lastIndexOf(":"));
              if (ele == updatedTime) {
                print(ele);
                return true;
              } else {
                return false;
              }
            });
            print(e.teledates[dayIndex!].dates);
          }
        }
      }
    }
    emit(CalcBusyTimesState());
    // dates[index].teledates[cubit.dayIndex!].dates
  }

  int? selectedDay;
  String? dayValue;
  // selectDay(int index) {
  //   selectedDay = index;
  //   emit(SelectDayIndexState());
  // }

  initDayValue() {
    selectedDay = 0;
    dayValue = DateFormat('EEEE').format(DateTime.now());
    findDay(dayValue!);
    emit(InitDayValueState());
  }

  int? dayIndex;
  findDay(String day) {
    switch (day) {
      case "Saturday":
        dayIndex = 0;
        break;
      case "Sunday":
        dayIndex = 1;
        break;
      case "Monday":
        dayIndex = 2;
        break;
      case "Tuesday":
        dayIndex = 3;
        break;
      case "Wednesday":
        dayIndex = 4;
        break;
      case "Thursday":
        dayIndex = 5;
        break;

      default:
        dayIndex = 6;
        break;
    }
  }

  int? selectedHour;
  int? doctorId;
  selectHour(index, id) {
    selectedHour = index;
    doctorId = id;
    print(doctorId);
    emit(SelectHourState());
  }

  List<String> generateTimeSlots(
      String startTime, String endTime, DateTime today) {
    DateTime compareTime = DateTime.now();
    String compare = DateFormat('HH:mm:ss', 'en').format(compareTime);
    DateTime now = DateFormat('HH:mm:ss', 'en').parse(compare);
    DateTime start = DateFormat('HH:mm:ss', 'en').parse(startTime);
    DateTime end = DateFormat('HH:mm:ss', 'en').parse(endTime);
    String day = "";
    if (compareTime.day == today.day) {
      if (now.isAfter(start)) {
        // Start from the current time
        if (now.minute > 0 && now.minute < 30) {
          day = "${now.hour}:30:00";
          start = DateFormat('HH:mm:ss', 'en').parse(day);
        } else {
          day = "${now.hour + 1}:00:00";
          start = DateFormat('HH:mm:ss', 'en').parse(day);
        }
      }
    }

    List<String> slots = [];
    for (DateTime time = start;
        time.isBefore(end);
        time = time.add(const Duration(minutes: 30))) {
      slots.add(DateFormat('hh:mm a', 'en').format(time));
    }
    return slots;
  }

  final TextEditingController noteController = TextEditingController();
  double sessoionPrice = 0;
  bool fromCleander = false;

  createTeleOrder(
      {required int patientId,
      required BuildContext context,
      required bool isInstant,
      required String visitDateTime}) async {
    emit(LoadCreateTeleOrderState());
    try {
      final result = await _ordersRepository.createTeleOrder(
          requestTele: RequestTele(departmentId, doctorId, patientId,
              noteController.text, visitDateTime, isInstant));
      result.fold((error) {
        debugPrint(error.message);
        toast(
            text:
                "Sorry, this time slot has already been booked. Please choose another time.",
            color: Colors.red);
        emit(FailureCreateTeleOrderState());
      }, (response) {
        debugPrint(response.message);
        toast(
            text: "Tele med order has been created Successfully",
            color: Colors.green);
        if (image != null) uploadFileX(image!, response.id!);
        final price = sessoionPrice + (sessoionPrice * .14);
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => PaymentView(
                      orderId: response.id,
                      amount: (price * 100).toInt(),
                      description: "T${response.id}",
                      fromTele: context.read<AccountCubit>().instantTele
                          ? false
                          : true,
                    )));
        if (image != null) {
          uploadImage(image!, response.id!);
        }
        emit(SuccessCreateTeleOrderState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureCreateTeleOrderState());
    }
  }

  List<ResponseTeleMedOrders> teleOrders = [];
  getTelemedOrders() async {
    teleOrders.clear();
    emit(LoadGetTeleOrderState());
    try {
      final result = await _ordersRepository.getTelemedOrders();
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetTeleOrderState());
      }, (teleOrders) {
        {
          debugPrint(teleOrders.length.toString());
          this.teleOrders.addAll(teleOrders);
          emit(SuccessGetTeleOrderState());
        }
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetTeleOrderState());
    }
  }

  ResponseOrderStateId? orderState;
  bool zoomURL = false;
  getOrderCurrentState({required int orderId}) async {
    orderState = null;
    emit(LoadGetOrderCurrentState());
    try {
      final result =
          await _ordersRepository.getOrderCurrentState(orderId: orderId);
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetOrderCurrentState());
        zoomURL = false;
      }, (orderState) {
        this.orderState = orderState;
        if (orderState.zoomURL != null) {
          zoomURL = true;
        }

        emit(SuccessGetOrderCurrentState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetOrderCurrentState());
    }
  }

  ResponseTelemedDetails? orderDetails;
  getOrderDetails({required int orderId}) async {
    orderDetails = null;
    emit(LoadGetTeleOrderState());
    try {
      final result =
          await _ordersRepository.getTelemedOrderDetails(orderId: orderId);
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetTeleOrderState());
      }, (orderDetails) {
        {
          debugPrint(orderDetails.id.toString());
          this.orderDetails = orderDetails;
          emit(SuccessGetTeleOrderState());
        }
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetTeleOrderState());
    }
  }

  Future cancelTelemedAppt({required int telemedId}) async {
    emit(LoadCancelTelemedApptState());
    try {
      final result =
          await _ordersRepository.cancelTelemedAppt(telemedId: telemedId);
      result.fold((error) {
        debugPrint(error.message);
        toast(text: "لا يمكن الغاء هذا الحجز", color: Colors.red);
        emit(FailureCancelTelemedApptState());
      }, (response) {
        debugPrint(response.message);
        toast(text: "تم الغاء الحجز بنجاح", color: Colors.red);
        getTelemedOrders();
        emit(SuccessCancelTelemedApptState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureCancelTelemedApptState());
    }
  }

  Future<void> launchUrlFun(uri) async {
    var url = Uri.parse(uri);
    if (!await launchUrl(url)) {
      toast(text: 'Could not launch $url', color: Colors.red);
    }
  }

  Future<void> uploadImage(File imageFile, int orderId) async {
    String apiUrl =
        "${EndPoints.baseUrl}/Files/UploadFile?id=$orderId&entityName=TelemedicineAttachments&isPdf=false"; // Replace with your API endpoint URL

    var request = http.MultipartRequest('POST', Uri.parse(apiUrl));
    request.headers['Content-Type'] = 'multipart/form-data';

    var imageStream = http.ByteStream(imageFile.openRead());
    var imageLength = await imageFile.length();
    print("object1");
    var multipartFile = http.MultipartFile(
      'files',
      imageStream,
      imageLength,
      filename: imageFile.path.split("/").last,
      contentType: MediaType('image', 'jpeg'), // Set the correct content type
    );
    print("object2");
    request.files.add(multipartFile);
    print("object3");
    try {
      var response = await request.send();
      print("object4");
      response.stream.transform(utf8.decoder).listen((value) {
        print(value);
      });
    } catch (error) {
      print('Error uploading image: $error');
    }
  }

  int? departmentId;

  File? image;
  pickImage(ImageSource imageSource) async {
    XFile? file = await ImagePicker().pickImage(source: imageSource);
    if (file != null) {
      // Convert XFile to File

      image = File(file.path);
    }
    emit(PickFIleState());
  }

  Future<void> uploadFileX(
    File imageFile,
    int id,
  ) async {
    final authToken = _preferancesManager.getData(key: userToken);
    String apiUrl =
        "https://dev-api.tahliliapp.store/Files/UploadFile?id=$id&entityName=TelemedicineAttachments&isPdf=false"; // Replace with your API endpoint URL
    print(apiUrl);

    var request = http.MultipartRequest('POST', Uri.parse(apiUrl));
    request.headers['Content-Type'] = 'multipart/form-data';
    request.headers['Authorization'] = 'Bearer $authToken';

    var imageStream = http.ByteStream(imageFile.openRead());
    var imageLength = await imageFile.length();
    print("object1");
    var multipartFile = http.MultipartFile(
      'files',
      imageStream,
      imageLength,
      filename: imageFile.path.split("/").last,
      contentType: MediaType('image', 'jpeg'), // Set the correct content type
    );
    print("object2");
    request.files.add(multipartFile);

    try {
      var response = await request.send();
      print("object3");
      var responseBody = await response.stream.bytesToString();
      image = null;
      print(responseBody);

      response.stream.transform(utf8.decoder).listen((value) {
        print("object4");
        print(value);
      });
    } catch (error) {
      print('Error uploading image: $error');
    }
  }
}

class TeleMedDoctor {
  final int doctorId;
  final List<TeleMedDates> teledates;

  TeleMedDoctor({required this.doctorId, required this.teledates});
}

class TeleMedDates {
  final String weekDay;
  final List<String> dates;

  TeleMedDates({required this.dates, required this.weekDay});
}
