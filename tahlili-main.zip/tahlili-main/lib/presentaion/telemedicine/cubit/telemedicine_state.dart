part of 'telemedicine_cubit.dart';

@immutable
sealed class TelemedicineState {}

final class TelemedicineInitial extends TelemedicineState {}

class LoadGetDepartmentsState extends TelemedicineState {}

class SuccessGetDepartmentsState extends TelemedicineState {}

class FailureGetDepartmentsState extends TelemedicineState {}

class LoadGetTeleDoctorsState extends TelemedicineState {}

class SuccessGetTeleDoctorsState extends TelemedicineState {}

class FailureGetTeleDoctorsState extends TelemedicineState {}

class SelectDateState extends TelemedicineState {}

class InitCalenderState extends TelemedicineState {}

class SelectDayIndexState extends TelemedicineState {}

class InitDayValueState extends TelemedicineState {}

class SelectHourState extends TelemedicineState {}

class LoadGetBusyTeleState extends TelemedicineState {}

class SuccessGetBusyTeleState extends TelemedicineState {}

class FailureGetBusyTeleState extends TelemedicineState {}

class CalcBusyTimesState extends TelemedicineState {}

class LoadCreateTeleOrderState extends TelemedicineState {}

class SuccessCreateTeleOrderState extends TelemedicineState {}

class FailureCreateTeleOrderState extends TelemedicineState {}

class LoadGetTeleOrderState extends TelemedicineState {}

class SuccessGetTeleOrderState extends TelemedicineState {}

class FailureGetTeleOrderState extends TelemedicineState {}

class LoadCancelTelemedApptState extends TelemedicineState {}

class SuccessCancelTelemedApptState extends TelemedicineState {}

class FailureCancelTelemedApptState extends TelemedicineState {}

class SetCurentDayState extends TelemedicineState {}

class PickFIleState extends TelemedicineState {}

class LoadGetOrderCurrentState extends TelemedicineState {}

class SuccessGetOrderCurrentState extends TelemedicineState {}

class FailureGetOrderCurrentState extends TelemedicineState {}