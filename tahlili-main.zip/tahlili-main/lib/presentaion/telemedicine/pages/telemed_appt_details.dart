import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/telemedicine/cubit/telemedicine_cubit.dart';

import '../../resources/shared/appbar_divider.dart';
import '../../resources/styles_manger.dart';

class TeleMedDetailsView extends StatelessWidget {
  const TeleMedDetailsView({super.key, required this.orderId});
  final int orderId;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<TelemedicineCubit>();
    cubit.getOrderDetails(orderId: orderId);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          "Telemedicine Appointments Details",
          style:
              StylesManger.medium().copyWith(color: Colors.black, fontSize: 18),
        ),
      ),
      backgroundColor: Colors.white,
      body: BlocBuilder<TelemedicineCubit, TelemedicineState>(
        builder: (context, state) {
          return cubit.orderDetails==null?const Center(
            child: 
            CircularProgressIndicator(),
          ) :Column(
            children: [
              const AppBarDivider(),
              const SizedBox(
                height: 16,
              ),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 16),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  border: Border.all(color: ColorManger.grey),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Column(
                  children: [
                    Text(
                      "Telemedicine Appointment Summery",
                      style: StylesManger.rich().copyWith(color: Colors.black),
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    Row(
                      children: [
                        SvgPicture.asset('assets/images/telemed/patient.svg'),
                        const SizedBox(
                          width: 8,
                        ),
                        Text("Patient Name: ",
                            style: StylesManger.rich()
                                .copyWith(color: Colors.black),
                                ),
                        Expanded(
                          child: Text(
                            cubit.orderDetails!.patientName.orEmpty(),
                            style: StylesManger.rich()
                                .copyWith(color: ColorManger.buttonColor),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Row(
                      children: [
                        SvgPicture.asset('assets/images/telemed/doctor.svg'),
                        const SizedBox(
                          width: 8,
                        ),
                        Text("Doctor: ",
                            style: StylesManger.rich()
                                .copyWith(color: Colors.black)),
                        Text(
                     context.locale.languageCode=='ar'?
                         cubit.orderDetails!.doctor!.nameAr.orEmpty():
                         cubit.orderDetails!.doctor!.nameEn.orEmpty(),
                          style: StylesManger.rich()
                              .copyWith(color: ColorManger.buttonColor),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Row(
                      children: [
                        const Icon(Icons.date_range),
                        const SizedBox(
                          width: 8,
                        ),
                        Text("Date: ",
                            style: StylesManger.rich()
                                .copyWith(color: Colors.black)),
                        Text(
                      DateFormat('yyyy-MM-dd hh:mm a').format(DateTime.parse(cubit.orderDetails!.visitDateTime!))     ,
                          style: StylesManger.rich()
                              .copyWith(color: ColorManger.buttonColor),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    Row(
                      children: [
                        SvgPicture.asset(
                            'assets/images/telemed/session_price.svg'),
                        const SizedBox(
                          width: 8,
                        ),
                        Text("Price: ",
                            style: StylesManger.rich()
                                .copyWith(color: Colors.black)),
                        Text(
                          "${cubit.orderDetails!.priceWithVAT} ${'SAR'.tr()}",
                          style: StylesManger.rich()
                              .copyWith(color: ColorManger.buttonColor),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 16,
              ),
          cubit.orderDetails!.diagnostic==null? const SizedBox():   Container(
                margin: EdgeInsets.symmetric(horizontal: 16),
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  border: Border.all(color: ColorManger.grey),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Attachments",
                      style: StylesManger.rich().copyWith(color: Colors.black),
                    ),
                    SizedBox(
                      height: 8,
                    ),
                    Container(
                      height: 50,
                      width: double.infinity,
                      color: Colors.red,
                    )
                  ],
                ),
              )
            ],
          );
        },
      ),
    );
  }
}
