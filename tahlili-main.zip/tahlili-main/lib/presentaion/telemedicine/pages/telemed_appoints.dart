import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/telemedicine/cubit/telemedicine_cubit.dart';
import '../../../app/end_points.dart';
import '../../account/cubit/account_cubit.dart';
import '../../bnb/cubit/bnb_cubit.dart';
import '../../bnb/view/bnb_view.dart';
import '../../resources/color_manger.dart';
import '../../resources/shared/appbar_divider.dart';
import '../../resources/styles_manger.dart';
import 'telemed_appt_details.dart';

class TeleMedAppoiontmentsView extends StatelessWidget {
  const TeleMedAppoiontmentsView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<TelemedicineCubit>();
     context.read<AccountCubit>().direct=false;
    cubit.getTelemedOrders();
    return Scaffold(
      backgroundColor: Colors.white,
//       appBar: AppBar(
//         backgroundColor: Colors.white,
//         leading: IconButton(onPressed: (){
//            context.read<BnbCubit>().setIndex(3, context);
// Navigator.push(context, MaterialPageRoute(builder: (context)=>const BNBView()));
//         }, icon: Icon(Icons.arrow_back)),
//         centerTitle: true,
//         title: Text(
//           "Telemedicines".tr(),
//           style:
//               StylesManger.medium().copyWith(color: Colors.black, fontSize: 18),
//         ),
//       ),
//       backgroundColor: Colors.white,
      body: BlocBuilder<TelemedicineCubit, TelemedicineState>(
        builder: (context, state) {
          return Column(
            children: [
              // const AppBarDivider(),
              // const SizedBox(
              //   height: 8,
              // ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: ListView.separated(
                      shrinkWrap: true,
                      itemBuilder: (context, index) => Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: Colors.grey)),
                            child: Column(children: [
                              Row(
                                mainAxisAlignment:   (cubit.teleOrders[index]
                                                    .doctor==null)?
                                                    MainAxisAlignment.end:MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                               
                              if(cubit.teleOrders[index]
                                                    .doctor!=null)     CircleAvatar(

                                    backgroundImage:
                                        CachedNetworkImageProvider(
                                            EndPoints.baseImageUrl +
                                                cubit.teleOrders[index]
                                                    .doctor!.image!),
                                    radius: 20,
                                  ),
                                 const SizedBox(
                                    width: 10,
                                  ),
                             if(cubit.teleOrders[index]
                                                    .doctor!=null)     Text(
                                    cubit.teleOrders[index].doctor!.nameEn!,
                                    style: StylesManger.rich(),
                                  ),
                                if(cubit.teleOrders[index]
                                                    .doctor!=null)  const Spacer(),
                                  telePopUp(context,cubit.teleOrders[index].id!)
                                ],
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Row(
                                children: [
                                  SvgPicture.asset(
                                      'assets/images/more/lab_appointment.svg'),
                                  const SizedBox(
                                    width: 8,
                                  ),
                                  Text("${"OrderState".tr()}: ",
                                      style: StylesManger.rich()
                                          .copyWith(color: Colors.black)),
                                  Text(
                                    "${cubit.teleOrders[index].currentOrderState!.name}",
                                    style: StylesManger.rich().copyWith(
                                        color: ColorManger.buttonColor),
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Row(
                                children: [
                                  SvgPicture.asset(
                                      'assets/images/telemed/appt_id.svg'),
                                  const SizedBox(
                                    width: 8,
                                  ),
                                  Text("${"Id".tr()}: ",
                                      style: StylesManger.rich()
                                          .copyWith(color: Colors.black)),
                                  Text(
                                    "${cubit.teleOrders[index].id}",
                                    style: StylesManger.rich().copyWith(
                                        color: ColorManger.buttonColor),
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Row(
                                children: [
                                  SvgPicture.asset(
                                      'assets/images/telemed/date_calender.svg'),
                                  const SizedBox(
                                    width: 8,
                                  ),
                                  Text("${"Date".tr()}: ",
                                      style: StylesManger.rich()
                                          .copyWith(color: Colors.black)),
                                  Text(
                                    "${DateFormat("dd-MM-yyyy 'at' hh:mm a").format(DateTime.parse(cubit.teleOrders[index].date!))}",
                                    style: StylesManger.rich().copyWith(
                                        color: ColorManger.buttonColor),
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Row(
                                children: [
                                  SvgPicture.asset(
                                      'assets/images/telemed/session_price.svg'),
                                  const SizedBox(
                                    width: 8,
                                  ),
                                  Text("${"Price".tr()}: ",
                                      style: StylesManger.rich()
                                          .copyWith(color: Colors.black)),
                                  Text(
                                    "${cubit.teleOrders[index].priceWithVAT} ${"SAR".tr()}",
                                    style: StylesManger.rich().copyWith(
                                        color: ColorManger.buttonColor),
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: AppButton(
                                      borderSide: cubit.teleOrders[index].currentOrderState!.id==70? ColorManger.primary
                                        :ColorManger.grey,
                                        radius: 50,
                                        color:cubit.teleOrders[index].currentOrderState!.id==70? ColorManger.primary
                                        :ColorManger.grey,
                                        name: 'Start Meeting'.tr(),
                                        onPressed: () {
                                          if (cubit.teleOrders[index].currentOrderState!.id!<100) {
                                            cubit.launchUrlFun(cubit.teleOrders[index].zoomURL!);

                                          }

                                        }),
                                  ),
                                 ],
                              )
                            ]),
                          ),
                      separatorBuilder: (context, index) => const SizedBox(
                            height: 8,
                          ),
                      itemCount: cubit.teleOrders.length),
                ),
              )
            ],
          );
        },
      ),
    );
  }
  Widget telePopUp(BuildContext context,int orderId) {
  return Theme(
    data: Theme.of(context).copyWith(
        cardColor: Colors.white,
        popupMenuTheme: const PopupMenuThemeData(
          color: Colors.white,
          elevation: 0,
        )),
    child: PopupMenuButton(
      padding: const EdgeInsets.only(bottom: 20),

      // color: Colors.black,
      position: PopupMenuPosition.under,
      iconSize: 30,
      icon: const Icon(
        FontAwesomeIcons.ellipsisH,
        color: Colors.black,
      ),

      itemBuilder: (context) {
        return [
          PopupMenuItem(
            value: 0,
            child: Column(
              children: [
                 ListTile(
                  leading: Icon(
                    Icons.remove_red_eye_outlined,
                    color: Colors.black,
                  ),
                  title: Text(
                    "ViewDetails".tr(),
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10),
                  height: 1,
                  width: double.infinity,
                  color: ColorManger.grey,
                )
              ],
            ),
          ),
          PopupMenuItem(
            value: 1,
            child: Column(
              children: [
                 ListTile(
                  leading:const Icon(
                    Icons.file_download_outlined,
                    color: Colors.black,
                  ),
                  title: Text("DownloadFile".tr()),
                ),
                const SizedBox(
                  height: 5,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10),
                  height: 1,
                  width: double.infinity,
                  color: ColorManger.grey,
                ),
                
              ],
            ),
          ),
           PopupMenuItem(
            value: 2,
            child: Column(
              children: [
                 ListTile(
                  leading:const Icon(
                    Icons.file_download_outlined,
                    color: Colors.black,
                  ),
                  title: Text("Cancel Order".tr()),
                ),
                
                
              ],
            ),
          ),

        ];
      },
      onSelected: (value) async {
        switch (value) {
          case 0:
          Navigator.push(context, MaterialPageRoute(builder: (context)=> TeleMedDetailsView(orderId: orderId)));

            break;
          case 1:

            break;
            case 2:
            context.read<TelemedicineCubit>().cancelTelemedAppt(telemedId: orderId);

            break;

        }
      },
    ),
  );
}
}
