import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/telemedicine/cubit/telemedicine_cubit.dart';
import 'package:tahlili/presentaion/telemedicine/view/instant_telemed/check_tele.dart';

import '../../../resources/styles_manger.dart';

class InstantTelemedView extends StatelessWidget {
  const InstantTelemedView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<TelemedicineCubit>();
    cubit.getDepartments(filterQuery: "orderIndex!=null&&(type=1||type=2)");
    cubit.departmentId=null;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          "استشاره طبيه فورية",
          style:
              StylesManger.medium().copyWith(color: Colors.black, fontSize: 18),
        ),
      ),
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            Padding(
               padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: InkWell(
                onTap: (){
                  cubit.departmentId=null;
                 
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>CheckInstantTeleView()));
                },
                child: Container(
                 
                  decoration: BoxDecoration(
                    border: Border.all(color: ColorManger.grey),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(
                    child: Text(
                      "طبيب عام",
                      style: StylesManger.rich(),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 16,
            ),
            BlocBuilder<TelemedicineCubit, TelemedicineState>(
              builder: (context, state) {
                return cubit.departments.isEmpty?Center(
                  child: CircularProgressIndicator(),
                ) :Column(
                  children: [
                    ...List.generate(
                      cubit.departments.length,
                      (index) => Padding(
                        padding:
                              EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                        child: InkWell(
                          onTap: (){
                            cubit.departmentId=cubit.departments[index].id;
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>CheckInstantTeleView()));
                        
                          },
                          child: Container(
                            margin: EdgeInsets.only(bottom: 16),
                            
                            decoration: BoxDecoration(
                              border: Border.all(color: ColorManger.grey),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Center(
                              child: Text(
                               context.locale.languageCode=='ar'?
                               cubit.departmentsAr[index]:cubit.departmentsEn[index],
                                style: StylesManger.rich(),
                              ),
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                );
              },
            )
          ],
        ),
      ),
    );
  }
}
