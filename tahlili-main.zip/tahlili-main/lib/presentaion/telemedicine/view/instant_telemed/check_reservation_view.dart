import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';
import 'package:tahlili/presentaion/telemedicine/cubit/telemedicine_cubit.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../account/cubit/account_cubit.dart';
import '../../../bnb/cubit/bnb_cubit.dart';
import '../../../bnb/view/bnb_view.dart';
import '../../../resources/styles_manger.dart';

class CheckReservationView extends StatefulWidget {
  const CheckReservationView({super.key, required this.orderId});
  final int orderId;

  @override
  State<CheckReservationView> createState() => _CheckReservationViewState();
}

class _CheckReservationViewState extends State<CheckReservationView> {
  late Timer _timer;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
   
    context.read<TelemedicineCubit>().zoomURL=false;
     _timer = Timer.periodic(Duration(seconds: 10), (Timer timer) {
    context.read<TelemedicineCubit>().getOrderCurrentState(orderId: widget.orderId);
    });
  }
  @override
  Widget build(BuildContext context) {
    final cubit=context.read<TelemedicineCubit>();
   
    return PopScope(
      canPop: false,
      child: Scaffold(
        appBar: AppBar(
          leading: SizedBox(),
          backgroundColor: Colors.white,
          centerTitle: true,
          title: Text(
            "تاكيد الحجز ",
            style:
                StylesManger.medium().copyWith(color: Colors.black, fontSize: 18),
          ),
        ),
        backgroundColor: Colors.white,
        body: BlocBuilder<TelemedicineCubit, TelemedicineState>(
          builder: (context, state) {
            return Padding(
              padding:  EdgeInsets.symmetric(horizontal: 16.w),
              child: Column(
                children: [
                    
               !(cubit.zoomURL)?   Text("جاري تاكيد طلبك",style: StylesManger.rich().copyWith(
                    color: Colors.black
                  ),): Text("تم تاكيد طلبك",style: StylesManger.rich().copyWith(
                    color: Colors.black
                  ),),
                  SizedBox(height: 50,),
                      (!cubit.zoomURL)?        Center(
                    child: CircularProgressIndicator(),
                  ):SvgPicture.asset("assets/images/telemed/cicle _check.svg",height: 40.h,width: 50.w,),
                  SizedBox(height: 50,),
                    (cubit.zoomURL)?
                    AppButton(color: Colors.green, name: "بدا الحجز", onPressed: (){
                       context.read<AccountCubit>().direct = false;
                       launchUrlFun(cubit.orderState!.zoomURL!);
                       
                    
                    }):AppButton(color: Colors.red, name: "الغاء الحجز", onPressed: (){
                      cubit.cancelTelemedAppt(telemedId: widget.orderId).whenComplete((){
                     context.read<AccountCubit>().direct = false;
                    context.read<BnbCubit>().setIndex(0, context);
                     Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) =>
                    BNBView()), (Route<dynamic> route) => false);
                      });
                    }),
                    
                    SizedBox(height: 50.h,),
                    AppButton(color: Colors.amber, name: "الذهاب للصفحه الرئيسية", onPressed: (){
                      context.read<AccountCubit>().direct = false;
                    context.read<BnbCubit>().setIndex(0, context);
                     Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) =>
                    BNBView()), (Route<dynamic> route) => false);
                    })
                  
                    
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
 Future<void> launchUrlFun(uri) async {
    var url = Uri.parse(uri);
    if (!await launchUrl(url)) {
      toast(text: 'Could not launch $url', color: Colors.red);
    }
  }