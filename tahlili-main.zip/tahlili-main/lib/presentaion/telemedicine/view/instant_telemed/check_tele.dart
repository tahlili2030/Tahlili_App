import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/presentaion/profiles/view/family_members.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';
import 'package:tahlili/presentaion/telemedicine/cubit/telemedicine_cubit.dart';
import '../../../../app/end_points.dart';
import '../../../../data/response/orders/response_order.dart';
import '../../../account/cubit/account_cubit.dart';
import '../../../orders/cubit/orders_cubit.dart';
import '../../../orders/view/home/home_order_first_page.dart';
import '../../../resources/color_manger.dart';
import '../../../resources/constant_manger.dart';
import '../../../resources/shared/appbar_divider.dart';
import '../../../resources/styles_manger.dart';

class CheckInstantTeleView extends StatelessWidget {
  const CheckInstantTeleView({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final orderCubit = context.read<OrdersCubit>();
    final cubit = context.read<TelemedicineCubit>();
    orderCubit.getProfileNames(context);
    orderCubit.setProfile(0, context);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: ColorManger.pageColor,
        centerTitle: true,
        title: Text(
          "استشاره طبيه فوريه عن بعد",
          style:
              StylesManger.medium().copyWith(color: Colors.black, fontSize: 18),
        ),
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: BlocBuilder<TelemedicineCubit, TelemedicineState>(
          builder: (context, state) {
            return Column(
              children: [
                const AppBarDivider(),
                const SizedBox(
                  height: 8,
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            height: 220.h,
                            width: double.infinity,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(
                                    ConstantManger.borderRadius),
                                // color: Colors.red
                                image: DecorationImage(
                                    fit: BoxFit.fill,
                                    image: CachedNetworkImageProvider(
                                        "https://www.aamc.org/sites/default/files/female-doctor-with-patient-1393489803.jpg"))),
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          Text(
                            "هي خدمة تساعدك للوصول الى أحد أطباء تحليلي في أقرب وقت دون العناء للذهاب الى عيادة أو مستشفى",
                            style: StylesManger.small()
                                .copyWith(color: ColorManger.grey),
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          Text(
                            "معلومات عن الاستشارة",
                            style: StylesManger.small().copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                padding: EdgeInsets.all(8),
                                height: 40.h,
                                width: 40.w,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(
                                      ConstantManger.borderRadius),
                                  border:
                                      Border.all(color: ColorManger.lightBlack),
                                ),
                                child: SvgPicture.asset(
                                  "assets/images/tahlili_new_logo.svg",
                                ),
                              ),
                              SizedBox(
                                width: 8.w,
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      SvgPicture.asset(
                                        'assets/images/telemed/clock.svg',
                                        color: ColorManger.grey,
                                      ),
                                      SizedBox(
                                        width: 8.w,
                                      ),
                                      Text("${"مدة الاستشارة الطبية".tr()}: ",
                                          style: StylesManger.small().copyWith(
                                              color: ColorManger.grey)),
                                      Text(
                                        "${30} ${"Min".tr()}",
                                        style: StylesManger.small().copyWith(
                                            color: ColorManger.newPrimary),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 8.h,
                                  ),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.replay,
                                        color: ColorManger.grey,
                                        size: 15,
                                      ),
                                      SizedBox(
                                        width: 8.w,
                                      ),
                                      Text("${"مدة الانتظار".tr()}: ",
                                          style: StylesManger.small().copyWith(
                                              color: ColorManger.grey)),
                                      Text(
                                        "${30} ${"Min".tr()}",
                                        style: StylesManger.small().copyWith(
                                            color: ColorManger.newPrimary),
                                      ),
                                    ],
                                  )
                                ],
                              )
                            ],
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                        ],
                      ),
                      BlocBuilder<OrdersCubit, OrdersState>(
                        builder: (context, state) {
                          return OrderDropDown(
                              profileImage: orderCubit.profileImages,
                              directed: true,
                              directBtn: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const FamilyMembersView()));
                              },
                              title: "اختر المريض".tr(),
                              hintText: "Patient".tr(),
                              value: orderCubit.profileValue,
                              list: orderCubit.profiles,
                              onDropCahnge: (value) {
                                orderCubit.setProfile(value, context);
                              });
                        },
                      ),
                      Container(
                        height: 32.h,
                        width: double.infinity,
                        decoration: BoxDecoration(
                            color: ColorManger.newPrimary.withOpacity(.1),
                            borderRadius: BorderRadius.circular(
                                ConstantManger.borderRadius)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "${"SessionPrice".tr()}: ",
                              style: StylesManger.small()
                                  .copyWith(color: ColorManger.newPrimary),
                            ),
                            Text(
                              " 100 ${"SAR".tr()}",
                              style: StylesManger.small().copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: ColorManger.newPrimary),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      AppButton(
                          textSize: 12.sp,
                          color: ColorManger.newPrimary,
                          name: "PaymentAndCheckout".tr(),
                          onPressed: () {
                            if (orderCubit.profileEntityId != null) {
                              // Parse the original date string into a DateTime object
                              // DateTime parsedDateTime =
                              //      DateFormat("MM-dd-yyyy hh:mm a")
                              //         .parse(visitDateTime)
                              //         .toUtc();
                              //         log(parsedDateTime.toString());

                              // Format the DateTime object to an ISO 8601 string with milliseconds
                              String formattedDateString =
                                  DateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", 'en')
                                      .format(DateTime.now());
                              print(formattedDateString);
                              cubit.sessoionPrice = 30;
                              context.read<AccountCubit>().instantTele = true;
                              print(orderCubit.profileEntityId);
                              cubit.createTeleOrder(
                                  isInstant: true,
                                  context: context,
                                  patientId: orderCubit.profileEntityId!,
                                  visitDateTime: formattedDateString);
                            } else {
                              toast(
                                  text: "ChangeProfile".tr(),
                                  color: Colors.red);
                            }
                          })
                    ],
                  ),
                )
              ],
            );
          },
        ),
      ),
    );
  }
}
