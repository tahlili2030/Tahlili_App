import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tahlili/presentaion/profiles/view/family_members.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';
import 'package:tahlili/presentaion/telemedicine/cubit/telemedicine_cubit.dart';
import '../../../../app/end_points.dart';
import '../../../../data/response/orders/response_order.dart';
import '../../../account/cubit/account_cubit.dart';
import '../../../orders/cubit/orders_cubit.dart';
import '../../../orders/view/home/home_order_first_page.dart';
import '../../../resources/color_manger.dart';
import '../../../resources/constant_manger.dart';
import '../../../resources/shared/appbar_divider.dart';
import '../../../resources/styles_manger.dart';

class CheckTeleView extends StatelessWidget {
  const CheckTeleView(
      {super.key,
      required this.doctor,
      required this.seassionTime,
      required this.visitDateTime,
      required this.degree});
  final ResponseTeleDoctor doctor;
  final String seassionTime;
  final String visitDateTime;
  final String degree;

  @override
  Widget build(BuildContext context) {
    final orderCubit = context.read<OrdersCubit>();
    final cubit = context.read<TelemedicineCubit>();
    orderCubit.getProfileNames(context);
    orderCubit.setProfile(0, context);
    print(visitDateTime);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          "OrderConfirmation".tr(),
          style:
              StylesManger.medium().copyWith(color: Colors.black, fontSize: 18),
        ),
      ),
      backgroundColor: ColorManger.pageColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const AppBarDivider(),
            const SizedBox(
              height: 8,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              height: 90.h,
                              width: 90.w,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(
                                      ConstantManger.borderRadius),
                                  image: DecorationImage(
                                      fit: BoxFit.fill,
                                      image: CachedNetworkImageProvider(
                                          EndPoints.baseImageUrl +
                                              doctor.image!))),
                            ),
                            SizedBox(
                              width: 8.w,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  context.locale.languageCode == 'ar'
                                      ? doctor.nameAr!
                                      : doctor.nameEn!,
                                  style: StylesManger.rich(),
                                ),
                                SizedBox(
                                  height: 8.h,
                                ),
                                Text(
                                  degree,
                                  style: StylesManger.medium().copyWith(
                                      fontWeight: FontWeight.w500,
                                      color: ColorManger.newPrimary),
                                ),
                                SizedBox(
                                  height: 8.h,
                                ),
                                Row(
                                  children: [
                                    Text(
                                      "${"Experience".tr()}: ",
                                      style: StylesManger.small()
                                          .copyWith(color: ColorManger.grey),
                                    ),
                                    Text(
                                      "${doctor.experienceYears} ${"years".tr()}",
                                      style: StylesManger.medium().copyWith(
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 8.h,
                                ),
                                Row(
                                  children: [
                                    Text(
                                      "${"مدة الاستشارة الطبية".tr()}: ",
                                      style: StylesManger.small()
                                          .copyWith(color: ColorManger.grey),
                                    ),
                                    Text(
                                      "${doctor.sessionTime} ${"Min".tr()}",
                                      style: StylesManger.medium().copyWith(
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            )
                          ],
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        Text(
                          "وصف عن الطبيب",
                          style: StylesManger.medium().copyWith(
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        SizedBox(
                          height: 8.h,
                        ),
                        Text(
                          "datadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadata",
                          style: StylesManger.rich().copyWith(
                              fontSize: 8.sp, color: ColorManger.grey),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ]),
                  SizedBox(
                    height: 24.h,
                  ),
                  BlocBuilder<OrdersCubit, OrdersState>(
                    builder: (context, state) {
                      return OrderDropDown(
                          profileImage: orderCubit.profileImages,
                          directed: true,
                          directBtn: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        const FamilyMembersView()));
                          },
                          title: "Patient".tr(),
                          hintText: "Patient".tr(),
                          value: orderCubit.profileValue,
                          list: orderCubit.profiles,
                          onDropCahnge: (value) {
                            orderCubit.setProfile(value, context);
                          });
                    },
                  ),
                  SizedBox(
                    height: 8.h,
                  ),
                  authForm(
                      maxLines: 5,
                      hintText: "Notes".tr(),
                      title: "Notes".tr(),
                      controller: cubit.noteController,
                      validator: null),
                  SizedBox(
                    height: 24.h,
                  ),
                  Row(
                    children: [
                      Text("Attachments".tr(), style: StylesManger.medium()),
                      Text(
                        "(${"Optional".tr()})",
                        style: StylesManger.small().copyWith(
                            fontSize: 10.sp, fontWeight: FontWeight.w300),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 8.h,
                  ),
                  BlocBuilder<TelemedicineCubit, TelemedicineState>(
                    builder: (context, state) {
                      return InkWell(
                        onTap: () {
                          cubit.pickImage(ImageSource.gallery);
                        },
                        child: Container(
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(
                                  ConstantManger.borderRadius),
                              border:
                                  Border.all(color: ColorManger.lightBlack)),
                          child: Row(
                            children: [
                              CircleAvatar(
                                radius: 10.r,
                                backgroundColor: ColorManger.newPrimary,
                                child: Icon(
                                  Icons.attachment,
                                  color: Colors.white,
                                  size: 15,
                                ),
                              ),
                              SizedBox(
                                width: 16.w,
                              ),
                              Text(
                                cubit.image != null
                                    ? "A file has been choosen"
                                    : "اسحب او قم بالضغط لتحميل الملفات هنا. يمكنك تحميل 4 ملفات كحد اقصي",
                                style: StylesManger.extremelySmall()
                                    .copyWith(color: ColorManger.grey),
                              )
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(
                    height: 27,
                  ),
                  AppButton(
                      textSize: 12.sp,
                      color: ColorManger.newPrimary,
                      name: "PaymentAndCheckout".tr(),
                      onPressed: () {
                        if (orderCubit.profileEntityId != null) {
                          // Parse the original date string into a DateTime object
                          DateTime parsedDateTime =
                              DateFormat("MM-dd-yyyy hh:mm a", 'en')
                                  .parse(visitDateTime)
                                  .toUtc();
                          log(parsedDateTime.toString());

                          // Format the DateTime object to an ISO 8601 string with milliseconds
                          String formattedDateString =
                              DateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", 'en')
                                  .format(parsedDateTime);
                          print(formattedDateString);

                          print(orderCubit.profileEntityId);
                          context.read<AccountCubit>().instantTele = false;
                          cubit.createTeleOrder(
                              isInstant: false,
                              context: context,
                              patientId: orderCubit.profileEntityId!,
                              visitDateTime: formattedDateString);
                        } else {
                          toast(text: "ChangeProfile".tr(), color: Colors.red);
                        }
                      })
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
