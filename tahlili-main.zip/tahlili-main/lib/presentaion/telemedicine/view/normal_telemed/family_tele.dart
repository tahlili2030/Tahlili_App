import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';
import 'package:tahlili/presentaion/telemedicine/cubit/telemedicine_cubit.dart';
import 'package:tahlili/presentaion/telemedicine/view/normal_telemed/check_tele.dart';

import '../../../resources/shared/appbar_divider.dart';

class FamilyTelemedicine extends StatelessWidget {
  const FamilyTelemedicine(
      {super.key, required this.departmentId, required this.departmentName});
  final int departmentId;
  final String departmentName;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<TelemedicineCubit>();
    cubit.initDayValue();
    cubit.initCalender();
    cubit.getTeleDoctors(departmentId: departmentId);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(departmentName, style: StylesManger.medium()),
      ),
      backgroundColor: ColorManger.pageColor,
      body: SingleChildScrollView(
        child: BlocBuilder<TelemedicineCubit, TelemedicineState>(
          builder: (context, state) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const AppBarDivider(),
                const SizedBox(
                  height: 8,
                ),
                Text(
                  "قم باختيار تاريخ الاستشارة الطبية ومن ثم الوقت المناسب للمتابعة",
                  style: StylesManger.small().copyWith(color: ColorManger.grey),
                ),
                SizedBox(height: 16.h),
                Text(
                  "تاريخ الاستشارة",
                  style: StylesManger.medium()
                      .copyWith(fontWeight: FontWeight.w500),
                ),
                SizedBox(height: 16.h),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () async {
                              final result = await showDatePicker(
                                  context: context,
                                  currentDate: cubit.currentDate,
                                  firstDate: DateTime.now(),
                                  lastDate: DateTime.now()
                                      .add(const Duration(days: 30)));
                              if (result != null) {
                                cubit.initialDay = result;
                                cubit.setCurentDay(result, true, 0,
                                    context.locale.languageCode, departmentId);

                                cubit.dayValue = DateFormat(
                                  'EEEE',
                                ).format(result);
                                debugPrint(cubit.dayValue);
                                cubit.findDay(cubit.dayValue!);
                                cubit.calcBusyTimes(result);
                                cubit.fromCleander = true;
                                cubit.selectedHour = null;
                              }
                            },
                            child: Container(
                              padding: EdgeInsets.symmetric(
                                  vertical: 8.h, horizontal: 10.w),
                              decoration: BoxDecoration(
                                  border:
                                      Border.all(color: ColorManger.lightBlack),
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(
                                      ConstantManger.borderRadius)),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    cubit.selectedDate != null
                                        ? cubit.selectedDate!
                                        : context.locale.languageCode == 'ar'
                                            ? DateFormat('EEE, dd MMM', 'ar')
                                                .format(DateTime.now())
                                            : DateFormat('EEE, dd MMM')
                                                .format(DateTime.now()),
                                    style:
                                        StylesManger.extremelySmall().copyWith(
                                      color: ColorManger.grey,
                                    ),
                                  ),
                                  SizedBox(
                                    width: 130.w,
                                  ),
                                  Icon(
                                    Icons.date_range,
                                    color: Colors.black,
                                    size: 15.sp,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(
                                vertical: 10.h, horizontal: 10.w),
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(
                                    ConstantManger.borderRadius),
                                border:
                                    Border.all(color: ColorManger.lightBlack)),
                            child: Row(
                              children: [
                                SvgPicture.asset(
                                  'assets/images/telemed/filter-list.svg',
                                  height: 10.h,
                                  width: 12.w,
                                ),
                                SizedBox(
                                  width: 8.w,
                                ),
                                Text(
                                  "تصنيف البحث",
                                  style: StylesManger.extremelySmall()
                                      .copyWith(color: ColorManger.grey),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      // SizedBox(
                      //   height: 80,
                      //   child: ListView.separated(
                      //     scrollDirection: Axis.horizontal,
                      //     separatorBuilder: (context, index) => const SizedBox(
                      //       width: 10,
                      //     ),
                      //     itemCount: cubit.calender.length,
                      //     itemBuilder: (context, index) => InkWell(
                      //       onTap: () {
                      //         cubit.setCurentDay(
                      //             cubit.calender[index],
                      //             false,
                      //             index,
                      //             context.locale.languageCode,
                      //             departmentId);
                      //         cubit.dayValue = DateFormat('EEEE')
                      //             .format(cubit.calender[index]);
                      //         debugPrint(cubit.dayValue);
                      //         cubit.findDay(cubit.dayValue!);
                      //         cubit.calcBusyTimes(cubit.calender[index]);
                      //         cubit.fromCleander = false;

                      //         print(cubit.dayIndex);
                      //       },
                      //       child: Container(
                      //         width: 80,
                      //         decoration: BoxDecoration(
                      //             color: cubit.selectedDay == index
                      //                 ? ColorManger.primary
                      //                 : Colors.white,
                      //             border: Border.all(color: ColorManger.grey),
                      //             borderRadius: BorderRadius.circular(20)),
                      //         child: Column(
                      //           mainAxisAlignment: MainAxisAlignment.center,
                      //           children: [
                      //             Text(
                      //               context.locale.languageCode == 'ar'
                      //                   ? DateFormat('EEE', 'ar')
                      //                       .format(cubit.calender[index])
                      //                   : DateFormat('EEE')
                      //                       .format(cubit.calender[index]),
                      //               style: StylesManger.medium().copyWith(
                      //                   color: cubit.selectedDay == index
                      //                       ? Colors.white
                      //                       : Colors.black),
                      //             ),
                      //             const SizedBox(
                      //               height: 5,
                      //             ),
                      //             Text(
                      //               DateFormat('dd MMM')
                      //                   .format(cubit.calender[index]),
                      //               style: StylesManger.medium().copyWith(
                      //                   color: cubit.selectedDay == index
                      //                       ? Colors.white
                      //                       : Colors.black),
                      //             ),
                      //           ],
                      //         ),
                      //       ),
                      //     ),
                      //   ),
                      // ),
                      const SizedBox(
                        height: 8,
                      ),
                      state is LoadGetTeleDoctorsState
                          ? Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const SizedBox(
                                  height: 200,
                                ),
                                Center(
                                  child: CircularProgressIndicator(
                                    color: ColorManger.newPrimary,
                                  ),
                                ),
                              ],
                            )
                          : ListView.separated(
                              physics: const NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              itemBuilder: (context, index) => Container(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 8.h),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(
                                            color: ColorManger.lightBlack)),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              height: 80.h,
                                              width: 80.w,
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: ColorManger
                                                          .lightBlack),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          ConstantManger
                                                              .borderRadius),
                                                  image: DecorationImage(
                                                      fit: BoxFit.fill,
                                                      image: CachedNetworkImageProvider(
                                                          EndPoints
                                                                  .baseImageUrl +
                                                              cubit
                                                                  .teleDocotors[
                                                                      index]
                                                                  .image!))),
                                            ),
                                            SizedBox(
                                              width: 8.w,
                                            ),
                                            Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      context.locale
                                                                  .languageCode ==
                                                              'ar'
                                                          ? cubit
                                                              .teleDocotors[
                                                                  index]
                                                              .nameAr!
                                                          : cubit
                                                              .teleDocotors[
                                                                  index]
                                                              .nameEn!,
                                                      style:
                                                          StylesManger.rich(),
                                                    ),
                                                    SizedBox(
                                                      height: 3.h,
                                                    ),
                                                    Text(
                                                      context.locale
                                                                  .languageCode ==
                                                              'ar'
                                                          ? cubit
                                                              .arDegrees[index]
                                                          : cubit
                                                              .enDegrees[index],
                                                      style: StylesManger
                                                              .medium()
                                                          .copyWith(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                              color: ColorManger
                                                                  .newPrimary),
                                                    ),
                                                    SizedBox(
                                                      height: 3.h,
                                                    ),
                                                    Row(
                                                      children: [
                                                        Text(
                                                          "${"Experience".tr()}: ",
                                                          style: StylesManger
                                                                  .small()
                                                              .copyWith(
                                                                  color:
                                                                      ColorManger
                                                                          .grey),
                                                        ),
                                                        Text(
                                                          "${cubit.teleDocotors[index].experienceYears} ${"years".tr()}",
                                                          style: StylesManger
                                                                  .medium()
                                                              .copyWith(
                                                            fontWeight:
                                                                FontWeight.w500,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    SizedBox(
                                                      height: 3.h,
                                                    ),
                                                    Row(
                                                      children: [
                                                        Text(
                                                          "${"مدة الاستشارة الطبية".tr()}: ",
                                                          style: StylesManger
                                                                  .small()
                                                              .copyWith(
                                                                  color:
                                                                      ColorManger
                                                                          .grey),
                                                        ),
                                                        Text(
                                                          "${cubit.teleDocotors[index].sessionTime} ${"Min".tr()}",
                                                          style: StylesManger
                                                                  .medium()
                                                              .copyWith(
                                                            fontWeight:
                                                                FontWeight.w500,
                                                          ),
                                                        ),
                                                      ],
                                                    )
                                                  ],
                                                ),
                                                Column(
                                                  children: [
                                                    Text(
                                                      "SessionPrice".tr(),
                                                      style: StylesManger
                                                              .extremelySmall()
                                                          .copyWith(
                                                              color: ColorManger
                                                                  .newPrimary),
                                                    ),
                                                    SizedBox(
                                                      height: 4.h,
                                                    ),
                                                    Container(
                                                      padding:
                                                          EdgeInsets.all(6.sp),
                                                      decoration: BoxDecoration(
                                                          color: Color(
                                                              0xFFEDFCFF)),
                                                      child: Center(
                                                        child: Text(
                                                          "${cubit.teleDocotors[index].price} ${"SAR".tr()}",
                                                          style: StylesManger
                                                                  .small()
                                                              .copyWith(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700,
                                                                  color: Color(
                                                                      0xff00828E)),
                                                        ),
                                                      ),
                                                    )
                                                  ],
                                                )
                                              ],
                                            )
                                          ],
                                        ),
                                        SizedBox(
                                          height: 16.h,
                                        ),
                                        Text(
                                          "وصف عن الطبيب",
                                          style: StylesManger.medium().copyWith(
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                        SizedBox(
                                          height: 8.h,
                                        ),
                                        Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 4.w),
                                          child: Text(
                                            "datadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadatadata",
                                            style: StylesManger.rich().copyWith(
                                                fontSize: 8.sp,
                                                color: ColorManger.grey),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        SizedBox(
                                          height: 24.h,
                                        ),
                                        SizedBox(
                                          height: 40,
                                          child: ListView.separated(
                                              scrollDirection: Axis.horizontal,
                                              itemBuilder:
                                                  (context, timeIndex) =>
                                                      InkWell(
                                                        onTap: () {
                                                          cubit.selectHour(
                                                              timeIndex,
                                                              cubit.dates[index]
                                                                  .doctorId);
                                                          cubit.sessoionPrice =
                                                              cubit
                                                                  .teleDocotors[
                                                                      index]
                                                                  .price!
                                                                  .toDouble();

                                                          Navigator.push(
                                                              context,
                                                              MaterialPageRoute(
                                                                  builder: (context) => CheckTeleView(
                                                                      degree: context.locale.languageCode ==
                                                                              'ar'
                                                                          ? cubit.arDegrees[
                                                                              index]
                                                                          : cubit.enDegrees[
                                                                              index],
                                                                      visitDateTime:
                                                                          "${DateFormat('dd-MM-yyyy', 'en').format(cubit.currentDate!)} ${cubit.dates[index].teledates[cubit.dayIndex!].dates[timeIndex]}",
                                                                      seassionTime: context.locale.languageCode ==
                                                                              'ar'
                                                                          ? "${DateFormat('dd MMM', 'ar').format(cubit.currentDate!)} ${cubit.dates[index].teledates[cubit.dayIndex!].dates[timeIndex]}"
                                                                          : "${DateFormat('dd MMM').format(cubit.currentDate!)} ${cubit.dates[index].teledates[cubit.dayIndex!].dates[timeIndex]}",
                                                                      doctor: cubit
                                                                              .teleDocotors[
                                                                          index])));
                                                        },
                                                        child: Container(
                                                          width: 80,
                                                          decoration: BoxDecoration(
                                                              border: Border.all(
                                                                  color: ColorManger
                                                                      .lightBlack),
                                                              color: cubit.selectedHour ==
                                                                          timeIndex &&
                                                                      cubit.doctorId ==
                                                                          cubit
                                                                              .dates[
                                                                                  index]
                                                                              .doctorId
                                                                  ? Color(
                                                                      0xFFEDFCFF)
                                                                  : Colors
                                                                      .white,
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          10)),
                                                          child: Center(
                                                            child: Text(
                                                              cubit
                                                                  .dates[index]
                                                                  .teledates[cubit
                                                                      .dayIndex!]
                                                                  .dates[timeIndex],
                                                              style: StylesManger.small().copyWith(
                                                                  color: cubit.selectedHour ==
                                                                              timeIndex &&
                                                                          cubit.doctorId ==
                                                                              cubit
                                                                                  .dates[
                                                                                      index]
                                                                                  .doctorId
                                                                      ? ColorManger
                                                                          .newPrimary
                                                                      : ColorManger
                                                                          .blueBlack),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                              separatorBuilder:
                                                  (context, index) =>
                                                      const SizedBox(
                                                        width: 10,
                                                      ),
                                              /*03-04-2024*/
                                              itemCount: cubit.dayIndex !=
                                                          null &&
                                                      cubit.dates[index]
                                                                  .teledates[
                                                              cubit
                                                                  .dayIndex!] !=
                                                          null
                                                  ? cubit
                                                      .dates[index]
                                                      .teledates[
                                                          cubit.dayIndex!]
                                                      .dates
                                                      .length
                                                  : 0),
                                        )
                                      ],
                                    ),
                                  ),
                              separatorBuilder: (context, index) =>
                                  const SizedBox(
                                    height: 8,
                                  ),
                              itemCount: cubit.teleDocotors.length),
                      const SizedBox(
                        height: 10,
                      )
                    ],
                  ),
                )
              ],
            );
          },
        ),
      ),
    );
  }
}
