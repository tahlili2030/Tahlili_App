import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/telemedicine/cubit/telemedicine_cubit.dart';
import 'package:tahlili/presentaion/telemedicine/view/normal_telemed/family_tele.dart';

import '../../../resources/styles_manger.dart';

class DepartmentsView extends StatelessWidget {
  const DepartmentsView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<TelemedicineCubit>();
    cubit.getDepartments(filterQuery: "");
    cubit.departmentId = null;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title:
            Text("TelemedicineConsultation".tr(), style: StylesManger.medium()),
      ),
      backgroundColor: ColorManger.pageColor,
      body: Column(
        children: [
          Container(
            width: double.infinity,
            height: 1,
            color: ColorManger.grey,
          ),
          const SizedBox(
            height: 16,
          ),
          BlocBuilder<TelemedicineCubit, TelemedicineState>(
            builder: (context, state) {
              return Expanded(
                child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: cubit.departments.isEmpty
                        ? Center(
                            child: CircularProgressIndicator(),
                          )
                        : GridView.builder(
                            itemCount: cubit.departments.length,
                            shrinkWrap: true,
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 2,
                                    crossAxisSpacing: 24.w,
                                    mainAxisSpacing: 24.h,
                                    mainAxisExtent: 130.h),
                            itemBuilder: (context, index) => InkWell(
                                  onTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                FamilyTelemedicine(
                                                  departmentId: cubit
                                                      .departments[index].id!,
                                                  departmentName: context.locale
                                                              .languageCode ==
                                                          'ar'
                                                      ? cubit
                                                          .departmentsAr[index]
                                                      : cubit
                                                          .departmentsEn[index],
                                                )));
                                  },
                                  child: Container(
                                    padding: EdgeInsetsDirectional.only(
                                      top: 16.sp,
                                      start: 16.sp,
                                      end: 16.sp,
                                    ),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: ColorManger.lightBlack),
                                        borderRadius: BorderRadius.circular(
                                            ConstantManger.borderRadius)),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        CircleAvatar(
                                          backgroundColor: Color(0xffF9F9F9),
                                          radius: 30.r,
                                          child: SvgPicture.asset(
                                            "assets/images/telemed/general.svg",
                                            height: 60.h,
                                            width: 60.w,
                                          ),
                                        ),
                                        // Container(
                                        //   height: 60.h,
                                        //   width: 60.w,
                                        //   decoration: BoxDecoration(
                                        //       image: DecorationImage(
                                        //           image:
                                        //               CachedNetworkImageProvider(
                                        //                   EndPoints
                                        //                           .baseImageUrl +
                                        //                       cubit
                                        //                           .departments[
                                        //                               index]
                                        //                           .image!))),
                                        // ),
                                        SizedBox(
                                          height: 16.h,
                                        ),
                                        Expanded(
                                          child: Text(
                                            context.locale.languageCode == 'ar'
                                                ? cubit.departmentsAr[index]
                                                : cubit.departmentsEn[index],
                                            style: StylesManger.medium()
                                                .copyWith(
                                                    color:
                                                        ColorManger.newPrimary),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.center,
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                ))),
              );
            },
          )
        ],
      ),
    );
  }
}
