import 'dart:developer';

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:tahlili/presentaion/page_details/pages/check_out_page.dart';
import 'package:tahlili/presentaion/page_details/pages/fill_data_page.dart';

import '../../../data/requests/order/request_order.dart';
import '../pages/item_details_page.dart';
import '../pages/service_place_page.dart';

part 'page_details_state.dart';

class PageDetailsCubit extends Cubit<PageDetailsState> {
  PageDetailsCubit() : super(PageDetailsInitial());

  List<Widget> pageDetails = [
    ItemDetailsPage(),
    ServicePlacePage(),
    FillDataPgae(),
    CheckOutPage()
  ];
  List<Widget> cartDetails = [
    ItemDetailsPage(),
    FillDataPgae(),
    CheckOutPage()
  ];
  bool isCart = false;

  List<String> pageDetailsHeaders = [
    "تحديد الباقة",
    "مكان الخدمة",
    "ملئ البيانات",
    "الدفع"
  ];

  final PageController pageDetailsController = PageController();

  int pageIndex = 0;

  incPageIndex() {
    pageIndex++;
    log(pageIndex.toString());
    emit(SetPageIndexState());
  }

  decPageIndex() {
    pageIndex--;
    log(pageIndex.toString());
    emit(SetPageIndexState());
  }

  RequestOrderData? orderData;

  clearData() {
    pageIndex = 0;
    emit(ClearDataState());
  }
}
