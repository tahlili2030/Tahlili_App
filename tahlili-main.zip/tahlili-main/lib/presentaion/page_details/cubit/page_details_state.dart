part of 'page_details_cubit.dart';

sealed class PageDetailsState {
  const PageDetailsState();

  @override
  List<Object> get props => [];
}

final class PageDetailsInitial extends PageDetailsState {}

class SetPageIndexState extends PageDetailsState {}

class ClearDataState extends PageDetailsState {}
