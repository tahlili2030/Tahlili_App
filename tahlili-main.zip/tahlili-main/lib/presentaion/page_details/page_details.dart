import 'dart:io';

import 'package:expandable_page_view/expandable_page_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/presentaion/page_details/cubit/page_details_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

class PageDetailsView extends StatelessWidget {
  const PageDetailsView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<PageDetailsCubit>();
    return BlocBuilder<PageDetailsCubit, PageDetailsState>(
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            leading: IconButton(
                onPressed: () {
                  if (cubit.pageIndex == 0) {
                    Navigator.pop(context);
                  } else {
                    cubit.decPageIndex();
                    cubit.pageDetailsController.previousPage(
                        duration: Duration(milliseconds: 500),
                        curve: Curves.bounceIn);
                  }
                },
                icon: Platform.isAndroid
                    ? Icon(Icons.arrow_back)
                    : Icon(Icons.arrow_back_ios)),
          ),
          backgroundColor: ColorManger.pageColor,
          body: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: Column(
                children: [
                  Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 24.h),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(
                          color: ColorManger.lightBlack,
                        ),
                        borderRadius:
                            BorderRadius.circular(ConstantManger.borderRadius)),
                    child: SingleChildScrollView(
                      // scrollDirection: Axis.horizontal,
                      physics: NeverScrollableScrollPhysics(),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ...List.generate(
                              cubit.pageDetailsHeaders.length,
                              (index) => Padding(
                                    padding:
                                        EdgeInsetsDirectional.only(end: 8.w),
                                    child: Row(
                                      children: [
                                        CircleAvatar(
                                          backgroundColor:
                                              cubit.pageIndex >= index
                                                  ? Color(0xff00A1B0)
                                                  : Color(0xffA5A5A5),
                                          radius: 5.r,
                                          child: Text(
                                            "${index + 1}",
                                            style: StylesManger.extremelySmall()
                                                .copyWith(color: Colors.white),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 2.w,
                                        ),
                                        Text(
                                          cubit.pageDetailsHeaders[index],
                                          style: StylesManger.extremelySmall()
                                              .copyWith(
                                                  fontSize: 10.sp,
                                                  color:
                                                      cubit.pageIndex >= index
                                                          ? Color(0xff00A1B0)
                                                          : Color(0xffA5A5A5)),
                                        ),
                                        SizedBox(
                                          width: 2.w,
                                        ),
                                        if (index != 3)
                                          Container(
                                            height: 2.h,
                                            width: 10.w,
                                            color: cubit.pageIndex >= index
                                                ? Color(0xff00A1B0)
                                                : Color(0xffA5A5A5),
                                          )
                                      ],
                                    ),
                                  ))
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(
                          color: ColorManger.lightBlack,
                        ),
                        borderRadius:
                            BorderRadius.circular(ConstantManger.borderRadius)),
                    child: ExpandablePageView.builder(
                      onPageChanged: (ondex) {
                        print(ondex);
                      },
                      controller: cubit.pageDetailsController,
                      itemCount: cubit.pageDetails.length,
                      physics: NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) =>
                          cubit.pageDetails[cubit.pageIndex],
                    ),
                  ),
                  SizedBox(
                    height: 16.h,
                  )
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
