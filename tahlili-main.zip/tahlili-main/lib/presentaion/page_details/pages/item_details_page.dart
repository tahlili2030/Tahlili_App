import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/data/requests/order/request_order.dart';
import 'package:tahlili/presentaion/page_details/cubit/page_details_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';
import 'package:tahlili/app/extenstions.dart';
import '../../../data/response/home/response_home.dart';
import '../../home/cubit/home_cubit.dart';

class ItemDetailsPage extends StatelessWidget {
  const ItemDetailsPage({super.key, this.deals});
  final ResponsePackageDetails? deals;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<PageDetailsCubit>();
    return BlocBuilder<PageDetailsCubit, PageDetailsState>(
      builder: (context, state) {
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 16.h,
              ),
              Text(
                context.locale.languageCode == 'ar'
                    ? context
                        .read<HomeCubit>()
                        .dealsDetails
                        .first
                        .package!
                        .nameAr!
                    : context
                        .read<HomeCubit>()
                        .dealsDetails
                        .first
                        .package!
                        .nameEn!,
                style: StylesManger.rich(),
              ),
              SizedBox(
                height: 16.h,
              ),
              SizedBox(
                height: 165.h,
                child: Stack(
                  children: [
                    Container(
                      height: 165.h,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                            fit: BoxFit.fill,
                            image: CachedNetworkImageProvider(
                                context.locale.languageCode == 'ar'
                                    ? EndPoints.baseImageUrl +
                                        context
                                            .read<HomeCubit>()
                                            .dealsDetails
                                            .first
                                            .package!
                                            .imageAR!
                                    : EndPoints.baseImageUrl +
                                        context
                                            .read<HomeCubit>()
                                            .dealsDetails
                                            .first
                                            .package!
                                            .imageEN!)),
                        borderRadius:
                            BorderRadius.circular(ConstantManger.borderRadius),
                      ),
                    ),
                    PositionedDirectional(
                      top: 8.h,
                      end: 8.w,
                      child: Container(
                          padding: EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: Color(0xffE6FBF3),
                            borderRadius: BorderRadius.circular(
                                ConstantManger.borderRadius),
                          ),
                          child: Row(
                            children: [
                              Text(
                                "${context.read<HomeCubit>().dealsDetails.first.tat!.toInt()} ساعة",
                                style: StylesManger.extremelySmall().copyWith(
                                  color: Color(0xff5DB896),
                                ),
                              ),
                              SizedBox(
                                width: 4.w,
                              ),
                              Icon(
                                Icons.watch_later_outlined,
                                size: 15,
                                color: Color(0xff5DB896),
                              ),
                            ],
                          )),
                    ),
                    PositionedDirectional(
                      top: 8.h,
                      start: 8.w,
                      child: CircleAvatar(
                        backgroundColor: Color(0xffE6FBF3),
                        child: Icon(
                          Icons.favorite_border_rounded,
                          color: Color(0xff5DB896),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 16.h,
              ),
              Text(
                "لا شك أن مشكلة تساقط الشعر مشكلة محرجة ولمعرفة العلاج لابد من معرفة الأسباب عن طريق التشخيص الصحيح للوقوف على الاسباب لعلاج أسرع وأدق. ",
                style: StylesManger.small().copyWith(color: Color(0xffA5A5A5)),
              ),
              SizedBox(
                height: 16.h,
              ),
              Text(
                "التحاليل المشمولة في الباقة",
                style: StylesManger.small()
                    .copyWith(color: Colors.black, fontWeight: FontWeight.w700),
              ),
              SizedBox(
                height: 16.h,
              ),
              ...List.generate(
                context
                    .read<HomeCubit>()
                    .dealsDetails
                    .first
                    .package!
                    .packagesTests!
                    .length,
                (index) => context.locale.languageCode == 'ar'
                    ? Text(
                        "●  ${context.read<HomeCubit>().dealsDetails.first.package!.packagesTests![index].testNameAr.orEmpty()}",
                        style: StylesManger.small().copyWith(
                          color: Color(0xffA5A5A5),
                        ),
                      )
                    : Text(
                        "●  ${context.read<HomeCubit>().dealsDetails.first.package!.packagesTests![index].testNameEn.orEmpty()}",
                        style: StylesManger.small().copyWith(
                          color: Color(0xffA5A5A5),
                        ),
                      ),
              ),
              SizedBox(
                height: 16.h,
              ),
              Row(
                children: [
                  Icon(
                    Icons.watch_later_outlined,
                    color: Color(0xffA5A5A5),
                  ),
                  SizedBox(
                    width: 8.w,
                  ),
                  Text(
                    "وقت استلام النتيجة:",
                    style: StylesManger.small().copyWith(
                      color: Color(0xffA5A5A5),
                    ),
                  ),
                  SizedBox(
                    width: 4.w,
                  ),
                  Text(
                    "${context.read<HomeCubit>().dealsDetails.first.tat!.toInt()} ساعة",
                    style: StylesManger.small().copyWith(
                      color: ColorManger.newPrimary,
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 16.h,
              ),
              Container(
                height: 32.h,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: ColorManger.newPrimary.withOpacity(.1),
                    borderRadius:
                        BorderRadius.circular(ConstantManger.borderRadius)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      context.locale.languageCode == 'ar'
                          ? "سعر ${context.read<HomeCubit>().dealsDetails.first.package!.nameAr!}: "
                          : "price ${context.read<HomeCubit>().dealsDetails.first.package!.nameEn!}: ",
                      style: StylesManger.small()
                          .copyWith(color: ColorManger.newPrimary),
                    ),
                    Text(
                      " ${context.read<HomeCubit>().dealsDetails.first.price!} ${"SAR".tr()}",
                      style: StylesManger.small().copyWith(
                          fontWeight: FontWeight.w600,
                          color: ColorManger.newPrimary),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 16.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: AppButton(
                        textColor: ColorManger.newPrimary,
                        textSize: 10.sp,
                        color: Colors.white,
                        name: "اضف الي السلة",
                        onPressed: () {}),
                  ),
                  SizedBox(
                    width: 90.w,
                  ),
                  Expanded(
                    child: AppButton(
                        textColor: Colors.white,
                        textSize: 12.sp,
                        color: ColorManger.newPrimary,
                        name: "احجز الان",
                        onPressed: () {
                          cubit.incPageIndex();
                          cubit.pageDetailsController.nextPage(
                              duration: Duration(milliseconds: 500),
                              curve: Curves.bounceIn);
                        }),
                  )
                ],
              ),
              SizedBox(
                height: 16.h,
              ),
            ],
          ),
        );
      },
    );
  }
}
