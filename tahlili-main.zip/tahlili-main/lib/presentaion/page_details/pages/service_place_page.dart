import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/presentaion/page_details/cubit/page_details_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

import '../../../data/requests/order/request_order.dart';
import '../../orders/view/home/home_order_first_page.dart';
import '../../orders/view/lab/lab_order_page.dart';
import '../../resources/shared/app_button.dart';

class ServicePlacePage extends StatelessWidget {
  const ServicePlacePage({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<PageDetailsCubit>();
    return BlocBuilder<PageDetailsCubit, PageDetailsState>(
      builder: (context, state) {
        return Padding(
          padding: EdgeInsets.symmetric(vertical: 24.h, horizontal: 55.w),
          child: Column(
            children: [
              Icon(
                Icons.location_on_outlined,
                color: ColorManger.newPrimary,
                size: 70,
              ),
              SizedBox(
                height: 24.h,
              ),
              Text(
                "اختيار مكان الخدمة",
                style: StylesManger.rich(),
              ),
              SizedBox(
                height: 8.h,
              ),
              Text(
                context.read<PageDetailsCubit>().orderData!.packageName,
                style: StylesManger.small().copyWith(color: Color(0xffA5A5A5)),
              ),
              SizedBox(
                height: 24.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: AppButton(
                        radius: 10.r,
                        textColor: ColorManger.newPrimary,
                        textSize: 12.sp,
                        color: Colors.white,
                        name: "في المختبر",
                        onPressed: () {}),
                  ),
                  SizedBox(
                    width: 20.w,
                  ),
                  Expanded(
                    child: AppButton(
                        radius: 10.r,
                        textColor: Colors.white,
                        textSize: 12.sp,
                        color: ColorManger.newPrimary,
                        name: "في المنزل",
                        onPressed: () {
                          cubit.incPageIndex();
                          cubit.pageDetailsController.nextPage(
                              duration: Duration(milliseconds: 500),
                              curve: Curves.bounceIn);
                        }),
                  )
                ],
              ),
              SizedBox(
                height: 16.h,
              ),
            ],
          ),
        );
      },
    );
  }
}
