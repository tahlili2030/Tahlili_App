import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/presentaion/page_details/cubit/page_details_cubit.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

import '../../account/view/addresses/patient_addresses_view.dart';
import '../../orders/cubit/orders_cubit.dart';
import '../../orders/view/home/home_order_first_page.dart';
import '../../profiles/view/family_members.dart';
import '../../resources/color_manger.dart';
import '../../resources/shared/app_button.dart';

class FillDataPgae extends StatelessWidget {
  const FillDataPgae({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<OrdersCubit>();
    cubit.clearOrderData();
    cubit.getAddresses(context);
    cubit.getProfileNames(context);
    final pageCubit = context.read<PageDetailsCubit>();
    cubit.getLabWorkingHours();
    cubit.setProfile(0, context);
    cubit.setAddress(0, context);
    return BlocBuilder<OrdersCubit, OrdersState>(
      builder: (context, state) {
        return BlocBuilder<PageDetailsCubit, PageDetailsState>(
          builder: (context, state) {
            return Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "ملئ البيانات",
                    style: StylesManger.rich(),
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  OrderDropDown(
                      profileImage: cubit.profileImages,
                      directed: true,
                      directBtn: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const FamilyMembersView()));
                      },
                      title: "Patient".tr(),
                      hintText: "Patient".tr(),
                      value: cubit.profileValue,
                      list: cubit.profiles,
                      onDropCahnge: (value) {
                        cubit.setProfile(value, context);
                      }),
                  OrderDropDown(
                      directed: true,
                      directBtn: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const AddressessView()));
                      },
                      profileImage: [],
                      title: "Address".tr(),
                      hintText: "Address".tr(),
                      value: cubit.addressValue,
                      list: cubit.addresses,
                      onDropCahnge: (value) {
                        cubit.setAddress(value, context);
                      }),
                  Row(
                    children: [
                      Expanded(
                        child: OrderDropDown(
                            profileImage: [],
                            title: "Date".tr(),
                            hintText: "Date".tr(),
                            value: cubit.dateValue,
                            list: context.locale.languageCode == 'ar'
                                ? cubit.arDates
                                : cubit.enDates,
                            onDropCahnge: (value) {
                              cubit.setDate(value);
                            }),
                      ),
                      SizedBox(
                        width: 8.w,
                      ),
                      Expanded(
                        child: OrderDropDown(
                            profileImage: [],
                            title: "VisitingTime".tr(),
                            hintText: "VisitingTime".tr(),
                            value: cubit.hourValue,
                            list: cubit.selectedDay,
                            onDropCahnge: (value) {
                              cubit.setHour(value);
                            }),
                      ),
                    ],
                  ),
                  OrderDropDown(
                      profileImage: [],
                      title: "Nurse".tr(),
                      hintText: "Nurse".tr(),
                      value: cubit.nurseValue,
                      list: cubit.enNurses,
                      onDropCahnge: (value) {
                        cubit.setNurse(
                            value,
                            context.read<PageDetailsCubit>().orderData!.price,
                            context.read<PageDetailsCubit>().orderData!.isTest
                                ? null
                                : context
                                    .read<PageDetailsCubit>()
                                    .orderData!
                                    .itemId,
                            context.read<PageDetailsCubit>().orderData!.isTest
                                ? context
                                    .read<PageDetailsCubit>()
                                    .orderData!
                                    .itemId
                                : null);
                      }),
                  SizedBox(
                    height: 32.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: AppButton(
                            radius: 10.r,
                            textColor: ColorManger.newPrimary,
                            textSize: 12.sp,
                            color: Colors.white,
                            name: "السابق",
                            onPressed: () {
                              pageCubit.pageDetailsController.previousPage(
                                  duration: Duration(milliseconds: 500),
                                  curve: Curves.bounceIn);
                              context.read<PageDetailsCubit>().decPageIndex();
                            }),
                      ),
                      SizedBox(
                        width: 20.w,
                      ),
                      Expanded(
                        child: AppButton(
                            radius: 10.r,
                            textColor: Colors.white,
                            textSize: 12.sp,
                            color: ColorManger.newPrimary,
                            name: "التالي",
                            onPressed: () {
                              pageCubit.pageDetailsController.nextPage(
                                  duration: Duration(milliseconds: 500),
                                  curve: Curves.bounceIn);
                              context.read<PageDetailsCubit>().incPageIndex();
                            }),
                      )
                    ],
                  ),
                  // Row(
                  //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //   children: [
                  //     SizedBox(
                  //       width: 180,
                  //       child: AppButton(
                  //           color: ColorManger.primary,
                  //           name: "AddToCart".tr(),
                  //           onPressed: () {
                  //             if (cubit.homeFirstPgaeValidation()) {
                  //               // Navigator.push(
                  //               //     context,
                  //               //     MaterialPageRoute(
                  //               //         builder: (context) =>
                  //               //             HomeOrderSecondPage(
                  //               //               orderData: orderData,
                  //               //             )));
                  //             }
                  //           }),
                  //     ),
                  //     SizedBox(
                  //       width: 180,
                  //       child: AppButton(
                  //           textColor: ColorManger.primary,
                  //           color: Colors.white,
                  //           name: "Add to cart".tr(),
                  //           onPressed: () {
                  //             if (cubit.homeFirstPgaeValidation()) {
                  //               // String inputDateTime =
                  //               //     "${cubit.date} ${cubit.hour}";
                  //               // print(inputDateTime);
                  //               // // // DateTime inputDate =
                  //               // // //     DateFormat('EEEE, yyyy-MM-dd hh:mm a',)
                  //               // // //         .parse(inputDateTime);
                  //               // // DateTime utcDate = inputDate.toUtc();
                  //               // // String outputDateString =
                  //               // //     DateFormat('yyyy-MM-ddTHH:mm:ssZ','en')
                  //               // //         .format(utcDate);
                  //               // String formattedDate =
                  //               //     convertToIso8601(inputDateTime);

                  //               // print(formattedDate);
                  //               // //         print(outputDateString);
                  //               // // DateFormat inputFormat =
                  //               // //     DateFormat("EEEE, dd-MM-yyyy HH:mm");
                  //               // // DateTime dateTime =
                  //               // //     inputFormat.parse(inputDateTime);

                  //               // context.read<CartCubit>().addTotCart(
                  //               //         cart: RequestCart(
                  //               //       cubit.profileEntityId!,
                  //               //       orderData.isTest
                  //               //           ? orderData.itemId
                  //               //           : null,
                  //               //       !orderData.isTest
                  //               //           ? orderData.itemId
                  //               //           : null,
                  //               //       formattedDate!,
                  //               //       null,
                  //               //       cubit.addressId!,
                  //               //     ));
                  //             }
                  //           }),
                  //     )
                  //   ],
                  // )
                ],
              ),
            );
          },
        );
      },
    );
  }
}
