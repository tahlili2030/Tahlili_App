import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/presentaion/page_details/cubit/page_details_cubit.dart';

import '../../account/cubit/account_cubit.dart';
import '../../cart/view/home_cart_view.dart';
import '../../orders/cubit/orders_cubit.dart';
import '../../orders/view/home/home_order_first_page.dart';
import '../../resources/color_manger.dart';
import '../../resources/constant_manger.dart';
import '../../resources/shared/app_button.dart';
import '../../resources/styles_manger.dart';

class CheckOutPage extends StatelessWidget {
  const CheckOutPage({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<OrdersCubit>();
    cubit.clacTotal(context.read<PageDetailsCubit>().orderData!.price);
    final pageCubit = context.read<PageDetailsCubit>();
    cubit.getPayMentType();
    return BlocBuilder<OrdersCubit, OrdersState>(
      builder: (context, state) {
        return BlocBuilder<PageDetailsCubit, PageDetailsState>(
          builder: (context, state) {
            return Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "تفاصيل الدفع",
                    style: StylesManger.rich(),
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  Container(
                    height: 1,
                    width: double.infinity,
                    color: Color(0xffE2E6E9),
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  orderDetails(
                      title: "Subtotal".tr(),
                      content:
                          "${context.read<PageDetailsCubit>().orderData!.price} ${"SAR".tr()}"),
                  orderDetails(title: "CouponDiscount".tr(), content: "0"),
                  orderDetails(
                      title: "NurseFees".tr(), content: "${cubit.nurseFees}"),
                  context.read<AccountCubit>().patient.first.nationalityId ==
                          192
                      ? const SizedBox()
                      : orderDetails(
                          title: "VAT".tr(), content: "${ConstantManger.vat}%"),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        cubit.patientWallet != null
                            ? "${"WalletCredit".tr()} (${cubit.patientWallet} ${"SAR".tr()})"
                            : "${"WalletCredit".tr()} (0 ${"SAR".tr()})",
                        style: StylesManger.small().copyWith(
                            color: ColorManger.blueBlack,
                            fontWeight: FontWeight.w500),
                      ),
                      Transform.scale(
                        alignment: AlignmentDirectional.topEnd,
                        scale: .8,
                        child: Switch(
                            materialTapTargetSize: MaterialTapTargetSize.padded,
                            activeTrackColor: ColorManger.primary,
                            inactiveTrackColor: Colors.grey,
                            value: cubit.useWallet,
                            onChanged: (value) {
                              cubit.switchWallet(
                                  value,
                                  context
                                      .read<PageDetailsCubit>()
                                      .orderData!
                                      .price);
                            }),
                      )
                    ],
                  ),
                  orderDetails(
                      title: "Total".tr(),
                      content: "${cubit.total} ${"SAR".tr()}"),
                  SizedBox(
                    height: 16.h,
                  ),
                  Container(
                    height: 1,
                    width: double.infinity,
                    color: Color(0xffE2E6E9),
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: OrderDropDown(
                            profileImage: [],
                            title: "PaymentType".tr(),
                            hintText: "PaymentType".tr(),
                            value: cubit.paymentValue,
                            list: cubit.methods,
                            onDropCahnge: (value) {
                              cubit.setPayment(value);
                            }),
                      ),
                      SizedBox(
                        width: 8.w,
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("CouponDiscount".tr(),
                                style: StylesManger.medium().copyWith(
                                    color: Colors.black,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500)),
                            const SizedBox(
                              height: 8,
                            ),
                            Row(
                              children: [
                                Expanded(
                                  child: TextFormField(
                                    //  controller: cubit.couponController,
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(10.r))),
                                        contentPadding: EdgeInsets.zero,
                                        suffixIcon: Container(
                                          height: 32.h,
                                          width: 44.w,
                                          decoration: BoxDecoration(
                                              color: ColorManger.newPrimary,
                                              borderRadius:
                                                  BorderRadiusDirectional.only(
                                                      topEnd:
                                                          Radius.circular(10.r),
                                                      bottomEnd:
                                                          Radius.circular(
                                                              10.r))),
                                        )),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: AppButton(
                            radius: 10.r,
                            textColor: ColorManger.newPrimary,
                            textSize: 12.sp,
                            color: Colors.white,
                            name: "السابق",
                            onPressed: () {
                              pageCubit.pageDetailsController.previousPage(
                                  duration: Duration(milliseconds: 500),
                                  curve: Curves.bounceIn);
                              context.read<PageDetailsCubit>().decPageIndex();
                            }),
                      ),
                      SizedBox(
                        width: 20.w,
                      ),
                      Expanded(
                        child: AppButton(
                            radius: 10.r,
                            textColor: Colors.white,
                            textSize: 12.sp,
                            color: ColorManger.newPrimary,
                            name: "حجز الزيارة",
                            onPressed: () {
                              context.read<AccountCubit>().instantTele = false;
                              if (cubit.homeCheckPgaeValidation()) {
                                cubit.createHomeOrder(
                                    context: context,
                                    isTest: context
                                        .read<PageDetailsCubit>()
                                        .orderData!
                                        .isTest,
                                    itemId: context
                                        .read<PageDetailsCubit>()
                                        .orderData!
                                        .itemId,
                                    labId: context
                                        .read<PageDetailsCubit>()
                                        .orderData!
                                        .labId);
                              }
                              context.read<PageDetailsCubit>().incPageIndex();
                            }),
                      )
                    ],
                  ),
                  // AppButton(
                  //     color: ColorManger.primary,
                  //     name: "PaymentAndCheckout".tr(),
                  //     onPressed: () {

                  //     })
                ],
              ),
            );
          },
        );
      },
    );
  }
}
