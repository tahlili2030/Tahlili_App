import 'dart:convert';
import 'dart:io';
import 'package:http_parser/http_parser.dart' show MediaType;
import 'package:http/http.dart' as http;

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/domain/repository/account/account.dart';

import '../../../app/pref_manager.dart';
import '../../../data/network/error_handler.dart';
import '../../../data/requests/accounts/request_account.dart';
import '../../../data/response/account/reponse_account.dart';
import '../../../data/response/response.dart';

part 'prescription_state.dart';

class PrescriptionCubit extends Cubit<PrescriptionState> {
  PrescriptionCubit(this._accountReposiotry, this._preferancesManager)
      : super(PrescriptionInitial());
  final BaseAccountReposiotry _accountReposiotry;
  final PreferancesManager _preferancesManager;

  final TextEditingController noteController = TextEditingController();
  List<ResponsePrescriptions> prescriptions = [];
  getPrescriptions() async {
    emit(LoadGetPrescriptionsState());
    try {
      final result = await _accountReposiotry.getPrescriptions();

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetPrescriptionsState(failure.message));
      }, (prescriptions) {
        debugPrint(prescriptions.length.toString());
        this.prescriptions.addAll(prescriptions);
        emit(SuccessGetPrescriptionsState(prescriptions));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetPrescriptionsState(e.toString()));
    }
  }

  getPrescriptionsDetails() async {
    emit(LoadGetPrescriptionDetailsState());
    try {
      final result =
          await _accountReposiotry.getPrescriptionDetails(prescriptionId: 0);

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetPrescriptionDetailsState(failure.message));
      }, (prescriptions) {
        debugPrint(prescriptions.length.toString());
        emit(SuccessGetPrescriptionDetailsState(prescriptions));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetPrescriptionDetailsState(e.toString()));
    }
  }

  Future addPrescription(
      {required String languageCode, required int patientId}) async {
    DateTime now = DateTime.now();
    String date = DateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", 'en').format(now);
    emit(LoadAddPrescriptionsState());
    try {
      final result = await _accountReposiotry.addPrescription(
          prescriptions:
              RequestPrescriptions(patientId, date, noteController.text));

      result.fold((failure) async {
        debugPrint(failure);
        await handleSuccessMessages(
            failure.orEmpty(), languageCode, Colors.red);
        emit(FailureAddPrescriptionsState(failure));
      }, (response) async {
        debugPrint(response.message);

        if (image != null) uploadFileX(image!, response.id!, 'Prescriptions');
        await handleSuccessMessages(
            response.message.orEmpty(), languageCode, Colors.green);

        emit(SuccessAddPrescriptionsState(response));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureAddPrescriptionsState(e.toString()));
    }
  }

  File? image;
  pickImage(ImageSource imageSource) async {
    XFile? file = await ImagePicker().pickImage(source: imageSource);
    if (file != null) {
      // Convert XFile to File

      image = File(file.path);
    }
    emit(PickFIleState());
  }

  Future<void> uploadFileX(File imageFile, int id, String entity) async {
    final authToken = _preferancesManager.getData(key: userToken);
    String apiUrl =
        "https://dev-api.tahliliapp.store/Files/UploadFile?id=$id&entityName=$entity&isPdf=false"; // Replace with your API endpoint URL
    print(apiUrl);

    var request = http.MultipartRequest('POST', Uri.parse(apiUrl));
    request.headers['Content-Type'] = 'multipart/form-data';
    request.headers['Authorization'] = 'Bearer $authToken';

    var imageStream = http.ByteStream(imageFile.openRead());
    var imageLength = await imageFile.length();
    print("object1");
    var multipartFile = http.MultipartFile(
      'files',
      imageStream,
      imageLength,
      filename: imageFile.path.split("/").last,
      contentType: MediaType('image', 'jpeg'), // Set the correct content type
    );
    print("object2");
    request.files.add(multipartFile);

    try {
      var response = await request.send();
      print("object3");
      var responseBody = await response.stream.bytesToString();
      print(responseBody);
      response.stream.transform(utf8.decoder).listen((value) {
        print("object4");
        print(value);
      });
    } catch (error) {
      print('Error uploading image: $error');
    }
  }
}
