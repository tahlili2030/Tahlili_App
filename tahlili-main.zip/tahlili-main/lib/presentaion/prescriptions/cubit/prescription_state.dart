part of 'prescription_cubit.dart';

sealed class PrescriptionState {
  const PrescriptionState();
}

final class PrescriptionInitial extends PrescriptionState {}

class LoadGetPrescriptionsState extends PrescriptionState {}

class FailureGetPrescriptionsState extends PrescriptionState {
  final String error;

  FailureGetPrescriptionsState(this.error);
}

class SuccessGetPrescriptionsState extends PrescriptionState {
  final List<ResponsePrescriptions> prescriptions;

  SuccessGetPrescriptionsState(this.prescriptions);
}

class LoadGetPrescriptionDetailsState extends PrescriptionState {}

class FailureGetPrescriptionDetailsState extends PrescriptionState {
  final String error;

  FailureGetPrescriptionDetailsState(this.error);
}

class SuccessGetPrescriptionDetailsState extends PrescriptionState {
  final List<ResponsePrescriptions> prescriptions;

  SuccessGetPrescriptionDetailsState(this.prescriptions);
}

class LoadAddPrescriptionsState extends PrescriptionState {}

class FailureAddPrescriptionsState extends PrescriptionState {
  final String error;

  FailureAddPrescriptionsState(this.error);
}

class SuccessAddPrescriptionsState extends PrescriptionState {
  final ResponseAPI response;

  SuccessAddPrescriptionsState(this.response);
}

class PickFIleState extends PrescriptionState {}
