import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/prescriptions/cubit/prescription_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

import '../../resources/constant_manger.dart';
import '../../resources/shared/shared_widgets.dart';

class UploadPrescriptionScreen extends StatelessWidget {
  const UploadPrescriptionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<PrescriptionCubit>();
    return Scaffold(
      appBar: AppBar(),
      backgroundColor: ColorManger.pageColor,
      body: BlocBuilder<PrescriptionCubit, PrescriptionState>(
        builder: (context, state) {
          return Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            child: ListView(
              children: [
                SizedBox(
                  height: 50.h,
                ),
                Text(
                  "رفع طلب التحاليل الطبية ",
                  style: StylesManger.rich(),
                ),
                SizedBox(
                  height: 16.h,
                ),
                Text(
                  "قم برفع طلب التحاليل الطبيبة من قِبل الطبيب المعالج وسنقوم بتزويدك بالباقة المناسبة",
                  style:
                      StylesManger.medium().copyWith(color: Color(0xffb0b0b0)),
                ),
                SizedBox(
                  height: 16.h,
                ),
                Container(
                  width: double.infinity,
                  height: 274.h,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          fit: BoxFit.fitWidth,
                          image: AssetImage(
                              'assets/images/prescription/upload_prescription.png'))),
                ),
                SizedBox(
                  height: 16.h,
                ),
                Text(
                  "رفع مستندات التحاليل الطبية",
                  style: StylesManger.medium(),
                ),
                SizedBox(
                  height: 12.h,
                ),
                InkWell(
                  onTap: () {
                    cubit.pickImage(ImageSource.gallery);
                  },
                  child: Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius:
                            BorderRadius.circular(ConstantManger.borderRadius),
                        border: Border.all(color: ColorManger.lightBlack)),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 10.r,
                          backgroundColor: ColorManger.newPrimary,
                          child: Icon(
                            Icons.attachment,
                            color: Colors.white,
                            size: 15,
                          ),
                        ),
                        SizedBox(
                          width: 16.w,
                        ),
                        Text(
                          "اسحب او قم بالضغط لتحميل الملفات هنا. يمكنك تحميل 4 ملفات كحد اقصي",
                          style: StylesManger.extremelySmall()
                              .copyWith(color: ColorManger.grey),
                        )
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 16.h,
                ),
                if (cubit.image != null)
                  Row(
                    children: [
                      ...List.generate(
                          1,
                          (index) => Container(
                                padding: EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(
                                        ConstantManger.borderRadius),
                                    border: Border.all(
                                        color: ColorManger.lightBlack)),
                                child: Column(
                                  children: [
                                    Container(
                                      height: 38.h,
                                      width: 48.w,
                                      decoration: BoxDecoration(
                                          color: Colors.red,
                                          image: DecorationImage(
                                              image: FileImage(cubit.image!),
                                              fit: BoxFit.fill)),
                                    ),
                                    SizedBox(
                                      height: 8.h,
                                    ),
                                    Text(
                                      "مرفق ملف رقم ${index + 1}",
                                      style: StylesManger.extremelySmall()
                                          .copyWith(color: Colors.grey),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    )
                                  ],
                                ),
                              ))
                    ],
                  ),
                SizedBox(
                  height: 16.h,
                ),
                authForm(
                    maxLines: 5,
                    hintText: "Notes".tr(),
                    title: "${"Notes".tr()} (اختياري)",
                    controller: cubit.noteController,
                    validator: null),
                SizedBox(
                  height: 16.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(
                      height: 42.h,
                      width: 110.w,
                      child: state is LoadAddPrescriptionsState
                          ? Center(
                              child: CircularProgressIndicator(),
                            )
                          : AppButton(
                              radius: 5.r,
                              color: ColorManger.newPrimary,
                              name: "رفع",
                              onPressed: () {
                                cubit.addPrescription(
                                    languageCode: context.locale.languageCode,
                                    patientId: context
                                        .read<AccountCubit>()
                                        .userModel!
                                        .entityId!);
                              }),
                    ),
                    SizedBox(
                      height: 42.h,
                      width: 110.w,
                      child: AppButton(
                          radius: 5.r,
                          textColor: ColorManger.newPrimary,
                          color: Colors.white,
                          name: "السابق",
                          onPressed: () {
                            Navigator.pop(context);
                          }),
                    )
                  ],
                ),
                SizedBox(
                  height: 16.h,
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
