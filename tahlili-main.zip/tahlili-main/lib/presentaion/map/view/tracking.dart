import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:tahlili/presentaion/map/cubit/map_cubit.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

class TrackingNurse extends StatefulWidget {
  const TrackingNurse({super.key});

  @override
  State<TrackingNurse> createState() => _TrackingNurseState();
}

class _TrackingNurseState extends State<TrackingNurse> {
  @override
  void initState() {
    context.read<MapCubit>().initPostion();
    context.read<MapCubit>().getPolyPoints();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<MapCubit>();
    return BlocBuilder<MapCubit, MapState>(
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            title: Text("Track Nurse".tr(),style: StylesManger.medium(),),
            centerTitle: true,
          ),
          body: cubit.nurseLocation!=null? GoogleMap(
          initialCameraPosition: cubit.initPoint,
          polylines: {
            Polyline(polylineId: const PolylineId('route'),
            points: cubit.polylineCoordinates,
            color: Colors.blue)
          },
          markers: {
            //TODO: need user location
            Marker(
                markerId: const MarkerId(
                  "UserLocation",
                ),
                position: LatLng(29.622997,
                    31.256780)),
                       //TODO: need nurse location
             Marker(
                markerId: MarkerId("Nurse"),
                position: LatLng(cubit.nurseLocation!.latitude, cubit.nurseLocation!.longitude))
          },
        ):Center(
          child: Text("The Order hasnt been Assigend yet".tr(),style: StylesManger.rich(),),
        ),
        );
      },
    );
  }
}
