import 'dart:developer';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:tahlili/presentaion/map/cubit/map_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

class GoogleMapScreen extends StatefulWidget {
  const GoogleMapScreen({Key? key, required this.fromEdit}) : super(key: key);
  final bool fromEdit;

  @override
  State<GoogleMapScreen> createState() => GoogleMapScreenState();
}

class GoogleMapScreenState extends State<GoogleMapScreen> {
  double? latitude;
  double? longitude;
  final TextEditingController _textEditingController = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<MapCubit>();

    return BlocConsumer<MapCubit, MapState>(
      listener: (context, state) {},
      builder: (context, state) {
        return Scaffold(
            appBar: AppBar(
              title: Text(
                cubit.address ?? "Add Addresses".tr(),
                style: StylesManger.rich(),
              ),
              centerTitle: true,
            ),
            body: Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                      border:
                          Border.all(width: 2, color: ColorManger.newPrimary)),
                  child: TextFormField(
                    controller: _textEditingController,
                    validator: (value) {
                      return null;
                    },
                    onChanged: (value) {
                      cubit.changeLocation(value);
                    },
                    decoration: InputDecoration(
                        labelText: "SearchForPlace".tr(),
                        prefixIcon: Icon(
                          Icons.location_on,
                          color: ColorManger.newPrimary,
                        ),
                        suffixIcon: Icon(
                          Icons.search,
                          color: ColorManger.newPrimary,
                        )),
                  ),
                ),
                Expanded(
                  child: Stack(
                    children: [
                      GoogleMap(
                          onCameraMove: (position) {
                            setState(() {
                              latitude = position.target.latitude;
                              longitude = position.target.longitude;
                              print(latitude);
                              print(longitude);
                            });
                          },
                          mapType: MapType.normal,
                          initialCameraPosition: widget.fromEdit
                              ? cubit.addressInitPoint!
                              : cubit.initPoint,
                          onMapCreated: (GoogleMapController controller) {
                            if (!cubit.googleMapController.isCompleted) {
                              cubit.googleMapController.complete(controller);
                            } else {}
                          }),
                      Container(
                        color: Colors.grey.withOpacity(.4),
                        child: ListView.builder(
                          physics: const NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemCount: cubit.placeList.length,
                          itemBuilder: (context, index) {
                            return GestureDetector(
                              onTap: () {
                                cubit.getPlace(index);
                              },
                              child: ListTile(
                                leading: Icon(
                                  Icons.location_on,
                                  color: ColorManger.newPrimary,
                                ),
                                title:
                                    Text(cubit.placeList[index]["description"]),
                              ),
                            );
                          },
                        ),
                      ),
                      const Center(
                        child: Icon(
                          Icons.pin_drop,
                          color: Colors.red,
                          size: 30,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsetsDirectional.only(
                            bottom: 10, start: 35, end: 35),
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: SizedBox(
                            width: double.infinity,
                            height: 50,
                            child: AppButton(
                                color: ColorManger.newPrimary,
                                onPressed: () async {
                                  await cubit
                                      .getUserAdress(
                                          latitude!, longitude!, false)
                                      .whenComplete(() {
                                    if (cubit.latitude != null) {
                                      log(cubit.address!.toString());
                                      Navigator.pop(context);
                                    }
                                  });
                                },
                                name: "SaveAddress".tr()),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ));
      },
    );
  }
}
