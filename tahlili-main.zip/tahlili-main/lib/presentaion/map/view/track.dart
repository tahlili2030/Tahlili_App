// import 'dart:math';

// import 'package:flutter/material.dart';
// import 'dart:async';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:flutter_polyline_points/flutter_polyline_points.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:tahlili/app/end_points.dart';
// import 'package:tahlili/presentaion/map/cubit/map_cubit.dart';

// class TrackOrder extends StatefulWidget {
//   const TrackOrder({Key? key}) : super(key: key);

//   @override
//   State<TrackOrder> createState() => _TrackOrderState();
// }

// class _TrackOrderState extends State<TrackOrder> {
//   List<Marker> markers = [];
//   PolylinePoints polylinePoints = PolylinePoints();
//   Map<PolylineId, Polyline> polylines = {};
//   late GoogleMapController googleMapController;
//   final Completer<GoogleMapController> completer = Completer();

//   Marker? userPositionMarker;

//   void onMapCreated(GoogleMapController controller) {
//     googleMapController = controller;
//     if (!completer.isCompleted) {
//       completer.complete(controller);

//       setState(() {
//         userPositionMarker = Marker(
//           markerId: const MarkerId('userPosition'),
//           position: LatLng(
//             context.read<MapCubit>().userLocation!.latitude,
//             context.read<MapCubit>().userLocation!.longitude,
//           ),
//           icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
//         );
//       });
//     }
//   }

//   addMarker(LatLng latLng, newSetState) {
//     markers.add(
//       Marker(
//         consumeTapEvents: true,
//         markerId: MarkerId(latLng.toString()),
//         position: latLng,
//         onTap: () {
//           markers.removeWhere((element) => element.markerId == MarkerId(latLng.toString()));
//           if (markers.length > 1) {
//             getDirections(markers, newSetState);
//           } else {
//             polylines.clear();
//           }
//           newSetState(() {});
//         },
//       ),
//     );

//     if (markers.length > 1) {
//       getDirections(markers, newSetState);
//     }

//     setState(() {
//       userPositionMarker = Marker(
//         markerId: const MarkerId('userPosition'),
//         position: LatLng(
//           context.read<MapCubit>().userLocation!.latitude,
//           context.read<MapCubit>().userLocation!.longitude,
//         ),
//         icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
//       );
//     });

//     newSetState(() {});
//   }

//   getDirections(List<Marker> markers, newSetState) async {
//     List<LatLng> polylineCoordinates = [];
//     List<PolylineWayPoint> polylineWayPoints = [];
//     for (var i = 0; i < markers.length; i++) {
//       polylineWayPoints.add(PolylineWayPoint(
//         location: "${markers[i].position.latitude},${markers[i].position.longitude}",
//         stopOver: true,
//       ));
//     }

//     PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
//       EndPoints.googleAPiKey,
//       PointLatLng(markers.first.position.latitude, markers.first.position.longitude),
//       PointLatLng(markers.last.position.latitude, markers.last.position.longitude),
//       travelMode: TravelMode.driving,
//     );

//     if (result.points.isNotEmpty) {
//       result.points.forEach((PointLatLng point) {
//         polylineCoordinates.add(LatLng(point.latitude, point.longitude));
//       });
//     } else {
//       print(result.errorMessage);
//     }

//     newSetState(() {});

//     addPolyLine(polylineCoordinates, newSetState);
//   }

//   addPolyLine(List<LatLng> polylineCoordinates, newSetState) {
//     PolylineId id = PolylineId("poly");
//     Polyline polyline = Polyline(
//       polylineId: id,
//       color: Colors.blue,
//       points: polylineCoordinates,
//       width: 4,
//     );
//     polylines[id] = polyline;

//     newSetState(() {});
//   }

//   @override
//   void initState() {
//     print( context.read<MapCubit>().userLocation!.latitude);
    
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: StatefulBuilder(
//         builder: (context, newSetState) => GoogleMap(
//           mapToolbarEnabled: false,
//           onMapCreated: onMapCreated,
//           polylines: Set<Polyline>.of(polylines.values),
//           initialCameraPosition: context.read<MapCubit>().initPoint,
//           myLocationEnabled: true,
//           myLocationButtonEnabled: true,
//           markers: (userPositionMarker != null ? Set<Marker>.from([userPositionMarker!]) : null)!,

//           onTap: (newLatLng) async {
//             await addMarker(newLatLng, newSetState);
//             newSetState(() {});
//           },
//         ),
//       ),
//     );
//   }
// }
