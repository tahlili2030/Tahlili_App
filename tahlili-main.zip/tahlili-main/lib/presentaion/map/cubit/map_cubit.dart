import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:meta/meta.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/app/pref_manager.dart';
import 'package:tahlili/data/repository_impl/map/maps.dart';
import 'package:tahlili/domain/repository/auth/auth.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';
import 'package:uuid/uuid.dart';
import 'package:http/http.dart' as http;

import '../../../data/requests/accounts/request_account.dart';
import '../../../data/response/account/reponse_account.dart';
import '../../../data/response/home/response_home.dart';
import '../../../data/response/response.dart';

part 'map_state.dart';

class MapCubit extends Cubit<MapState> {
  MapCubit(this._repository, this._authRepository, this._preferancesManager)
      : super(MapInitial());
  final BaseMapRepository _repository;
  final BaseAuthRepository _authRepository;
  final PreferancesManager _preferancesManager;
  Position? userLocation;

  start() {
    getCities();
    getDistricts();
  }

  Future<Position> getUserLocation() async {
    await Geolocator.requestPermission();

    emit(GetCurrentUserLocationSuccessState());
    userLocation = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best);

    return userLocation!;
  }

  late CameraPosition initPoint;
  initPostion() {
    initPoint = CameraPosition(
      target: LatLng(userLocation!.latitude, userLocation!.longitude),
      zoom: 14.4746,
    );
  }

  CameraPosition? addressInitPoint;
  Future initAddressPostion() async {
    print("alo");
    print(latitude);
    print(longitude);
    addressInitPoint = await CameraPosition(
      target: LatLng(latitude!, longitude!),
      zoom: 14.4746,
    );

    log(addressInitPoint!.target.latitude.toString());
  }

  Future<void> getUserAdress(
      double latitude, double longitude, bool fromEdit) async {
    this.latitude = null;
    this.longitude = null;
    print("object");
    List<Placemark> placemarks = await GeocodingPlatform.instance
        .placemarkFromCoordinates(latitude, longitude);
    print(placemarks.reversed.last.administrativeArea);
    if (fromEdit) {
      this.latitude = latitude;
      this.longitude = longitude;
    } else {
      if (placemarks.reversed.last.administrativeArea == 'Riyadh Province') {
        this.latitude = latitude;
        this.longitude = longitude;
        address =
            "${placemarks.reversed.last.subAdministrativeArea}-${placemarks.reversed.last.administrativeArea}-${placemarks.reversed.last.street}";
        toast(text: "Location has been picked", color: Colors.green);
      } else {
        toast(
            text: "We dont serve locations outside the Riyadah Province",
            color: Colors.red);
      }
    }

    emit(GetUserAdress());
  }

  Completer<GoogleMapController> googleMapController =
      Completer<GoogleMapController>();

  Future<void> cameraToPlace(Map<String, dynamic> map) async {
    if (map.isNotEmpty) {
      final double lat = map['geometry']['location']['lat'];
      final double lng = map['geometry']['location']['lng'];
      final GoogleMapController controller = await googleMapController.future;
      controller.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(target: LatLng(lat, lng), zoom: 16)));
      placeList.clear();
    } else {}
    emit(GetCameraToPostionState());
  }

  TextEditingController nameController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  String? address;
  double? latitude;
  double? longitude;
  List<String> cities = [];
  List<ResponseLookup> citiesLookUp = [];
  getCities() async {
    cities.clear();
    citiesLookUp.clear();
    emit(LoadAddGetCityState());
    try {
      final result = await _authRepository.getLookUp(tableName: 'Cities');
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureAddGetCityState());
      }, (data) {
        debugPrint(data.length.toString());

        List.generate(data.length, (index) => cities.add(data[index].name!));
        List.generate(data.length, (index) => citiesLookUp.add(data[index]));
        emit(SuccessAddGetCityState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureAddGetCityState());
    }
  }

  int? city;
  int? cityId;
  setCity(value) {
    city = value;
    for (var i = 0; i < citiesLookUp.length; i++) {
      if (cities[city!] == citiesLookUp[i].name) {
        cityId = citiesLookUp[i].id!;
        debugPrint(cityId.toString());
      }
    }
    emit(SetCityState());
  }

  bool added = false;
  Future addNewAddress({required BuildContext context}) async {
    added = false;
    final userId = _preferancesManager.getData(key: userID);
    if (latitude == null) {
      toast(text: "يرجي اختيار الموقع", color: Colors.red);
      return;
    }
    if (latitude == null) {
      toast(text: "يرجي اختيار الموقع", color: Colors.red);
      return;
    }
    if (nameController.text.isEmpty) {
      toast(text: "يرجي اختيار اسم الموقع", color: Colors.red);
      return;
    }
    if (cityId == null) {
      toast(text: "يرجي اختيار المدينه", color: Colors.red);
      return;
    }
    if (districtId == null) {
      toast(text: "يرجي اختيار المقاطعه", color: Colors.red);
      return;
    }
    final String location = "https://maps.google.com/?q=$latitude, $longitude";
    emit(LoadAddAddressesState());
    try {
      final result = await _repository.addNewAddress(
          address: RequestAddress(
              userId,
              nameController.text,
              address!,
              location,
              cityId!,
              districtId!,
              longitude!,
              latitude!,
              defaultAddress));

      result.fold((failure) {
        added = false;
        debugPrint(failure.message);
        emit(FailureAddAddressesState(failure.message));
      }, (response) {
        debugPrint(response.message);
        context.read<AccountCubit>().getAddresses();
        toast(text: "تم اضافه العنوان بنجاح", color: Colors.green);
        added = true;
        clearAddressData();
        emit(SuccessAddAddressesState(response));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureAddAddressesState(e.toString()));
    }
  }

  deleteAddress({required int addressId, required BuildContext context}) async {
    emit(LoadDeleteAddressState());
    try {
      final result =
          await _repository.deletePatientAddress(addressId: addressId);

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureDeleteAddressState());
      }, (response) {
        debugPrint(response.message);
        toast(text: "تم حذف العنوان بنجاح", color: Colors.green);
        context.read<AccountCubit>().getAddresses();
        clearAddressData();
        emit(SuccessDeleteAddressState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureDeleteAddressState());
    }
  }

  bool updated = false;
  Future updatePatientAddress(
      {required int addressId, required BuildContext context}) async {
    updated = false;
    final userId = _preferancesManager.getData(key: userID);
    final String location = "https://maps.google.com/?q=$latitude, $longitude";
    emit(LoadUpdateAddressesState());
    try {
      final result = await _repository.updatePatientAddress(
          addressId: addressId,
          address: RequestAddress(
              userId,
              nameController.text,
              address!,
              location,
              cityId!,
              districtId!,
              longitude!,
              latitude!,
              defaultAddress));

      result.fold((failure) {
        updated = false;
        debugPrint(failure.message);
        emit(FailureUpdateAddressesState(failure.message));
      }, (response) {
        debugPrint(response.message);
        context.read<AccountCubit>().getAddresses();
        updated = true;

        clearAddressData();

        emit(SuccessUpdateAddressesState(response));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureUpdateAddressesState(e.toString()));
    }
  }

  initEditAddress(ResponseAddresses address) {
    nameController =
        TextEditingController.fromValue(TextEditingValue(text: address.name!));
    this.address = address.address!;
    cityId = address.cityId!;
    for (var i = 0; i < citiesLookUp.length; i++) {
      if (citiesLookUp[i].id == cityId) {
        city = i;
      }
    }
    districtId = address.district!.id;
    for (var i = 0; i < districtsLookUp.length; i++) {
      if (districtsLookUp[i].id == districtId) {
        district = i;
      }
    }

    defaultAddress = address.defaultAddress!;
    latitude = address.latitude;
    longitude = address.longitude;
    emit(InitEditAddressState());
  }

  clearAddressData() {
    nameController.clear();
    address = null;
    cityId = null;
    city = null;
    districtId = null;
    district = null;
    longitude = null;
    latitude = null;
    defaultAddress = false;
  }

  bool defaultAddress = false;
  changeDefaultAddress(bool value) {
    defaultAddress = value;
    emit(ChangeDefaultAddressState());
  }

  List<String> districts = [];
  List<ResponseLookup> districtsLookUp = [];
  getDistricts() async {
    districts.clear();
    districtsLookUp.clear();
    emit(LoadAddGetCityState());
    try {
      final result = await _authRepository.getLookUp(tableName: 'Districts');
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureAddGetCityState());
      }, (data) {
        debugPrint(data.length.toString());

        List.generate(data.length, (index) => districts.add(data[index].name!));
        List.generate(data.length, (index) => districtsLookUp.add(data[index]));
        emit(SuccessAddGetCityState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureAddGetCityState());
    }
  }

  int? district;
  int? districtId;
  setDistrict(value) {
    district = value;
    for (var i = 0; i < districtsLookUp.length; i++) {
      if (districts[district!] == districtsLookUp[i].name) {
        districtId = districtsLookUp[i].id!;
        debugPrint(districtId.toString());
      }
    }
    emit(SetCityState());
  }

  Polyline? line;
  createPlyLine() {
    line = const Polyline(
      polylineId: PolylineId('line'),
      color: Colors.blue,
      width: 5,
      points: [
        LatLng(37.7749, -122.4194), // Replace with your start point coordinates
        LatLng(34.0522, -118.2437), // Replace with your end point coordinates
      ],
    );
    emit(CreatePlyLineState());
  }

  var uuid = const Uuid();
  String? _sessionToken;
  List<dynamic> placeList = [];

  changeLocation(String location) {
    _sessionToken ??= uuid.v4();
    emit(SrarchUserAddresses());
    getSuggestion(location);
  }

  getPlace(int index) async {
    try {
      String placeID = placeList[index]['place_id'];
      final map = await _repository.getPlace(placeID);

      cameraToPlace(map);
    } catch (e) {
      toast(text: "please enter a valid location", color: Colors.red);
      return {};
    }
  }

  void getSuggestion(String input) async {
    String kplacesApiKey = EndPoints.googleAPiKey;
    //String type = '(regions)';
    String baseURL =
        'https://maps.googleapis.com/maps/api/place/autocomplete/json';
    String request =
        '$baseURL?input=$input&key=$kplacesApiKey&sessiontoken=$_sessionToken&components=country:EG';
    var response = await http.get(Uri.parse(request));
    if (response.statusCode == 200) {
      placeList = jsonDecode(response.body)['predictions'];
      print(placeList.length);

      emit(SrarchUserAddresses());
    } else {
      throw Exception('Failed to load predictions');
    }
  }

  List<LatLng> polylineCoordinates = [];
  BitmapDescriptor userIcon = BitmapDescriptor.defaultMarker;
  BitmapDescriptor initIcon = BitmapDescriptor.defaultMarker;
  BitmapDescriptor nurseIcon = BitmapDescriptor.defaultMarker;

  setCustomIcons() {
    BitmapDescriptor.fromAssetImage(ImageConfiguration.empty, "assetName")
        .then((icon) {
      userIcon = icon;
      emit(SetCustomIconState());
    });
  }

  LatLng? nurseLocation;
  getNurseLocation({required int orderID}) async {
    nurseLocation = null;
    emit(LoadGetNurseLocationState());
    try {
      final result = await _repository.getNurseLocation(orderID: orderID);
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetNurseLocationState());
      }, (response) async {
        debugPrint(response.location);
        List<String> parts = response.location.split('|');
        double latitude = double.parse(parts[0]);
        double longitude = double.parse(parts[1]);
        if (latitude != 0.0 && longitude != 0.0) {
          nurseLocation = LatLng(latitude, longitude);
          getPolyPoints();
          print(nurseLocation!.latitude);
          print(nurseLocation!.longitude);
        }
        emit(SuccessGetNurseLocationState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetNurseLocationState());
    }
  }

  getPolyPoints() async {
    PolylinePoints polylinePoints = PolylinePoints();
    PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
        EndPoints.googleAPiKey,
        //TODO: need user location
        PointLatLng(29.622997, 31.256780),
        //TODO: need nurse location
        PointLatLng(nurseLocation!.latitude, nurseLocation!.longitude));

    if (result.points.isNotEmpty) {
      result.points.forEach((element) {
        polylineCoordinates.add(LatLng(element.latitude, element.longitude));
      });
      emit(GetMapRoutesState());
    }
  }
  // recall(){
  //   Future.
  // }
}
