part of 'map_cubit.dart';

@immutable
sealed class MapState {}

final class MapInitial extends MapState {}

class GetCurrentUserLocationSuccessState extends MapState {}

class GetUserAdress extends MapState {}

class GetCameraToPostionState extends MapState {}

class LoadAddAddressesState extends MapState {}

class FailureAddAddressesState extends MapState {
  final String error;

  FailureAddAddressesState(this.error);
}

class SuccessAddAddressesState extends MapState {
  final ResponseAPI response;

  SuccessAddAddressesState(this.response);
}

class LoadGetLookUpState extends MapState{}


class SuccessGetLookUpState extends MapState{}


class FailureGetLookUpState extends MapState{}

class SrarchUserAddresses extends MapState{}

class SetCityIdState extends MapState{}

class SetDiestrictIdState extends MapState{}

class CreatePlyLineState extends MapState{}

class GetMapRoutesState extends MapState{}

class SetCustomIconState extends MapState{}

class LoadGetNurseLocationState extends MapState{}

class SuccessGetNurseLocationState extends MapState{}

class FailureGetNurseLocationState extends MapState{}

class LoadAddGetCityState extends MapState{}

class SuccessAddGetCityState extends MapState{}

class FailureAddGetCityState extends MapState{}

class SetCityState extends MapState{}

class ChangeDefaultAddressState extends MapState{}

class LoadUpdateAddressesState extends MapState {}

class FailureUpdateAddressesState extends MapState {
  final String error;

  FailureUpdateAddressesState(this.error);
}

class SuccessUpdateAddressesState extends MapState {
  final ResponseAPI response;

  SuccessUpdateAddressesState(this.response);
}

class LoadDeleteAddressState extends MapState{}

class SuccessDeleteAddressState extends MapState{}

class FailureDeleteAddressState extends MapState{}

class InitEditAddressState extends MapState{}