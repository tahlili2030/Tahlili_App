import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:moyasar/moyasar.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/bnb/cubit/bnb_cubit.dart';
import 'package:tahlili/presentaion/bnb/view/bnb_view.dart';

import '../../lab_appointments/view/lab_appointmnets.dart';
import '../../telemedicine/pages/telemed_appoints.dart';
import '../../telemedicine/view/instant_telemed/check_reservation_view.dart';

// ignore: must_be_immutable
class PaymentView extends StatelessWidget {
  final int amount;
  final String description;
  final bool fromTele;
  var paymentConfig;
  final int? orderId;
  PaymentView(
      {super.key,
      required this.amount,
      required this.description,
      required this.fromTele,
      this.orderId}) {
    paymentConfig = PaymentConfig(
      publishableApiKey: 'pk_test_dbRD2kSMiSGLGuQUnpovGk3EYnY5n815EwuxDHxE',
      amount: amount,

      description: description,

      currency: 'SAR',
      // creditCard: CreditCardConfig(saveCard: true, manual: false),
      applePay: ApplePayConfig(
          merchantId: 'YOUR_MERCHANT_ID',
          label: 'YOUR_STORE_NAME',
          manual: true),
    );
  }

  navigation(BuildContext context) {
    Future.delayed(Duration(seconds: 1), () {
      print("****************");
      if (context.read<AccountCubit>().direct) {
        if (fromTele) {
          context.read<BnbCubit>().setIndex(3, context);
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => const BNBView()));
        } else if (context.read<AccountCubit>().instantTele) {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => CheckReservationView(
                        orderId: orderId!,
                      )));
        } else {
          context.read<BnbCubit>().setIndex(3, context);
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => const BNBView()));
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AccountCubit>();

    return BlocBuilder<AccountCubit, AccountState>(
      builder: (context, state) {
        navigation(context);
        return Scaffold(
          body: Directionality(
            textDirection: TextDirection.ltr,
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: 100,
                    ),

                    ApplePay(
                      config: paymentConfig,
                      onPaymentResult: cubit.onPaymentResult,
                    ),
                    // const Text("or"),
                    CreditCard(
                      config: paymentConfig,
                      onPaymentResult: cubit.onPaymentResult,
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
