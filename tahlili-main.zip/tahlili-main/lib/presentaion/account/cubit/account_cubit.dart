import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:easy_localization/easy_localization.dart';
import 'package:http_parser/http_parser.dart' show MediaType;
import 'package:bloc/bloc.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:meta/meta.dart';
import 'package:moyasar/moyasar.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/app/pref_manager.dart';
import 'package:tahlili/data/network/error_handler.dart';
import 'package:tahlili/data/requests/accounts/request_account.dart';
import 'package:tahlili/data/response/response.dart';
import 'package:tahlili/domain/repository/account/account.dart';
import 'package:tahlili/domain/repository/auth/auth.dart';
import 'package:tahlili/presentaion/auth/cubit/auth_cubit.dart';
import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import '../../../data/response/account/reponse_account.dart';
import '../../../data/response/auth/response_auth.dart';
import '../../../data/response/orders/response_order.dart';

part 'account_state.dart';

class AccountCubit extends Cubit<AccountState> {
  AccountCubit(
      this._accountReposiotry, this._preferancesManager, this._authRepository)
      : super(AccountInitial());
  final BaseAccountReposiotry _accountReposiotry;
  final BaseAuthRepository _authRepository;
  final PreferancesManager _preferancesManager;
  start() {
    getPatinetProfiles();
    getPatientAddresses();
    getAddresses();
  }

  getDashboard() async {
    emit(LoadGetDashboardState());
    try {
      final result = await _accountReposiotry.getDashboard();

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetDashboardState(failure.message));
      }, (dashboard) {
        debugPrint(dashboard.totalOrder.toString());
        emit(SuccessGetDashboardState(dashboard));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetDashboardState(e.toString()));
    }
  }

  getPatientWallet() async {
    emit(LoadGetPatientWalletState());
    try {
      final result = await _accountReposiotry.getPatientWallet();

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetPatientWalletState(failure.message));
      }, (wallets) {
        debugPrint(wallets.length.toString());
        emit(SuccessGetPatientWalletState(wallets));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetPatientWalletState(e.toString()));
    }
  }

  getPatientAddresses() async {
    emit(LoadGetPatientAddressesState());
    try {
      final result = await _accountReposiotry.getPatientAddresses(patientId: 5);

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetPatientAddressesState(failure.message));
      }, (addresses) {
        debugPrint(addresses.length.toString());
        emit(SuccessGetPatientAddressesState(addresses));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetPatientAddressesState(e.toString()));
    }
  }

  final TextEditingController addressNameController = TextEditingController();
  final TextEditingController addressController = TextEditingController();

  getUserEntityID() async {
    // if (userModel != null) return;
    emit(LoadGetUserEntityIDState());
    final result = await _accountReposiotry.getUserEntityID();
    result.fold((error) {
      debugPrint(error.message);
      emit(FailureGetUserEntityIDState());
    }, (userEntityID) {
      debugPrint(userEntityID.toString());
      getUserData(userEntityID: userEntityID);
      getPatient(patientEntityId: userEntityID);
      emit(SuccessGetUserEntityIDState());
    });
  }

  ResponseUserEntity? userModel;

  getUserData({required int userEntityID}) async {
    userModel = null;
    emit(LoadGetUserEntityIDState());
    final id = await _preferancesManager.getData(key: userID);
    final result = await _accountReposiotry.getUserData(
        userID: id, userEntityID: userEntityID);
    result.fold((error) {
      debugPrint(error.message);
      emit(FailureGetUserEntityIDState());
    }, (user) {
      debugPrint(user.id!.toString());
      userModel = ResponseUserEntity(
          id: user.id,
          entityId: user.entityId,
          email: user.email,
          emailConfirmed: user.emailConfirmed,
          entityNameAr: user.entityNameAr,
          entityNameEn: user.entityNameEn,
          phoneNumber: user.phoneNumber,
          phoneNumberConfirmed: user.phoneNumberConfirmed,
          role: user.role,
          roles: user.roles,
          twoFactorEnabled: user.twoFactorEnabled);

      emit(SuccessGetUserEntityIDState());
    });
  }

  final familyForm = GlobalKey<FormState>();
  addProfile(
      {required AuthCubit authCubit, required BuildContext context}) async {
    final userId = _preferancesManager.getData(key: userID);
    emit(LoadAddProfileState());
    final result = await _accountReposiotry.addProfile(
        userID: userId,
        addProfile: RequestAddProfile(
            phone: authCubit.phoneController.text,
            idNumber: authCubit.nationalIDController.text,
            firstName: authCubit.fNameController.text,
            middleName: authCubit.mNameController.text,
            lastName: authCubit.lNameController.text,
            genderId: authCubit.genderID!,
            nationalityId: authCubit.nationalityID!,
            languageId: 1,
            birthDate: "2024-03-07",
            userId: userId,
            copyOrdersAddressToProfile: false));
    result.fold((error) async {
      debugPrint(error);
      await handleSuccessMessages(
          error, context.locale.languageCode, Colors.red);
      emit(FailureAddProfileState());
    }, (response) async {
      debugPrint(response.message);
      await handleSuccessMessages(response.message.orEmpty(),
          context.locale.languageCode, Colors.green);
      //  final msg = await handleSuccessMessages(response.message!);
      // toast(text: "ItemIsCreatedSuccessfully", color: Colors.green);
      getPatinetProfiles();
      Navigator.pop(context);

      emit(SuccessGAddProfileState());
    });
  }

  uploadFile(
      {required RequestUploadFile uploadFile,
      required String languageCode}) async {
    emit(LoadUploadFileState());

    final result = await _accountReposiotry.uploadFile(file: uploadFile);
    result.fold((error) async {
      debugPrint(error);
      await handleSuccessMessages(error.orEmpty(), languageCode, Colors.red);
      emit(FailureUploadFileState());
    }, (response) async {
      await handleSuccessMessages(
          response.message.orEmpty(), languageCode, Colors.green);
      debugPrint(response.message);
      emit(SuccessUploadFileState());
    });
  }

  final TextEditingController complaintController = TextEditingController();
  final complaintForm = GlobalKey<FormState>();
  addComplaints(
      {required RequestComplaints complaints,
      required BuildContext context}) async {
    emit(LoadAddComplaintsSuccessState());

    final result =
        await _accountReposiotry.addComplaints(complaints: complaints);

    result.fold((error) async {
      debugPrint(error);
      await handleSuccessMessages(
          error.orEmpty(), context.locale.languageCode, Colors.red);
      emit(FailureAddComplaintsSuccessState());
    }, (data) async {
      if (data.statusCode == 200) {
        debugPrint(data.message);
        if (image != null) {
          await uploadFileX(image!, data.id!, "Complaints");
          image = null;
        }
        await handleSuccessMessages(
            data.message.orEmpty(), context.locale.languageCode, Colors.green);
        clearComplaintsData();

        getComplaints();
        Navigator.pop(context);
      } else {
        await handleSuccessMessages(
            data.message.orEmpty(), context.locale.languageCode, Colors.red);
      }
      emit(SuccessAddComplaintsSuccessState());
    });
  }

  clearComplaintsData() {
    complaintController.clear();
  }

  List<ResponseComplaints> complaints = [];

  getComplaints() async {
    complaints.clear();
    emit(LoadGetComplaintState());
    try {
      final result = await _accountReposiotry.getComplaints();
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetComplaintState());
      }, (complaints) {
        debugPrint(complaints.length.toString());
        this.complaints.addAll(complaints);
        emit(SuccessGetComplaintState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetComplaintState());
    }
  }

  List<ResponseComplaintDetail> complaintDetails = [];
  getComplaintDetails({required int id}) async {
    complaintDetails.clear();
    emit(LoadGetComplaintDetailsState());
    try {
      final result = await _accountReposiotry.getComplaintsDetails(id: id);
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetComplaintDetailsState());
      }, (complaintDetails) {
        debugPrint(complaintDetails.description);
        this.complaintDetails.add(complaintDetails);
        emit(SuccessGetComplaintDetailsState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetComplaintDetailsState());
    }
  }

  bool direct = false;
  bool instantTele = false;
  savePayment({
    required Map<String, dynamic> map,
  }) async {
    emit(LoadSavePaymentState());
    final result = await _accountReposiotry.savePayment(map: map);
    result.fold((error) async {
      debugPrint(error);
      direct = true;
      //  await handleSuccessMessages(error.orEmpty(), languageCode, Colors.red);
      emit(FailureSavePaymentState());
    }, (response) async {
      direct = true;
      debugPrint(response.message);

      emit(SuccessSavePaymentState());
    });
  }

  dynamic convertSourceToJson(dynamic source) {
    if (source is CardPaymentResponseSource) {
      return {
        'type': 'creditcard',
        'company': source.company.toString().split('.').last,
        'name': source.name,
        'number': source.number,
        'gateway_id': source.gatewayId,
        'reference_number': source.referenceNumber,
        'token': source.token,
        'message': source.message,
        'transaction_url': source.transactionUrl,
      }; // Assuming CardPaymentResponseSource has a toJson method
    } else {
      return source; // If it's not a special type, return as is
    }
  }

  void onPaymentResult(result) async {
    if (result is PaymentResponse) {
      print("object");
      switch (result.status) {
        case PaymentStatus.paid:
          var jsonMap = {
            "id": result.id,
            "status": result.status.name,
            "amount_format": result.amountFormat,
            "created_at": result.createdAt,
            "description": result.description,
            "amount": result.amount,
            "fee": result.fee,
            "currency": result.currency,
            "refunded": result.refunded,
            "refunded_at": result.refundedAt,
            "captured": result.captured,
            "captured_at": result.capturedAt,
            "voided_at": result.voidedAt,
            "fee_format": result.feeFormat,
            "refunded_format": result.refundedFormat,
            "captured_format": result.capturedFormat,
            "invoice_id": result.invoiceId,
            "ip": result.ip,
            "callback_url": result.callbackUrl,
            "updated_at": result.updatedAt,
            "metadata": null,
            "source": convertSourceToJson(result.source),
          };

          savePayment(
            map: jsonMap,
          );

          break;
        case PaymentStatus.failed:
          // handle failure.
          break;
        case PaymentStatus.initiated:
        // TODO: Handle this case.
        case PaymentStatus.authorized:
        // TODO: Handle this case.
        case PaymentStatus.captured:
        // TODO: Handle this case.
      }
    }
  }

  List<ResponsePatient> patient = [];
  getPatient({required int patientEntityId}) async {
    patient.clear();
    emit(LoadGetPtientState());
    try {
      final result =
          await _accountReposiotry.getPatient(patientEntityId: patientEntityId);
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetPtientState());
      }, (patient) {
        debugPrint(patient.firstName);
        this.patient.add(patient);
        emit(SuccessGetPtientState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetPtientState());
    }
  }

  Future editProfile(
      {required int patientEntityId,
      required RequestEditProfile editProfile,
      required String languageCode}) async {
    emit(LoadEditProfileState());
    try {
      final result = await _accountReposiotry.editProfile(
          patientEntityId: patientEntityId, editProfile: editProfile);
      result.fold((error) async {
        debugPrint(error);
        await handleSuccessMessages(error.orEmpty(), languageCode, Colors.red);
        emit(FailureEditProfileState());
      }, (response) async {
        debugPrint(response.message);
        await handleSuccessMessages(
            response.message.orEmpty(), languageCode, Colors.green);
        if (profileImage != null) {
          await uploadFileX(profileImage!, patientEntityId, "Patients");
        }
        await getPatient(patientEntityId: patientEntityId);
        profileImage = null;

        emit(SuccessEditProfileState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureEditProfileState());
    }
  }

  List<ResponsePatientProfile> patinetProfiles = [];
  Future getPatinetProfiles() async {
    final patientUserId = _preferancesManager.getData(key: userID);
    patinetProfiles.clear();
    emit(LoadGetPatientProfilesState());
    try {
      final result = await _accountReposiotry.getPatientProfiles(
          patientUserId: patientUserId);
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetPatientProfilesState());
      }, (patinetProfiles) {
        debugPrint(patinetProfiles.length.toString());
        this.patinetProfiles.addAll(patinetProfiles);
        emit(SuccessGetPatientProfilesState());
      });
    } catch (e) {
      debugPrint(e.toString());

      emit(FailureGetPatientProfilesState());
    }
  }

  List<ResponseAddresses> addresses = [];
  Future getAddresses() async {
    final patientUserId = _preferancesManager.getData(key: userID);
    addresses.clear();
    emit(LoadGetAddressesState());
    try {
      final result =
          await _accountReposiotry.getAddresses(patientId: patientUserId);
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetAddressesState());
      }, (addresses) {
        debugPrint(addresses.length.toString());
        this.addresses.addAll(addresses);
        emit(SuccessGetAddressesState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetAddressesState());
    }
  }

  File? image;
  pickImage(ImageSource imageSource) async {
    XFile? file = await ImagePicker().pickImage(source: imageSource);
    if (file != null) {
      // Convert XFile to File

      image = File(file.path);
    }
    emit(PickFIleState());
  }

  File? profileImage;
  pickProfileImage(ImageSource imageSource) async {
    XFile? file = await ImagePicker().pickImage(source: imageSource);
    if (file != null) {
      // Convert XFile to File

      profileImage = File(file.path);
    }
    emit(PickFIleState());
  }

  Future<void> uploadImage(File imageFile, int complaintID) async {
    String apiUrl =
        "${EndPoints.baseUrl}/Files/UploadFile?id=$complaintID&entityName=complaints&isPdf=false"; // Replace with your API endpoint URL

    var request = http.MultipartRequest('POST', Uri.parse(apiUrl));
    request.headers['Content-Type'] = 'multipart/form-data';

    var imageStream = http.ByteStream(imageFile.openRead());
    var imageLength = await imageFile.length();
    print("object1");
    var multipartFile = http.MultipartFile(
      'files',
      imageStream,
      imageLength,
      filename: imageFile.path.split("/").last,
      contentType: MediaType('image', 'jpeg'), // Set the correct content type
    );
    print("object2");
    request.files.add(multipartFile);
    print("object3");
    try {
      var response = await request.send();
      print("object4");
      response.stream.transform(utf8.decoder).listen((value) {
        print(value);
      });
    } catch (error) {
      print('Error uploading image: $error');
    }
  }

  List<ResponseWalletTracking> walletTracking = [];
  Future getWalletTracing() async {
    walletTracking.clear();
    emit(LoadGetWalletTrackingState());
    try {
      final result = await _accountReposiotry.getWalletTracking();
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetWalletTrackingState());
      }, (walletTracking) {
        debugPrint(walletTracking.length.toString());
        this.walletTracking.addAll(walletTracking);
        emit(SuccessGetWalletTrackingState());
      });
    } catch (e) {
      debugPrint(e.toString());

      emit(FailureGetWalletTrackingState());
    }
  }

  List<ResponseRefund> refunds = [];
  getRefunds() async {
    refunds.clear();
    try {
      emit(LoadGetRefundState());
      final result = await _accountReposiotry.getRefunds();
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetRefundState());
      }, (refunds) {
        debugPrint(refunds.length.toString());
        this.refunds.addAll(refunds);
        emit(SuccessGetRefundState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetRefundState());
    }
  }

  requestRefund() async {
    emit(LoadRequestRefundState());
    try {
      DateTime now = DateTime.now().toUtc();

      // Convert to ISO 8601 string and add the 'Z' suffix
      String isoString = now.toIso8601String();

      final result = await _accountReposiotry.requestRefund(
          refund: RequestRefund(5, patient.first.walletMoney!, isoString));

      result.fold((error) {
        debugPrint(error.message);
        emit(FailureRequestRefundState());
      }, (success) {
        debugPrint(success.message);
        toast(text: "تم ارسال الطلب", color: Colors.green);
        emit(SuccessRequestRefundState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureRequestRefundState());
    }
  }

  Future<void> launchUrlFun(uri) async {
    var url = Uri.parse(uri);
    if (!await launchUrl(url)) {
      toast(text: 'Could not launch $url', color: Colors.red);
    }
  }

  Future<void> uploadFileX(File imageFile, int id, String entity) async {
    final authToken = _preferancesManager.getData(key: userToken);
    String apiUrl =
        "https://dev-api.tahliliapp.store/Files/UploadFile?id=$id&entityName=$entity&isPdf=false"; // Replace with your API endpoint URL
    print(apiUrl);

    var request = http.MultipartRequest('POST', Uri.parse(apiUrl));
    request.headers['Content-Type'] = 'multipart/form-data';
    request.headers['Authorization'] = 'Bearer $authToken';

    var imageStream = http.ByteStream(imageFile.openRead());
    var imageLength = await imageFile.length();
    print("object1");
    var multipartFile = http.MultipartFile(
      'files',
      imageStream,
      imageLength,
      filename: imageFile.path.split("/").last,
      contentType: MediaType('image', 'jpeg'), // Set the correct content type
    );
    print("object2");
    request.files.add(multipartFile);

    try {
      var response = await request.send();
      print("object3");
      var responseBody = await response.stream.bytesToString();
      print(responseBody);
      response.stream.transform(utf8.decoder).listen((value) {
        print("object4");
        print(value);
      });
    } catch (error) {
      print('Error uploading image: $error');
    }
  }
}
