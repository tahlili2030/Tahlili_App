part of 'account_cubit.dart';

@immutable
sealed class AccountState {}

final class AccountInitial extends AccountState {}

class LoadGetDashboardState extends AccountState {}

class FailureGetDashboardState extends AccountState {
  final String error;

  FailureGetDashboardState(this.error);
}

class SuccessGetDashboardState extends AccountState {
  final ResponseDashboard dashboard;

  SuccessGetDashboardState(this.dashboard);
}

class LoadGetPatientWalletState extends AccountState {}

class FailureGetPatientWalletState extends AccountState {
  final String error;

  FailureGetPatientWalletState(this.error);
}

class SuccessGetPatientWalletState extends AccountState {
  final List<ResponsePatientWallet> wallets;

  SuccessGetPatientWalletState(this.wallets);
}

class LoadGetPatientAddressesState extends AccountState {}

class FailureGetPatientAddressesState extends AccountState {
  final String error;

  FailureGetPatientAddressesState(this.error);
}

class SuccessGetPatientAddressesState extends AccountState {
  final List<ResponseAddresses> addresses;

  SuccessGetPatientAddressesState(this.addresses);
}

class LoadGetUserEntityIDState extends AccountState {}

class SuccessGetUserEntityIDState extends AccountState {}

class FailureGetUserEntityIDState extends AccountState {}

class LoadAddProfileState extends AccountState {}

class SuccessGAddProfileState extends AccountState {}

class FailureAddProfileState extends AccountState {}

class LoadUploadFileState extends AccountState {}

class FailureUploadFileState extends AccountState {}

class SuccessUploadFileState extends AccountState {}

class LoadAddComplaintsSuccessState extends AccountState {}

class SuccessAddComplaintsSuccessState extends AccountState {}

class FailureAddComplaintsSuccessState extends AccountState {}

class LoadSavePaymentState extends AccountState {}

class SuccessSavePaymentState extends AccountState {}

class FailureSavePaymentState extends AccountState {}

class LoadGetPtientState extends AccountState {}

class SuccessGetPtientState extends AccountState {}

class FailureGetPtientState extends AccountState {}

class LoadEditProfileState extends AccountState {}

class SuccessEditProfileState extends AccountState {}

class FailureEditProfileState extends AccountState {}

class LoadGetPatientProfilesState extends AccountState {}

class SuccessGetPatientProfilesState extends AccountState {}

class FailureGetPatientProfilesState extends AccountState {}

class LoadGetAddressesState extends AccountState {}

class SuccessGetAddressesState extends AccountState {}

class FailureGetAddressesState extends AccountState {}

class PickFIleState extends AccountState {}

class LoadGetComplaintState extends AccountState {}

class SuccessGetComplaintState extends AccountState {}

class FailureGetComplaintState extends AccountState {}

class LoadGetComplaintDetailsState extends AccountState {}

class SuccessGetComplaintDetailsState extends AccountState {}

class FailureGetComplaintDetailsState extends AccountState {}

class LoadGetWalletTrackingState extends AccountState {}

class SuccessGetWalletTrackingState extends AccountState {}

class FailureGetWalletTrackingState extends AccountState {}

class LoadAddGetCityState extends AccountState {}

class SuccessAddGetCityState extends AccountState {}

class FailureAddGetCityState extends AccountState {}

class SetCityState extends AccountState {}

class LoadGetRefundState extends AccountState {}

class SuccessGetRefundState extends AccountState {}

class FailureGetRefundState extends AccountState {}

class LoadRequestRefundState extends AccountState {}

class SuccessRequestRefundState extends AccountState {}

class FailureRequestRefundState extends AccountState {}
