import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/prescriptions/cubit/prescription_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';

import '../../resources/shared/appbar_divider.dart';
import '../../resources/styles_manger.dart';

class PrescriptionsView extends StatelessWidget {
  const PrescriptionsView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<PrescriptionCubit>();
    cubit.getPrescriptions();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          "Lab Test Request".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          const AppBarDivider(),
          const SizedBox(
            height: 16,
          ),
          Expanded(
            child: BlocBuilder<PrescriptionCubit, PrescriptionState>(
              builder: (context, state) {
                return cubit.prescriptions.isEmpty
                    ? Center(
                        child: CircularProgressIndicator(),
                      )
                    : Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16.w),
                        child: ListView.separated(
                            shrinkWrap: true,
                            itemBuilder: (context, index) => Container(
                                  padding: EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                        color: ColorManger.grey,
                                      ),
                                      borderRadius:
                                          BorderRadius.circular(10.r)),
                                  child: Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            "تاريخ الارسال",
                                            style: StylesManger.rich().copyWith(
                                                color: Color(0xff424242)),
                                          ),
                                          Text(
                                            cubit.prescriptions[index].date!,
                                            style: StylesManger.medium()
                                                .copyWith(
                                                    color: Color(0xff424242)),
                                          )
                                        ],
                                      ),
                                      SizedBox(
                                        height: 8.h,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            "الحاله",
                                            style: StylesManger.rich().copyWith(
                                                color: Color(0xff424242)),
                                          ),
                                          Container(
                                            padding: EdgeInsets.all(4),
                                            decoration: BoxDecoration(
                                                color: Color(0xff0d6dfc),
                                                borderRadius:
                                                    BorderRadius.circular(15)),
                                            child: Center(
                                              child: Text(
                                                "جديد",
                                                style: StylesManger.medium()
                                                    .copyWith(
                                                        color: Colors.white),
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                      SizedBox(
                                        height: 8.h,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            "العمليات",
                                            style: StylesManger.rich().copyWith(
                                                color: Color(0xff424242)),
                                          ),
                                          GestureDetector(
                                            onTap: () {
                                              showDialog(
                                                  context: context,
                                                  builder:
                                                      (context) => AlertDialog(
                                                            actionsPadding:
                                                                EdgeInsets.symmetric(
                                                                    horizontal:
                                                                        16.w,
                                                                    vertical:
                                                                        8.h),
                                                            actions: [
                                                              Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                // mainAxisSize: MainAxisSize.min,
                                                                children: [
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceBetween,
                                                                    children: [
                                                                      Text(
                                                                        "الملفات التي تم تحميلها",
                                                                        style: StylesManger.rich().copyWith(
                                                                            color:
                                                                                Color(0xff424242)),
                                                                      ),
                                                                      GestureDetector(
                                                                        onTap:
                                                                            () {
                                                                          Navigator.pop(
                                                                              context);
                                                                        },
                                                                        child:
                                                                            Icon(
                                                                          Icons
                                                                              .close,
                                                                          color:
                                                                              ColorManger.grey,
                                                                        ),
                                                                      )
                                                                    ],
                                                                  ),
                                                                  SizedBox(
                                                                    height: 8.h,
                                                                  ),
                                                                  if (cubit
                                                                          .prescriptions[
                                                                              index]
                                                                          .results !=
                                                                      null)
                                                                    Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceBetween,
                                                                      children: [
                                                                        Container(
                                                                          margin: const EdgeInsets
                                                                              .symmetric(
                                                                              horizontal: 16),
                                                                          height:
                                                                              50,
                                                                          width:
                                                                              150.w,
                                                                          decoration: BoxDecoration(
                                                                              image: DecorationImage(fit: BoxFit.fill, image: CachedNetworkImageProvider(EndPoints.baseImageUrl + cubit.prescriptions[index].results!.first)),
                                                                              borderRadius: BorderRadius.circular(10.r)),
                                                                        ),
                                                                        GestureDetector(
                                                                          onTap:
                                                                              () {
                                                                            Navigator.push(context,
                                                                                MaterialPageRoute(builder: (context) => FullScreenImage(imageUrl: EndPoints.baseImageUrl + cubit.prescriptions[index].results!.first)));
                                                                          },
                                                                          child:
                                                                              Container(
                                                                            padding:
                                                                                EdgeInsets.symmetric(horizontal: 20.w, vertical: 8.h),
                                                                            decoration:
                                                                                BoxDecoration(color: Color(0xff0d6dfc), borderRadius: BorderRadius.circular(10)),
                                                                            child: Center(
                                                                                child: Icon(
                                                                              Icons.remove_red_eye,
                                                                              color: Colors.white,
                                                                            )),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                ],
                                                              )
                                                            ],
                                                          ));
                                            },
                                            child: Container(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 20.w,
                                                  vertical: 8.h),
                                              decoration: BoxDecoration(
                                                  color: Color(0xff14875f),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          10)),
                                              child: Center(
                                                  child: Icon(
                                                Icons.photo_library_sharp,
                                                color: Colors.white,
                                              )),
                                            ),
                                          )
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                            separatorBuilder: (context, index) => SizedBox(
                                  height: 16.h,
                                ),
                            itemCount: cubit.prescriptions.length),
                      );
              },
            ),
          )
        ],
      ),
    );
  }
}

class FullScreenImage extends StatelessWidget {
  final String imageUrl;

  FullScreenImage({required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 50.h,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            child: CircleAvatar(
              backgroundColor: Colors.white,
              child: IconButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: Icon(
                    Icons.close,
                    color: Colors.red,
                  )),
            ),
          ),
          SizedBox(
            height: 50.h,
          ),
          Center(
            child: Image.network(
              imageUrl,
              loadingBuilder: (BuildContext context, Widget child,
                  ImageChunkEvent? loadingProgress) {
                if (loadingProgress == null) {
                  return child;
                } else {
                  return Center(
                    child: CircularProgressIndicator(
                      value: loadingProgress.expectedTotalBytes != null
                          ? loadingProgress.cumulativeBytesLoaded /
                              (loadingProgress.expectedTotalBytes ?? 1)
                          : null,
                    ),
                  );
                }
              },
              errorBuilder:
                  (BuildContext context, Object error, StackTrace? stackTrace) {
                return Text('Failed to load image');
              },
            ),
          ),
        ],
      ),
    );
  }
}
