import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:tahlili/presentaion/map/cubit/map_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';

import '../../../map/view/map_view.dart';
import '../../../resources/shared/app_drop_down.dart';
import '../../../resources/shared/shared_widgets.dart';
import '../../../resources/strings_manager.dart';
import '../../../resources/styles_manger.dart';
import '../../../resources/validation_manager.dart';

class AddEditAddressView extends StatelessWidget {
  const AddEditAddressView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<MapCubit>();
    cubit.getUserAdress(
        cubit.userLocation!.latitude, cubit.userLocation!.longitude, true);

    return BlocBuilder<MapCubit, MapState>(
      builder: (context, state) {
        return Expanded(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                cubit.latitude == null
                    ? SizedBox()
                    : Container(
                        height: 200,
                        width: double.infinity,
                        child: GoogleMap(
                          onTap: (LatLng position) async {
                            cubit.initPostion();

                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => const GoogleMapScreen(
                                          fromEdit: false,
                                        )));
                          },
                          initialCameraPosition: CameraPosition(
                            target: LatLng(cubit.latitude!, cubit.longitude!),
                            zoom: 14,
                          ),
                          onMapCreated: (GoogleMapController controller) {},
                          markers: {
                            Marker(
                              markerId: MarkerId('currentLocation'),
                              position:
                                  LatLng(cubit.latitude!, cubit.longitude!),
                            ),
                          },
                        ),
                      ),
                const SizedBox(
                  height: 8,
                ),
                authForm(
                    title: "Address Name",
                    hintText: "Home",
                    controller: cubit.nameController,
                    validator: (value) {
                      if (value != null && value.isNotEmpty) {
                        if (!ValidationManager.lengthValidation(
                            text: value, length: 3)) {
                          return StringsManager.nameValid;
                        }
                      } else {
                        return StringsManager.fieldRequierd;
                      }
                      return null;
                    }),
                Text(
                  "City",
                  style: StylesManger.medium().copyWith(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w500),
                ),
                const SizedBox(
                  height: 8,
                ),
                AppDropdown(
                    prfoileImage: [],
                    buttonDecoration: BoxDecoration(
                        border: Border.all(),
                        borderRadius: BorderRadius.circular(5)),
                    value: cubit.city,
                    hintText: "City",
                    list: cubit.cities,
                    onChange: (value) {
                      cubit.setCity(value);
                    }),
                const SizedBox(
                  height: 16,
                ),
                Text(
                  "District",
                  style: StylesManger.medium().copyWith(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w500),
                ),
                const SizedBox(
                  height: 8,
                ),
                AppDropdown(
                    prfoileImage: [],
                    buttonDecoration: BoxDecoration(
                        border: Border.all(),
                        borderRadius: BorderRadius.circular(5)),
                    value: cubit.district,
                    hintText: "District",
                    list: cubit.districts,
                    onChange: (value) {
                      cubit.setDistrict(value);
                    }),
                const SizedBox(
                  height: 16,
                ),
                Row(
                  children: [
                    Checkbox(
                        activeColor: ColorManger.newPrimary,
                        value: cubit.defaultAddress,
                        onChanged: (value) {
                          cubit.changeDefaultAddress(value!);
                        }),
                    Text(
                      "Set as default address",
                      style: StylesManger.medium()
                          .copyWith(fontSize: 14, color: Colors.black),
                    )
                  ],
                ),
                const SizedBox(
                  height: 16,
                ),
                AppButton(
                    radius: ConstantManger.borderRadius,
                    color: ColorManger.newPrimary,
                    name: "Add New Address",
                    onPressed: () {
                      cubit.addNewAddress(context: context).whenComplete(() {
                        if (cubit.added) {
                          Navigator.pop(context);
                        }
                      });
                    })
              ],
            ),
          ),
        );
      },
    );
  }
}
