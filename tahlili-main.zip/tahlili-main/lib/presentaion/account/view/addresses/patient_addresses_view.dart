import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/account/view/addresses/edit_address_view.dart';
import 'package:tahlili/presentaion/map/cubit/map_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';

import '../../../resources/shared/appbar_divider.dart';
import '../../../resources/styles_manger.dart';
import 'add_address_view.dart';

class AddressessView extends StatelessWidget {
  const AddressessView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AccountCubit>();
    cubit.getAddresses();

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: Text(
          "Addresses",
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          const AppBarDivider(),
          const SizedBox(
            height: 16,
          ),
          Expanded(child: BlocBuilder<AccountCubit, AccountState>(
            builder: (context, state) {
              return cubit.addresses.isEmpty
                  ? const Center(
                      child: CircularProgressIndicator(),
                    )
                  : Padding(
                      padding: const EdgeInsets.only(
                          left: 16, right: 16, bottom: 150),
                      child: ListView.separated(
                          itemBuilder: (context, index) => Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border:
                                        Border.all(color: ColorManger.grey)),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          cubit.addresses[index].name.orEmpty(),
                                          style: StylesManger.rich()
                                              .copyWith(color: Colors.black),
                                        ),
                                        if (cubit
                                            .addresses[index].defaultAddress!)
                                          Container(
                                            padding: EdgeInsets.all(8),
                                            decoration: BoxDecoration(
                                                color: ColorManger.newPrimary,
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        ConstantManger
                                                            .borderRadius)),
                                            child: Center(
                                              child: Text(
                                                "العنوان الافتراضي",
                                                style: StylesManger.small()
                                                    .copyWith(
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        color: Colors.white),
                                              ),
                                            ),
                                          )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 16,
                                    ),
                                    addressItem(
                                        title: "Address",
                                        body: cubit.addresses[index].address!,
                                        icon: "location.svg"),
                                    addressItem(
                                        title: "City",
                                        body:
                                            cubit.addresses[index].city!.name!,
                                        icon: "city.svg"),
                                    addressItem(
                                        title: "District",
                                        body: cubit
                                            .addresses[index].district!.name!,
                                        icon: "district.svg"),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.location_on,
                                          color: ColorManger.blueBlack,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          "عنوان خرائط جوجل",
                                          style: StylesManger.medium().copyWith(
                                              color: Color(0xff1270fc)),
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 8,
                                    ),
                                    SizedBox(
                                      height: 35.h,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(
                                            child: AppButton(
                                                radius:
                                                    ConstantManger.borderRadius,
                                                color: ColorManger.newPrimary,
                                                name: "Edit",
                                                onPressed: () {
                                                  showModalBottomSheet(
                                                      context: context,
                                                      isScrollControlled: true,
                                                      builder: (context) =>
                                                          Padding(
                                                              padding: EdgeInsets.only(
                                                                  bottom: MediaQuery.of(
                                                                          context)
                                                                      .viewInsets
                                                                      .bottom),
                                                              child: Container(
                                                                  height: 700,
                                                                  padding: const EdgeInsets
                                                                      .symmetric(
                                                                      horizontal:
                                                                          16),
                                                                  width: double
                                                                      .infinity,
                                                                  decoration: const BoxDecoration(
                                                                      color: Colors
                                                                          .white,
                                                                      borderRadius: BorderRadius.only(
                                                                          topLeft: Radius.circular(
                                                                              20),
                                                                          topRight:
                                                                              Radius.circular(20))),
                                                                  child: Form(
                                                                    key: cubit
                                                                        .complaintForm,
                                                                    child:
                                                                        Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .min,
                                                                      children: [
                                                                        const SizedBox(
                                                                          height:
                                                                              16,
                                                                        ),
                                                                        Padding(
                                                                          padding: const EdgeInsets
                                                                              .symmetric(
                                                                              vertical: 10.0),
                                                                          child:
                                                                              Container(
                                                                            width:
                                                                                40,
                                                                            height:
                                                                                5,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              color: Colors.grey[400],
                                                                              borderRadius: BorderRadius.circular(10),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        const SizedBox(
                                                                          height:
                                                                              16,
                                                                        ),
                                                                        Text(
                                                                          "Edit Address",
                                                                          style:
                                                                              StylesManger.rich().copyWith(color: Colors.black),
                                                                        ),
                                                                        const SizedBox(
                                                                          height:
                                                                              24,
                                                                        ),
                                                                        EditAddressView(
                                                                            address:
                                                                                cubit.addresses[index]),
                                                                        const SizedBox(
                                                                          height:
                                                                              30,
                                                                        )
                                                                      ],
                                                                    ),
                                                                  ))));
                                                }),
                                          ),
                                          const SizedBox(
                                            width: 16,
                                          ),
                                          Expanded(
                                            child: AppButton(
                                                borderSide: Color(0xffd64045),
                                                radius:
                                                    ConstantManger.borderRadius,
                                                textColor: Color(0xffd64045),
                                                color: Colors.white,
                                                name: "Delete",
                                                onPressed: () {
                                                  context
                                                      .read<MapCubit>()
                                                      .deleteAddress(
                                                          context: context,
                                                          addressId: cubit
                                                              .addresses[index]
                                                              .id!);
                                                }),
                                          )
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              ),
                          separatorBuilder: (context, index) => const SizedBox(
                                height: 16,
                              ),
                          itemCount: cubit.addresses.length),
                    );
            },
          )),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: InkWell(
        onTap: () {
          showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              builder: (context) => Padding(
                  padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).viewInsets.bottom),
                  child: Container(
                      height: 700,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      width: double.infinity,
                      decoration: const BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20))),
                      child: Form(
                        key: cubit.complaintForm,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const SizedBox(
                              height: 16,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 10.0),
                              child: Container(
                                width: 40,
                                height: 5,
                                decoration: BoxDecoration(
                                  color: Colors.grey[400],
                                  borderRadius: BorderRadius.circular(10),
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 16,
                            ),
                            Text(
                              "Add New Address",
                              style: StylesManger.rich()
                                  .copyWith(color: Colors.black),
                            ),
                            const SizedBox(
                              height: 24,
                            ),
                            const AddEditAddressView(),
                            const SizedBox(
                              height: 30,
                            )
                          ],
                        ),
                      ))));
        },
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 30, vertical: 40),
          height: 50,
          width: double.infinity,
          decoration: BoxDecoration(
              color: ColorManger.newPrimary,
              borderRadius: BorderRadius.circular(ConstantManger.borderRadius)),
          child: Center(
            child: Text(
              "Add New Address",
              style: StylesManger.rich().copyWith(color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }

  Widget addressItem({
    required String title,
    required String body,
    required String? icon,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // SvgPicture.asset('assets/images/address/$icon'),
          // const SizedBox(
          //   width: 5,
          // ),
          Text(
            "$title:",
            style: StylesManger.medium()
                .copyWith(fontSize: 14, color: Colors.black),
          ),
          const SizedBox(
            width: 5,
          ),
          Expanded(
            child: Text(
              body,
              style: StylesManger.medium()
                  .copyWith(fontSize: 14, color: Color(0xff79818f)),
            ),
          )
        ],
      ),
    );
  }
}

Widget addressPopUp(BuildContext context, String url) {
  return Theme(
    data: Theme.of(context).copyWith(
        cardColor: Colors.white,
        popupMenuTheme: const PopupMenuThemeData(
          color: Colors.white,
          elevation: 0,
        )),
    child: PopupMenuButton(
      padding: const EdgeInsets.only(bottom: 20),

      // color: Colors.black,
      position: PopupMenuPosition.under,
      iconSize: 30,
      icon: const Icon(
        FontAwesomeIcons.ellipsisH,
        color: Colors.black,
      ),

      itemBuilder: (context) {
        return [
          PopupMenuItem(
            value: 0,
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(
                    Icons.location_on,
                    color: Colors.black,
                  ),
                  title: Text(
                    "GoogleMapsUrl".tr(),
                  ),
                ),
              ],
            ),
          ),
        ];
      },
      onSelected: (value) async {
        switch (value) {
          case 0:
            context.read<AccountCubit>().launchUrlFun(url);

            break;
        }
      },
    ),
  );
}
