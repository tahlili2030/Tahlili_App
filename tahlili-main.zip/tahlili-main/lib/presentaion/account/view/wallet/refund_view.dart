import 'package:easy_localization/easy_localization.dart' hide TextDirection;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';

import '../../../resources/shared/appbar_divider.dart';
import '../../../resources/styles_manger.dart';

class RefundView extends StatelessWidget {
  const RefundView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AccountCubit>();
    cubit.getRefunds();
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: Text(
          "Refunds".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          const AppBarDivider(),
          const SizedBox(
            height: 16,
          ),
          Expanded(
              child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: BlocBuilder<AccountCubit, AccountState>(
              builder: (context, state) {
                return state is LoadGetRefundState
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : cubit.refunds.isEmpty
                        ? Center(
                            child: Text(
                              "There is no Refunds",
                              style: StylesManger.rich()
                                  .copyWith(color: Colors.black),
                            ),
                          )
                        : ListView.separated(
                            itemBuilder: (context, index) => Container(
                                padding: const EdgeInsets.all(16),
                                width: double.infinity,
                                decoration: BoxDecoration(
                                    border: Border.all(color: ColorManger.grey),
                                    borderRadius: BorderRadius.circular(5)),
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    refundItem(
                                        title: "رقم الموعد",
                                        body:
                                            cubit.refunds[index].id.toString()),
                                    SizedBox(
                                      height: 8.h,
                                    ),
                                    refundItem(
                                        title: "لنوع",
                                        body:
                                            cubit.refunds[index].dateCreated!),
                                    SizedBox(
                                      height: 8.h,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "حاله استرداد الاموال",
                                          style: StylesManger.rich().copyWith(
                                              color: Color(0xff424242)),
                                        ),
                                        Container(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 8.w, vertical: 4.h),
                                          decoration: BoxDecoration(
                                              color: Color(0xff0d6dfc),
                                              borderRadius:
                                                  BorderRadius.circular(5)),
                                          child: Center(
                                            child: Text(
                                              cubit.refunds[index].refundState!
                                                  .name!,
                                              style: StylesManger.medium()
                                                  .copyWith(
                                                      color: Colors.white),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                    SizedBox(
                                      height: 8.h,
                                    ),
                                    refundItem(
                                        title: "المبلغ",
                                        body: cubit.refunds[index].amount
                                            .toString()),
                                    SizedBox(
                                      height: 8.h,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "العمليات",
                                          style: StylesManger.rich().copyWith(
                                              color: Color(0xff424242)),
                                        ),
                                        Container(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 16.w, vertical: 8.h),
                                          decoration: BoxDecoration(
                                              color: Color(0xff1b6ec2),
                                              borderRadius:
                                                  BorderRadius.circular(5)),
                                          child: Center(
                                              child: Icon(
                                            Icons.zoom_in,
                                            color: Colors.white,
                                          )),
                                        )
                                      ],
                                    ),
                                    SizedBox(
                                      height: 8.h,
                                    )
                                  ],
                                )),
                            separatorBuilder: (context, index) =>
                                const SizedBox(
                                  height: 16,
                                ),
                            itemCount: cubit.refunds.length);
              },
            ),
          ))
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: InkWell(
        onTap: () {
          cubit.requestRefund();
        },
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 30, vertical: 40),
          height: 60,
          width: double.infinity,
          decoration: BoxDecoration(
              color: ColorManger.newPrimary,
              borderRadius: BorderRadius.circular(ConstantManger.borderRadius)),
          child: Center(
            child: Text(
              "Request Refund".tr(),
              style: StylesManger.rich().copyWith(color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }

  Widget refundPopUp(
    BuildContext context,
  ) {
    return Theme(
      data: Theme.of(context).copyWith(
          cardColor: Colors.white,
          popupMenuTheme: const PopupMenuThemeData(
            color: Colors.white,
            elevation: 0,
          )),
      child: PopupMenuButton(
        padding: const EdgeInsets.only(bottom: 20),

        // color: Colors.black,
        position: PopupMenuPosition.under,
        iconSize: 30,
        icon: const Icon(
          FontAwesomeIcons.ellipsisH,
          color: Colors.black,
        ),

        itemBuilder: (context) {
          return [
            PopupMenuItem(
              value: 0,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.remove_red_eye_outlined,
                      color: Colors.black,
                    ),
                    title: Text(
                      "Track Refund".tr(),
                    ),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                ],
              ),
            ),
          ];
        },
        onSelected: (value) async {
          switch (value) {
            case 0:
              break;
          }
        },
      ),
    );
  }
}

Row refundItem({
  required String title,
  required String body,
}) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(
        title,
        style: StylesManger.rich().copyWith(color: Color(0xff424242)),
      ),
      Text(
        body,
        style: StylesManger.medium().copyWith(color: Color(0xff424242)),
      )
    ],
  );
}
