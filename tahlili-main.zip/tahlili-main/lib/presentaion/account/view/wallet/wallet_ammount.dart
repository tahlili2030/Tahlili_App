import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/account/view/wallet/wallet_tracking.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';
import '../../../resources/color_manger.dart';
import '../../../resources/styles_manger.dart';

class WalletAmountView extends StatelessWidget {
  const WalletAmountView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AccountCubit>();
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: Text(
          "WalletCredit".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          const AppBarDivider(),
          const SizedBox(
            height: 200,
          ),
          SvgPicture.asset('assets/images/wallet/wallet_amount.svg'),
          const SizedBox(
            height: 16,
          ),
          Text(
            "${cubit.patient.first.walletMoney!} ${"SAR".tr()}",
            style: StylesManger.rich().copyWith(color: Colors.black),
          )
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: InkWell(
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => const WalletTrackingView()));
        },
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 30, vertical: 40),
          height: 60,
          width: double.infinity,
          decoration: BoxDecoration(
              color: ColorManger.newPrimary,
              borderRadius: BorderRadius.circular(ConstantManger.borderRadius)),
          child: Center(
            child: Text(
              "WalletTracking".tr(),
              style: StylesManger.rich().copyWith(color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }
}
