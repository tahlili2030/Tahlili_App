import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';

import '../../../resources/styles_manger.dart';
import '../../cubit/account_cubit.dart';

class WalletTrackingView extends StatelessWidget {
  const WalletTrackingView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AccountCubit>();
    cubit.getWalletTracing();
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: Text(
          "WalletTracking".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          const AppBarDivider(),
          const SizedBox(
            height: 8,
          ),
          Expanded(
            child: BlocBuilder<AccountCubit, AccountState>(
              builder: (context, state) {
                return cubit.walletTracking.isEmpty
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : ListView.separated(
                        itemBuilder: (context, index) => Container(
                          margin: EdgeInsets.symmetric(horizontal: 16),
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: ColorManger.grey,
                                ),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Column(
                                children: [
                                  walletItem(
                                      title: "DateTime".tr(),
                                      body:
                                      context.locale.languageCode=="ar"?
                                      DateFormat("dd-MM-yyyy 'في' hh:mm a",'ar').format(DateTime.parse( cubit.walletTracking[index].dateTime!)):
                                      DateFormat("dd-MM-yyyy 'at' hh:mm a").format(DateTime.parse( cubit.walletTracking[index].dateTime!))
                                         ,
                                      icon: null,isDate: true),
                                  walletItem(
                                      title: "Amount Money".tr(),
                                      body:
                                         "${cubit.walletTracking[index].amountMoney!} ${"SAR".tr()}",
                                      icon: "amount.svg",isDate: false),
                                  walletItem(
                                      title: "WalletCredit".tr(),
                                      body:
                                         "${cubit.walletTracking[index].amountCredit!} ${"SAR".tr()}",
                                      icon: "creidt.svg",isDate: false),
                                  walletItem(
                                      title: "Notes".tr(),
                                      body:
                                          cubit.walletTracking[index].notes!,
                                      icon: "note.svg",isDate: false),
                                ],
                              ),
                            ),
                        separatorBuilder: (context, index) =>const SizedBox(
                              height: 16,
                            ),
                        itemCount: cubit.walletTracking.length);
              },
            ),
          )
        ],
      ),
    );
  }

  Widget walletItem(
      {required String title,
      required String body,
      required String? icon,
      bool? isDate}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          isDate!
              ? Icon(Icons.date_range_outlined)
              : SvgPicture.asset('assets/images/wallet/$icon'),
          SizedBox(
            width: 5,
          ),
          Text(
            "$title:",
            style: StylesManger.medium()
                .copyWith(fontSize: 14, color: Colors.black),
          ),
          SizedBox(
            width: 5,
          ),
          Expanded(
            child: Text(
              body,
              style: StylesManger.medium()
                  .copyWith(fontSize: 14, color: ColorManger.buttonColor),

            ),
          )
        ],
      ),
    );
  }
}
