import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/presentaion/account/view/call_now_view.dart';
import 'package:tahlili/presentaion/account/view/privacy_view.dart';
import 'package:tahlili/presentaion/account/view/reviews_view.dart';
import 'package:tahlili/presentaion/account/view/wallet/wallet_ammount.dart';
import 'package:tahlili/presentaion/contact_us/view/contact_us_view.dart';
import 'package:tahlili/presentaion/lab_appointments/view/lab_appointmnets.dart';
import 'package:tahlili/presentaion/medical/view/medical_info_view.dart';
import 'package:tahlili/presentaion/profiles/view/edit_profile_view.dart';
import 'package:tahlili/presentaion/profiles/view/family_members.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

import '../../../app/pref_manager.dart';
import '../../complaints/view/complaint_view.dart';
import '../../onBording/view/onbording_view.dart';
import '../../prescriptions/view/prescriptions_view.dart';
import '../../resources/locle/locale_cubit.dart';
import '../../resources/shared/langugae_button.dart';
import '../../telemedicine/pages/telemed_appoints.dart';
import 'about_us.dart';
import 'addresses/patient_addresses_view.dart';
import 'wallet/refund_view.dart';

class AccountView extends StatelessWidget {
  const AccountView(this._manager, {super.key});
  final PreferancesManager _manager;

  @override
  Widget build(BuildContext context) {
    // context.read<AccountCubit>().getDashboard();
    return BlocBuilder<LocaleCubit, LocaleState>(
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
              surfaceTintColor: Color(0xfffcfeff),
              leading: const SizedBox(),
              toolbarHeight: 130.h,
              backgroundColor: Color(0xfffcfeff),
              flexibleSpace: Container(
                margin: EdgeInsets.only(top: 40.h),
                height: 120.h,
                width: double.infinity,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage('assets/images/more/more.png'))),
              )),
          backgroundColor: ColorManger.pageColor,
          body: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(
                  height: 30.h,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.w),
                  child: Container(
                    width: double.infinity,
                    height: 1,
                    color: Color(0xffE2E6E9),
                  ),
                ),
                moreItem(
                    icon: 'assets/images/more/profile.svg',
                    text: "الصفحة الشخصية".tr(),
                    ontap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const EditProfile()));
                    }),
                //             moreItem(
                //                 icon: 'assets/images/more/lab_appointment.svg',
                //                 text: "Orders".tr(),
                //                 ontap: () {
                //                   Navigator.push(
                //                       context,
                //                       MaterialPageRoute(
                //                           builder: (context) => const LabAppointmectsView()));
                //                 }),
                //                 InkWell(
                //   onTap: (){
                //     Navigator.push(
                //                       context,
                //                       MaterialPageRoute(
                //                           builder: (context) =>
                //                               const TeleMedAppoiontmentsView()));
                //   },
                //   child: Padding(
                //     padding: const EdgeInsets.only(bottom: 10),
                //     child: Column(
                //       children: [
                //         Padding(
                //           padding: const EdgeInsets.symmetric(horizontal: 33),
                //           child: ListTile(
                //             leading: Image.asset('assets/images/more/tele_med_appts.png'),
                //             title: Text(
                //               "Telemedicines".tr(),
                //               style: StylesManger.rich().copyWith(color: Colors.black),
                //             ),
                //           ),
                //         ),
                //         const SizedBox(
                //           height: 10,
                //         ),
                //         Container(
                //           width: double.infinity,
                //           height: 1,
                //           color: Colors.black,
                //         )
                //       ],
                //     ),
                //   ),
                // ),
                // moreItem(
                //     icon: 'assets/images/more/telemed.svg',
                //     text: "Telemedicine Appointments",
                //     ontap: () {
                //       Navigator.push(
                //           context,
                //           MaterialPageRoute(
                //               builder: (context) =>
                //                   TeleMedAppoiontmentsView()));
                //     }),
                moreItem(
                    icon: 'assets/images/home/compare.svg',
                    text: "المقارنة بين الخدمات".tr(),
                    ontap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const MedicalInfoView()));
                    }),
                moreItem(
                    icon: 'assets/images/more/prescriptions.svg',
                    text: "Prescriptions".tr(),
                    ontap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const PrescriptionsView()));
                    }),
                moreItem(
                    icon: 'assets/images/more/wallet.svg',
                    text: "Wallet".tr(),
                    ontap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const WalletAmountView()));
                    }),
                moreItem(
                    icon: 'assets/images/address/location.svg',
                    text: "Addresses".tr(),
                    ontap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const AddressessView()));
                    }),
                moreItem(
                    icon: 'assets/images/more/familyMem.svg',
                    text: "FamilyMembers".tr(),
                    ontap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const FamilyMembersView()));
                    }),
                moreItem(
                    icon: 'assets/images/more/refunds.svg',
                    text: "Refunds".tr(),
                    ontap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const RefundView()));
                    }),
                moreItem(
                    icon: 'assets/images/more/complaints.svg',
                    text: "Complaints".tr(),
                    ontap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const ComplaintsView()));
                    }),
                moreItem(
                    icon: 'assets/images/more/about.svg',
                    text: "AboutUs".tr(),
                    ontap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const AboutUsView()));
                    }),
                moreItem(
                    icon: 'assets/images/more/contactus.svg',
                    text: "ContactUs".tr(),
                    ontap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const ContactUsView()));
                    }),
                moreItem(
                    icon: 'assets/images/more/about.svg',
                    text: "سياسه الخصوصية".tr(),
                    ontap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const PrivacyView()));
                    }),

                // moreItem(
                //     icon: 'assets/images/more/callUs.svg',
                //     text: "CallNow".tr(),
                //     ontap: () {
                //       Navigator.push(
                //           context,
                //           MaterialPageRoute(
                //               builder: (context) => const CallNowView()));
                //     }),

                // moreItem(
                //     icon: 'assets/images/more/reviews.svg',
                //     text: "Feedbacks".tr(),
                //     ontap: () {
                //       Navigator.push(
                //           context,
                //           MaterialPageRoute(
                //               builder: (context) => const ReviewsView()));
                //     }),
                // moreItem(
                //     icon: 'assets/images/more/medReports.svg',
                //     text: "ShowDiagnosis".tr(),
                //     ontap: () {}),

                // moreItem(
                // icon: 'assets/images/more/trusted.svg',
                // text: "We Are Trusted By Clients".tr(),
                // ontap: () {
                //   Navigator.push(
                //       context,
                //       MaterialPageRoute(
                //           builder: (context) => const AboutUsView()));
                // }),

                moreItem(
                    icon: 'assets/images/more/lang.svg',
                    text: "Language".tr(),
                    ontap: () {
                      showModalBottomSheet(
                        backgroundColor: Colors.white,
                        context: context,
                        builder: (context) => const ChangelanguageWidget(),
                      );
                    }),
                InkWell(
                  onTap: () async {
                    await _manager.removeData(key: userToken);

                    if (context.mounted) {
                      Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const OnBordingView()),
                          (route) => false);
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 33),
                          child: ListTile(
                            leading: const Icon(
                              Icons.logout,
                              color: Colors.red,
                            ),
                            title: Text(
                              "LogOut".tr(),
                              style: StylesManger.rich()
                                  .copyWith(color: Colors.red),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Container(
                          width: double.infinity,
                          height: 1,
                          color: Colors.black,
                        )
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        );
      },
    );
  }

  Widget moreItem(
      {required String icon,
      required String text,
      required VoidCallback ontap}) {
    return InkWell(
      onTap: ontap,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 33),
              child: ListTile(
                leading: SvgPicture.asset(
                  icon,
                  color: ColorManger.blueBlack,
                  height: 20.h,
                  width: 16.w,
                ),
                title: Text(
                  text,
                  style: StylesManger.rich().copyWith(
                    color: ColorManger.blueBlack,
                    fontSize: 20.sp,
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: Container(
                width: double.infinity,
                height: 1,
                color: Color(0xffE2E6E9),
              ),
            )
          ],
        ),
      ),
    );
  }
}
