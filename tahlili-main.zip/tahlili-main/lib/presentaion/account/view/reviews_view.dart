import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';

import '../../resources/color_manger.dart';
import '../../resources/styles_manger.dart';

class ReviewsView extends StatelessWidget {
  const ReviewsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: Text(
          "Reviews".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          const AppBarDivider(),
          const SizedBox(
            height: 16,
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ListView.separated(
                shrinkWrap: true,
                  itemBuilder: (context,index)=>  const ReviewItem(),
                  separatorBuilder: (context,index)=>const SizedBox(height: 16,),
                  itemCount: 10),
            ),
          )
        ],
      ),
    );
  }
}

class ReviewItem extends StatelessWidget {
  const ReviewItem({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          border: Border.all(color: ColorManger.grey),
          borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const CircleAvatar(
                radius: 14,
                backgroundColor: Colors.green,
              ),
              const SizedBox(
                width: 8,
              ),
              Text(
                "Ahmed",
                style: StylesManger.rich().copyWith(color: Colors.black),
              )
            ],
          ),
          const SizedBox(
            height: 12,
          ),
          RatingBar.builder(
            initialRating: 3,
            itemSize: 18,
            minRating: 1,
            direction: Axis.horizontal,
            allowHalfRating: true,
            itemCount: 5,
            itemPadding: const EdgeInsets.symmetric(horizontal: 2.0),
            itemBuilder: (context, _) => Icon(
              Icons.star,
              color: ColorManger.primary,
            ),
            onRatingUpdate: (rating) {
              print(rating);
            },
          ),
          const SizedBox(
            height: 8,
          ),
          Text(
            "Great app",
            style:
                StylesManger.medium().copyWith(color: ColorManger.buttonColor,fontSize: 14),
          ),
          const SizedBox(
            height: 8,
          ),
          Container(
              child: Text(
            "Very friendly, good listener, she was really nice and treats patients with respect and kindness, one of the best doctors i have ever went to",
            style: StylesManger.medium().copyWith(color: Colors.black,fontSize: 14),
          ))
        ],
      ),
    );
  }
}
