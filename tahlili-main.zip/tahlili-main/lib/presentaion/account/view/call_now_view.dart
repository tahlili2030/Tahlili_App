import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';

import '../../resources/shared/appbar_divider.dart';
import '../../resources/styles_manger.dart';

class CallNowView extends StatelessWidget {
  const CallNowView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit=context.read<AccountCubit>();
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: Text(
          "CallNow".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          const AppBarDivider(),
          const SizedBox(
            height: 24,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              children: [
                callUsItem(
                    iconData: Icons.phone,
                    title: "${"Phone".tr()}: ",
                    body: "920022897",
                    ontap: () {
                      cubit.launchUrlFun("tel:920022897");
                    }),
                callUsItem(
                    iconData: Icons.phone_android,
                    title: "${"Mobile".tr()}: ",
                    body: "966539378007",
                    ontap: () {
                      cubit.launchUrlFun("tel:966539378007");
                    }),

                    callUsItem(
                    iconData: Icons.email_outlined,
                    title: "${"Email".tr()}: ",
                    body: "info@tahlili.sa",
                    ontap: () {
                       cubit.launchUrlFun("mailto:info@tahlili.sa");
                    }),
                    callUsItem(
                    iconData: Icons.location_on_outlined,
                    title: "${"Location".tr()}: ",
                    body: "RiyadhOffice".tr(),
                    ontap: () {
                       cubit.launchUrlFun("https://maps.app.goo.gl/dszyn3EyxVZG1HVg6");
                    })
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget callUsItem(
      {required IconData iconData,
      required String title,
      required String body,
      required VoidCallback ontap}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: ColorManger.lightGrey,
          ),
        ),
        child: Row(
          children: [
            Icon(
              iconData,
              color: ColorManger.lightGrey,
            ),
            const SizedBox(
              width: 16,
            ),
            Text(
              title,
              style: StylesManger.rich().copyWith(color: Colors.black),
            ),
            Text(
              body,
              style:
                  StylesManger.rich().copyWith(color: ColorManger.buttonColor),
            ),
            const Spacer(),
            InkWell(
              onTap: ontap,
              child: Icon(
                Icons.arrow_forward_ios_sharp,
                color: ColorManger.grey,
              ),
            )
          ],
        ),
      ),
    );
  }
}
