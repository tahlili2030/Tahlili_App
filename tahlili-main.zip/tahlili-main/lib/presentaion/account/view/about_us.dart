import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';

import '../../resources/styles_manger.dart';

class AboutUsView extends StatelessWidget {
  const AboutUsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: Text(
          "AboutUs".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
        centerTitle: true,
      ),
      backgroundColor: ColorManger.pageColor,
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        child: ListView(
          children: [
            SizedBox(
              height: 24.h,
            ),
            Container(
              height: 200.h,
              padding: EdgeInsets.symmetric(horizontal: 40.w, vertical: 24.h),
              decoration: BoxDecoration(
                color: Color(0xffEDFCFF),
                borderRadius:
                    BorderRadius.circular(ConstantManger.borderRadius),
              ),
              child: Column(
                children: [
                  Text(
                    "تعرف أكثر عن تحليلي",
                    style: StylesManger.rich().copyWith(
                        color: ColorManger.newPrimary,
                        fontSize: 24.sp,
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  Text(
                    "تحليلي، تجربة الرعاية الصحية الأولى تحت سقف واحد",
                    style: StylesManger.rich().copyWith(
                        color: Colors.black,
                        fontSize: 24.sp,
                        fontWeight: FontWeight.w500),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 40.h,
            ),
            Container(
              height: 176.h,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage('assets/images/home/video_temp.png')),
                  borderRadius:
                      BorderRadius.circular(ConstantManger.borderRadius)),
            ),
            SizedBox(
              height: 40.h,
            ),
            Text(
              "AboutUs".tr(),
              style: StylesManger.rich().copyWith(
                  color: ColorManger.blueBlack,
                  fontSize: 24.sp,
                  fontWeight: FontWeight.w500),
            ),
            SizedBox(
              height: 24.h,
            ),
            Text(
              "منصة سعودية ريادية جمعت المختبرات الطبية الموثوقة تحت سقف واحد و تميزت بتقديم خدمة الاستشارات الطبية عن بعد في مجالات عدة  بإشراف نخبة من الأطباء السعوديين والعالميين"
                  .tr(),
              style: StylesManger.small().copyWith(
                color: ColorManger.lightGrey,
              ),
            ),
            SizedBox(
              height: 24.h,
            ),
            Row(
              children: [
                SizedBox(
                  width: 144.w,
                  child: AppButton(
                      radius: ConstantManger.borderRadius,
                      textSize: 12.sp,
                      color: ColorManger.newPrimary,
                      name: "تصفح باقاتنا الخاصة",
                      onPressed: () {}),
                ),
              ],
            ),
            SizedBox(
              height: 40.h,
            ),
            aboutItem(
                title: "رسالتنا",
                descrption:
                    "منصة سعودية ريادية جمعت المختبرات الطبية الموثوقة تحت سقف واحد و تميزت بتقديم خدمة الاستشارات الطبية عن بعد في مجالات عدة  بإشراف نخبة من الأطباء السعوديين والعالميين"
                        .tr()),
            SizedBox(
              height: 56.h,
            ),
            aboutItem(
                title: "هدفنا",
                descrption:
                    "متخصصون في مجال علم الطب الوراثي، ونهدف الى الحد من انتشار الأمراض الوراثية في المجتمع ، عبر كوادر طبية مختصة في الأمراض والتحاليل المخبرية الوراثية."),
            SizedBox(
              height: 56.h,
            ),
            aboutItem(
                title: "رؤيتنا",
                descrption:
                    "أن نكون جزءًا من مسيرة المملكة العربية السعودية في تحقيق رؤيتها لنمو القطاع الصحي، وأن نحدث أثرًا في تحسين جودة الخدمات الطبية المقدمة لأفراد المجتمع."),
            SizedBox(
              height: 56.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "قيمنا",
                  style: StylesManger.rich().copyWith(
                      color: ColorManger.newPrimary,
                      fontSize: 24.sp,
                      fontWeight: FontWeight.w500),
                ),
              ],
            ),
            SizedBox(
              height: 32.h,
            ),
            aboutSpeicalItem(title: "التميز"),
            SizedBox(
              height: 48.h,
            ),
            aboutSpeicalItem(title: "دقة في التشخيص"),
            SizedBox(
              height: 48.h,
            ),
            aboutSpeicalItem(title: "المرونة"),
            SizedBox(
              height: 48.h,
            ),
            aboutSpeicalItem(title: "الابتكار"),
            SizedBox(
              height: 48.h,
            ),
            aboutSpeicalItem(title: "الموثوقية"),
            SizedBox(
              height: 48.h,
            ),
          ],
        ),
      ),
    );
  }

  Widget aboutSpeicalItem({required String title}) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 16.h, horizontal: 50.w),
      height: 180.h,
      width: double.infinity,
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(8.r)),
      child: Column(
        children: [
          CircleAvatar(
            radius: 50.r,
            backgroundColor: ColorManger.ligtNewPrimary,
            child: Center(
              child: SvgPicture.asset(
                "assets/images/about_us/speical.svg",
                color: ColorManger.newPrimary,
                height: 32.h,
                width: 32.w,
              ),
            ),
          ),
          SizedBox(
            height: 16.h,
          ),
          Text(
            title,
            style: StylesManger.rich().copyWith(
                color: ColorManger.newPrimary,
                fontSize: 24.sp,
                fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }

  Widget aboutItem({required String title, required String descrption}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: EdgeInsets.all(13),
              decoration: BoxDecoration(
                  color: Color(0xffEDFCFF),
                  borderRadius:
                      BorderRadius.circular(ConstantManger.borderRadius)),
              child: Center(
                child: SvgPicture.asset(
                  "assets/images/about_us/ourMessage.svg",
                  color: ColorManger.newPrimary,
                  height: 16.h,
                  width: 16.w,
                ),
              ),
            ),
          ],
        ),
        SizedBox(
          height: 24.h,
        ),
        Text(
          title,
          style: StylesManger.rich()
              .copyWith(fontSize: 24.sp, fontWeight: FontWeight.w500),
        ),
        SizedBox(
          height: 24.h,
        ),
        Text(
          descrption,
          style: StylesManger.small().copyWith(
            color: ColorManger.lightGrey,
          ),
        ),
      ],
    );
  }
}
