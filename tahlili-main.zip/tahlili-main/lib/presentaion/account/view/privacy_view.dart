import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';

import '../../resources/styles_manger.dart';

class PrivacyView extends StatelessWidget {
  const PrivacyView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        surfaceTintColor: Colors.white,
        elevation: 0,
        backgroundColor: Colors.white,
        title: Text(
          "Privacy".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
        centerTitle: true,
      ),
      backgroundColor: ColorManger.pageColor,
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        child: ListView(
          children: [
            SizedBox(
              height: 24.h,
            ),
            Container(
              width: double.infinity,
              height: 202.h,
              decoration: BoxDecoration(color: Color(0xffEDFCFF)),
              child: Center(
                child: Text(
                  "السياسات والخصوصية",
                  style: StylesManger.rich()
                      .copyWith(color: ColorManger.newPrimary),
                ),
              ),
            ),
            SizedBox(
              height: 40.h,
            ),
            privacyItem(
                title: "الحرص على خصوصيتك",
                body:
                    "تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك "),
            privacyItem(
                title: "الحرص على خصوصيتك",
                body:
                    "تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك "),
            privacyItem(
                title: "الحرص على خصوصيتك",
                body:
                    "تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك تحرص تحليلي على خصوصيتك "),
          ],
        ),
      ),
    );
  }

  Widget privacyItem({
    required String title,
    required String body,
  }) {
    return Padding(
      padding: EdgeInsets.only(bottom: 48.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: StylesManger.rich()
                .copyWith(color: ColorManger.newPrimary, fontSize: 24.sp),
          ),
          SizedBox(
            height: 16.h,
          ),
          Text(
            body,
            style: StylesManger.small().copyWith(color: Color(0xffA5A5A5)),
          )
        ],
      ),
    );
  }

  Widget aboutSpeicalItem({required String title}) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 16.h, horizontal: 50.w),
      height: 180.h,
      width: double.infinity,
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(8.r)),
      child: Column(
        children: [
          CircleAvatar(
            radius: 50.r,
            backgroundColor: ColorManger.ligtNewPrimary,
            child: Center(
              child: SvgPicture.asset(
                "assets/images/about_us/speical.svg",
                color: ColorManger.newPrimary,
                height: 32.h,
                width: 32.w,
              ),
            ),
          ),
          SizedBox(
            height: 16.h,
          ),
          Text(
            title,
            style: StylesManger.rich().copyWith(
                color: ColorManger.newPrimary,
                fontSize: 24.sp,
                fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }

  Widget aboutItem({required String title, required String descrption}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: EdgeInsets.all(13),
              decoration: BoxDecoration(
                  color: Color(0xffEDFCFF),
                  borderRadius:
                      BorderRadius.circular(ConstantManger.borderRadius)),
              child: Center(
                child: SvgPicture.asset(
                  "assets/images/about_us/ourMessage.svg",
                  color: ColorManger.newPrimary,
                  height: 16.h,
                  width: 16.w,
                ),
              ),
            ),
          ],
        ),
        SizedBox(
          height: 24.h,
        ),
        Text(
          title,
          style: StylesManger.rich()
              .copyWith(fontSize: 24.sp, fontWeight: FontWeight.w500),
        ),
        SizedBox(
          height: 24.h,
        ),
        Text(
          descrption,
          style: StylesManger.small().copyWith(
            color: ColorManger.lightGrey,
          ),
        ),
      ],
    );
  }
}
