import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:meta/meta.dart';
import 'package:pinput/pinput.dart';
import 'package:tahlili/app/pref_manager.dart';
import 'package:tahlili/data/requests/cart/request_cart.dart';
import 'package:tahlili/data/requests/order/request_order.dart';
import 'package:tahlili/data/response/cart/response_cart.dart';
import 'package:tahlili/domain/repository/cart/cart.dart';

import '../../../data/response/response.dart';
import '../../account/cubit/account_cubit.dart';
import '../../bnb/cubit/bnb_cubit.dart';
import '../../bnb/view/bnb_view.dart';
import '../../lab_appointments/view/lab_appointmnets.dart';
import '../../payment/view/payment_view.dart';
import '../../resources/shared/shared_widgets.dart';
import '../view/home_cart_view.dart';

part 'cart_state.dart';

class CartCubit extends Cubit<CartState> {
  CartCubit(this._cartRepository, this._preferancesManager)
      : super(CartInitial());
  final BaseCartRepository _cartRepository;
  final PreferancesManager _preferancesManager;
  List<ResponseCart> cart = [];
  double price = 0;
  int? patientId;
  int? addressId;
  getCart({required String filterQuery, required BuildContext context}) async {
    try {
      price = 0;
      cart.clear();
      emit(LoadGetGetCartState());
      final result = await _cartRepository.getCart(filterQuery: filterQuery);
      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetGetCartState(failure.message));
      }, (cart) {
        debugPrint(cart.length.toString());
        this.cart.addAll(cart);
        for (var element in cart) {
          price += element.package!.price!;
          patientId = element.patient!.id;
          addressId = element.addressId;
        }
        getPatientWallet(context);
        clacTotal(0);
        emit(SuccessGetGetCartState(cart));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetGetCartState(e.toString()));
    }
  }

  List<String> labPaymentMethod = ['Credit Card'];
  int? paymentValue;
  int paymentId = 2;
  setPayment(value) {
    paymentValue = value;
    paymentId = 2;
    emit(SetPaymentState());
  }

  addTotCart({
    required RequestCart cart,
  }) async {
    try {
      final userId = _preferancesManager.getData(key: userID);
      emit(LoadAddToCartState());
      final result =
          await _cartRepository.addToCart(userId: userId, requestCart: cart);
      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureAddToCartState(failure.message));
      }, (response) {
        debugPrint(response.message);
        toast(text: "Item Is Created Successfully", color: Colors.green);

        emit(SuccessAddToCartState(response));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureAddToCartState(e.toString()));
    }
  }

  deleteCartItem({
    required int cartId,
    required BuildContext context,
    required bool isHome
  }) async {
    try {
      emit(LoadDeleteCartItemState());
      final result = await _cartRepository.deleteCartItem(cartId: cartId);
      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureDeleteCartItemState(failure.message));
      }, (response) {
        debugPrint(response.message);
         if (isHome) {
      getCart(filterQuery: 'addressId!=null', context: context);
    } else {
      getCart(filterQuery: 'addressId==null', context: context);
    }
        emit(SuccessDeleteCartItemState(response));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureDeleteCartItemState(e.toString()));
    }
  }

  bool checkPgaeValidation(int? paymentId) {
    if (paymentId == null) {
      toast(text: "Choose Payment", color: Colors.red);
      return false;
    }

    return true;
  }

  createOrder(
      {required String? couponName,
      required int paymentTypeId,
      required bool useWallet,
      required bool? isMale,
      required BuildContext context}) async {
    try {
      final userId = _preferancesManager.getData(key: userID);
      emit(LoadCreateOrderState());
      final result = await _cartRepository.createOrder(
          order: RequestOrder(
              couponName, paymentTypeId, userId, useWallet, isMale));
      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureCreateOrderState());
      }, (response) {
        debugPrint(response.message);
        if (paymentTypeId == 2) {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => PaymentView(
                        amount: (total * 100).toInt(),
                        description: "O${response.id}",
                        fromTele: false,
                      )));

          toast(
              text: "Item has been created successfully", color: Colors.green);
        } else {
           context.read<BnbCubit>().setIndex(3, context);
           Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => const BNBView()));

          toast(
              text: "Item has been created successfully", color: Colors.green);
        }
        toast(
            gravity: ToastGravity.CENTER,
            text: "The appointment has	been	booked successfully",
            color: Colors.green);
        getCart(filterQuery: 'addressId!=null', context: context);

        emit(SuccessCreateOrderState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureCreateOrderState());
    }
  }



  createLabOrder(
      {required String? couponName,
      required bool useWallet,
      required BuildContext context}) async {
    try {
      final userId = _preferancesManager.getData(key: userID);
      emit(LoadCreateOrderState());
      final result = await _cartRepository.createLabOrder(
          order: RequestOrder(couponName, 2, userId, useWallet, null));
      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureCreateOrderState());
      }, (response) {
        debugPrint(response.message);
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => PaymentView(
                      amount: (total * 100).toInt(),
                      description: "O${response.id}",
                      fromTele: false,
                    )));

        toast(text: "Item has been created successfully", color: Colors.green);

        toast(
            gravity: ToastGravity.CENTER,
            text: "The appointment has	been	booked successfully",
            color: Colors.green);
        getCart(filterQuery: 'addressId==null', context: context);

        emit(SuccessCreateOrderState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureCreateOrderState());
    }
  }

  bool useWallet = false;
  switchWallet(bool value, double nurseFees) {
    useWallet = value;
    print(useWallet);
    clacTotal(nurseFees);
    emit(SwitchWalletState());
  }

  double total = 0;
  double? patientWallet;
  clacTotal(double nurseFees) {
    total = 0;
    print(nurseFees);
    total = price + nurseFees;
    if (useWallet) {
      total = total - patientWallet!;
      if (total < 0) total = 0;
    }
    emit(CalcTotalPriceState());
  }

  getPatientWallet(BuildContext context) {
    for (var i = 0;
        i < context.read<AccountCubit>().patinetProfiles.length;
        i++) {
      if (patientId == context.read<AccountCubit>().patinetProfiles[i].id!) {
        patientWallet =
            context.read<AccountCubit>().patinetProfiles[i].walletMoney!;
      }
    }
  }

  clearData() {
    total = 0;
    patientWallet = null;
    useWallet = false;
    price = 0;
    patientId = null;
    addressId = null;
    emit(ClearDataState());
  }
}
