part of 'cart_cubit.dart';

@immutable
sealed class CartState {}

final class CartInitial extends CartState {}


class LoadGetGetCartState extends CartState {}

class FailureGetGetCartState extends CartState {
  final String error;

  FailureGetGetCartState(this.error);
}

class SuccessGetGetCartState extends CartState {
  final List<ResponseCart> cart;

  SuccessGetGetCartState(this.cart);
}

class LoadAddToCartState extends CartState {}

class FailureAddToCartState extends CartState {
  final String error;

  FailureAddToCartState(this.error);
}

class SuccessAddToCartState extends CartState {
  final ResponseAPI responseAPI;

  SuccessAddToCartState(this.responseAPI);
}

class LoadDeleteCartItemState extends CartState {}

class FailureDeleteCartItemState extends CartState {
  final String error;

  FailureDeleteCartItemState(this.error);
}

class SuccessDeleteCartItemState extends CartState {
  final ResponseAPI responseAPI;

  SuccessDeleteCartItemState(this.responseAPI);
}

class LoadCreateOrderState extends CartState{}

class SuccessCreateOrderState extends CartState{}

class FailureCreateOrderState extends CartState{}

class SwitchWalletState extends CartState{}

class CalcTotalPriceState extends CartState{}

class ClearDataState extends CartState{}

class SetPaymentState extends CartState{}
