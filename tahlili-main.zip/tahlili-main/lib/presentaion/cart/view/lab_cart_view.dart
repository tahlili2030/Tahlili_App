import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:tahlili/presentaion/cart/cubit/cart_cubit.dart';
import 'package:tahlili/presentaion/orders/cubit/orders_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';

import '../../account/cubit/account_cubit.dart';
import '../../orders/view/home/home_order_first_page.dart';
import '../../resources/constant_manger.dart';
import '../../resources/shared/app_button.dart';
import '../../resources/styles_manger.dart';

class LabCartView extends StatelessWidget {
  const LabCartView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<CartCubit>();
    cubit.clearData();
     cubit.setPayment(0);
    final orderCubit = context.read<OrdersCubit>();
    cubit.getCart(filterQuery: 'addressId==null',context: context);
    orderCubit.getPayMentType();
    return BlocBuilder<CartCubit, CartState>(
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            elevation: 0,
            backgroundColor: Colors.white,
            title: Text(
              "lab Cart".tr(),
              style: StylesManger.rich().copyWith(color: Colors.black),
            ),
            centerTitle: true,
          ),
          backgroundColor: Colors.white,
          body: cubit.cart.isEmpty?const SizedBox(): SingleChildScrollView(
            child: Column(
              children: [
                const AppBarDivider(),
                const SizedBox(
                  height: 16,
                ),
               SizedBox(
                        height: cubit.cart.length < 2 ? 330 : 500,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child:
                              ListView.separated(
                                  itemBuilder: (context, index) => Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 8, vertical: 16),
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                              color: ColorManger.grey,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        child: Column(
                                          children: [
                                            Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  context.locale.languageCode ==
                                                          'ar'
                                                      ? cubit.cart[index]
                                                          .package!.nameAr!
                                                      : cubit.cart[index]
                                                          .package!.nameEn!,
                                                  style: StylesManger.rich()
                                                      .copyWith(
                                                          color: Colors.black),
                                                ),
                                                cartPopUp(context, 0)
                                              ],
                                            ),
                                            const SizedBox(
                                              height: 16,
                                            ),
                                            cartDetailItem(
                                              title: "PatientName".tr(),
                                              body: cubit.cart[index].patient!
                                                      .firstName! +
                                                  cubit.cart[index].patient!
                                                      .lastName!),
                                            cartDetailItem(
                                              title: "Date".tr(),
                                              body: context.locale
                                                          .languageCode ==
                                                      "ar"
                                                  ? DateFormat(
                                                          "EEEE, dd-MM-yyyy",
                                                          'ar')
                                                      .format(DateTime.parse(
                                                          cubit.cart[index]
                                                              .vistDate!))
                                                  : DateFormat("EEEE, dd-MM-yyyy")
                                                      .format(DateTime.parse(
                                                          cubit.cart[index]
                                                              .vistDate!))),
                                             cartDetailItem(
                                              title:
                                                  "PreferedVisitingTime".tr(),
                                              body:
                                                  "${DateFormat('hh:mm', 'ar').format(DateTime.parse(cubit.cart[index].vistDate!))} - ${DateFormat('hh:mm a').format(DateTime.parse(cubit.cart[index].vistDate!).add(const Duration(minutes: 30)))}"),
                                            cartDetailItem(
                                              title: "Partner".tr(),
                                              body:
                                                  context.locale.languageCode ==
                                                          "ar"
                                                      ? cubit.cart[index]
                                                          .partner!.nameAr!
                                                      : cubit.cart[index]
                                                          .partner!.nameEn!),
                                           cartDetailItem(
                                              title: "Total".tr(),
                                              body:
                                                  "${cubit.cart[index].package!.price!} ${"SAR".tr()}"),
                                          ],
                                        ),
                                      ),
                                  separatorBuilder: (context, index) =>
                                      const SizedBox(
                                        height: 16,
                                      ),
                                  itemCount: cubit.cart.length),
                        )),

                const SizedBox(
                  height: 16,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: BlocBuilder<CartCubit, CartState>(
                    builder: (context, state) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                          OrderDropDown(
                              profileImage: [],
                              title: "PaymentType".tr(),
                              hintText:"PaymentType".tr(),
                              value: cubit.paymentValue,
                              list: cubit.labPaymentMethod,
                              onDropCahnge: (value) {
                                cubit.setPayment(value);
                              }),
                          Text("Coupon".tr(),
                              style: StylesManger.medium().copyWith(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500)),
                          const SizedBox(
                            height: 8,
                          ),
                          Row(
                            children: [
                              Expanded(
                                child: TextFormField(
                                  //  controller: cubit.couponController,
                                  decoration: InputDecoration(
                                    border: const OutlineInputBorder(),
                                    contentPadding: EdgeInsets.zero,
                                    suffixIcon: ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                          shape: const RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadiusDirectional.only(
                                            topEnd: Radius.circular(5),
                                            bottomEnd: Radius.circular(5),
                                          )),
                                          backgroundColor: ColorManger.primary,
                                          foregroundColor: Colors.white),
                                      onPressed: () {},
                                      child:  Text("ApplyCopoun".tr()),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(
                                width: 5,
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                          Text("Reservation Summary".tr(),
                              style: StylesManger.medium().copyWith(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              )),
                          const SizedBox(
                            height: 8,
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 16),
                            decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey),
                                borderRadius: BorderRadius.circular(5)),
                            child: Column(
                              children: [

                                 orderDetails(
                                          title: "CouponDiscount".tr(),
                                          content: "0"),
                                   context.read<AccountCubit>().patient.first.nationalityId==192?const SizedBox():    orderDetails(
                                          title: "VAT".tr(), content: "${ConstantManger.vat}%"),
                                      BlocBuilder<CartCubit, CartState>(
                                        builder: (context, state) {
                                          return Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                cubit.patientWallet != null
                                                    ? "${"WalletCredit".tr()} (${cubit.patientWallet} ${"SAR".tr()})"
                                                    : "${"WalletCredit".tr()} (0 ${"SAR".tr()})",
                                                style: StylesManger.rich()
                                                    .copyWith(
                                                        color: Colors.black),
                                              ),
                                              Switch(
                                                  materialTapTargetSize:
                                                      MaterialTapTargetSize
                                                          .padded,
                                                  activeTrackColor:
                                                      ColorManger.primary,
                                                  inactiveTrackColor:
                                                      Colors.grey,
                                                  value: cubit.useWallet,
                                                  onChanged: (value) {
                                                    cubit.switchWallet(value,
                                                        0);
                                                  })
                                            ],
                                          );
                                        },
                                      ),
                                      orderDetails(
                                          title: "Total".tr(),
                                          content: "${cubit.total} ${"SAR".tr()}"),
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 70,
                          ),
                          AppButton(
                              color: ColorManger.primary,
                              name: "PaymentAndCheckout".tr(),
                              onPressed: () {
                                context.read<AccountCubit>().instantTele=false;
                                cubit.createLabOrder(
                                    context: context,
                                      couponName: '',

                                      useWallet: cubit.useWallet,
                                      );
                              }),
                        ],
                      );
                    },
                  ),
                ),
                const SizedBox(
                  height: 8,
                )
              ],
            ),
          ),
        );
      },
    );
  }

  Widget cartDetailItem({required String title, required String body}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: StylesManger.medium().copyWith(
                fontSize: 13, fontWeight: FontWeight.w800, color: Colors.black),
          ),
          Text(
            body,
            style: StylesManger.medium()
                .copyWith(fontSize: 13, color: ColorManger.buttonColor),
          ),
        ],
      ),
    );
  }
}

Widget cartPopUp(BuildContext context, int orderId) {
  return Theme(
    data: Theme.of(context).copyWith(
        cardColor: Colors.white,
        popupMenuTheme: const PopupMenuThemeData(
          color: Colors.white,
          elevation: 0,
        )),
    child: PopupMenuButton(
      padding: const EdgeInsets.only(bottom: 20),

      // color: Colors.black,
      position: PopupMenuPosition.under,
      iconSize: 30,
      icon: const Icon(
        FontAwesomeIcons.ellipsisH,
        color: Colors.black,
      ),

      itemBuilder: (context) {
        return [
          PopupMenuItem(
            value: 0,
            child: Column(
              children: [
                 ListTile(
                  leading:const Icon(
                    Icons.remove_red_eye_outlined,
                    color: Colors.black,
                  ),
                  title: Text(
                   "ViewDetails".tr(),
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10),
                  height: 1,
                  width: double.infinity,
                  color: ColorManger.grey,
                )
              ],
            ),
          ),
          PopupMenuItem(
            value: 1,
            child: Column(
              children: [
                 ListTile(
                  leading:const Icon(
                    Icons.file_download_outlined,
                    color: Colors.black,
                  ),
                  title: Text("DownloadFile".tr()),
                ),
                const SizedBox(
                  height: 5,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10),
                  height: 1,
                  width: double.infinity,
                  color: ColorManger.grey,
                )
              ],
            ),
          ),
          PopupMenuItem(
            value: 2,
            child: Column(
              children: [
                 ListTile(
                  leading:const Icon(
                    Icons.map_outlined,
                    color: Colors.black,
                  ),
                  title: Text("TrackOrder".tr()),
                ),
                const SizedBox(
                  height: 5,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10),
                  height: 1,
                  width: double.infinity,
                  color: ColorManger.grey,
                )
              ],
            ),
          ),
          PopupMenuItem(
            value: 3,
            child: ListTile(
              leading: Icon(
                Icons.delete,
                color: Colors.red[900],
              ),
              title:  Text("Delete".tr()),
            ),
          )
        ];
      },
      onSelected: (value) async {
        switch (value) {
          case 0:
            // Navigator.push(
            //     context,
            //     MaterialPageRoute(
            //       builder: (context) => OrderDetailsView(
            //        order: cubit.orders[index],
            //       ),
            //     ));
            break;
          case 1:
            break;
          case 2:
            // await  context.read<MapCubit>().getNurseLocation(orderID:orderId);
            // Navigator.push(context, MaterialPageRoute(builder: (context)=>TrackingNurse()));
            break;

          case 3:
            print("2");

            break;
        }
      },
    ),
  );
}

Widget orderDetails({
  required String title,
  required String content,
}) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(
        title,
        style: StylesManger.rich().copyWith(color: Colors.black),
      ),
      Text(
        content,
        style: StylesManger.medium().copyWith(color: Colors.black),
      ),
    ],
  );
}
