import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/auth/cubit/auth_cubit.dart';
import 'package:tahlili/presentaion/cart/cubit/cart_cubit.dart';
import 'package:tahlili/presentaion/orders/cubit/orders_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';

import '../../home/cubit/home_cubit.dart';
import '../../home/view/widgest/home_item.dart';
import '../../orders/view/home/home_order_first_page.dart';
import '../../resources/shared/app_button.dart';
import '../../resources/shared/view_details.dart';
import '../../resources/styles_manger.dart';

class HomeCartView extends StatelessWidget {
  const HomeCartView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<CartCubit>();
    cubit.clearData();
    final orderCubit = context.read<OrdersCubit>();
    cubit.getCart(filterQuery: 'addressId!=null', context: context);
    orderCubit.getPayMentType();
    return BlocBuilder<CartCubit, CartState>(
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            elevation: 0,
            backgroundColor: Colors.white,
            title: Text(
              "Home Cart".tr(),
              style: StylesManger.rich().copyWith(color: Colors.black),
            ),
            centerTitle: true,
          ),
          backgroundColor: Colors.white,
          body: cubit.cart.isEmpty
              ? const SizedBox()
              : SingleChildScrollView(
                  child: Column(
                    children: [
                      const AppBarDivider(),
                      const SizedBox(
                        height: 16,
                      ),
                      SizedBox(
                          height: cubit.cart.length < 2 ? 330 : 500,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: ListView.separated(
                                itemBuilder: (context, index) => Container(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 16.w, vertical: 16.h),
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                            color: ColorManger.lightBlack,
                                          ),
                                          borderRadius: BorderRadius.circular(
                                              ConstantManger.borderRadius),
                                          color: Colors.white),
                                      child: Column(
                                        children: [
                                          Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                height: 75.h,
                                                width: 90.w,
                                                decoration: BoxDecoration(
                                                  color: ColorManger.blueBlack,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          ConstantManger
                                                              .borderRadius),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 16.w,
                                              ),
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                      padding:
                                                          EdgeInsets.all(4),
                                                      decoration: BoxDecoration(
                                                        color:
                                                            Color(0xffE6FBF3),
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                ConstantManger
                                                                    .borderRadius),
                                                      ),
                                                      child: Row(
                                                        children: [
                                                          if (cubit.cart[index]
                                                                  .package !=
                                                              null)
                                                            Text(
                                                              "${(cubit.cart[index].package!.tat! / 24).round()} يوم",
                                                              style: StylesManger
                                                                      .extremelySmall()
                                                                  .copyWith(
                                                                color: Color(
                                                                    0xff5DB896),
                                                              ),
                                                            ),
                                                          if (cubit.cart[index]
                                                                  .test !=
                                                              null)
                                                            Text(
                                                              "${cubit.cart[index].test!.tat! / 24} يوم",
                                                              style: StylesManger
                                                                      .extremelySmall()
                                                                  .copyWith(
                                                                color: Color(
                                                                    0xff5DB896),
                                                              ),
                                                            ),
                                                          SizedBox(
                                                            width: 4.w,
                                                          ),
                                                          Icon(
                                                            Icons
                                                                .watch_later_outlined,
                                                            size: 15,
                                                            color: Color(
                                                                0xff5DB896),
                                                          ),
                                                        ],
                                                      )),
                                                  SizedBox(
                                                    height: 6.h,
                                                  ),
                                                  if (cubit.cart[index]
                                                          .package !=
                                                      null)
                                                    Column(
                                                      children: [
                                                        Container(
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  horizontal:
                                                                      16.w,
                                                                  vertical:
                                                                      8.h),
                                                          decoration: BoxDecoration(
                                                              color: ColorManger
                                                                  .newPrimary
                                                                  .withOpacity(
                                                                      .1),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          30.r)),
                                                          child: Center(
                                                            child: Text(
                                                              cubit.cart[index]
                                                                          .package !=
                                                                      null
                                                                  ? "باقه"
                                                                  : "فحص",
                                                              style: StylesManger
                                                                      .small()
                                                                  .copyWith(
                                                                      color: ColorManger
                                                                          .newPrimary),
                                                            ),
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          height: 8.h,
                                                        ),
                                                        Text(
                                                          context.locale
                                                                      .languageCode ==
                                                                  'en'
                                                              ? cubit
                                                                  .cart[index]
                                                                  .package!
                                                                  .nameEn!
                                                              : cubit
                                                                  .cart[index]
                                                                  .package!
                                                                  .nameAr!,
                                                          style: StylesManger
                                                                  .small()
                                                              .copyWith(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700),
                                                        ),
                                                      ],
                                                    ),
                                                  if (cubit.cart[index].test !=
                                                      null)
                                                    Text(
                                                      context.locale
                                                                  .languageCode ==
                                                              'en'
                                                          ? cubit.cart[index]
                                                              .test!.nameEn!
                                                          : cubit.cart[index]
                                                              .test!.nameAr!,
                                                      style: StylesManger
                                                              .small()
                                                          .copyWith(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700),
                                                    )
                                                ],
                                              ),
                                              const Spacer(),
                                              CircleAvatar(
                                                radius: 12.r,
                                                backgroundColor:
                                                    Color(0xffD64045),
                                                child: Icon(
                                                  Icons.close,
                                                  color: Colors.white,
                                                ),
                                              )
                                            ],
                                          ),
                                          SizedBox(
                                            height: 16.h,
                                          ),
                                          Padding(
                                            padding: EdgeInsetsDirectional.only(
                                                end: 80.w),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    if (cubit.cart[index]
                                                            .addressName !=
                                                        null)
                                                      apttDetails(
                                                          icon: Icons
                                                              .location_on_outlined,
                                                          title: "العنوان:",
                                                          body: cubit
                                                              .cart[index]
                                                              .addressName!),
                                                    apttDetails(
                                                        icon: Icons
                                                            .location_on_outlined,
                                                        title: "اسم المريض:",
                                                        body: cubit
                                                                .cart[index]
                                                                .patient!
                                                                .firstName! +
                                                            " " +
                                                            cubit
                                                                .cart[index]
                                                                .patient!
                                                                .lastName!),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 16.h,
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    apttDetails(
                                                        icon: Icons
                                                            .location_on_outlined,
                                                        title: "وقت الزيارة:",
                                                        body: DateFormat(
                                                                'h:mm a')
                                                            .format(DateTime
                                                                .parse(cubit
                                                                    .cart[index]
                                                                    .vistDate!))),
                                                    apttDetails(
                                                        icon: Icons
                                                            .location_on_outlined,
                                                        title: "تاريخ الزيارة:",
                                                        body: DateFormat(
                                                                'EEE dd MM yyy')
                                                            .format(DateTime
                                                                .parse(cubit
                                                                    .cart[index]
                                                                    .vistDate!))),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 16.h,
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    apttDetails(
                                                        icon: Icons
                                                            .location_on_outlined,
                                                        title: "اسم المختبر:",
                                                        body: context.locale
                                                                    .languageCode ==
                                                                'ar'
                                                            ? cubit
                                                                .cart[index]
                                                                .partner!
                                                                .nameAr!
                                                            : cubit
                                                                .cart[index]
                                                                .partner!
                                                                .nameEn!),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 16.h,
                                          ),
                                          Container(
                                            height: 1,
                                            width: double.infinity,
                                            color: ColorManger.lightGrey,
                                          ),
                                          SizedBox(
                                            height: 16.h,
                                          ),
                                          AppButton(
                                              textSize: 12.sp,
                                              radius:
                                                  ConstantManger.borderRadius,
                                              textColor: ColorManger.newPrimary,
                                              color: Colors.white,
                                              name: "استعراض الخدمة",
                                              onPressed: () {}),
                                        ],
                                      ),
                                    ),
                                separatorBuilder: (context, index) =>
                                    const SizedBox(
                                      height: 16,
                                    ),
                                itemCount: cubit.cart.length),
                          )),
                      const SizedBox(
                        height: 16,
                      ),
                      SizedBox(
                        height: 16.h,
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 16.w, vertical: 16.h),
                        decoration: BoxDecoration(
                            border: Border.all(
                              color: ColorManger.lightBlack,
                            ),
                            borderRadius: BorderRadius.circular(
                                ConstantManger.borderRadius),
                            color: Colors.white),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "تفاصيل الدفع",
                              style: StylesManger.rich(),
                            ),
                            SizedBox(
                              height: 16.h,
                            ),
                            Container(
                              height: 1,
                              width: double.infinity,
                              color: ColorManger.lightGrey,
                            ),
                            SizedBox(
                              height: 16.h,
                            ),
                            Text(
                              "الممارس الصحي",
                              style: StylesManger.small()
                                  .copyWith(color: ColorManger.blueBlack),
                            ),
                            OrderDropDown(
                                profileImage: [],
                                title: "",
                                hintText: "الممارس الصحي",
                                value: orderCubit.nurseValue,
                                list: context.locale.languageCode == 'ar'
                                    ? orderCubit.arNurses
                                    : orderCubit.enNurses,
                                onDropCahnge: (value) {
                                  // orderCubit.setNurse(
                                  //     value, cubit.price, cubit.addressId!);
                                }),
                            paymentItem(
                                title: "الاجمالي الفرعي",
                                body: "TODO ${"SAR".tr()}"),
                            paymentItem(
                                title: "خصم الكوبون", body: "0 ${"SAR".tr()}"),
                            paymentItem(
                                title: "ضريبة القيمة المضافة",
                                body: "${ConstantManger.vat} ${"SAR".tr()}"),
                            paymentItem(
                                title: "المبلغ الاجمالي",
                                body: "${cubit.total} ${"SAR".tr()}"),
                            SizedBox(
                              height: 16.h,
                            ),
                            Text(
                              "رمز الخصم ",
                              style: StylesManger.small()
                                  .copyWith(color: ColorManger.blueBlack),
                            ),
                            Row(
                              children: [
                                Expanded(
                                  child: TextFormField(
                                    //  controller: cubit.couponController,
                                    decoration: InputDecoration(
                                      border: const OutlineInputBorder(),
                                      contentPadding: EdgeInsets.zero,
                                      suffixIcon: ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            shape: const RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadiusDirectional
                                                        .only(
                                              topEnd: Radius.circular(5),
                                              bottomEnd: Radius.circular(5),
                                            )),
                                            backgroundColor:
                                                ColorManger.newPrimary,
                                            foregroundColor: Colors.white),
                                        onPressed: () {},
                                        child: Text("نطبيق"),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  width: 5,
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 16.h,
                            ),
                            OrderDropDown(
                                profileImage: [],
                                title: "PaymentType".tr(),
                                hintText: "PaymentType".tr(),
                                value: orderCubit.paymentValue,
                                list: orderCubit.methods,
                                onDropCahnge: (value) {
                                  orderCubit.setPayment(value);
                                }),
                            Container(
                              height: 1,
                              width: double.infinity,
                              color: ColorManger.lightGrey,
                            ),
                            SizedBox(
                              height: 16.h,
                            ),
                            Column(
                              children: [
                                AppButton(
                                    textSize: 12.sp,
                                    radius: ConstantManger.borderRadius,
                                    textColor: Colors.white,
                                    color: ColorManger.newPrimary,
                                    name: "PaymentAndCheckout".tr(),
                                    onPressed: () {
                                      if (cubit.checkPgaeValidation(
                                          orderCubit.paymentId)) {
                                        context
                                            .read<AccountCubit>()
                                            .instantTele = false;
                                        cubit.createOrder(
                                            context: context,
                                            couponName: '',
                                            paymentTypeId:
                                                orderCubit.paymentId!,
                                            useWallet: cubit.useWallet,
                                            isMale: orderCubit.isMale);
                                      }
                                    }),
                              ],
                            )
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 8,
                      )
                    ],
                  ),
                ),
        );
      },
    );
  }

  Widget cartDetailItem({required String title, required String body}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: StylesManger.medium().copyWith(
                fontSize: 13, fontWeight: FontWeight.w800, color: Colors.black),
          ),
          Text(
            body,
            style: StylesManger.medium()
                .copyWith(fontSize: 13, color: ColorManger.buttonColor),
          ),
        ],
      ),
    );
  }
}

Widget cartPopUp(BuildContext context, int orderId, int cartId) {
  return Theme(
    data: Theme.of(context).copyWith(
        cardColor: Colors.white,
        popupMenuTheme: const PopupMenuThemeData(
          color: Colors.white,
          elevation: 0,
        )),
    child: PopupMenuButton(
      padding: const EdgeInsets.only(bottom: 20),

      // color: Colors.black,
      position: PopupMenuPosition.under,
      iconSize: 30,
      icon: const Icon(
        FontAwesomeIcons.ellipsisH,
        color: Colors.black,
      ),

      itemBuilder: (context) {
        return [
          PopupMenuItem(
            value: 0,
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(
                    Icons.remove_red_eye_outlined,
                    color: Colors.black,
                  ),
                  title: Text(
                    "ViewDetails".tr(),
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10),
                  height: 1,
                  width: double.infinity,
                  color: ColorManger.grey,
                )
              ],
            ),
          ),
          PopupMenuItem(
            value: 1,
            child: ListTile(
              leading: Icon(
                Icons.delete,
                color: Colors.red[900],
              ),
              title: Text("Delete".tr()),
            ),
          )
        ];
      },
      onSelected: (value) async {
        switch (value) {
          case 0:
            context
                .read<HomeCubit>()
                .getShownDealsDetails(itemId: orderId)
                .whenComplete(() => showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                          actionsPadding: EdgeInsets.zero,
                          actions: [
                            ViewDetailsWidget(
                                fromCart: true,
                                deals: context
                                    .read<HomeCubit>()
                                    .dealsDetails
                                    .first)
                          ],
                        )));
            break;
          case 1:
            context
                .read<CartCubit>()
                .deleteCartItem(cartId: cartId, context: context, isHome: true);
            break;
        }
      },
    ),
  );
}

Widget orderDetails({
  required String title,
  required String content,
}) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(
        title,
        style: StylesManger.small().copyWith(
            color: ColorManger.blueBlack, fontWeight: FontWeight.w500),
      ),
      Text(
        content,
        style: StylesManger.small()
            .copyWith(color: Color(0xffA5A5A5), fontWeight: FontWeight.w500),
      ),
    ],
  );
}

Widget apttDetails(
    {required IconData icon, required String title, required String body}) {
  return Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Icon(
        icon,
        color: ColorManger.lightGrey,
        size: 20.r,
      ),
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: StylesManger.small().copyWith(color: ColorManger.lightGrey),
          ),
          SizedBox(
            width: 70.w,
            child: Text(
              body,
              style:
                  StylesManger.small().copyWith(color: ColorManger.newPrimary),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          )
        ],
      )
    ],
  );
}

Widget paymentItem({required String title, required String body}) {
  return Padding(
    padding: EdgeInsets.only(bottom: 16.h),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: StylesManger.small().copyWith(color: ColorManger.blueBlack),
        ),
        Text(
          body,
          style: StylesManger.small().copyWith(color: ColorManger.lightGrey),
        ),
      ],
    ),
  );
}
