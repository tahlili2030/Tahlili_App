part of 'wishlist_cubit.dart';

@immutable
sealed class WishlistState {}

final class WishlistInitial extends WishlistState {}

class LoadGetWishlistState extends WishlistState {}

class FailureGetWishlistState extends WishlistState {
  final String error;

  FailureGetWishlistState(this.error);
}

class SuccessGetWishlistState extends WishlistState {
  final List<ResponseWishlist> wishlist;

  SuccessGetWishlistState(this.wishlist);
}

class LoadAddToWishlistState extends WishlistState {}

class FailureAddToWishlistState extends WishlistState {
  final String error;

  FailureAddToWishlistState(this.error);
}

class SuccessAddToWishlistState extends WishlistState {
  final ResponseAPI responseAPI;

  SuccessAddToWishlistState(this.responseAPI);
}


class LoadDeleteWishlistItemState extends WishlistState {}

class FailureDeleteWishlistItemState extends WishlistState {
  final String error;

  FailureDeleteWishlistItemState(this.error);
}

class SuccessDeleteWishlistItemState extends WishlistState {
  final ResponseAPI responseAPI;

  SuccessDeleteWishlistItemState(this.responseAPI);
}