import 'package:bloc/bloc.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';
import 'package:tahlili/data/requests/wishlist/request_wishlist.dart';
import 'package:tahlili/data/response/response.dart';
import 'package:tahlili/data/response/wishlist/response_wishlist.dart';
import 'package:tahlili/domain/repository/wishlist/wishlist.dart';
import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';

part 'wishlist_state.dart';

class WishlistCubit extends Cubit<WishlistState> {
  WishlistCubit(this._wishlistRepository) : super(WishlistInitial());

  final BaseWishlistRepository _wishlistRepository;
List<ResponseWishlist> wishlist=[];
  getWishlist() async {
    try {
      wishlist.clear();
      emit(LoadGetWishlistState());
      final result = await _wishlistRepository.getWishlist(asc: true);
      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetWishlistState(failure.message));
      }, (wishlist) {
        debugPrint(wishlist.length.toString());
        this.wishlist.addAll(wishlist);
        emit(SuccessGetWishlistState(wishlist));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetWishlistState(e.toString()));
    }
  }

 Future addToWishlit({
    required RequestWishlist wishlist
  }) async {
    try {
      emit(LoadAddToWishlistState());
      final result = await _wishlistRepository.addToWishlit(
          requestWishlist: wishlist);
      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureAddToWishlistState(failure.message));
      }, (wishlist) {
        debugPrint(wishlist.message);
        toast(text: "item has been added", color: Colors.green);
        getWishlist();
        emit(SuccessAddToWishlistState(wishlist));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureAddToWishlistState(e.toString()));
    }
  }

  deleteWishlistItem({
    required int itemId
  }) async {
    try {
      emit(LoadDeleteWishlistItemState());
      final result = await _wishlistRepository.deleteWishlistItem(
          itemId: itemId);
      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureDeleteWishlistItemState(failure.message));
      }, (wishlist) {
        debugPrint(wishlist.message);
        toast(text: "item has been removed", color: Colors.green);
        getWishlist();
        emit(SuccessDeleteWishlistItemState(wishlist));
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureDeleteWishlistItemState(e.toString()));
    }
  }
}
