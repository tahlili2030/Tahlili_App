import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/presentaion/wishlist/cubit/wishlist_cubit.dart';

import '../../home/view/widgest/new_home_widget.dart';
import '../../resources/color_manger.dart';
import '../../resources/shared/appbar_divider.dart';
import '../../resources/styles_manger.dart';

class WishlistView extends StatelessWidget {
  const WishlistView({super.key});
  final String photo =
      'https://img.freepik.com/free-vector/science-logo-template-design_23-2150369141.jpg?size=338&ext=jpg&ga=GA1.1.1413502914.1701561600&semt=ais';

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<WishlistCubit>();
    cubit.getWishlist();
    return BlocBuilder<WishlistCubit, WishlistState>(
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            centerTitle: true,
            title: Text(
              "Wishlist".tr(),
              style: StylesManger.medium()
                  .copyWith(color: Colors.black, fontSize: 18),
            ),
          ),
          backgroundColor: ColorManger.pageColor,
          body: Column(
            children: [
              const AppBarDivider(),
              const SizedBox(
                height: 8,
              ),
              Expanded(
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
                  child: GridView.builder(
                      shrinkWrap: true,
                      itemCount: cubit.wishlist.length,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          // rmainAxisExtent:MediaQuery.of(context).size.height>800? 212.h:240.h,
                          childAspectRatio: .67,
                          crossAxisSpacing: 10,
                          mainAxisSpacing: 10),
                      itemBuilder: (context, index) => HomeNewCard(
                            fromWishList: true,
                            testId: null,
                            partnerId: 0,
                            discount: null,
                            packageId: cubit.wishlist[index].id!,
                            labName: context.locale.languageCode == 'ar'
                                ? cubit
                                    .wishlist[index].package!.partner!.nameAr!
                                : cubit
                                    .wishlist[index].package!.partner!.nameEn!,
                            labImage: null,
                            image: (context.locale.languageCode == 'ar'
                                ? cubit.wishlist[index].imageAR!
                                : cubit.wishlist[index].imageEN!),
                            packageName: context.locale.languageCode == 'ar'
                                ? cubit
                                    .wishlist[index].package!.package!.nameAr!
                                : cubit
                                    .wishlist[index].package!.package!.nameEn!,
                            description:
                                "الوصف الخاص بالخدمة الوصف الخاص بالخدمةالوصف الخاص بالخدمةالوصف",
                            price: cubit.wishlist[index].package!.price!,
                          )),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget wishlistPopUp(BuildContext context, int wishListId) {
    return Theme(
      data: Theme.of(context).copyWith(
          cardColor: Colors.white,
          popupMenuTheme: const PopupMenuThemeData(
            color: Colors.white,
            elevation: 0,
          )),
      child: PopupMenuButton(
        padding: const EdgeInsets.only(bottom: 20),

        // color: Colors.black,
        position: PopupMenuPosition.under,
        iconSize: 20,
        icon: const Icon(
          FontAwesomeIcons.ellipsisH,
          color: Colors.black,
        ),

        itemBuilder: (context) {
          return [
            PopupMenuItem(
              value: 0,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.remove_red_eye_outlined,
                      color: Colors.black,
                    ),
                    title: Text(
                      "ViewDetails".tr(),
                    ),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 1,
                    width: double.infinity,
                    color: ColorManger.grey,
                  )
                ],
              ),
            ),
            PopupMenuItem(
              value: 1,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.delete,
                      color: Colors.red,
                    ),
                    title: Text("Delete".tr()),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 1,
                    width: double.infinity,
                    color: ColorManger.grey,
                  )
                ],
              ),
            ),
          ];
        },
        onSelected: (value) async {
          switch (value) {
            case 0:
              // Navigator.push(context, MaterialPageRoute(builder: (context)=>TeleMedDetailsView()));

              break;
            case 1:
              context
                  .read<WishlistCubit>()
                  .deleteWishlistItem(itemId: wishListId);
              break;
          }
        },
      ),
    );
  }
}
