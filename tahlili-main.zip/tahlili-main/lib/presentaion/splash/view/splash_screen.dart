import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'package:flutter/material.dart';
import 'package:tahlili/app/pref_manager.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/auth/cubit/auth_cubit.dart';
import 'package:tahlili/presentaion/bnb/view/bnb_view.dart';
import 'package:tahlili/presentaion/map/cubit/map_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/wishlist/cubit/wishlist_cubit.dart';

import '../../onBording/view/onBordingSizes.dart';

class SplashScreen extends StatefulWidget {
  final PreferancesManager _preferancesManager;

  const SplashScreen(this._preferancesManager, {super.key});
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  late Timer _timer;
  int _seconds = 0;
  bool _imageChanged = false;
  final List<Color> _circleColors = [
    ColorManger.grey,
    ColorManger.grey,
    ColorManger.grey,
    ColorManger.grey
  ];

  @override
  void initState() {
    super.initState();
    context.read<AuthCubit>().start();
    context.read<MapCubit>().start();

    context.read<AccountCubit>().start();
    context.read<WishlistCubit>().getWishlist();

    _startTimer();
  }

  void _startTimer() async {
    final token = await widget._preferancesManager.getData(key: userToken);

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _seconds++;

        if (_seconds == 2) {
          _imageChanged = true;
        }

        if (_seconds == 5) {
          _timer.cancel();
          if (token != null) {
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => const BNBView()));
          } else {
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => OnBoridingSizesView()));
          }
        }

        if (_seconds < 5) {
          // Gradually change circle colors from grey to red
          _circleColors[_seconds - 1] = ColorManger.primary;
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.only(top: 250),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              _imageChanged
                  ? SvgPicture.asset('assets/images/logo_name1.svg',
                      height: 97, width: 75)
                  : SvgPicture.asset('assets/images/logo_with_title.svg',
                      height: 92, width: 200),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCircleAvatar(Color color) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 10),
      child: CircleAvatar(
        radius: 7,
        backgroundColor: color,
      ),
    );
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }
}
