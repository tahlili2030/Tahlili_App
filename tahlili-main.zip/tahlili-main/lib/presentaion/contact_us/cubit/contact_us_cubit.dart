import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/data/requests/auth/request_contact_us.dart';
import 'package:tahlili/data/response/response.dart';
import 'package:tahlili/domain/repository/auth/auth.dart';

import '../../../data/network/error_handler.dart';

part 'contact_us_state.dart';

class ContactUsCubit extends Cubit<ContactUsState> {
  ContactUsCubit(this._authRepository) : super(ContactUsInitial());

  final BaseAuthRepository _authRepository;
final contactForm=GlobalKey<FormState>();
  final TextEditingController fNameController =TextEditingController();
  final TextEditingController lNameController =TextEditingController();
  final TextEditingController phoneController =TextEditingController();
  final TextEditingController emailController =TextEditingController();
  final TextEditingController descriptionController =TextEditingController();

  contactUs({
    required String languageCode
  }) async {
    emit(LoadContactUsState());
    try {
      final result = await _authRepository.contactUs(
          requestContactUs:
              RequestContactUs(fNameController.text, lNameController.text, emailController.text,
               phoneController.text, descriptionController.text));
      result.fold((failure)async{
        debugPrint(failure);
         await handleSuccessMessages(failure, languageCode, Colors.red);
        emit(FailureContactUsState(failure));
      }, (response)async{
        debugPrint(response.message);
                 await handleSuccessMessages(response.message.orEmpty(),languageCode, Colors.green);

        emit(SuccessContactUsState(response));
      });
    } catch (e) {
      debugPrint(e.toString());
       emit(FailureContactUsState(e.toString()));
    }
  }
}
