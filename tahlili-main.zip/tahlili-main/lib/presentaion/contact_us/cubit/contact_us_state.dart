part of 'contact_us_cubit.dart';

@immutable
sealed class ContactUsState {}

final class ContactUsInitial extends ContactUsState {}

class LoadContactUsState extends ContactUsState{}

class SuccessContactUsState extends ContactUsState{
  final ResponseAPI responseAPI;

  SuccessContactUsState(this.responseAPI);
}

class FailureContactUsState extends ContactUsState{
  final String error;

  FailureContactUsState(this.error);
}