import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:tahlili/presentaion/contact_us/cubit/contact_us_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';

import '../../resources/shared/appbar_divider.dart';
import '../../resources/strings_manager.dart';
import '../../resources/styles_manger.dart';
import '../../resources/validation_manager.dart';

class ContactUsView extends StatelessWidget {
  const ContactUsView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ContactUsCubit>();
    return BlocBuilder<ContactUsCubit, ContactUsState>(
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            elevation: 0,
            backgroundColor: Colors.white,
            title: Text(
              "ContactUs".tr(),
              style: StylesManger.rich().copyWith(color: Colors.black),
            ),
            centerTitle: true,
          ),
          backgroundColor: Colors.white,
          body: SingleChildScrollView(
            child: Form(
              key: cubit.contactForm,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const AppBarDivider(),
                  const SizedBox(
                    height: 8,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SvgPicture.asset(
                          'assets/images/contact/contact.svg',
                          height: 180.h,
                          width: double.infinity,
                        ),
                        authForm(
                            title: "FirstName".tr(),
                            hintText: "FirstName".tr(),
                            controller: cubit.fNameController,
                            validator: (value) {
                              if (value != null && value.isNotEmpty) {
                                if (!ValidationManager.lengthValidation(
                                    text: value, length: 2)) {
                                  return StringsManager.nameValid;
                                }
                              } else {
                                return StringsManager.fieldRequierd;
                              }
                              return null;
                            }),
                        authForm(
                            title: "LastName".tr(),
                            hintText: "LastName".tr(),
                            controller: cubit.lNameController,
                            validator: (value) {
                              if (value != null && value.isNotEmpty) {
                                if (!ValidationManager.lengthValidation(
                                    text: value, length: 2)) {
                                  return StringsManager.nameValid;
                                }
                              } else {
                                return StringsManager.fieldRequierd;
                              }
                              return null;
                            }),
                        authForm(
                            title: "PhoneNumber".tr(),
                            hintText: "PhoneNumber".tr(),
                            controller: cubit.phoneController,
                            validator: (value) {
                              if (value != null && value.isNotEmpty) {
                                if (!ValidationManager.phoneNumberValidation(
                                  phone: value,
                                )) {
                                  return StringsManager.numberValid;
                                }
                              } else {
                                return StringsManager.fieldRequierd;
                              }
                              return null;
                            }),
                        authForm(
                            title: "Email".tr(),
                            hintText: "Email".tr(),
                            controller: cubit.emailController,
                            validator: (value) {
                              if (value != null && value.isNotEmpty) {
                                if (!ValidationManager.emailValidation(
                                    email: value)) {
                                  return StringsManager.numberValid;
                                }
                              } else {
                                return StringsManager.fieldRequierd;
                              }
                              return null;
                            }),
                        authForm(
                            maxLines: 5,
                            title: "Description".tr(),
                            hintText: "Description".tr(),
                            controller: cubit.descriptionController,
                            validator: (value) {
                              if (value != null && value.isNotEmpty) {
                                if (!ValidationManager.lengthValidation(
                                    text: value, length: 10)) {
                                  return StringsManager.nameValid;
                                }
                              } else {
                                return StringsManager.fieldRequierd;
                              }
                              return null;
                            }),
                        const SizedBox(
                          height: 8,
                        ),
                        BlocBuilder<ContactUsCubit, ContactUsState>(
                          builder: (context, state) {
                            return state is LoadContactUsState
                                ? const Center(
                                    child: CircularProgressIndicator(),
                                  )
                                : AppButton(
                                    radius: ConstantManger.borderRadius,
                                    textColor: Colors.white,
                                    color: ColorManger.newPrimary,
                                    name: "ارسل",
                                    onPressed: () {
                                      if (cubit.contactForm.currentState!
                                          .validate()) {
                                        cubit.contactUs(
                                            languageCode:
                                                context.locale.languageCode);
                                      }
                                    });
                          },
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        Text(
                          "تواصل معنا عن طريق",
                          style: StylesManger.rich()
                              .copyWith(color: ColorManger.blueBlack),
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            contactItem(
                                title: "الرقم الموحد ",
                                body: "920021660",
                                icon: FontAwesomeIcons.phone),
                            contactItem(
                                title: "البريد الالكتروني",
                                body: "info@tahlili.sa",
                                icon: Icons.email)
                          ],
                        ),
                        SizedBox(
                          height: 8.h,
                        ),
                        contactItem(
                            title: "رقم الواتس آب",
                            body: "920021660",
                            icon: FontAwesomeIcons.whatsapp),
                        SizedBox(
                          height: 24.h,
                        ),
                        Text(
                          "موقع شركة تحليلي",
                          style: StylesManger.rich(),
                        ),
                        Text(
                          "الرياض حي المروج طريق العليا العام / برج المروج الطابق الخامس/ مكتب رقم ٤",
                          style: StylesManger.medium()
                              .copyWith(color: ColorManger.newPrimary),
                        ),
                        SizedBox(
                          height: 16.h,
                        ),
                        SizedBox(
                          width: double.infinity,
                          height: 200.h,
                          child: GoogleMap(
                            initialCameraPosition: CameraPosition(
                              target: LatLng(24.7523735, 46.6535062),
                              zoom: 14,
                            ),
                            onMapCreated: (GoogleMapController controller) {},
                            markers: {
                              Marker(
                                markerId: MarkerId('currentLocation'),
                                position: LatLng(24.7523735, 46.6535062),
                              ),
                            },
                          ),
                        ),
                        SizedBox(
                          height: 24.h,
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          resizeToAvoidBottomInset: true,
        );
      },
    );
  }

  Widget contactItem({
    required String title,
    required String body,
    required IconData icon,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: StylesManger.rich().copyWith(color: ColorManger.newPrimary),
        ),
        SizedBox(
          height: 8.h,
        ),
        Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
              color: Color(0xfffafafa), borderRadius: BorderRadius.circular(5)),
          child: Center(
            child: Row(
              children: [
                FaIcon(
                  icon,
                  size: 15,
                ),
                SizedBox(
                  width: 8.w,
                ),
                Text(
                  body,
                  style: StylesManger.medium().copyWith(color: Colors.black),
                )
              ],
            ),
          ),
        )
      ],
    );
  }

  Widget authForm(
      {required String hintText,
      required String title,
      required TextEditingController controller,
      int? maxLines,
      required String? Function(String?)? validator}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: StylesManger.medium().copyWith(
                color: Colors.black, fontSize: 16, fontWeight: FontWeight.w500),
          ),
          const SizedBox(
            height: 8,
          ),
          TextFormField(
            maxLines: maxLines,
            validator: validator,
            controller: controller,
            decoration: InputDecoration(
                focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.grey),
                    borderRadius: BorderRadius.circular(5)),
                enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.grey),
                    borderRadius: BorderRadius.circular(5)),
                hintText: hintText,
                border: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.grey),
                    borderRadius: BorderRadius.circular(5))),
          ),
        ],
      ),
    );
  }
}
