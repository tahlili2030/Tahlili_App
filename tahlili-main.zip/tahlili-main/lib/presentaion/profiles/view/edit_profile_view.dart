import 'package:cached_network_image/cached_network_image.dart';
import 'package:country_code_picker/country_code_picker.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/data/requests/accounts/request_account.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/auth/cubit/auth_cubit.dart';
import 'package:tahlili/presentaion/resources/shared/nationality_drop.dart';

import '../../resources/color_manger.dart';
import '../../resources/shared/app_button.dart';
import '../../resources/shared/app_drop_down.dart';
import '../../resources/strings_manager.dart';
import '../../resources/styles_manger.dart';
import '../../resources/validation_manager.dart';

class EditProfile extends StatelessWidget {
  const EditProfile({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AuthCubit>();
    cubit.initProfile(context);
    return BlocBuilder<AuthCubit, AuthState>(
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            leading: IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(
                  Icons.arrow_back,
                  color: Colors.white,
                )),
            backgroundColor: ColorManger.newPrimary,
            title: Text(
              "MyProfile".tr(),
              style: StylesManger.rich().copyWith(color: Colors.white),
            ),
            centerTitle: true,
          ),
          body: Padding(
            padding: const EdgeInsets.only(top: 24, left: 20, right: 20),
            child: Form(
              key: cubit.profileForm,
              child: ListView(
                children: [
                  Row(
                    children: [
                      BlocBuilder<AccountCubit, AccountState>(
                        builder: (context, state) {
                          return SizedBox(
                            height: 85,
                            child: Stack(
                              children: [
                                Container(
                                  height: 75,
                                  width: 75,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(90),
                                      image: context
                                                  .read<AccountCubit>()
                                                  .profileImage !=
                                              null
                                          ? DecorationImage(
                                              image: FileImage(context
                                                  .read<AccountCubit>()
                                                  .profileImage!))
                                          : DecorationImage(
                                              image: CachedNetworkImageProvider(
                                                  EndPoints.baseImageUrl +
                                                      context
                                                          .read<AccountCubit>()
                                                          .patient
                                                          .first
                                                          .image!))),
                                ),
                                PositionedDirectional(
                                  end: 0,
                                  bottom: 10,
                                  child: InkWell(
                                    onTap: () {
                                      context
                                          .read<AccountCubit>()
                                          .pickProfileImage(
                                              ImageSource.gallery);
                                    },
                                    child: const CircleAvatar(
                                      radius: 15,
                                      backgroundColor: Colors.white,
                                      child: Icon(
                                        Icons.edit,
                                        color: Colors.black,
                                        size: 15,
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          );
                        },
                      ),
                      const SizedBox(
                        width: 16,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            cubit.fNameController.text +
                                " " +
                                cubit.lNameController.text,
                            style: StylesManger.rich()
                                .copyWith(color: Colors.black),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          Text(
                            cubit.emailController.text,
                            style: StylesManger.medium()
                                .copyWith(color: Colors.black),
                          ),
                        ],
                      )
                    ],
                  ),
                  authForm(
                      title: "FirstName".tr(),
                      hintText: "FirstName".tr(),
                      controller: cubit.fNameController,
                      validator: (value) {
                        if (value != null && value.isNotEmpty) {
                          if (!ValidationManager.lengthValidation(
                              text: value, length: 2)) {
                            return StringsManager.nameValid;
                          }
                        } else {
                          return StringsManager.fieldRequierd;
                        }
                        return null;
                      }),
                  authForm(
                      title: "MiddleName".tr(),
                      hintText: "middleName".tr(),
                      controller: cubit.mNameController,
                      validator: (value) {
                        return null;
                      }),
                  authForm(
                      title: "LastName".tr(),
                      hintText: "LastName".tr(),
                      controller: cubit.lNameController,
                      validator: (value) {
                        if (value != null && value.isNotEmpty) {
                          if (!ValidationManager.lengthValidation(
                              text: value, length: 2)) {
                            return StringsManager.nameValid;
                          }
                        } else {
                          return StringsManager.fieldRequierd;
                        }
                        return null;
                      }),
                  authForm(
                      title: "Email".tr(),
                      hintText: "Email".tr(),
                      controller: cubit.emailController,
                      validator: (value) {
                        if (value != null && value.isNotEmpty) {
                          if (!ValidationManager.emailValidation(
                              email: value)) {
                            return StringsManager.numberValid;
                          }
                        } else {
                          return StringsManager.fieldRequierd;
                        }
                        return null;
                      }),
                  authForm(
                      title: "IdNumber".tr(),
                      hintText: "IdNumber".tr(),
                      controller: cubit.nationalIDController,
                      validator: (value) {
                        if (value != null && value.isNotEmpty) {
                          if (!ValidationManager.lengthValidation(
                              text: value, length: 2)) {
                            return StringsManager.nameValid;
                          }
                        } else {
                          return StringsManager.fieldRequierd;
                        }
                        return null;
                      }),
                  const SizedBox(
                    height: 15,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "MobileNumber".tr(),
                        style:
                            StylesManger.rich().copyWith(color: Colors.black),
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      TextFormField(
                          validator: (value) {
                            if (value != null && value.isNotEmpty) {
                              if (!ValidationManager.phoneNumberValidation(
                                  phone: value)) {
                                return "Please enter a valid phone number";
                              }
                            } else {
                              return StringsManager.fieldRequierd;
                            }
                            return null;
                          },
                          keyboardType: TextInputType.number,
                          controller: cubit.phoneController,
                          decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5),
                                borderSide: BorderSide(
                                  color: ColorManger.lightBlack,
                                )),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(5),
                                borderSide: BorderSide(
                                  color: ColorManger.lightBlack,
                                )),
                            // prefixIcon: SizedBox(
                            //   width: 100,
                            //   child: CountryCodePicker(
                            //     padding: EdgeInsets.zero,
                            //     onChanged: (countryCode) {
                            //       cubit.setCountryCode(countryCode);
                            //     },
                            //     // Initial selection and favorite can be one of code ('IT') OR dial_code('+39')
                            //     initialSelection:cubit.country ,

                            //     // flag can be styled with BoxDecoration's `borderRadius` and `shape` fields
                            //     flagDecoration: BoxDecoration(
                            //       borderRadius: BorderRadius.circular(7),
                            //     ),
                            //   ),
                            // )
                          )),
                    ],
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  Text(
                    "Gender".tr(),
                    style: StylesManger.medium().copyWith(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w500),
                  ),
                  AppDropdown(
                      prfoileImage: [],
                      buttonDecoration: BoxDecoration(
                          border: Border.all(
                            color: ColorManger.lightBlack,
                          ),
                          borderRadius: BorderRadius.circular(5)),
                      value: cubit.gender,
                      hintText: "Gender".tr(),
                      list: cubit.gendersName,
                      onChange: (value) {
                        cubit.setGender(value);
                      }),
                  const SizedBox(
                    height: 30,
                  ),
                  NationalityDrop(cubit: cubit),
                  const SizedBox(
                    height: 30,
                  ),
                  Text(
                    "DateOfBirth".tr(),
                    style: StylesManger.medium().copyWith(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w500),
                  ),
                  InkWell(
                    onTap: () async {
                      final dateTime = await showDatePicker(
                          context: context,
                          firstDate: DateTime(1950),
                          lastDate: DateTime.now());
                      if (dateTime != null) {
                        final date =
                            DateFormat('yyyy-MM-dd', 'en').format(dateTime);
                        cubit.setDate(date);
                      }
                    },
                    child: Container(
                      padding: EdgeInsetsDirectional.symmetric(
                          horizontal: 16.w, vertical: 8.h),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: ColorManger.lightBlack)),
                      child: GestureDetector(
                        onTap: () {},
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Icon(Icons.date_range),
                            SizedBox(
                              width: 16.w,
                            ),
                            Text(
                              cubit.dateController.text,
                              style: StylesManger.medium()
                                  .copyWith(color: Colors.black),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  Text(
                    "Relationship".tr(),
                    style: StylesManger.medium().copyWith(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w500),
                  ),
                  AppDropdown(
                      prfoileImage: [],
                      buttonDecoration: BoxDecoration(
                          border: Border.all(color: ColorManger.lightBlack),
                          borderRadius: BorderRadius.circular(5)),
                      value: cubit.relationship,
                      hintText: "Relationship".tr(),
                      list: cubit.relationships,
                      onChange: (value) {
                        cubit.setRelationship(value);
                      }),
                  const SizedBox(
                    height: 50,
                  ),
                  BlocBuilder<AccountCubit, AccountState>(
                    builder: (context, state) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 15),
                        child: state is LoadEditProfileState
                            ? const Center(
                                child: CircularProgressIndicator(),
                              )
                            : AppButton(
                                color: ColorManger.newPrimary,
                                name: "Save".tr(),
                                onPressed: () async {
                                  print(cubit.mNameController.text);

                                  context
                                      .read<AccountCubit>()
                                      .editProfile(
                                          languageCode:
                                              context.locale.languageCode,
                                          patientEntityId:
                                              cubit.patientEntityId!,
                                          editProfile: RequestEditProfile(
                                            phone: cubit.phoneController.text
                                                .trim(),
                                            relationShipId:
                                                cubit.relationshipID!,
                                            idNumber: cubit
                                                .nationalIDController.text
                                                .trim(),
                                            nationalityId: cubit.nationalityID!,
                                            firstName: cubit
                                                .fNameController.text
                                                .trim(),
                                            middleName:
                                                cubit.mNameController.text,
                                            lastName:
                                                cubit.lNameController.text,
                                            genderId: cubit.genderID!,
                                            languageId: cubit.languagesID!,
                                            birthDate:
                                                cubit.dateController.text,
                                          ))
                                      .whenComplete(() {
                                    cubit.initProfile(context);
                                  });
                                }),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget authForm(
      {required String hintText,
      required String title,
      required TextEditingController controller,
      required String? Function(String?)? validator}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: StylesManger.medium().copyWith(
                color: Colors.black, fontSize: 16, fontWeight: FontWeight.w500),
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
            validator: validator,
            controller: controller,
            decoration: InputDecoration(
                focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: ColorManger.lightBlack),
                    borderRadius: BorderRadius.circular(5)),
                enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: ColorManger.lightBlack),
                    borderRadius: BorderRadius.circular(5)),
                hintText: hintText,
                border: OutlineInputBorder(
                    borderSide: BorderSide(color: ColorManger.lightBlack),
                    borderRadius: BorderRadius.circular(5))),
          ),
        ],
      ),
    );
  }
}
