import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/auth/cubit/auth_cubit.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';
import 'package:tahlili/presentaion/resources/shared/nationality_drop.dart';
import '../../../data/requests/accounts/request_account.dart';
import '../../resources/color_manger.dart';
import '../../resources/shared/app_button.dart';
import '../../resources/shared/app_drop_down.dart';
import '../../resources/shared/shared_widgets.dart';
import '../../resources/strings_manager.dart';
import '../../resources/styles_manger.dart';
import '../../resources/validation_manager.dart';

class FamilyMembersView extends StatelessWidget {
  const FamilyMembersView({super.key});
  String relationshipName(AuthCubit authCubit, int id) {
    String name = "";
    for (var element in authCubit.relationshipsLookUp) {
      if (element.id == id) {
        name = element.name!;
      }
    }
    return name;
  }

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AccountCubit>();
    final authCubit = context.read<AuthCubit>();
    authCubit.resetProfileData();
    cubit.getPatinetProfiles();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        title: Text(
          "FamilyMembers".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          const AppBarDivider(),
          const SizedBox(
            height: 24,
          ),
          Expanded(child: BlocBuilder<AccountCubit, AccountState>(
            builder: (context, state) {
              return cubit.patinetProfiles.isEmpty
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SvgPicture.asset('assets/images/noFamily.svg'),
                        const SizedBox(height: 40),
                        Text(
                          "NoFamilyMembers".tr(),
                          style:
                              StylesManger.rich().copyWith(color: Colors.black),
                        )
                      ],
                    )
                  : Padding(
                      padding: const EdgeInsets.only(
                          left: 16, right: 16, bottom: 16),
                      child: ListView.separated(
                          itemBuilder: (context, index) => FamliyItem(
                              name: cubit.patinetProfiles[index].firstName!,
                              dob: cubit.patinetProfiles[index].birthDate!,
                              image: cubit.patinetProfiles[index].image!,
                              editBtn: () {
                                authCubit.initEditProfile(
                                    context, cubit.patinetProfiles[index]);
                                showModalBottomSheet(
                                    context: context,
                                    isScrollControlled: true,
                                    builder: (context) => AddFamilyItem(
                                        userId:
                                            cubit.patinetProfiles[index].id!,
                                        isAdd: false,
                                        cubit: cubit,
                                        authCubit: authCubit));
                              },
                              removeBtn: () {}),
                          separatorBuilder: (context, index) => const SizedBox(
                                height: 16,
                              ),
                          itemCount: cubit.patinetProfiles.length),
                    );
            },
          ))
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: GestureDetector(
        onTap: () {
          showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              builder: (context) => AddFamilyItem(
                    cubit: cubit,
                    authCubit: authCubit,
                    isAdd: true,
                    userId: 0,
                  ));
        },
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 30, vertical: 40),
          height: 60,
          width: double.infinity,
          decoration: BoxDecoration(
              color: ColorManger.newPrimary,
              borderRadius: BorderRadius.circular(10)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SvgPicture.asset('assets/images/addMem.svg'),
              const SizedBox(
                width: 10,
              ),
              Text(
                "AddConditionsforFamilyMembers".tr(),
                style: StylesManger.rich().copyWith(color: Colors.white),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AddFamilyItem extends StatelessWidget {
  const AddFamilyItem({
    super.key,
    required this.cubit,
    required this.authCubit,
    required this.isAdd,
    required this.userId,
  });

  final AccountCubit cubit;
  final AuthCubit authCubit;
  final bool isAdd;
  final int userId;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: BlocBuilder<AccountCubit, AccountState>(
        builder: (context, state) {
          return Container(
              height: 700,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              width: double.infinity,
              decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20))),
              child: Form(
                key: cubit.complaintForm,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(
                      height: 16,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10.0),
                      child: Container(
                        width: 40,
                        height: 5,
                        decoration: BoxDecoration(
                          color: Colors.grey[400],
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    Text(
                      isAdd
                          ? "AddConditionsforFamilyMembers".tr()
                          : "editFamilyMemeber".tr(),
                      style: StylesManger.rich().copyWith(color: Colors.black),
                    ),
                    const SizedBox(
                      height: 24,
                    ),
                    Expanded(
                      child: SingleChildScrollView(
                        child: Form(
                          key: cubit.familyForm,
                          child: BlocBuilder<AuthCubit, AuthState>(
                            builder: (context, state) {
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  authForm(
                                      title: "FirstName".tr(),
                                      hintText: "FirstName".tr(),
                                      controller: authCubit.fNameController,
                                      validator: (value) {
                                        if (value != null && value.isNotEmpty) {
                                          if (!ValidationManager
                                              .lengthValidation(
                                                  text: value, length: 2)) {
                                            return StringsManager.nameValid;
                                          }
                                        } else {
                                          return StringsManager.fieldRequierd;
                                        }
                                        return null;
                                      }),
                                  authForm(
                                      title: "middleName".tr(),
                                      hintText: "middleName".tr(),
                                      controller: authCubit.mNameController,
                                      validator: (value) {
                                        return null;
                                      }),
                                  authForm(
                                      title: "LastName".tr(),
                                      hintText: "LastName".tr(),
                                      controller: authCubit.lNameController,
                                      validator: (value) {
                                        if (value != null && value.isNotEmpty) {
                                          if (!ValidationManager
                                              .lengthValidation(
                                                  text: value, length: 2)) {
                                            return StringsManager.nameValid;
                                          }
                                        } else {
                                          return StringsManager.fieldRequierd;
                                        }
                                        return null;
                                      }),
                                  authForm(
                                      title: "Email".tr(),
                                      hintText: "Email".tr(),
                                      controller: authCubit.emailController,
                                      validator: (value) {
                                        if (value != null && value.isNotEmpty) {
                                          if (!ValidationManager
                                              .emailValidation(email: value)) {
                                            return StringsManager.emailValid;
                                          }
                                        } else {
                                          return StringsManager.fieldRequierd;
                                        }
                                        return null;
                                      }),
                                  authForm(
                                      title: "IdNumber".tr(),
                                      hintText: "IdNumber".tr(),
                                      controller:
                                          authCubit.nationalIDController,
                                      validator: (value) {
                                        if (value != null && value.isNotEmpty) {
                                          if (!ValidationManager
                                              .lengthValidation(
                                                  text: value, length: 2)) {
                                            return StringsManager.nameValid;
                                          }
                                        } else {
                                          return StringsManager.fieldRequierd;
                                        }
                                        return null;
                                      }),
                                  const SizedBox(
                                    height: 15,
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "MobileNumber".tr(),
                                        style: StylesManger.rich()
                                            .copyWith(color: Colors.black),
                                      ),
                                      const SizedBox(
                                        height: 8,
                                      ),
                                      TextFormField(
                                          validator: (value) {
                                            if (value != null &&
                                                value.isNotEmpty) {
                                              if (!ValidationManager
                                                  .phoneNumberValidation(
                                                      phone: value)) {
                                                return "Please enter a valid phone number";
                                              }
                                            } else {
                                              return StringsManager
                                                  .fieldRequierd;
                                            }
                                            return null;
                                          },
                                          keyboardType: TextInputType.number,
                                          controller: authCubit.phoneController,
                                          decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color:
                                                        ColorManger.lightBlack),
                                                borderRadius:
                                                    BorderRadius.circular(5)),
                                            enabledBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color:
                                                        ColorManger.lightBlack),
                                                borderRadius:
                                                    BorderRadius.circular(5)),
                                            // prefixIcon: SizedBox(
                                            //   width: 100,
                                            //   child: CountryCodePicker(
                                            //     padding: EdgeInsets.zero,
                                            //     onChanged: (countryCode) {
                                            //       cubit.setCountryCode(countryCode);
                                            //     },
                                            //     // Initial selection and favorite can be one of code ('IT') OR dial_code('+39')
                                            //     initialSelection:cubit.country ,

                                            //     // flag can be styled with BoxDecoration's `borderRadius` and `shape` fields
                                            //     flagDecoration: BoxDecoration(
                                            //       borderRadius: BorderRadius.circular(7),
                                            //     ),
                                            //   ),
                                            // )
                                          )),
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 30,
                                  ),
                                  Text(
                                    "Gender".tr(),
                                    style: StylesManger.medium().copyWith(
                                        color: Colors.black,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500),
                                  ),
                                  AppDropdown(
                                      prfoileImage: [],
                                      buttonDecoration: BoxDecoration(
                                          border: Border.all(
                                              color: ColorManger.lightBlack),
                                          borderRadius:
                                              BorderRadius.circular(5)),
                                      value: authCubit.gender,
                                      hintText: "Gender".tr(),
                                      list: authCubit.gendersName,
                                      onChange: (value) {
                                        authCubit.setGender(value);
                                      }),
                                  const SizedBox(
                                    height: 30,
                                  ),

                                  NationalityDrop(cubit: authCubit),
                                  // AppDropdown(
                                  //     prfoileImage: [],
                                  //     buttonDecoration: BoxDecoration(
                                  //         border: Border.all(),
                                  //         borderRadius:
                                  //             BorderRadius.circular(5)),
                                  //     value: authCubit.nationality,
                                  //     hintText:
                                  //         StringsManager.chooseNationality,
                                  //     list: authCubit.nationalities,
                                  //     onChange: (value) {
                                  //       authCubit.setNationality(value);
                                  //     }),
                                  const SizedBox(
                                    height: 30,
                                  ),
                                  Text(
                                    "Relationship".tr(),
                                    style: StylesManger.medium().copyWith(
                                        color: Colors.black,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500),
                                  ),
                                  AppDropdown(
                                      prfoileImage: [],
                                      buttonDecoration: BoxDecoration(
                                          border: Border.all(
                                              color: ColorManger.lightBlack),
                                          borderRadius:
                                              BorderRadius.circular(5)),
                                      value: authCubit.relationship,
                                      hintText: "Relationship".tr(),
                                      list: authCubit.relationships,
                                      onChange: (value) {
                                        authCubit.setRelationship(value);
                                      }),
                                  const SizedBox(
                                    height: 18,
                                  ),
                                  BlocBuilder<AccountCubit, AccountState>(
                                    builder: (context, state) {
                                      return Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 20, vertical: 15),
                                        child: state is LoadAddProfileState
                                            ? const Center(
                                                child:
                                                    CircularProgressIndicator(),
                                              )
                                            : AppButton(
                                                color: ColorManger.newPrimary,
                                                name: "Save".tr(),
                                                onPressed: () async {
                                                  log(isAdd.toString());
                                                  authCubit.checkValidaty();
                                                  if (cubit.familyForm
                                                          .currentState!
                                                          .validate() &&
                                                      authCubit
                                                          .validNational! &&
                                                      authCubit.validGender! &&
                                                      authCubit
                                                          .validRelation!) {
                                                    log("message");
                                                    if (isAdd) {
                                                      cubit.addProfile(
                                                          context: context,
                                                          authCubit: authCubit);
                                                    } else {
                                                      context
                                                          .read<AccountCubit>()
                                                          .editProfile(
                                                              languageCode: context
                                                                  .locale
                                                                  .languageCode,
                                                              patientEntityId:
                                                                  userId,
                                                              editProfile:
                                                                  RequestEditProfile(
                                                                phone: authCubit
                                                                    .phoneController
                                                                    .text
                                                                    .trim(),
                                                                relationShipId:
                                                                    authCubit
                                                                        .relationshipID!,
                                                                idNumber: authCubit
                                                                    .nationalIDController
                                                                    .text
                                                                    .trim(),
                                                                nationalityId:
                                                                    authCubit
                                                                        .nationalityID!,
                                                                firstName: authCubit
                                                                    .fNameController
                                                                    .text
                                                                    .trim(),
                                                                middleName:
                                                                    authCubit
                                                                        .mNameController
                                                                        .text,
                                                                lastName: authCubit
                                                                    .lNameController
                                                                    .text,
                                                                genderId: authCubit
                                                                    .genderID!,
                                                                languageId:
                                                                    authCubit
                                                                        .languagesID!,
                                                                birthDate: authCubit
                                                                    .dateController
                                                                    .text,
                                                              ))
                                                          .whenComplete(() {
                                                        cubit
                                                            .getPatinetProfiles();
                                                        Navigator.pop(context);
                                                      });
                                                    }
                                                  } else {
                                                    toast(
                                                        text:
                                                            "Complete the follwing Data"
                                                                .tr(),
                                                        color: Colors.red);
                                                  }
                                                }),
                                      );
                                    },
                                  ),
                                ],
                              );
                            },
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 30,
                    )
                  ],
                ),
              ));
        },
      ),
    );
  }
}

class FamliyItem extends StatelessWidget {
  const FamliyItem(
      {super.key,
      required this.name,
      required this.dob,
      required this.image,
      required this.editBtn,
      required this.removeBtn});
  final String name;
  final String dob;
  final String image;
  final VoidCallback editBtn;
  final VoidCallback removeBtn;
  int calculateAge(String dobString) {
    DateTime dob = DateTime.parse(dobString);
    DateTime now = DateTime.now();

    int age = now.year - dob.year;
    if (now.month < dob.month ||
        (now.month == dob.month && now.day < dob.day)) {
      age--;
    }

    return age;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
            border: Border.all(color: ColorManger.grey),
            borderRadius: BorderRadius.circular(10)),
        child: Column(children: [
          CircleAvatar(
            radius: 50.r,
            backgroundImage:
                CachedNetworkImageProvider(EndPoints.baseImageUrl + image),
          ),
          SizedBox(
            height: 8.h,
          ),
          Text(
            name,
            style: StylesManger.medium().copyWith(color: Colors.black),
          ),
          SizedBox(
            height: 8.h,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              SizedBox(
                height: 48.h,
                width: 100.w,
                child: AppButton(
                    radius: ConstantManger.borderRadius,
                    color: ColorManger.newPrimary,
                    name: "تعديل",
                    onPressed: editBtn),
              ),
              SizedBox(
                height: 48.h,
                width: 100.w,
                child: AppButton(
                    radius: ConstantManger.borderRadius,
                    textColor: Colors.red,
                    borderSide: Colors.red,
                    color: Colors.white,
                    name: "حذف",
                    onPressed: removeBtn),
              )
            ],
          )
        ]));
  }
}
