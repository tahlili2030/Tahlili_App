// import 'package:easy_localization/easy_localization.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:tahlili/presentaion/resources/shared/app_button.dart';
// import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';
// import 'package:tahlili/presentaion/resources/styles_manger.dart';

// import '../../../data/response/orders/response_order.dart';
// import '../../map/cubit/map_cubit.dart';
// import '../../map/view/tracking.dart';

// class OrderDetailsView extends StatelessWidget {
//   const OrderDetailsView({super.key, required this.order});
//   final ResponseOrder order;

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(),
//       body: Padding(
//         padding: const EdgeInsetsDirectional.only(start: 20, top: 100, end: 20),
//         child: Column(
//           children: [
//             content(
//                 title: "Patient's Name",
//                 content: order.patientFirstName! + order.patientLastName!),
//             content(
//                 title: "Visting Date",
//                 content: DateFormat('yyyy-MM-dd hh:mm')
//                     .format(DateTime.parse(order.visitDateTime!))),
//             content(
//                 title: "Reservation Date",
//                 content: DateFormat('yyyy-MM-dd')
//                     .format(DateTime.parse(order.date!))),
//             content(title: "Lab", content: order.labNameEn!),
//             content(title: "Nurser Name", content: order.nurseNameEn!),
//             content(title: "Order State", content: order.currentOrderState!),
//             content(title: "Price", content: "${order.price!} SAR"),
//             content(
//                 title: "Price with Vat", content: "${order.priceWithVAT!} SAR"),
//             v(24),
//             Row(
//               children: [
//                 Expanded(
//                     child: AppButton(
//                         color: Colors.green,
//                         name: "Track Order",
//                         onPressed: () async {
//                           await context.read<MapCubit>().getNurseLocation(
//                               orderID:order.id!);
//                           Navigator.push(
//                               context,
//                               MaterialPageRoute(
//                                   builder: (context) => const TrackingNurse()));
//                         })),
//                 const SizedBox(
//                   width: 20,
//                 ),
//                 Expanded(
//                     child: AppButton(
//                         color: Colors.amber,
//                         name: "Rate Service",
//                         onPressed: () {})),
//               ],
//             ),
//             v(25),
//             AppButton(
//                 color: Colors.red,
//                 name: "Cancel Or Reschedule Order",
//                 onPressed: () {}),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget content({required String title, required String content}) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Text(
//             title,
//             style: StylesManger.medium(),
//           ),
//           Text(
//             content,
//             style: StylesManger.medium(),
//           ),
//         ],
//       ),
//     );
//   }
// }
