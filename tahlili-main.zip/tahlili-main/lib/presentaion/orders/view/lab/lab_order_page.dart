import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tahlili/presentaion/orders/cubit/orders_cubit.dart';
import 'package:tahlili/presentaion/orders/view/lab/lab_order_second_page.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';
import '../../../../data/requests/cart/request_cart.dart';
import '../../../../data/requests/order/request_order.dart';
import '../../../cart/cubit/cart_cubit.dart';
import '../../../profiles/view/family_members.dart';
import '../../../resources/shared/appbar_divider.dart';
import '../home/home_order_first_page.dart';

class LabOrderPage extends StatelessWidget {
  const LabOrderPage({super.key, required this.orderData});
  final RequestOrderData orderData;

 @override
  Widget build(BuildContext context) {
    final cubit = context.read<OrdersCubit>();
    cubit.clearOrderData();
    cubit.getAddresses(context);
    cubit.getProfileNames(context);
    cubit.getLabBranches(partnerId: orderData.labId, itemId: orderData.itemId, isTest: orderData.isTest).whenComplete(() =>    cubit.setLab(0, context));
 cubit.setProfile(0, context);
    cubit.getLabWorkingHours();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
        title: Text(
          "Lab Visit",
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
      ),
      backgroundColor: Colors.white,
      body: BlocBuilder<OrdersCubit, OrdersState>(
        builder: (context, state) {
          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AppBarDivider(),
                SizedBox(
                  height: 16,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      OrderDropDown(
                          profileImage: cubit.profileImages,
                          directed: true,
                          directBtn: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => FamilyMembersView()));
                          },
                          title: "Patient".tr(),
                          hintText: "Patient".tr(),
                          value: cubit.profileValue,
                          list: cubit.profiles,
                          onDropCahnge: (value) {
                            cubit.setProfile(value, context);
                          }),
                      OrderDropDown(

                          profileImage: [],
                          title: "Branches",
                          hintText:  "Branches",
                          value: cubit.lab,
                          list:context.locale.languageCode=='ar'?
                           cubit.arBranches:cubit.enBranches,
                          onDropCahnge: (value) {
                            cubit.setLab(value, context);
                          }),
                      OrderDropDown(
                          profileImage: [],
                          title: "Date",
                          hintText: "Date",
                          value: cubit.dateValue,
                          list: cubit.enDates,
                          onDropCahnge: (value) {
                            cubit.setDate(value);
                          }),
                      OrderDropDown(
                          profileImage: [],
                          title: "Visiting Time",
                          hintText: "Visiting Time",
                          value: cubit.hourValue,
                          list: cubit.selectedDay,
                          onDropCahnge: (value) {
                            cubit.setHour(value);
                          }),

                      const SizedBox(
                        height: 70,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                            width: 180,
                            child: AppButton(
                                color: ColorManger.primary,
                                name: "AddToCart".tr(),
                                onPressed: () {
                                  if (cubit.labFirstPgaeValidation()) {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                LabOrderSecondPage(
                                                  orderData: orderData,
                                                )));
                                  }
                                }),
                          ),
                          SizedBox(
                            width: 180,
                            child: AppButton(
                                textColor: ColorManger.primary,
                                color: Colors.white,
                                name: "Add to cart".tr(),
                                onPressed: () {

                                  if (cubit.labFirstPgaeValidation()) {

                                     String inputDateTime = "${cubit.date} ${cubit.hour}";
                                   DateTime inputDate =
                                        DateFormat('EEEE, yyyy-MM-dd hh:mm a')
                                            .parse(inputDateTime);
                                    DateTime utcDate = inputDate.toUtc();
                                    String outputDateString =
                                        DateFormat('yyyy-MM-ddTHH:mm:ssZ')
                                            .format(utcDate);
                                    context.read<CartCubit>().addTotCart(
                                        cart: RequestCart(
                                            cubit.profileEntityId!,
                                            orderData.isTest?orderData.itemId:null,
                                             !orderData.isTest?orderData.itemId:null,
                                            outputDateString,
                                            cubit.labId,
                                            null,
                                            ));
                                  }
                                }),
                          )
                        ],
                      )
                    ],
                  ),
                )
              ],
            ),
          );
        },
      ),
    );
  }
}
