import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tahlili/presentaion/orders/cubit/orders_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

import '../../../../data/requests/order/request_order.dart';
import '../../../account/cubit/account_cubit.dart';
import '../../../resources/constant_manger.dart';
import 'home_order_first_page.dart';

class HomeOrderSecondPage extends StatelessWidget {
  const HomeOrderSecondPage({super.key, required this.orderData});
  final RequestOrderData orderData;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<OrdersCubit>();
    cubit.clacTotal(orderData.price);
    cubit.getPayMentType();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
        title: Text(
          "OrderSummary".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
      ),
      backgroundColor: Colors.white,
      body: BlocBuilder<OrdersCubit, OrdersState>(
        builder: (context, state) {
          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const AppBarDivider(),
                const SizedBox(
                  height: 16,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      OrderDropDown(
                          profileImage: [],
                          title: "Nurse".tr(),
                          hintText: "Nurse".tr(),
                          value: cubit.nurseValue,
                          list: cubit.enNurses,
                          onDropCahnge: (value) {
                            // cubit.setNurse(value, orderData.price,cubit.addressId! );
                          }),
                      OrderDropDown(
                          profileImage: [],
                          title: "PaymentType".tr(),
                          hintText: "PaymentType".tr(),
                          value: cubit.paymentValue,
                          list: cubit.methods,
                          onDropCahnge: (value) {
                            cubit.setPayment(value);
                          }),
                      Text("CouponDiscount".tr(),
                          style: StylesManger.medium().copyWith(
                              color: Colors.black,
                              fontSize: 16,
                              fontWeight: FontWeight.w500)),
                      const SizedBox(
                        height: 8,
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              //  controller: cubit.couponController,
                              decoration: InputDecoration(
                                border: const OutlineInputBorder(),
                                contentPadding: EdgeInsets.zero,
                                suffixIcon: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      shape: const RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadiusDirectional.only(
                                        topEnd: Radius.circular(5),
                                        bottomEnd: Radius.circular(5),
                                      )),
                                      backgroundColor: ColorManger.primary,
                                      foregroundColor: Colors.white),
                                  onPressed: () {},
                                  child: Text("ApplyCopoun".tr()),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(
                            width: 5,
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Text("OrderSummary".tr(),
                          style: StylesManger.medium().copyWith(
                            color: Colors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          )),
                      const SizedBox(
                        height: 8,
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 16),
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey),
                            borderRadius: BorderRadius.circular(5)),
                        child: Column(
                          children: [
                            orderDetails(
                                title: "Subtotal".tr(),
                                content: "${orderData.price} ${"SAR".tr()}"),
                            orderDetails(
                                title: "CouponDiscount".tr(), content: "0"),
                            orderDetails(
                                title: "NurseFees".tr(),
                                content: "${cubit.nurseFees}"),
                            context
                                        .read<AccountCubit>()
                                        .patient
                                        .first
                                        .nationalityId ==
                                    192
                                ? const SizedBox()
                                : orderDetails(
                                    title: "VAT".tr(),
                                    content: "${ConstantManger.vat}%"),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  cubit.patientWallet != null
                                      ? "${"WalletCredit".tr()} (${cubit.patientWallet} ${"SAR".tr()})"
                                      : "${"WalletCredit".tr()} (0 ${"SAR".tr()})",
                                  style: StylesManger.rich()
                                      .copyWith(color: Colors.black),
                                ),
                                Switch(
                                    materialTapTargetSize:
                                        MaterialTapTargetSize.padded,
                                    activeTrackColor: ColorManger.primary,
                                    inactiveTrackColor: Colors.grey,
                                    value: cubit.useWallet,
                                    onChanged: (value) {
                                      cubit.switchWallet(
                                          value, orderData.price);
                                    })
                              ],
                            ),
                            orderDetails(
                                title: "Total".tr(),
                                content: "${cubit.total} ${"SAR".tr()}"),
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 70,
                      ),
                      AppButton(
                          color: ColorManger.primary,
                          name: "PaymentAndCheckout".tr(),
                          onPressed: () {
                            context.read<AccountCubit>().instantTele = false;
                            if (cubit.homeCheckPgaeValidation()) {
                              cubit.createHomeOrder(
                                  context: context,
                                  isTest: orderData.isTest,
                                  itemId: orderData.itemId,
                                  labId: orderData.labId);
                            }
                          })
                    ],
                  ),
                )
              ],
            ),
          );
        },
      ),
    );
  }

  Widget orderDetails({
    required String title,
    required String content,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
        Text(
          content,
          style: StylesManger.medium().copyWith(color: Colors.black),
        ),
      ],
    );
  }
}
