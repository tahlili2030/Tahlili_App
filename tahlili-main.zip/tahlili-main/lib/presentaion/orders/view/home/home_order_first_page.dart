import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/data/requests/cart/request_cart.dart';
import 'package:tahlili/data/requests/order/request_order.dart';
import 'package:tahlili/presentaion/cart/cubit/cart_cubit.dart';
import 'package:tahlili/presentaion/orders/cubit/orders_cubit.dart';
import 'package:tahlili/presentaion/orders/view/home/home_order_second_page.dart';
import 'package:tahlili/presentaion/profiles/view/family_members.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

import '../../../account/view/addresses/patient_addresses_view.dart';
import '../../../resources/shared/app_drop_down.dart';

class HomeOrderFirstPage extends StatelessWidget {
  const HomeOrderFirstPage({super.key, required this.orderData});
  final RequestOrderData orderData;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<OrdersCubit>();
    cubit.clearOrderData();
    cubit.getAddresses(context);
    cubit.getProfileNames(context);

    cubit.getLabWorkingHours();
    cubit.setProfile(0, context);
    cubit.setAddress(0, context);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
        title: Text(
          "At Home".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
      ),
      backgroundColor: Colors.white,
      body: BlocBuilder<OrdersCubit, OrdersState>(
        builder: (context, state) {
          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const AppBarDivider(),
                const SizedBox(
                  height: 16,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      OrderDropDown(
                          profileImage: cubit.profileImages,
                          directed: true,
                          directBtn: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        const FamilyMembersView()));
                          },
                          title: "Patient".tr(),
                          hintText: "Patient".tr(),
                          value: cubit.profileValue,
                          list: cubit.profiles,
                          onDropCahnge: (value) {
                            cubit.setProfile(value, context);
                          }),
                      OrderDropDown(
                          directed: true,
                          directBtn: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        const AddressessView()));
                          },
                          profileImage: [],
                          title: "Address".tr(),
                          hintText: "Address".tr(),
                          value: cubit.addressValue,
                          list: cubit.addresses,
                          onDropCahnge: (value) {
                            cubit.setAddress(value, context);
                          }),
                      OrderDropDown(
                          profileImage: [],
                          title: "Date".tr(),
                          hintText: "Date".tr(),
                          value: cubit.dateValue,
                          list: context.locale.languageCode == 'ar'
                              ? cubit.arDates
                              : cubit.enDates,
                          onDropCahnge: (value) {
                            cubit.setDate(value);
                          }),
                      OrderDropDown(
                          profileImage: [],
                          title: "VisitingTime".tr(),
                          hintText: "VisitingTime".tr(),
                          value: cubit.hourValue,
                          list: cubit.selectedDay,
                          onDropCahnge: (value) {
                            cubit.setHour(value);
                          }),
                      const SizedBox(
                        height: 70,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                            width: 180,
                            child: AppButton(
                                color: ColorManger.primary,
                                name: "AddToCart".tr(),
                                onPressed: () {
                                  if (cubit.homeFirstPgaeValidation()) {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                HomeOrderSecondPage(
                                                  orderData: orderData,
                                                )));
                                  }
                                }),
                          ),
                          SizedBox(
                            width: 180,
                            child: AppButton(
                                textColor: ColorManger.primary,
                                color: Colors.white,
                                name: "Add to cart".tr(),
                                onPressed: () {
                                  if (cubit.homeFirstPgaeValidation()) {
                                    String inputDateTime =
                                        "${cubit.date} ${cubit.hour}";
                                    print(inputDateTime);
                                    // // DateTime inputDate =
                                    // //     DateFormat('EEEE, yyyy-MM-dd hh:mm a',)
                                    // //         .parse(inputDateTime);
                                    // DateTime utcDate = inputDate.toUtc();
                                    // String outputDateString =
                                    //     DateFormat('yyyy-MM-ddTHH:mm:ssZ','en')
                                    //         .format(utcDate);
                                    String formattedDate =
                                        convertToIso8601(inputDateTime);

                                    print(formattedDate);
                                    //         print(outputDateString);
                                    // DateFormat inputFormat =
                                    //     DateFormat("EEEE, dd-MM-yyyy HH:mm");
                                    // DateTime dateTime =
                                    //     inputFormat.parse(inputDateTime);

                                    context.read<CartCubit>().addTotCart(
                                            cart: RequestCart(
                                          cubit.profileEntityId!,
                                          orderData.isTest
                                              ? orderData.itemId
                                              : null,
                                          !orderData.isTest
                                              ? orderData.itemId
                                              : null,
                                          formattedDate!,
                                          null,
                                          cubit.addressId!,
                                        ));
                                  }
                                }),
                          )
                        ],
                      )
                    ],
                  ),
                )
              ],
            ),
          );
        },
      ),
    );
  }
}

class OrderDropDown extends StatelessWidget {
  final String title;
  final String hintText;
  final int? value;
  final List<String> list;
  final Function onDropCahnge;
  final Function(Object?)? onRadioChange;
  final String? groupValue;
  final List<String>? profileImage;
  final bool? directed;
  final VoidCallback? directBtn;
  const OrderDropDown({
    super.key,
    required this.title,
    required this.hintText,
    required this.value,
    required this.list,
    required this.onDropCahnge,
    this.onRadioChange,
    this.groupValue,
    this.directed,
    this.profileImage,
    this.directBtn,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: 16.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: StylesManger.medium().copyWith(
                color: ColorManger.blueBlack,
                fontSize: 14.sp,
                fontWeight: FontWeight.w500),
          ),
          const SizedBox(
            height: 8,
          ),
          BlocBuilder<OrdersCubit, OrdersState>(
            builder: (context, state) {
              return Row(
                children: [
                  Expanded(
                    child: AppDropdown(
                        prfoileImage: profileImage,
                        groupValue: groupValue,
                        onRadioChange: onRadioChange,
                        buttonDecoration: BoxDecoration(
                            border: Border.all(color: ColorManger.lightBlack),
                            borderRadius: BorderRadius.circular(
                                ConstantManger.borderRadius)),
                        value: value,
                        hintText: hintText,
                        list: list,
                        onChange: onDropCahnge),
                  ),
                  if (directed != null && directed!)
                    Row(
                      children: [
                        const SizedBox(
                          width: 10,
                        ),
                        InkWell(
                          onTap: directBtn,
                          child: Container(
                            height: 32.h,
                            padding: EdgeInsets.symmetric(horizontal: 16.w),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                color: ColorManger.newPrimary.withOpacity(.1)),
                            child: Row(
                              children: [
                                Text(
                                  "اضافه مريض",
                                  style: StylesManger.small().copyWith(
                                      fontSize: 10.sp,
                                      fontWeight: FontWeight.w700,
                                      color: ColorManger.newPrimary),
                                ),
                                SizedBox(
                                  width: 8.w,
                                ),
                                Icon(
                                  Icons.add,
                                  color: ColorManger.newPrimary,
                                  size: 15,
                                ),
                              ],
                            ),
                          ),
                        )
                      ],
                    )
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}

String convertToIso8601(String dateString) {
  // Define the input format with Arabic AM/PM
  DateFormat inputFormat = DateFormat("EEEE, yyyy-MM-dd hh:mm a", 'en');

  // Define the output format
  DateFormat outputFormat = DateFormat("yyyy-MM-ddTHH:mm:ss'Z'", 'en');

  // Replace Arabic numerals with English numerals
  String normalizedDate =
      dateString.replaceAllMapped(RegExp(r'[٠١٢٣٤٥٦٧٨٩]'), (match) {
    const arabicToEnglishDigits = {
      '٠': '0',
      '١': '1',
      '٢': '2',
      '٣': '3',
      '٤': '4',
      '٥': '5',
      '٦': '6',
      '٧': '7',
      '٨': '8',
      '٩': '9'
    };
    return arabicToEnglishDigits[match[0]]!;
  });

  // Convert Arabic AM/PM to English AM/PM
  normalizedDate = normalizedDate.replaceAll('ص', 'AM').replaceAll('م', 'PM');

  // Parse the input date string
  DateTime dateTime = inputFormat.parse(normalizedDate);

  // Convert to ISO 8601 format
  String iso8601String = outputFormat.format(dateTime.toUtc());

  return iso8601String;
}
