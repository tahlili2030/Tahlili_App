// import 'package:easy_localization/easy_localization.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:tahlili/presentaion/map/cubit/map_cubit.dart';
// import 'package:tahlili/presentaion/map/view/tracking.dart';
// import 'package:tahlili/presentaion/orders/cubit/orders_cubit.dart';
// import 'package:tahlili/presentaion/orders/pages/order_details_view.dart';
// import 'package:tahlili/presentaion/resources/color_manger.dart';
// import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';
// import 'package:tahlili/presentaion/resources/styles_manger.dart';

// class OrdersView extends StatelessWidget {
//   const OrdersView({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final cubit = context.read<OrdersCubit>();
//     cubit.getOrders();
//     return BlocBuilder<OrdersCubit, OrdersState>(
//       builder: (context, state) {
//         return Scaffold(
//             appBar: AppBar(),
//             body: Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 20),
//               child: cubit.orders.isNotEmpty
//                   ? ListView.separated(
//                       itemBuilder: (context, index) => Container(
//                             padding: EdgeInsets.symmetric(
//                                 horizontal: 10, vertical: 5),
//                             decoration: BoxDecoration(
//                                 borderRadius: BorderRadius.circular(20),
//                                 border: Border.all(color: ColorManger.primary)),
//                             child: Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Column(
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   children: [
//                                     Text(
//                                       "Reservation's ID : ${cubit.orders[index].id!}",
//                                       style: StylesManger.medium(),
//                                     ),
//                                     v(10),
//                                     Text(
//                                       "Bracnh : ${cubit.orders[index].labNameEn}",
//                                       style: StylesManger.medium(),
//                                     ),
//                                     v(10),
//                                     Text(
//                                       "Date : ${DateFormat('yyyy-MM-dd').format(DateTime.parse(cubit.orders[index].date!))}",
//                                       style: StylesManger.medium(),
//                                     ),
//                                   ],
//                                 ),
//                                 Column(
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   children: [
//                                     Container(
//                                       padding: EdgeInsets.all(5),
//                                       decoration: BoxDecoration(
//                                           color: ColorManger.offWhite,
//                                           borderRadius:
//                                               BorderRadius.circular(20)),
//                                       child: Center(
//                                         child: Text(
//                                           cubit
//                                               .orders[index].currentOrderState!,
//                                           style: StylesManger.medium(),
//                                         ),
//                                       ),
//                                     ),
//                                     v(10),
//                                     Row(
//                                       mainAxisAlignment:
//                                           MainAxisAlignment.spaceBetween,
//                                       children: [
//                                         Text(
//                                           "Total Price : ${cubit.orders[index].priceWithVAT!} SAR",
//                                           style: StylesManger.medium(),
//                                         ),
//                                         PopupMenuButton(
//                                           // color: Colors.black,
//                                           position: PopupMenuPosition.under,
//                                           iconSize: 20,
//                                           icon: const Icon(
//                                             FontAwesomeIcons.ellipsisVertical,
//                                             color: Colors.black,
//                                           ),

//                                           itemBuilder: (context) {
//                                             return [
//                                               PopupMenuItem(
//                                                 value: 0,
//                                                 child: ListTile(
//                                                   leading: Icon(
//                                                     Icons.info_rounded,
//                                                     color: Colors.blue,
//                                                   ),
//                                                   title: Text(
//                                                     "Details",
//                                                   ),
//                                                 ),
//                                               ),
//                                               PopupMenuItem(
//                                                 value: 1,
//                                                 child: ListTile(
//                                                   leading: Icon(
//                                                     Icons.location_on,
//                                                     color: Colors.red[900],
//                                                   ),
//                                                   title: Text("Track"),
//                                                 ),
//                                               )
//                                             ];
//                                           },
//                                           onSelected: (value) async{
//                                             switch (value) {
//                                               case 0:
//                                                 Navigator.push(
//                                                     context,
//                                                     MaterialPageRoute(
//                                                       builder: (context) => OrderDetailsView(
//                                                        order: cubit.orders[index],
//                                                       ),
//                                                     ));
//                                                 break;

//                                               case 1:
//                                                 print("2");
//                                               await  context.read<MapCubit>().getNurseLocation(orderID: cubit.orders[index].id!);
//                                               Navigator.push(context, MaterialPageRoute(builder: (context)=>TrackingNurse()));
//                                                 break;
//                                             }
//                                           },
//                                         )
//                                       ],
//                                     )
//                                   ],
//                                 )
//                               ],
//                             ),
//                           ),
//                       separatorBuilder: (context, index) => SizedBox(
//                             height: 15,
//                           ),
//                       itemCount: cubit.orders.length)
//                   : const Center(
//                       child: CircularProgressIndicator(),
//                     ),
//             ));
//       },
//     );
//   }
// }
