import 'dart:developer';

import 'package:bloc/bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:meta/meta.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/app/pref_manager.dart';
import 'package:tahlili/data/network/error_handler.dart';
import 'package:tahlili/data/requests/order/request_order.dart';
import 'package:tahlili/data/response/orders/response_order.dart';
import 'package:tahlili/domain/repository/orders/orders.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/lab_appointments/view/lab_appointmnets.dart';
import 'package:tahlili/presentaion/payment/view/payment_view.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';

import '../../../data/response/home/response_home.dart';
import '../../../domain/repository/auth/auth.dart';
import '../../bnb/cubit/bnb_cubit.dart';
import '../../bnb/view/bnb_view.dart';

part 'orders_state.dart';

class OrdersCubit extends Cubit<OrdersState> {
  OrdersCubit(
      this._ordersRepository, this._preferancesManager, this._authRepository)
      : super(OrdersInitial());
  final BaseOrdersRepository _ordersRepository;
  final PreferancesManager _preferancesManager;
  final BaseAuthRepository _authRepository;

  createHomeOrder(
      {required bool isTest,
      required int itemId,
      required int labId,
      required BuildContext context}) async {
    final userId = _preferancesManager.getData(key: userID);
    emit(LoadCreateHomeOrder());
    try {
      print(date!.split(', ')[1]);
      final prefearedTime =
          DateFormat("HH:mm", 'en').format(DateFormat("hh:mm a").parse(hour!));
      final result = await _ordersRepository.createHomeOrder(
          order: RequestQuickOrder(
        patientId: profileEntityId!,
        patientUserId: userId,
        useWallet: useWallet,
        isTest: isTest,
        prefearedDate: date!.split(', ')[1],
        prefearedTime: "$prefearedTime:00",
        paymnetTypeId: paymentId!,
        itemId: itemId,
        couponName: "couponName",
        isMale: isMale,
        addressId: addressId!,
        labId: labId,
      ));
      result.fold((error) {
        debugPrint(error.message);
        toast(text: "Error has occurred", color: Colors.red);
        emit(FailureCreateHomeOrder());
      }, (response) {
        debugPrint(response.message);
        if (paymentId == 2) {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => PaymentView(
                        amount: (total * 100).toInt(),
                        description: "Q${response.id}",
                        fromTele: false,
                      )));
          clearOrderData();
          toast(
              text: "Item has been created successfully", color: Colors.green);
        } else {
          context.read<BnbCubit>().setIndex(3, context);
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => const BNBView()));
          clearOrderData();

          toast(
              text: "Item has been created successfully", color: Colors.green);
        }

        emit(SuccessCreateHomeOrder());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureCreateHomeOrder());
    }
  }

  createLabOrder({
    required BuildContext context,
    required bool isTest,
    required int itemId,
  }) async {
    final userId = _preferancesManager.getData(key: userID);
    final prefearedTime =
        DateFormat("HH:mm", 'en').format(DateFormat("hh:mm a").parse(hour!));
    emit(LoadCreateLabOrder());
    try {
      print(date!.split(', ')[1]);
      final result = await _ordersRepository.createLabOrder(
          order: RequestQuickOrder(
        patientId: profileEntityId!,
        patientUserId: userId,
        useWallet: useWallet,
        isTest: isTest,
        prefearedDate: date!.split(', ')[1],
        prefearedTime: "$prefearedTime:00",
        paymnetTypeId: 2,
        itemId: itemId,
        couponName: "couponName",
        labId: labId,
      ));
      result.fold((error) async {
        debugPrint(error.response!.data['message']);

        await handleSuccessMessages(
            error.response!.data['message'], 'en', Colors.red);

        emit(FailureCreateLabOrder());
      }, (response) {
        debugPrint(response.message);
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => PaymentView(
                      amount: (total * 100).toInt(),
                      description: "Q${response.id}",
                      fromTele: false,
                    )));

        clearOrderData();
        emit(SuccessCreateLabOrder());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureCreateLabOrder());
    }
  }

  List<String> enDates = [];
  List<String> arDates = [];
  List<ResponseLabsWorkingTimesAtHomes> workingHours = [];
  List<WorkingDays> hours = [];
  getLabWorkingHours() async {
    workingHours.clear();
    hours.clear();
    enDates = List.generate(
      30,
      (index) {
        DateTime date = DateTime.now().add(Duration(days: index));
        String dayName = DateFormat('EEEE', 'en').format(date);
        String formattedDate = DateFormat('yyyy-MM-dd', 'en').format(date);
        return '$dayName, $formattedDate';
      },
    );
    arDates = List.generate(
      30,
      (index) {
        DateTime date = DateTime.now().add(Duration(days: index));
        String dayName = DateFormat('EEEE', 'ar').format(date);
        String formattedDate = DateFormat('yyyy-MM-dd', 'en').format(date);
        return '$dayName, $formattedDate';
      },
    );
    emit(LoadGetLabWorkingHourState());
    try {
      final result = await _ordersRepository.getLabWorkingHours();

      result.fold((failure) async {
        final error = await handleServerErrors(failure.message, failure.code);
        debugPrint(error.message);
        emit(FailureGetLabWorkingHourState());
      }, (workingHours) {
        debugPrint(workingHours.labsWorkingTimesAtHomes!.length.toString());
        this.workingHours.addAll(workingHours.labsWorkingTimesAtHomes!);
        print("1");

        for (var i = 0; i < this.workingHours.length; i++) {
          print("2");
          List<String> day =
              ConstantManger.splitTelda(this.workingHours[i].weekDay!.name!);
          print("3");
          hours.add(WorkingDays(
              day[1],
              day[0],
              generateTimeSlots(this.workingHours[i].startTime!,
                  this.workingHours[i].endTime!)));

          day.clear();
        }
        setDate(0);
        print("hours " + hours.length.toString());

        emit(SuccessGetLabWorkingHourState());
      });
    } catch (e) {
      emit(FailureGetLabWorkingHourState());
    }
  }

  double nurseFees = 0;
  getNurseFees(
      double subTotal, int? partnerTestId, int? partnerPackageId) async {
    nurseFees = 0;
    emit(LoadGetNurseFeesState());
    try {
      final result = await _ordersRepository.getNurseFees(
          partnerTestId: partnerTestId,
          partnerPackageId: partnerPackageId,
          isMale: isMale);
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetNurseFeesState());
      }, (fees) {
        debugPrint(fees.nurseFees.toString());
        nurseFees = fees.nurseFees;
        clacTotal(subTotal);
        emit(SuccessGetNurseFeesState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetNurseFeesState());
    }
  }

  List<ResponseLookup> payment = [];
  List<String> methods = [];
  getPayMentType() async {
    payment.clear();
    methods.clear();
    emit(LoadGetPaymentTypeState());
    try {
      final result =
          await _authRepository.getLookUp(tableName: "PaymentsTypes");
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetPaymentTypeState());
      }, (payment) {
        debugPrint(payment.length.toString());
        this.payment.addAll(payment);
        for (var i = 0; i < this.payment.length; i++) {
          methods.add(this.payment[i].name!);
        }
        emit(SuccessGetPaymentTypeState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetPaymentTypeState());
    }
  }

  int? paymentValue;
  int? paymentId;
  setPayment(value) {
    paymentValue = value;
    for (var i = 0; i < payment.length; i++) {
      if (methods[value] == payment[i].name) {
        paymentId = payment[i].id;
        print(paymentId);
      }
    }
    emit(SetPaymentState());
  }

  List<String> selectedDay = [];
  int? dateValue;
  String? date;

  setDate(value) {
    dateValue = value;
    print(dateValue);
    date = enDates[value];
    // debugPrint(date);
    final selectedDatetime =
        DateTime.parse(date!.replaceAll(RegExp(r'\b\w+,\s*'), ''));

    selectedDay.clear();
    hourValue = null;
    hour = null;
    List<String> parts = date!.trim().split(",");
    // print("fff"+parts[0]);
    for (var i = 0; i < hours.length; i++) {
      print(hours[i].enDay);
      print(parts[0]);
      if (parts[0].trim() == hours[i].enDay.trim()) {
        selectedDay.addAll(generateUniqueTimeSlots(
            hours[i].hours.first, hours[i].hours.last, selectedDatetime));
        // if (selectedDatetime.month==nowDay.month&&selectedDatetime.day==nowDay.day) {
        log(selectedDay.toString());
        //   selectedDay.addAll(hours[i].hours);
        // } else {
        //   selectedDay.addAll(hours[i].hours);
        // }
      }
    }
    print(selectedDay);
    emit(GetVisingDateState());
  }

  List<String> generateUniqueTimeSlots(
      String startTime, String endTime, DateTime today) {
    DateTime compareTime = DateTime.now();
    String compare = DateFormat('HH:mm').format(compareTime);
    DateTime now = DateFormat('HH:mm').parse(compare);
    DateTime start = DateFormat('HH:mm').parse(startTime);
    DateTime end = DateFormat('HH:mm').parse(endTime);
    String day = "";
    if (compareTime.day == today.day) {
      if (now.isAfter(start)) {
        // Start from the current time
        if (now.minute > 0 && now.minute < 30) {
          day = "${now.hour}:30";
          start = DateFormat('HH:mm').parse(day);
        } else {
          day = "${now.hour + 1}:00";
          start = DateFormat('HH:mm').parse(day);
        }
      }
    }

    List<String> slots = [];
    for (DateTime time = start;
        time.isBefore(end);
        time = time.add(const Duration(minutes: 30))) {
      slots.add(DateFormat('hh:mm a').format(time));
    }
    return slots;
  }

  int? hourValue;
  String? hour;
  setHour(value) {
    hourValue = value;
    hour = selectedDay[value];
    debugPrint(hour);
    emit(GetVisingDateState());
  }

  List<String> names = [
    "Andrew",
    "Moaz",
    "Ahmed",
  ];
  int? nameValue;
  String? nameRadio;
  setPatient(value) {
    nameValue = value;
    emit(SetPatientState());
  }

  setPatientRadio(value) {
    nameRadio = value;
    emit(SetPatientState());
  }

  List<String> profiles = [];
  List<String> profileImages = [];

  getProfileNames(BuildContext context) {
    profiles.clear();
    profileImages.clear();
    for (var i = 0;
        i < context.read<AccountCubit>().patinetProfiles.length;
        i++) {
      profiles.add(
          "${context.read<AccountCubit>().patinetProfiles[i].firstName!} ${context.read<AccountCubit>().patinetProfiles[i].lastName!}");
      profileImages.add(context.read<AccountCubit>().patinetProfiles[i].image!);
    }
    emit(GetPatientProfilesState());
  }

  int? profileEntityId;
  int? profileValue;
  double? patientWallet;
  setProfile(value, BuildContext context) {
    profileValue = value;
    for (var i = 0;
        i < context.read<AccountCubit>().patinetProfiles.length;
        i++) {
      if (profiles[value] ==
          "${context.read<AccountCubit>().patinetProfiles[i].firstName!} ${context.read<AccountCubit>().patinetProfiles[i].lastName!}") {
        profileEntityId = context.read<AccountCubit>().patinetProfiles[i].id;
        patientWallet =
            context.read<AccountCubit>().patinetProfiles[i].walletMoney;
        print(patientWallet);
      }
    }
    emit(SetPatientProfileState());
  }

  List<String> addresses = [];

  getAddresses(BuildContext context) {
    addresses.clear();
    for (var i = 0; i < context.read<AccountCubit>().addresses.length; i++) {
      addresses.add(context.read<AccountCubit>().addresses[i].name!);
    }
    emit(GetAddressesState());
  }

  int? addressId;
  int? addressValue;
  setAddress(value, BuildContext context) {
    addressValue = value;
    for (var i = 0; i < context.read<AccountCubit>().addresses.length; i++) {
      if (addresses[value] == context.read<AccountCubit>().addresses[i].name!) {
        addressId = context.read<AccountCubit>().addresses[i].id;
      }
    }
    emit(SetAddressesState());
  }

  final List<String> enNurses = ["Male", "Female", "Pediatric"];
  final List<String> arNurses = ["ذكر", "انثي", "اطفال"];
  int? nurseValue;
  bool? isMale;
  setNurse(value, double? subTotal, int? partnerPackageId, int? partnerTestId) {
    nurseValue = value;
    if (enNurses[value] == "Male") {
      isMale = true;
    } else if (enNurses[value] == "Female") {
      isMale = false;
    } else {
      isMale = null;
    }
    print(isMale);
    if (subTotal != null) {
      getNurseFees(subTotal, partnerTestId, partnerPackageId);
    }
    emit(SetNurserState());
  }

  bool homeFirstPgaeValidation() {
    if (profileEntityId == null) {
      toast(text: "Choose Profile", color: Colors.red);
      return false;
    }
    if (addressId == null) {
      toast(text: "Choose Address", color: Colors.red);
      return false;
    }
    if (date == null) {
      toast(text: "Choose Date", color: Colors.red);
      return false;
    }
    if (hour == null) {
      toast(text: "Choose Time", color: Colors.red);
      return false;
    }

    return true;
  }

  bool labFirstPgaeValidation() {
    if (profileEntityId == null) {
      toast(text: "Choose Profile", color: Colors.red);
      return false;
    }
    if (labId == null) {
      toast(text: "Choose Lab", color: Colors.red);
      return false;
    }
    if (date == null) {
      toast(text: "Choose Date", color: Colors.red);
      return false;
    }
    if (hour == null) {
      toast(text: "Choose Time", color: Colors.red);
      return false;
    }

    return true;
  }

  bool homeCheckPgaeValidation() {
    if (nurseValue == null) {
      toast(text: "Choose Nurse", color: Colors.red);
      return false;
    }
    if (paymentId == null) {
      toast(text: "Choose Payment", color: Colors.red);
      return false;
    }

    return true;
  }

  bool useWallet = false;
  switchWallet(bool value, double subTotal) {
    useWallet = value;
    clacTotal(subTotal);
    emit(SwitchWalletState());
  }

  double total = 0;
  clacTotal(double subTotal) {
    total = 0;
    total = subTotal + nurseFees;
    if (useWallet) {
      total = total - patientWallet!;
      if (total < 0) total = 0;
    }
    emit(CalcTotalPriceState());
  }

  List<String> generateTimeSlots(String startTime, String endTime) {
    print("4");
    DateTime start = DateFormat('HH:mm:ss', 'en').parse(startTime);
    DateTime end = DateFormat('HH:mm:ss', 'en').parse(endTime);

    List<String> slots = [];
    for (DateTime time = start;
        time.isBefore(end);
        time = time.add(const Duration(minutes: 60))) {
      slots.add(DateFormat('HH:mm').format(time));
    }
    print("5");
    return slots;
  }

  List<ResponseLabBranches> branches = [];
  List<String> arBranches = [];
  List<String> enBranches = [];
  Future getLabBranches(
      {required int partnerId,
      required int itemId,
      required bool isTest}) async {
    branches.clear();
    arBranches.clear();
    enBranches.clear();
    emit(LoadGetLabBranchesState());
    try {
      final result = await _ordersRepository.getLabBranches(
          partnerId: partnerId, itemId: itemId, isTest: isTest);
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetLabBranchesState());
      }, (branches) {
        debugPrint(branches.length.toString());
        this.branches.addAll(branches);
        for (var element in branches) {
          arBranches.add(element.nameAr!);
          enBranches.add(element.nameEn!);
        }
        emit(SuccessGetLabBranchesState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetLabBranchesState());
    }
  }

  int? labId;
  int? lab;

  setLab(int value, BuildContext context) {
    lab = value;
    for (var i = 0; i < branches.length; i++) {
      if (context.locale.languageCode == 'ar') {
        if (arBranches[value] == branches[i].nameAr!) {
          labId = branches[i].id;
        }
      } else {
        if (enBranches[value] == branches[i].nameEn!) {
          labId = branches[i].id;
        }
      }
    }
    emit(SetLabState());
  }

  List<ResponseUpcomimgAppts> upcomingAppts = [];
  getUpcomingAppts() async {
    upcomingAppts.clear();
    try {
      emit(LoadGetUpcomingApptsState());
      final result = await _ordersRepository.getUpcomingAppts();
      result.fold((error) {
        debugPrint(error.message);
        emit(FailurGetUpcomingApptsState());
      }, (upcomingAppts) {
        debugPrint(upcomingAppts.length.toString());
        this.upcomingAppts.addAll(upcomingAppts);
        emit(SuccessGetUpcomingApptsState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailurGetUpcomingApptsState());
    }
  }

  clearOrderData() {
    profileValue = null;
    profileEntityId = null;
    addressValue = null;
    addressId = null;
    dateValue = null;
    date = null;
    hourValue = null;
    hour = null;
    nurseValue = null;
    nurseFees = 0;
    isMale = null;
    paymentId = null;
    paymentValue = null;
    useWallet = false;
    lab = null;
    labId = null;
    emit(ClearOrderDateState());
  }
}

class WorkingDays {
  final String arDay;
  final String enDay;
  final List<String> hours;

  WorkingDays(this.arDay, this.enDay, this.hours);
}
