part of 'orders_cubit.dart';

@immutable
sealed class OrdersState {}

final class OrdersInitial extends OrdersState {}

class LoadGetOrdersState extends OrdersState {}

class SuccessGetOrdersState extends OrdersState {
  final List<ResponseOrder> orders;

  SuccessGetOrdersState(this.orders);
}

class FailureGetOrderState extends OrdersState {
  final String error;

  FailureGetOrderState(this.error);
}

class SetPatientState extends OrdersState {}

class GetPatientProfilesState extends OrdersState {}

class SetPatientProfileState extends OrdersState {}

class GetAddressesState extends OrdersState {}

class SetAddressesState extends OrdersState {}

class LoadGetLabWorkingHourState extends OrdersState {}

class SuccessGetLabWorkingHourState extends OrdersState {}

class FailureGetLabWorkingHourState extends OrdersState {}

class GetVisingDateState extends OrdersState {}

class SetNurserState extends OrdersState {}

class LoadGetNurseFeesState extends OrdersState {}

class SuccessGetNurseFeesState extends OrdersState {}

class FailureGetNurseFeesState extends OrdersState {}

class LoadGetPaymentTypeState extends OrdersState {}

class SuccessGetPaymentTypeState extends OrdersState {}

class FailureGetPaymentTypeState extends OrdersState {}

class SetPaymentState extends OrdersState {}

class SwitchWalletState extends OrdersState {}

class LoadCreateHomeOrder extends OrdersState {}

class SuccessCreateHomeOrder extends OrdersState {}

class FailureCreateHomeOrder extends OrdersState {}

class ChangeQuantityState extends OrdersState {}

class CalcTotalPriceState extends OrdersState {}

class LoadCreateLabOrder extends OrdersState {}

class SuccessCreateLabOrder extends OrdersState {}

class FailureCreateLabOrder extends OrdersState {}

class LoadGetLabBranchesState extends OrdersState {}

class SuccessGetLabBranchesState extends OrdersState {}

class FailureGetLabBranchesState extends OrdersState {}

class SetLabState extends OrdersState {}

class ClearOrderDateState extends OrdersState {}

class LoadGetUpcomingApptsState extends OrdersState {}

class SuccessGetUpcomingApptsState extends OrdersState {}

class FailurGetUpcomingApptsState extends OrdersState {}
