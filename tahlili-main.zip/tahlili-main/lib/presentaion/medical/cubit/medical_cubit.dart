import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';
import 'package:tahlili/domain/repository/auth/auth.dart';

import '../../../data/response/home/response_home.dart';

part 'medical_state.dart';

class MedicalCubit extends Cubit<MedicalState> {
  MedicalCubit(this._authRepository) : super(MedicalInitial());
  final BaseAuthRepository _authRepository;

  start(){
    getEthnicities();
    getBloodTypes();
    getTherapies();
    getSurgeries();
    getDailyLifeStresses();

  }

  final TextEditingController weightController=TextEditingController();
  final TextEditingController heightController=TextEditingController();
  final TextEditingController ethnicityController=TextEditingController();
  final TextEditingController bloodTypeController=TextEditingController();
  final TextEditingController therapyController=TextEditingController();
  final TextEditingController surgeryController=TextEditingController();
  final TextEditingController dailyLifeStressesController=TextEditingController();


List<ResponseLookup> ethnicities=[];
List<String> enEthnicities=[];
List<String> arEthnicities=[];

  getEthnicities() async {
    ethnicities.clear();
    enEthnicities.clear();
    arEthnicities.clear();
    emit(LoadGetLookUpState());
    try {
      final result = await _authRepository.getLookUp(tableName: 'Ethnicities');
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetLookUpState());
      }, (data) {
        debugPrint(data.length.toString());
        ethnicities.addAll(data);
           List.generate(data.length, (index) => enEthnicities.add(data[index].name!));
        // List.generate(data.length, (index) => languagesLookUp.add(data[index]));
        emit(SuccessGetLookUpState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetLookUpState());
    }
  }
  String? ethnicity;
  int? ethnicityId;
   setEthnicity(value) {
    ethnicity = value;
    for (var i = 0; i < ethnicities.length; i++) {
      if (ethnicities[i].name!.contains(value)) {
        ethnicityId = ethnicities[i].id!;
        debugPrint(ethnicityId.toString());
      }
    }
    emit(SetEthnicitState());
  }
List<ResponseLookup> bloodTypes=[];
List<String> enBloodTypes=[];
List<String> arBloodTypes=[];

  getBloodTypes() async {
    bloodTypes.clear();
    enBloodTypes.clear();
    arBloodTypes.clear();
    emit(LoadGetLookUpState());
    try {
      final result = await _authRepository.getLookUp(tableName: 'BloodTypes');
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetLookUpState());
      }, (data) {
        debugPrint(data.length.toString());
        bloodTypes.addAll(data);
           List.generate(data.length, (index) => enBloodTypes.add(data[index].name!));
        // List.generate(data.length, (index) => languagesLookUp.add(data[index]));
        emit(SuccessGetLookUpState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetLookUpState());
    }
  }
  String? bloodType;
  int? bloodTypeId;
   setBloodTypes(value) {
    bloodType = value;
    for (var i = 0; i < bloodTypes.length; i++) {
      if (bloodTypes[i].name!.contains(value)) {
        bloodTypeId = bloodTypes[i].id!;
        debugPrint(bloodTypeId.toString());
      }
    }
    emit(SetBloodTypesState());
  }
List<ResponseLookup> therapies=[];
List<String> enTherapies=[];
List<String> arTherapies=[];

  getTherapies() async {
    therapies.clear();
    enTherapies.clear();
    arTherapies.clear();
    emit(LoadGetLookUpState());
    try {
      final result = await _authRepository.getLookUp(tableName: 'Therapies');
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetLookUpState());
      }, (data) {
        debugPrint(data.length.toString());
        therapies.addAll(data);
           List.generate(data.length, (index) => enTherapies.add(data[index].name!));
        // List.generate(data.length, (index) => languagesLookUp.add(data[index]));
        emit(SuccessGetLookUpState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetLookUpState());
    }
  }
  String? therapy;
  int? therapyId;
   setTherapies(value) {
    therapy = value;
    for (var i = 0; i < therapies.length; i++) {
      if (therapies[i].name!.contains(value)) {
        therapyId = therapies[i].id!;
        debugPrint(therapyId.toString());
      }
    }
    emit(SetTherapiesState());
  }
List<ResponseLookup> surgeries=[];
List<String> enSurgeries=[];
List<String> arSurgeries=[];

  getSurgeries() async {
    surgeries.clear();
    enSurgeries.clear();
    arSurgeries.clear();
    emit(LoadGetLookUpState());
    try {
      final result = await _authRepository.getLookUp(tableName: 'Surgeries');
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetLookUpState());
      }, (data) {
        debugPrint(data.length.toString());
        surgeries.addAll(data);
           List.generate(data.length, (index) => enSurgeries.add(data[index].name!));
        // List.generate(data.length, (index) => languagesLookUp.add(data[index]));
        emit(SuccessGetLookUpState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetLookUpState());
    }
  }
  String? surgery;
  int? surgeryyId;
   setsurgeries(value) {
    surgery = value;
    for (var i = 0; i < surgeries.length; i++) {
      if (surgeries[i].name!.contains(value)) {
        surgeryyId = surgeries[i].id!;
        debugPrint(surgeryyId.toString());
      }
    }
    emit(SetTherapiesState());
  }
List<ResponseLookup> stresses=[];
List<String> enStress=[];
List<String> arStress=[];

  getDailyLifeStresses() async {
    stresses.clear();
    enStress.clear();
    arStress.clear();
    emit(LoadGetLookUpState());
    try {
      final result = await _authRepository.getLookUp(tableName: 'DailyLifeStresses');
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetLookUpState());
      }, (data) {
        debugPrint(data.length.toString());
        stresses.addAll(data);
           List.generate(data.length, (index) => enStress.add(data[index].name!));
        // List.generate(data.length, (index) => languagesLookUp.add(data[index]));
        emit(SuccessGetLookUpState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetLookUpState());
    }
  }
  String? stress;
  int? stressId;
   setStress(value) {
    stress = value;
    for (var i = 0; i < stresses.length; i++) {
      if (stresses[i].name!.contains(value)) {
        stressId = stresses[i].id!;
        debugPrint(stressId.toString());
      }
    }
    emit(SetStressState());
  }
}
