part of 'medical_cubit.dart';

@immutable
sealed class MedicalState {}

final class MedicalInitial extends MedicalState {}

class LoadGetLookUpState extends MedicalState {}

class FailureGetLookUpState extends MedicalState {}

class SuccessGetLookUpState extends MedicalState {}

class SetEthnicitState extends MedicalState {}

class SetBloodTypesState extends MedicalState {}

class SetTherapiesState extends MedicalState {}

class SetStressState extends MedicalState {}