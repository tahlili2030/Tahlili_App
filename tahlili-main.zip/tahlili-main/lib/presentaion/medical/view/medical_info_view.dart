import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tahlili/presentaion/medical/cubit/medical_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/shared/search_drop.dart';
import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';

import '../../resources/shared/appbar_divider.dart';
import '../../resources/strings_manager.dart';
import '../../resources/styles_manger.dart';
import '../../resources/validation_manager.dart';

class MedicalInfoView extends StatelessWidget {
  const MedicalInfoView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<MedicalCubit>();
    cubit.start();
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: Text(
          "AdditionalInfo".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: BlocBuilder<MedicalCubit, MedicalState>(
        builder: (context, state) {
          return Column(
            children: [
              const AppBarDivider(),
              const SizedBox(
                height: 24,
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      children: [
                        authForm(
                            keyboardType: TextInputType.number,
                            hintText: "Weight".tr(),
                            title: "Weight".tr(),
                            controller: cubit.weightController,
                            validator: (value) {
                              if (value != null && value.isNotEmpty) {
                                if (!ValidationManager.numberValidation(
                                  number: value,
                                )) {
                                  return StringsManager.numberValid;
                                }
                              } else {
                                return StringsManager.fieldRequierd;
                              }
                              return null;
                            }),
                        authForm(
                            keyboardType: TextInputType.number,
                            hintText: "Height".tr(),
                            title: "Height".tr(),
                            controller: cubit.heightController,
                            validator: (value) {
                              if (value != null && value.isNotEmpty) {
                                if (!ValidationManager.numberValidation(
                                  number: value,
                                )) {
                                  return StringsManager.numberValid;
                                }
                              } else {
                                return StringsManager.fieldRequierd;
                              }
                              return null;
                            }),
                        SearchDrop(
                            value: cubit.ethnicity,
                            onChanged: (value) {
                              cubit.setEthnicity(value);
                            },
                            searchController: cubit.ethnicityController,
                            items: cubit.enEthnicities,
                            title: "Ethnicity".tr()),
                        SearchDrop(
                            value: cubit.bloodType,
                            onChanged: (value) {
                              cubit.setBloodTypes(value);
                            },
                            searchController: cubit.bloodTypeController,
                            items: cubit.enBloodTypes,
                            title: "BloodType".tr()),
                        SearchDrop(
                            value: cubit.therapy,
                            onChanged: (value) {
                              cubit.setTherapies(value);
                            },
                            searchController: cubit.therapyController,
                            items: cubit.enTherapies,
                            title: "Therapies".tr()),
                        SearchDrop(
                            value: cubit.surgery,
                            onChanged: (value) {
                              cubit.setsurgeries(value);
                            },
                            searchController: cubit.surgeryController,
                            items: cubit.enSurgeries,
                            title: "Surgeries".tr()),
                        SearchDrop(
                            value: cubit.stress,
                            onChanged: (value) {
                              cubit.setStress(value);
                            },
                            searchController: cubit.dailyLifeStressesController,
                            items: cubit.enStress,
                            title: "DailyLifeStress".tr()),
                       const SizedBox(
                          height: 16,
                        ),
                        AppButton(
                          radius: 40,
                            color: ColorManger.primary, name: "Save".tr(), onPressed: (){

                            }),
                          const   SizedBox(
                          height: 24,
                        ),
                      ],
                    ),
                  ),
                ),
              )
            ],
          );
        },
      ),
    );
  }
}
