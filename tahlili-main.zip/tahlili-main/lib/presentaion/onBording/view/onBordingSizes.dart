import 'dart:developer';

import 'package:flutter/material.dart';

import 'onbording_view.dart';
import 's_onbording_view.dart';

class OnBoridingSizesView extends StatelessWidget {
  const OnBoridingSizesView({super.key});

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    log(screenSize.width.toString());
  late Widget content;
    if (screenSize.height >800) {
     content= OnBordingView();
    } else if (screenSize.height < 800) {
      content= SOnBordingView();
    }
    return content;
  }
}
