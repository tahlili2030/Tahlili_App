import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/presentaion/auth/cubit/auth_cubit.dart';
import 'package:tahlili/presentaion/auth/view/pages/phone_widget.dart';
import 'package:tahlili/presentaion/onBording/cubit/on_bording_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

import '../../resources/shared/app_drop_down.dart';
import '../../resources/shared/auth_sheet.dart';

class OnBordingView extends StatelessWidget {
  const OnBordingView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<OnBordingCubit>();
    final authCubit = context.read<AuthCubit>();

    context.read<AuthCubit>().initAuthPages(context, authCubit);
    return Scaffold(
      body: BlocBuilder<OnBordingCubit, OnBordingState>(
        builder: (context, state) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 23),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: 28.h,
                ),
                Row(
                  children: [
                    BlocBuilder<AuthCubit, AuthState>(
                      builder: (context, state) {
                        return SizedBox(
                          width: 135.w,
                          height: 30.h,
                          child: AppDropdown(
                            isNetworkImage: true,
                            buttonDecoration: BoxDecoration(
                                color: ColorManger.offWhite.withOpacity(.5),
                                borderRadius: BorderRadius.circular(20)),
                            prfoileImage:
                                context.read<AuthCubit>().languagesFlags,
                            list: context.read<AuthCubit>().languages,
                            value: context.read<AuthCubit>().language,
                            hintText: "",
                            onChange: (value) {
                              context.read<AuthCubit>().setLanguages(value);
                            },
                          ),
                        );
                      },
                    ),
                  ],
                ),
                SizedBox(
                  height: 38.h,
                ),
                Expanded(
                  //   height: 600,
                  child: PageView.builder(
                      itemCount: cubit.onBordings.length,
                      controller: cubit.pageController,
                      onPageChanged: (index) {
                        cubit.changeIndex(index);
                      },
                      itemBuilder: (context, index) => Column(
                            children: [
                              Container(
                                width: 250.w,
                                height: 280.h,
                                decoration: BoxDecoration(
                                    image: DecorationImage(
                                  fit: BoxFit.fill,
                                  image:
                                      AssetImage(cubit.onBordings[index].image),
                                )),
                              ),
                              SizedBox(
                                height: 38.h,
                              ),
                              Column(
                                children: [
                                  Text(
                                    cubit.onBordings[index].title,
                                    style: StylesManger.rich().copyWith(
                                        fontSize: 24.sp,
                                        color: const Color(0xff242B60)),
                                    textAlign: TextAlign.center,
                                  ),
                                  SizedBox(
                                    height: 26.h,
                                  ),
                                  Text(
                                    cubit.onBordings[index].description,
                                    style: StylesManger.medium().copyWith(
                                        color: const Color(0xff242B60)),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              )
                            ],
                          )),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ...List.generate(
                        cubit.onBordings.length,
                        (index) => AnimatedContainer(
                              margin: const EdgeInsetsDirectional.only(end: 5),
                              duration: const Duration(milliseconds: 300),
                              height: cubit.currentIndex == index ? 10 : 12,
                              width: cubit.currentIndex == index ? 25 : 12,
                              decoration: BoxDecoration(
                                  color: cubit.currentIndex == index
                                      ? ColorManger.newPrimary
                                      : ColorManger.grey,
                                  borderRadius: cubit.currentIndex == index
                                      ? BorderRadius.circular(30)
                                      : BorderRadius.circular(80)),
                            )),
                  ],
                ),
                SizedBox(
                  height: 16.h,
                ),
                ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        minimumSize: Size(double.infinity, 48.h),
                        backgroundColor: cubit.currentIndex == 3
                            ? ColorManger.newPrimary
                            : Colors.white,
                        shape: RoundedRectangleBorder(
                          side: BorderSide(color: ColorManger.newPrimary),
                          borderRadius: BorderRadius.circular(24.0.r),
                        )),
                    onPressed: () async {
                      if (cubit.currentIndex == 3) {
                        // Navigator.push(
                        //     context,
                        //     MaterialPageRoute(
                        //         builder: (context) => LoginView(
                        //               controller: authCubit.phoneController,
                        //             )));
                        // context.read<AuthCubit>().changePageSized(350.h);
                        showModalBottomSheet(
                            context: context,
                            isScrollControlled: true,
                            builder: (context) => const AuthSheet());
                        // await _manager.saveData(key: onBording, value: true);
                      } else {
                        cubit.pageController.nextPage(
                            duration: const Duration(milliseconds: 300),
                            curve: Curves.easeInOut);
                      }
                    },
                    child: Center(
                      child: Text(
                        cubit.currentIndex == 3
                            ? 'Get Started'.tr()
                            : 'Next'.tr(),
                        style: StylesManger.rich().copyWith(
                            color: cubit.currentIndex == 3
                                ? Colors.white
                                : ColorManger.newPrimary,
                            fontSize: 16),
                      ),
                    )),
                const SizedBox(
                  height: 24,
                )
              ],
            ),
          );
        },
      ),
    );
  }
}
