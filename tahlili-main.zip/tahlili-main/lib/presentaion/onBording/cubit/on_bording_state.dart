part of 'on_bording_cubit.dart';

@immutable
sealed class OnBordingState {}

final class OnBordingInitial extends OnBordingState {}

class ChangePageIndexState extends OnBordingState {}