import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';

part 'on_bording_state.dart';

class OnBordingCubit extends Cubit<OnBordingState> {
  OnBordingCubit() : super(OnBordingInitial());
  List<OnBording> onBordings=[
    OnBording('assets/images/onBording/onBording1.png', 'Welcome to Tahlili', 'Your personalized healthcare journey begins here. Tahlili empowers you to take control of your health with convenient lab test services. Lets get started!'),
    OnBording('assets/images/onBording/onBording2.png', 'Hassle-Free Lab Test Booking', 'Easily schedule lab tests from the comfort of your home. Select tests, choose a nearby lab, and pick a time that suits you. Its that simple!'),
    OnBording('assets/images/onBording/onBording3.png', 'Consultation And Telemedicine', 'Connect with healthcare professionals for personalized consultation via telemedicine. Discuss your results, ask questions, and receive expert guidance, all within the app.'),
    OnBording('assets/images/onBording/onBording4.png', 'Secure and Confidential', 'Your health data is precious. We prioritize security and confidentiality. Rest assured, your information is in safe hands.'),

  ];
  int currentIndex=0;
  final pageController=PageController();
  changeIndex(int index){
    currentIndex=index;
    emit(ChangePageIndexState());
  }

}

class OnBording{
  final String image;
  final String title;
  final String description;

  OnBording(this.image, this.title, this.description);

}