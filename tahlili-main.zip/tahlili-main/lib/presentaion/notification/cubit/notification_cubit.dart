import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';
import 'package:signalr_netcore/signalr_client.dart';
import 'package:tahlili/domain/repository/notification/notification.dart';
import 'package:logger/logger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';
import '../../../app/pref_manager.dart';
import '../../../data/response/notofication/notification.dart';
import '../../../data/response/response.dart';

part 'notification_state.dart';

class NotificationCubit extends Cubit<NotificationState> {
  NotificationCubit(this._notificationRepository, this._manager)
      : super(NotificationInitial());
  final BaseNotificationRepository _notificationRepository;
  final PreferancesManager _manager;
  final hubConnection = HubConnectionBuilder()
      .withUrl('https://dev-api.tahliliapp.store/NotificationHub')
      .build();
  List<ResponseNotifcation> notifications = [];
  List<String> arNotifications=[];
  List<String> enNotifications=[];

  getNotification() async {
    notifications = [];
    arNotifications.clear();
    enNotifications.clear();
    try {
      emit(LoadGetNotificationsState());
      final result = await _notificationRepository.getNotification();

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetNotificationsState(failure.message));
      }, (notifications) {
        debugPrint(notifications.length.toString());
        this.notifications.addAll(notifications);
        for (var element in notifications) {
          List<String> parts=ConstantManger.splitTelda(element.title!);
          print(parts[1]);
         enNotifications.add(parts[0]);
          arNotifications.add(parts[1]);


        }
        emit(SuccessGetNotificationsState(notifications));
      });
    } catch (e) {
      emit(FailureGetNotificationsState(e.toString()));
    }
  }

  notifcationHub() async {
    print("object1");
    await hubConnection.start();
    print("object2");
    hubConnection.on("ReceiveNotification", (arguments) {
      for (var i = 0; i < arguments!.length; i++) {
        if (arguments[i]['userId'] == '97dce0cc-4c40-4844-b4c4-980ff69d444c') {
          notifications.add(ResponseNotifcation.fromJson(arguments[i]));
          print("notifcatio $arguments");
        }
      }
      emit(SuccessGetNotificationsState(notifications));
      // Handle incoming message here

      // Update your UI with the received message
    });
  }

  Future<void> receiveDataFromHub() async {
    HubConnection connection = HubConnectionBuilder()
        .withUrl(
          'https://dev-api.tahliliapp.store/NotificationHub',
          options: HttpConnectionOptions(
            transport: HttpTransportType.ServerSentEvents,
          ),
        )
        .build();

    await connection.start();

    connection.onclose((error) => print('Connection closed: $error'));

    print("object");
    connection.on('ReceiveNotification', (data) {
      print('Received notification: $data');
    });
  }

  updateNotification({
    required int notificationId,
    required String title,
  }) async {
    final userId = _manager.getData(key: userID);
    emit(LoadUpdateNotificationState());
    try {
      final result = await _notificationRepository.updateNotifcation(
          notificationId: notificationId,
          userId: userId,
          title: title,
          seen: true);
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureUpdateNotificationState());
      }, (response) {
        debugPrint(response.message);
       getNotification();
        emit(SuccessUpdateNotificationState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureUpdateNotificationState());
    }
  }
}
