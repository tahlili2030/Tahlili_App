part of 'notification_cubit.dart';

@immutable
sealed class NotificationState {}

final class NotificationInitial extends NotificationState {}

class LoadGetNotificationsState extends NotificationState {}

class SuccessGetNotificationsState extends NotificationState {
  final List<ResponseNotifcation> notifications;

  SuccessGetNotificationsState(this.notifications);
}

class FailureGetNotificationsState extends NotificationState {
  final String error;

  FailureGetNotificationsState(this.error);
}

class LoadSendNotificationsState extends NotificationState {}

class SuccessSendNotificationsState extends NotificationState {
  final ResponseAPI responseAPI;

  SuccessSendNotificationsState(this.responseAPI);
}

class FailureSendNotificationsState extends NotificationState {
  final String error;

  FailureSendNotificationsState(this.error);
}

class LoadUpdateNotificationState extends NotificationState{}

class SuccessUpdateNotificationState extends NotificationState{}

class FailureUpdateNotificationState extends NotificationState{}