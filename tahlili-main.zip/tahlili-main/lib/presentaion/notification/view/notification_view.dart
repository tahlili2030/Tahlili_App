import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:signalr_flutter/signalr_api.dart';
import 'package:signalr_flutter/signalr_flutter.dart';
import 'package:signalr_netcore/signalr_client.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/presentaion/notification/cubit/notification_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

import '../../../app/pref_manager.dart';
import '../../resources/shared/appbar_divider.dart';

class NotificationView extends StatefulWidget {
  const NotificationView({super.key});

  @override
  State<NotificationView> createState() => _NotificationViewState();
}

class _NotificationViewState extends State<NotificationView> {
//   String signalRStatus = "disconnected";
//   late SignalR signalR;
//  void _onStatusChange(ConnectionStatus? status) {
//     if (mounted) {
//       setState(() {
//         signalRStatus = status?.name ?? ConnectionStatus.disconnected.name;
//       });
//       print(signalRStatus);
//     }
//   }

//   void _onNewMessage(String methodName, String message) {
//     print("MethodName = $methodName, Message = $message");
//   }
//   @override
//   void initState() {
//     super.initState();
//     initPlatformState();

//   }

//   // Platform messages are asynchronous, so we initialize in an async method.
//   Future<void> initPlatformState() async {
//     signalR = SignalR(
//       "https://uat-api.tahliliapp.store/",
//       "NotificationHub",
//       hubMethods: ["ReceiveNotification"],
//       statusChangeCallback: _onStatusChange,
//       hubCallback: _onNewMessage,
//     );
//     signalR.connect();
//   }
  // late HubConnection _tradesConnection;
  // Future<void> initTradesSignalr(Function(dynamic) callback) async {
  //   _tradesConnection = HubConnectionBuilder()
  //       .withUrl(
  //         'https://uat-api.tahliliapp.store/NotificationHub',
  //       )
  //       .build();
  //   _tradesConnection.on("ReceiveNotification", callback);
  //   print("object");
  //   await _tradesConnection.start();
  // }
  // @override
  // void initState() {
  //   // TODO: implement initState
  //   super.initState();
  //   initTradesSignalr((p0) => (value){
  //     print(value);

  //   });
  // }

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<NotificationCubit>();
    cubit.getNotification();
    cubit.notifcationHub();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          "Notifications".tr(),
          style:
              StylesManger.medium().copyWith(color: Colors.black, fontSize: 18),
        ),
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          const AppBarDivider(),
          const SizedBox(
            height: 8,
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: BlocBuilder<NotificationCubit, NotificationState>(
                builder: (context, state) {
                  return cubit.notifications.isNotEmpty
                      ? ListView.separated(
                          shrinkWrap: true,
                          itemCount: cubit.notifications.length,
                          separatorBuilder: (context, index) => const SizedBox(
                                height: 10,
                              ),
                          itemBuilder: (context, index) => InkWell(
                                onTap: () {
                                  cubit.updateNotification(
                                      notificationId:
                                          cubit.notifications[index].id!,
                                      title: context.locale.languageCode == 'ar'
                                          ? cubit.arNotifications[index]
                                          : cubit.enNotifications[index]);
                                },
                                child: Container(
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      border:
                                          Border.all(color: ColorManger.grey),
                                      borderRadius: BorderRadius.circular(10)),
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.remove_red_eye_outlined,
                                        color: cubit.notifications[index].seen!
                                            ? Colors.black
                                            : Colors.blue,
                                      ),
                                      SizedBox(
                                        width: 8.w,
                                      ),
                                      Expanded(
                                        child: Text(
                                          context.locale.languageCode == 'ar'
                                              ? cubit.arNotifications[index]
                                              : cubit.enNotifications[index],
                                          style: StylesManger.rich().copyWith(
                                              color: ColorManger.newPrimary),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ))
                      : const Center(
                          child: CircularProgressIndicator(),
                        );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
