import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:meta/meta.dart';
import 'package:tahlili/domain/repository/orders/orders.dart';
import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';

import '../../../data/network/error_handler.dart';
import '../../../data/response/orders/response_order.dart';
import '../../orders/cubit/orders_cubit.dart';
import '../../resources/constant_manger.dart';

part 'appointments_state.dart';

class AppointmentsCubit extends Cubit<AppointmentsState> {
  AppointmentsCubit(this._ordersRepository) : super(AppointmentsInitial());
  final BaseOrdersRepository _ordersRepository;

  int apptIndex = 0;
  chnageApptIndex(int value) {
    apptIndex = value;
    emit(ChnageApptIndexState());
  }

  //  List<ResponseOrder> orders = [];
  // getOrders() async {
  //   orders = [];
  //   emit(LoadGetOrdersState());
  //   try {
  //     final result = await _ordersRepository.getOrders(asc: false);

  //     result.fold((failure) async {
  //       final error = await handleServerErrors(failure.message, failure.code);
  //       debugPrint(error.message);
  //       emit(FailureGetOrderState());
  //     }, (orders) {
  //       debugPrint('orders count ${orders.length}');
  //       this.orders.addAll(orders);
  //       emit(SuccessGetOrdersState());
  //     });
  //   } catch (e) {
  //     emit(FailureGetOrderState());
  //   }
  // }

  List<ResponsiveNewApointment> orders = [];
  getOrders({required bool? now}) async {
    orders = [];
    emit(LoadGetOrdersState());
    try {
      final result =
          await _ordersRepository.getNewAppointments(asc: false, now: now);

      result.fold((failure) async {
        final error = await handleServerErrors(failure.message, failure.code);
        debugPrint(error.message);
        emit(FailureGetOrderState());
      }, (orders) {
        debugPrint('orders count ${orders.length}');
        this.orders.addAll(orders);
        emit(SuccessGetOrdersState());
      });
    } catch (e) {
      emit(FailureGetOrderState());
    }
  }

  List<ResponseOrderDetails> orderDetails = [];
  getOrderDetails({required int orderId}) async {
    orderDetails.clear();
    try {
      emit(LoadOrderDetailsState());
      final result = await _ordersRepository.getOrderDetails(orderId: orderId);
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureOrderDetailsState());
      }, (orderDetails) {
        debugPrint(orderDetails.id!.toString());
        this.orderDetails.add(orderDetails);
        emit(SuccessOrderDetailsState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureOrderDetailsState());
    }
  }

  String? reschaduledDate;
  setDate(String date) {
    reschaduledDate = date;

    emit(SetDateState());
  }

  List<ResponseLabWorkingHoursForAppt> workingHours = [];
  List<WorkingDays> hours = [];
  Future getLabWorkingHoursForAppt(
      {required int labId, required bool atHomeTiming}) async {
    workingHours.clear();
    hours.clear();

    emit(LoadGetLabWorkingHourState());
    try {
      final result = await _ordersRepository.getLabWorkingHoursForAppt(
          labId: labId, atHomeTiming: atHomeTiming);

      result.fold((failure) async {
        // final error = await handleServerErrors(failure.message, failure.code);
        debugPrint(failure.message);
        emit(FailureGetLabWorkingHourState());
      }, (workingHours) {
        debugPrint(workingHours.length.toString());
        this.workingHours.addAll(workingHours);

        for (var i = 0; i < this.workingHours.length; i++) {
          List<String> day =
              ConstantManger.splitTelda(this.workingHours[i].weekDay!.name!);

          hours.add(WorkingDays(
              day[1],
              day[0],
              generateTimeSlots(this.workingHours[i].startTime!,
                  this.workingHours[i].endTime!)));

          day.clear();
        }

        print("hours " + hours.length.toString());

        emit(SuccessGetLabWorkingHourState());
      });
    } catch (e) {
      emit(FailureGetLabWorkingHourState());
    }
  }

  List<String> generateTimeSlots(String startTime, String endTime) {
    DateTime start = DateFormat('HH:mm:ss', 'en').parse(startTime);
    DateTime end = DateFormat('HH:mm:ss', 'en').parse(endTime);

    List<String> slots = [];
    for (DateTime time = start;
        time.isBefore(end);
        time = time.add(const Duration(minutes: 60))) {
      slots.add(DateFormat('HH:mm', 'en').format(time));
    }

    return slots;
  }

  List<String> selectedHours = [];

  setSelectedHours(String day, bool isAr) {
    print(day);
    selectedHours.clear();
    if (isAr) {
      for (var element in hours) {
        if (element.arDay.contains(day)) {
          selectedHours.addAll(element.hours);
        }
      }
    } else {
      for (var element in hours) {
        if (element.enDay == day) {
          print("object");
          selectedHours.addAll(element.hours);
        }
      }
    }
    print(selectedHours);
    selectedHour = selectedHours[0];
    emit(SetSelectedHoursState());
  }

  int hourIndex = 0;
  selectHourIndex(int index) {
    hourIndex = index;
    emit(SlecetHourIndexState());
  }

  String? selectedHour;
  rescheduleOrder({
    required int orderId,
  }) async {
    if (reschaduledDate == null) {
      toast(text: "برجاء اختيار اليوم", color: Colors.red);
      return;
    }
    emit(LoadReschaduledApptState());

    try {
      final result = await _ordersRepository.rescheduleOrder(
          orderId: orderId, date: reschaduledDate!, time: "$selectedHour:00");
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureReschaduledApptState());
      }, (success) {
        debugPrint(success.message);
        emit(SuccessReschaduledApptState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureReschaduledApptState());
    }
  }
}
