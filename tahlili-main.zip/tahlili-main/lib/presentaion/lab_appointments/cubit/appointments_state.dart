part of 'appointments_cubit.dart';

@immutable
sealed class AppointmentsState {}

final class AppointmentsInitial extends AppointmentsState {}

class LoadGetOrdersState extends AppointmentsState {}

class FailureGetOrderState extends AppointmentsState {}

class SuccessGetOrdersState extends AppointmentsState {}

class ChnageApptIndexState extends AppointmentsState {}

class LoadOrderDetailsState extends AppointmentsState {}

class SuccessOrderDetailsState extends AppointmentsState {}

class FailureOrderDetailsState extends AppointmentsState {}

class SetDateState extends AppointmentsState {}

class LoadGetLabWorkingHourState extends AppointmentsState {}

class SuccessGetLabWorkingHourState extends AppointmentsState {}

class FailureGetLabWorkingHourState extends AppointmentsState {}

class SetSelectedHoursState extends AppointmentsState {}

class SlecetHourIndexState extends AppointmentsState {}

class LoadReschaduledApptState extends AppointmentsState {}

class SuccessReschaduledApptState extends AppointmentsState {}

class FailureReschaduledApptState extends AppointmentsState {}
