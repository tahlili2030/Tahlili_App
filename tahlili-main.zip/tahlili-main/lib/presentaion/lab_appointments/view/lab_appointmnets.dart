// import 'package:easy_localization/easy_localization.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:flutter_svg/flutter_svg.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:tahlili/presentaion/bnb/cubit/bnb_cubit.dart';
// import 'package:tahlili/presentaion/bnb/view/bnb_view.dart';
// import 'package:tahlili/presentaion/lab_appointments/cubit/appointments_cubit.dart';
// import 'package:tahlili/presentaion/resources/color_manger.dart';
// import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';
// import 'package:tahlili/presentaion/resources/styles_manger.dart';

// import '../../account/cubit/account_cubit.dart';
// import '../../map/cubit/map_cubit.dart';
// import '../../map/view/tracking.dart';
// import 'appointment_details_view.dart';

// class LabAppointmectsView extends StatelessWidget {
//   const LabAppointmectsView({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final cubit = context.read<AppointmentsCubit>();
//     context.read<AccountCubit>().direct = false;
//     cubit.getOrders();
//     return Scaffold(
//       backgroundColor: Colors.white,
//       // appBar: AppBar(
//       //   leading: IconButton(
//       //       onPressed: () {
//       //         context.read<BnbCubit>().setIndex(4, context);
//       //         Navigator.push(context,
//       //             MaterialPageRoute(builder: (context) => const BNBView()));
//       //       },
//       //       icon: Icon(Icons.arrow_back)),
//       //   centerTitle: true,
//       //   title: Text(
//       //     "Orders".tr(),
//       //     style: StylesManger.rich().copyWith(color: Colors.black),
//       //   ),
//       // ),
//       // backgroundColor: Colors.white,
//       body: BlocBuilder<AppointmentsCubit, AppointmentsState>(
//         builder: (context, state) {
//           return Column(
//             children: [
//               // const AppBarDivider(),
//               Expanded(
//                   child: Padding(
//                 padding:
//                     const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
//                 child: cubit.orders.isEmpty
//                     ? const Center(
//                         child: CircularProgressIndicator(),
//                       )
//                     : ListView.separated(
//                         itemBuilder: (context, index) => Container(
//                               padding: const EdgeInsets.all(16),
//                               width: double.infinity,
//                               decoration: BoxDecoration(
//                                 border: Border.all(color: ColorManger.grey),
//                                 borderRadius: BorderRadius.circular(10),
//                               ),
//                               child: Column(
//                                 children: [
//                                   Row(
//                                     children: [
//                                       SvgPicture.asset(
//                                         'assets/images/order/state.svg',
//                                         height: 18,
//                                         width: 18,
//                                       ),
//                                       const SizedBox(
//                                         width: 5,
//                                       ),
//                                       Text(
//                                         "${"OrderState".tr()}:",
//                                         style: StylesManger.medium().copyWith(
//                                             color: Colors.black,
//                                             fontSize: 13),
//                                       ),
//                                       const SizedBox(
//                                         width: 5,
//                                       ),
//                                       Text(
//                                         cubit
//                                             .orders[index].currentOrderState!,
//                                         style: StylesManger.medium().copyWith(
//                                             color: ColorManger.buttonColor,
//                                             fontSize: 13),
//                                       ),
//                                       const Spacer(),
//                                       Padding(
//                                           padding:
//                                               const EdgeInsets.only(top: 5),
//                                           child: appointmentPopUp(context,
//                                               cubit.orders[index].id!)),
//                                     ],
//                                   ),
//                                   cardDetailsItem(
//                                       svg: 'assets/images/order/id.svg',
//                                       title: "${"OrderId".tr()}:",
//                                       body: cubit.orders[index].id!.toString()),
//                                   cardDetailsItem(
//                                       svg: 'assets/images/order/date.svg',
//                                       title: "${"OrderingDate".tr()}:",
//                                       body: DateFormat('dd-MM-yyyy hh:mm')
//                                           .format(DateTime.parse(cubit
//                                               .orders[index].visitDateTime!))),
//                                   cardDetailsItem(
//                                       svg:
//                                           'assets/images/order/payment_type.svg',
//                                       title: "${"PaymentType".tr()}:",
//                                       body:
//                                           cubit.orders[index].paymentTypeName!),
//                                   cardDetailsItem(
//                                       svg: 'assets/images/order/price.svg',
//                                       title: "${"Price".tr()}:",
//                                       body:
//                                           "${cubit.orders[index].price} ${"SAR".tr()}"),
//                                 ],
//                               ),
//                             ),
//                         separatorBuilder: (context, index) => const SizedBox(
//                               height: 10,
//                             ),
//                         itemCount: cubit.orders.length),
//               ))
//             ],
//           );
//         },
//       ),
//     );
//   }

//   Widget cardDetailsItem(
//       {required String svg, required String title, required String body}) {
//     return Padding(
//       padding: const EdgeInsets.only(bottom: 8),
//       child: Row(
//         children: [
//           SvgPicture.asset(
//             svg,
//             height: 18,
//             width: 18,
//           ),
//           const SizedBox(
//             width: 5,
//           ),
//           Text(
//             title,
//             style: StylesManger.medium()
//                 .copyWith(color: Colors.black, fontSize: 13),
//           ),
//           const SizedBox(
//             width: 5,
//           ),
//           Text(
//             body,
//             style: StylesManger.medium()
//                 .copyWith(color: ColorManger.buttonColor, fontSize: 13),
//           ),
//         ],
//       ),
//     );
//   }
// }

// Widget appointmentPopUp(BuildContext context, int orderId) {
//   return Theme(
//     data: Theme.of(context).copyWith(
//         cardColor: Colors.white,
//         popupMenuTheme: const PopupMenuThemeData(
//           color: Colors.white,
//           elevation: 0,
//         )),
//     child: PopupMenuButton(
//       // padding: const EdgeInsets.only(bottom: 0),

//       // color: Colors.black,
//       position: PopupMenuPosition.under,
//       iconSize: 20,
//       icon: const Icon(
//         FontAwesomeIcons.ellipsisH,
//         color: Colors.black,
//       ),

//       itemBuilder: (context) {
//         return [
//           PopupMenuItem(
//             value: 0,
//             child: Column(
//               children: [
//                 ListTile(
//                   leading: const Icon(
//                     Icons.remove_red_eye_outlined,
//                     color: Colors.black,
//                   ),
//                   title: Text(
//                     "ViewDetails".tr(),
//                   ),
//                 ),
//                 const SizedBox(
//                   height: 5,
//                 ),
//                 Container(
//                   margin: const EdgeInsets.symmetric(horizontal: 10),
//                   height: 1,
//                   width: double.infinity,
//                   color: ColorManger.grey,
//                 )
//               ],
//             ),
//           ),
//           PopupMenuItem(
//             value: 1,
//             child: Column(
//               children: [
//                 ListTile(
//                   leading: const Icon(
//                     Icons.file_download_outlined,
//                     color: Colors.black,
//                   ),
//                   title: Text("DownloadFile".tr()),
//                 ),
//                 const SizedBox(
//                   height: 5,
//                 ),
//                 Container(
//                   margin: const EdgeInsets.symmetric(horizontal: 10),
//                   height: 1,
//                   width: double.infinity,
//                   color: ColorManger.grey,
//                 )
//               ],
//             ),
//           ),
//           PopupMenuItem(
//             value: 2,
//             child: Column(
//               children: [
//                 ListTile(
//                   leading: const Icon(
//                     Icons.map_outlined,
//                     color: Colors.black,
//                   ),
//                   title: Text("TrackOrder".tr()),
//                 ),
//                 const SizedBox(
//                   height: 5,
//                 ),
//                 Container(
//                   margin: const EdgeInsets.symmetric(horizontal: 10),
//                   height: 1,
//                   width: double.infinity,
//                   color: ColorManger.grey,
//                 )
//               ],
//             ),
//           ),
//           // PopupMenuItem(
//           //   value: 3,
//           //   child: ListTile(
//           //     leading: Icon(
//           //       Icons.delete,
//           //       color: Colors.red[900],
//           //     ),
//           //     title: Text("Delete".tr()),
//           //   ),
//           // )
//         ];
//       },
//       onSelected: (value) async {
//         switch (value) {
//           case 0:
//             Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => AppointmentDetailsView(
//                     orderId: orderId,
//                   ),
//                 ));
//             break;
//           case 1:
//             break;
//           case 2:
//             await context.read<MapCubit>().getNurseLocation(orderID: orderId);
//             Navigator.push(context,
//                 MaterialPageRoute(builder: (context) => const TrackingNurse()));
//             break;

//           // case 3:
//           //   print("2");

//           //   break;
//         }
//       },
//     ),
//   );
// }
