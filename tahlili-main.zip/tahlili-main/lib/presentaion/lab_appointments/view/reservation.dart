import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/presentaion/lab_appointments/cubit/appointments_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import '../../../data/response/orders/response_order.dart';
import '../../resources/styles_manger.dart';
import 'appointment_details_view.dart';

class Reservation extends StatelessWidget {
  const Reservation({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AppointmentsCubit>();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        actions: [
          Padding(
            padding: EdgeInsetsDirectional.only(end: 24.w),
            child: InkWell(
                onTap: () {},
                child: SvgPicture.asset("assets/images/order/filter.svg")),
          )
        ],
        title: Text(
          "مواعيدي",
          style: StylesManger.rich().copyWith(color: ColorManger.blueBlack),
        ),
      ),
      backgroundColor: ColorManger.pageColor,
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        child: BlocBuilder<AppointmentsCubit, AppointmentsState>(
          builder: (context, state) {
            return Column(
              children: [
                SizedBox(
                  height: 16.h,
                ),
                Container(
                  padding: EdgeInsets.all(4),
                  decoration: BoxDecoration(
                      border: Border.all(color: ColorManger.lightBlack),
                      color: Colors.white,
                      borderRadius:
                          BorderRadius.circular(ConstantManger.borderRadius)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      GestureDetector(
                        onTap: () {
                          if (cubit.apptIndex != 0) {
                            cubit.chnageApptIndex(0);
                            cubit.getOrders(now: true);
                          }
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              vertical: 11.h, horizontal: 8.w),
                          decoration: BoxDecoration(
                              color: cubit.apptIndex == 0
                                  ? Color(0xffEDFCFF)
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(
                                  ConstantManger.borderRadius)),
                          child: Center(
                            child: Text(
                              "المواعيد الحالية",
                              style: StylesManger.small().copyWith(
                                  color: cubit.apptIndex == 0
                                      ? ColorManger.newPrimary
                                      : ColorManger.lightGrey),
                            ),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          if (cubit.apptIndex != 1) {
                            cubit.chnageApptIndex(1);
                            cubit.getOrders(now: false);
                          }
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              vertical: 11.h, horizontal: 8.w),
                          decoration: BoxDecoration(
                              color: cubit.apptIndex == 1
                                  ? Color(0xffEDFCFF)
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(
                                  ConstantManger.borderRadius)),
                          child: Center(
                            child: Text(
                              "المواعيد القادمة",
                              style: StylesManger.small().copyWith(
                                  color: cubit.apptIndex == 1
                                      ? ColorManger.newPrimary
                                      : ColorManger.lightGrey),
                            ),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          if (cubit.apptIndex != 2) {
                            cubit.chnageApptIndex(2);
                            cubit.getOrders(now: null);
                          }
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              vertical: 11.h, horizontal: 8.w),
                          decoration: BoxDecoration(
                              color: cubit.apptIndex == 2
                                  ? Color(0xffEDFCFF)
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(
                                  ConstantManger.borderRadius)),
                          child: Center(
                            child: Text(
                              "المواعيد السابقة",
                              style: StylesManger.small().copyWith(
                                  color: cubit.apptIndex == 2
                                      ? ColorManger.newPrimary
                                      : ColorManger.lightGrey),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: 16.h,
                ),
                state is LoadGetOrdersState
                    ? Center(
                        child: CircularProgressIndicator(),
                      )
                    : cubit.orders.isNotEmpty
                        ? Expanded(
                            child: ListView.separated(
                                shrinkWrap: true,
                                itemBuilder: (context, index) => cubit
                                            .orders[index].type ==
                                        "Telemedicine"
                                    ? telemedAppt(order: cubit.orders[index])
                                    : apptItem(
                                        order: cubit.orders[index],
                                        context: context),
                                separatorBuilder: (context, index) => SizedBox(
                                      height: 16.h,
                                    ),
                                itemCount: cubit.orders.length),
                          )
                        : Column(
                            children: [
                              SizedBox(
                                height: 145.h,
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 54.w),
                                child: Column(
                                  children: [
                                    SvgPicture.asset(
                                        'assets/images/no_results.svg'),
                                    SizedBox(
                                      height: 16.h,
                                    ),
                                    Text(
                                      "لا يوجد نتائج",
                                      style: StylesManger.rich(),
                                    ),
                                    SizedBox(
                                      height: 16.h,
                                    ),
                                    Text(
                                      "لا يوجد نتائج متاحة في هذه اللحظة ، يرجي التحقق لاحقاً او حجز موعد جديد",
                                      style: StylesManger.small().copyWith(
                                          color: ColorManger.lightGrey),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 16.h,
                              ),
                              AppButton(
                                  radius: 50.r,
                                  color: ColorManger.newPrimary,
                                  name: "احجز موعدك",
                                  onPressed: () {})
                            ],
                          )
              ],
            );
          },
        ),
      ),
    );
  }

  Widget telemedAppt({required ResponsiveNewApointment order}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
      decoration: BoxDecoration(
          border: Border.all(
            color: ColorManger.lightBlack,
          ),
          borderRadius: BorderRadius.circular(ConstantManger.borderRadius),
          color: Colors.white),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 38.h,
                width: 64.w,
                decoration: BoxDecoration(
                  color: ColorManger.blueBlack,
                  borderRadius:
                      BorderRadius.circular(ConstantManger.borderRadius),
                ),
              ),
              SizedBox(
                width: 16.w,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                      padding: EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Color(0xffE6FBF3),
                        borderRadius:
                            BorderRadius.circular(ConstantManger.borderRadius),
                      ),
                      child: Row(
                        children: [
                          Text(
                            "الان",
                            style: StylesManger.extremelySmall().copyWith(
                              color: Color(0xff5DB896),
                            ),
                          ),
                          SizedBox(
                            width: 4.w,
                          ),
                          Icon(
                            Icons.watch_later_outlined,
                            size: 15,
                            color: Color(0xff5DB896),
                          ),
                        ],
                      )),
                  SizedBox(
                    height: 6.h,
                  ),
                  Text(
                    "استشارة طبية فورية",
                    style: StylesManger.small()
                        .copyWith(fontWeight: FontWeight.w700),
                  )
                ],
              ),
              const Spacer(),
              CircleAvatar(
                radius: 12.r,
                backgroundColor: Color(0xffD64045),
                child: Icon(
                  Icons.close,
                  color: Colors.white,
                ),
              )
            ],
          ),
          SizedBox(
            height: 16.h,
          ),
          Container(
            height: 1,
            width: double.infinity,
            color: ColorManger.lightGrey,
          ),
          SizedBox(
            height: 16.h,
          ),
          SizedBox(
            height: 42.h,
            child: AppButton(
                borderSide: order.currentOrderStateId == 70
                    ? ColorManger.newPrimary
                    : ColorManger.lightGrey,
                radius: 50.r,
                textSize: 12.sp,
                textColor: order.currentOrderStateId == 70
                    ? Colors.white
                    : ColorManger.newPrimary,
                color: order.currentOrderStateId == 70
                    ? ColorManger.newPrimary
                    : ColorManger.lightGrey,
                name: "دخول الاستشارة",
                onPressed: () {}),
          )
        ],
      ),
    );
  }

  Widget apptItem(
      {required ResponsiveNewApointment order, required BuildContext context}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
      decoration: BoxDecoration(
          border: Border.all(
            color: ColorManger.lightBlack,
          ),
          borderRadius: BorderRadius.circular(ConstantManger.borderRadius),
          color: Colors.white),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 38.h,
                width: 64.w,
                decoration: BoxDecoration(
                  color: ColorManger.blueBlack,
                  borderRadius:
                      BorderRadius.circular(ConstantManger.borderRadius),
                ),
              ),
              SizedBox(
                width: 16.w,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                      padding: EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Color(0xffE6FBF3),
                        borderRadius:
                            BorderRadius.circular(ConstantManger.borderRadius),
                      ),
                      child: Row(
                        children: [
                          Text(
                            "12 ساعة",
                            style: StylesManger.extremelySmall().copyWith(
                              color: Color(0xff5DB896),
                            ),
                          ),
                          SizedBox(
                            width: 4.w,
                          ),
                          Icon(
                            Icons.watch_later_outlined,
                            size: 15,
                            color: Color(0xff5DB896),
                          ),
                        ],
                      )),
                  SizedBox(
                    height: 6.h,
                  ),
                  Text(
                    "باقة تساقط الشعر",
                    style: StylesManger.small()
                        .copyWith(fontWeight: FontWeight.w700),
                  )
                ],
              ),
              const Spacer(),
              CircleAvatar(
                radius: 12.r,
                backgroundColor: Color(0xffD64045),
                child: Icon(
                  Icons.close,
                  color: Colors.white,
                ),
              )
            ],
          ),
          SizedBox(
            height: 16.h,
          ),
          Padding(
            padding: EdgeInsetsDirectional.only(end: 80.w),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    if (order.visitLocation != null)
                      apttDetails(
                          icon: Icons.location_on_outlined,
                          title: "العنوان:",
                          body: order.visitLocation),
                    apttDetails(
                        icon: Icons.location_on_outlined,
                        title: "اسم المريض:",
                        body: order.patientName),
                  ],
                ),
                SizedBox(
                  height: 16.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    apttDetails(
                        icon: Icons.location_on_outlined,
                        title: "وقت الزيارة:",
                        body: DateFormat('h:mm a')
                            .format(DateTime.parse(order.visitDateTime))),
                    apttDetails(
                        icon: Icons.location_on_outlined,
                        title: "فني سحب الدم:",
                        body: order.isMale == null
                            ? "ممرض أطفال"
                            : order.isMale
                                ? "َذكر"
                                : "انثي"),
                  ],
                ),
                SizedBox(
                  height: 16.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    apttDetails(
                        icon: Icons.location_on_outlined,
                        title: "تاريخ الحجز:",
                        body: DateFormat('EEE dd MMM, yyyy')
                            .format(DateTime.parse(order.visitDateTime))),
                    apttDetails(
                        icon: Icons.location_on_outlined,
                        title: "تاريخ الزيارة:",
                        body: DateFormat('EEE dd MMM, yyyy')
                            .format(DateTime.parse(order.visitDateTime))),
                  ],
                ),
                SizedBox(
                  height: 16.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    apttDetails(
                        icon: Icons.location_on_outlined,
                        title: "اسم المختبر:",
                        body: context.locale.languageCode == 'ar'
                            ? order.partnerNameAr
                            : order.partnerNameEn),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(
            height: 16.h,
          ),
          Container(
            height: 1,
            width: double.infinity,
            color: ColorManger.lightGrey,
          ),
          SizedBox(
            height: 16.h,
          ),
          context.read<AppointmentsCubit>().apptIndex != 2
              ? Row(
                  children: [
                    Expanded(
                      child: AppButton(
                          borderSide: Color(0xffEDFCFF),
                          radius: 50.r,
                          textSize: 12.sp,
                          textColor: ColorManger.newPrimary,
                          color: Color(0xffEDFCFF),
                          name: "عرض التفاصيل",
                          onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        AppointmentDetailsView(
                                          orderId: order.orderId,
                                        )));
                          }),
                    ),
                    SizedBox(
                      width: 16.w,
                    ),
                    Expanded(
                      child: AppButton(
                          textSize: 12.sp,
                          radius: 50.r,
                          textColor: ColorManger.newPrimary,
                          color: Colors.white,
                          name: "تتبع حالة الطلب",
                          onPressed: () {}),
                    )
                  ],
                )
              : AppButton(
                  borderSide: Color(0xffEDFCFF),
                  radius: 50.r,
                  textSize: 12.sp,
                  textColor: ColorManger.newPrimary,
                  color: Color(0xffEDFCFF),
                  name: "عرض الفاتورة",
                  onPressed: () {}),
        ],
      ),
    );
  }

  Widget apttDetails(
      {required IconData icon, required String title, required String body}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          color: ColorManger.lightGrey,
          size: 20.r,
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style:
                  StylesManger.small().copyWith(color: ColorManger.lightGrey),
            ),
            SizedBox(
              width: 70.w,
              child: Text(
                body,
                style: StylesManger.small()
                    .copyWith(color: ColorManger.newPrimary),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            )
          ],
        )
      ],
    );
  }
}
