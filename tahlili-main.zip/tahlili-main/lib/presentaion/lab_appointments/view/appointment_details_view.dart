import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/presentaion/lab_appointments/cubit/appointments_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import '../../payment/view/payment_view.dart';
import '../../resources/constant_manger.dart';
import '../../resources/shared/appbar_divider.dart';
import '../../resources/styles_manger.dart';

class AppointmentDetailsView extends StatelessWidget {
  const AppointmentDetailsView({super.key, required this.orderId});
  final int orderId;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AppointmentsCubit>();
    cubit.getOrderDetails(orderId: orderId);
    return Scaffold(
      backgroundColor: ColorManger.pageColor,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "OrderDetails".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
      ),
      body: BlocBuilder<AppointmentsCubit, AppointmentsState>(
        builder: (context, state) {
          return cubit.orderDetails.isEmpty
              ? const Center(
                  child: const CircularProgressIndicator(),
                )
              : Column(
                  children: [
                    const AppBarDivider(),
                    const SizedBox(
                      height: 16,
                    ),
                    Expanded(
                      child: SingleChildScrollView(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: Column(
                            children: [
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 16.w, vertical: 16.h),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                      color: ColorManger.lightBlack,
                                    ),
                                    borderRadius: BorderRadius.circular(
                                        ConstantManger.borderRadius),
                                    color: Colors.white),
                                child: Column(
                                  children: [
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          height: 38.h,
                                          width: 64.w,
                                          decoration: BoxDecoration(
                                            color: ColorManger.blueBlack,
                                            borderRadius: BorderRadius.circular(
                                                ConstantManger.borderRadius),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16.w,
                                        ),
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                                padding: EdgeInsets.all(4),
                                                decoration: BoxDecoration(
                                                  color: Color(0xffE6FBF3),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          ConstantManger
                                                              .borderRadius),
                                                ),
                                                child: Row(
                                                  children: [
                                                    Text(
                                                      "12 ساعة",
                                                      style: StylesManger
                                                              .extremelySmall()
                                                          .copyWith(
                                                        color:
                                                            Color(0xff5DB896),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 4.w,
                                                    ),
                                                    Icon(
                                                      Icons
                                                          .watch_later_outlined,
                                                      size: 15,
                                                      color: Color(0xff5DB896),
                                                    ),
                                                  ],
                                                )),
                                            SizedBox(
                                              height: 6.h,
                                            ),
                                            Text(
                                              "باقة تساقط الشعر",
                                              style: StylesManger.small()
                                                  .copyWith(
                                                      fontWeight:
                                                          FontWeight.w700),
                                            )
                                          ],
                                        ),
                                        const Spacer(),
                                        CircleAvatar(
                                          radius: 12.r,
                                          backgroundColor: Color(0xffD64045),
                                          child: Icon(
                                            Icons.close,
                                            color: Colors.white,
                                          ),
                                        )
                                      ],
                                    ),
                                    SizedBox(
                                      height: 16.h,
                                    ),
                                    Padding(
                                      padding:
                                          EdgeInsetsDirectional.only(end: 80.w),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              if (cubit.orderDetails.first
                                                      .address !=
                                                  null)
                                                apttDetails(
                                                    icon: Icons
                                                        .location_on_outlined,
                                                    title: "العنوان:",
                                                    body: cubit.orderDetails
                                                        .first.address!),
                                              apttDetails(
                                                  icon: Icons
                                                      .location_on_outlined,
                                                  title: "اسم المريض:",
                                                  body: cubit.orderDetails.first
                                                      .patientName!),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 16.h,
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              apttDetails(
                                                  icon: Icons
                                                      .location_on_outlined,
                                                  title: "وقت الزيارة:",
                                                  body: DateFormat('h:mm a')
                                                      .format(DateTime.parse(
                                                          cubit
                                                              .orderDetails
                                                              .first
                                                              .visitDateTime!))),
                                              apttDetails(
                                                  icon: Icons
                                                      .location_on_outlined,
                                                  title: "فني سحب الدم:",
                                                  body: cubit.orderDetails.first
                                                              .isMale ==
                                                          null
                                                      ? "ممرض أطفال"
                                                      : cubit.orderDetails.first
                                                              .isMale!
                                                          ? "َذكر"
                                                          : "انثي"),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 16.h,
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              apttDetails(
                                                  icon: Icons
                                                      .location_on_outlined,
                                                  title: "تاريخ الحجز:",
                                                  body: DateFormat(
                                                          'EEE dd MMM, yyyy')
                                                      .format(DateTime.parse(
                                                          cubit
                                                              .orderDetails
                                                              .first
                                                              .visitDateTime!))),
                                              apttDetails(
                                                  icon: Icons
                                                      .location_on_outlined,
                                                  title: "تاريخ الزيارة:",
                                                  body: DateFormat(
                                                          'EEE dd MMM, yyyy')
                                                      .format(DateTime.parse(
                                                          cubit
                                                              .orderDetails
                                                              .first
                                                              .visitDateTime!))),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 16.h,
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              apttDetails(
                                                  icon: Icons
                                                      .location_on_outlined,
                                                  title: "اسم المختبر:",
                                                  body: context.locale
                                                              .languageCode ==
                                                          'ar'
                                                      ? cubit.orderDetails.first
                                                          .partnerNameAr!
                                                      : cubit.orderDetails.first
                                                          .partnerNameEn!),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: 16.h,
                                    ),
                                    Container(
                                      height: 1,
                                      width: double.infinity,
                                      color: ColorManger.lightGrey,
                                    ),
                                    SizedBox(
                                      height: 16.h,
                                    ),
                                    Column(
                                      children: [
                                        AppButton(
                                            textSize: 12.sp,
                                            radius: ConstantManger.borderRadius,
                                            textColor: ColorManger.newPrimary,
                                            color: Colors.white,
                                            name: "تتبع حالة الطلب",
                                            onPressed: () {}),
                                        SizedBox(
                                          height: 16.h,
                                        ),
                                        AppButton(
                                            borderSide: Color(0xffEDFCFF),
                                            radius: ConstantManger.borderRadius,
                                            textSize: 12.sp,
                                            textColor: ColorManger.newPrimary,
                                            color: Color(0xffEDFCFF),
                                            name: "اعادة جدولة الحجز",
                                            onPressed: () {
                                              if (cubit.orderDetails.first
                                                      .address !=
                                                  null) {
                                                cubit
                                                    .getLabWorkingHoursForAppt(
                                                        labId: 18,
                                                        atHomeTiming: true)
                                                    .whenComplete(() {
                                                  cubit.setSelectedHours(
                                                      DateFormat('EEEE').format(
                                                          DateTime.parse(cubit
                                                              .orderDetails
                                                              .first
                                                              .visitDateTime!)),
                                                      context.locale
                                                                  .languageCode ==
                                                              'ar'
                                                          ? true
                                                          : false);
                                                });
                                              } else {
                                                cubit
                                                    .getLabWorkingHoursForAppt(
                                                        labId: cubit
                                                            .orderDetails
                                                            .first
                                                            .labId!,
                                                        atHomeTiming: false)
                                                    .whenComplete(() {
                                                  cubit.setSelectedHours(
                                                      DateFormat('EEEE').format(
                                                          DateTime.parse(cubit
                                                              .orderDetails
                                                              .first
                                                              .visitDateTime!)),
                                                      context.locale
                                                                  .languageCode ==
                                                              'ar'
                                                          ? true
                                                          : false);
                                                });
                                              }
                                              showDialog(
                                                context: context,
                                                builder: (context) =>
                                                    AlertDialog(
                                                  insetPadding: EdgeInsets.zero,
                                                  contentPadding:
                                                      EdgeInsets.zero,
                                                  clipBehavior: Clip
                                                      .antiAliasWithSaveLayer,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20),
                                                  ),
                                                  content: BlocBuilder<
                                                      AppointmentsCubit,
                                                      AppointmentsState>(
                                                    builder: (context, state) {
                                                      return Builder(
                                                          builder: (context) {
                                                        var width =
                                                            MediaQuery.of(
                                                                    context)
                                                                .size
                                                                .width;
                                                        return Container(
                                                          width: width - 16.w,
                                                          child:
                                                              SingleChildScrollView(
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(
                                                                      16.0),
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                children: [
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceBetween,
                                                                    children: [
                                                                      Text(
                                                                        "اعادة جدولة الموعد",
                                                                        style: StylesManger
                                                                            .medium(),
                                                                      ),
                                                                      GestureDetector(
                                                                        onTap:
                                                                            () {
                                                                          Navigator.pop(
                                                                              context);
                                                                        },
                                                                        child:
                                                                            CircleAvatar(
                                                                          backgroundColor:
                                                                              Color(0xffE2E6E9),
                                                                          child:
                                                                              Icon(Icons.close),
                                                                        ),
                                                                      )
                                                                    ],
                                                                  ),
                                                                  SizedBox(
                                                                    height:
                                                                        16.h,
                                                                  ),
                                                                  Text(
                                                                    "قم باختيار التاريخ و الوقت الجديد للمتابعة",
                                                                    style: StylesManger.small().copyWith(
                                                                        color: Color(
                                                                            0xffA5A5A5),
                                                                        fontSize:
                                                                            10.sp),
                                                                  ),
                                                                  SizedBox(
                                                                    height:
                                                                        16.h,
                                                                  ),
                                                                  Container(
                                                                    padding:
                                                                        EdgeInsets.all(
                                                                            16),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              ConstantManger.borderRadius),
                                                                      border:
                                                                          Border
                                                                              .all(
                                                                        color: ColorManger
                                                                            .lightBlack,
                                                                      ),
                                                                    ),
                                                                    child:
                                                                        Column(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Text(
                                                                          "تاريخ ووقت الموعد الحالي هو :${DateFormat('yyyy-MM-dd').format(DateTime.parse(cubit.orderDetails.first.visitDateTime!))}  |  03:00 م -  04:00 م ",
                                                                          style: StylesManger.small().copyWith(
                                                                              color: Color(0xffA5A5A5),
                                                                              fontSize: 10.sp),
                                                                        ),
                                                                        SizedBox(
                                                                          height:
                                                                              16.h,
                                                                        ),
                                                                        Text(
                                                                          "تاريخ الموعد",
                                                                          style:
                                                                              StylesManger.small(),
                                                                        ),
                                                                        SizedBox(
                                                                          height:
                                                                              16.h,
                                                                        ),
                                                                        GestureDetector(
                                                                          onTap:
                                                                              () async {
                                                                            final result = await showDatePicker(
                                                                                initialEntryMode: DatePickerEntryMode.calendarOnly,
                                                                                currentDate: DateTime.now().add(Duration(days: 1)),
                                                                                context: context,
                                                                                firstDate: DateTime.now().add(Duration(days: 1)),
                                                                                lastDate: DateTime.now().add(Duration(days: 365)));
                                                                            if (result !=
                                                                                null) {
                                                                              cubit.setDate(DateFormat('yyyy-MM-dd', 'en').format(result));
                                                                              cubit.setSelectedHours(DateFormat('EEEE').format(result), context.locale.languageCode == 'ar' ? true : false);
                                                                            }
                                                                          },
                                                                          child:
                                                                              Container(
                                                                            padding:
                                                                                EdgeInsets.all(16),
                                                                            decoration:
                                                                                BoxDecoration(border: Border.all(color: ColorManger.lightBlack), borderRadius: BorderRadius.circular(ConstantManger.borderRadius)),
                                                                            child:
                                                                                Row(
                                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                              children: [
                                                                                Text(
                                                                                  cubit.reschaduledDate != null
                                                                                      ? cubit.reschaduledDate!
                                                                                      : DateFormat(
                                                                                          'EEEE d MMMM yyyy',
                                                                                        ).format(DateTime.parse(cubit.orderDetails.first.visitDateTime!)),
                                                                                  style: StylesManger.extremelySmall().copyWith(color: Color(0xffA5A5A5)),
                                                                                ),
                                                                                Icon(
                                                                                  Icons.date_range,
                                                                                  size: 10.sp,
                                                                                )
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        SizedBox(
                                                                          height:
                                                                              32.h,
                                                                        ),
                                                                        SingleChildScrollView(
                                                                          scrollDirection:
                                                                              Axis.horizontal,
                                                                          child:
                                                                              Row(
                                                                            children: [
                                                                              ...List.generate(
                                                                                  cubit.selectedHours.length,
                                                                                  (index) => GestureDetector(
                                                                                        onTap: () {
                                                                                          cubit.selectHourIndex(index);
                                                                                          cubit.selectedHour = (cubit.selectedHours[index]);
                                                                                        },
                                                                                        child: Container(
                                                                                          margin: EdgeInsetsDirectional.only(end: 8.w),
                                                                                          padding: EdgeInsets.all(16),
                                                                                          decoration: BoxDecoration(color: cubit.hourIndex == index ? Color(0xffEDFCFF) : Colors.white, borderRadius: BorderRadius.circular(ConstantManger.borderRadius), border: Border.all(color: cubit.hourIndex == index ? ColorManger.newPrimary : ColorManger.lightBlack)),
                                                                                          child: Text(
                                                                                            cubit.selectedHours[index],
                                                                                            style: StylesManger.small().copyWith(color: cubit.hourIndex == index ? ColorManger.newPrimary : ColorManger.blueBlack),
                                                                                          ),
                                                                                        ),
                                                                                      ))
                                                                            ],
                                                                          ),
                                                                        )
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                    height:
                                                                        16.h,
                                                                  ),
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceBetween,
                                                                    children: [
                                                                      SizedBox(
                                                                        width:
                                                                            84.w,
                                                                        height:
                                                                            42.h,
                                                                        child: AppButton(
                                                                            textSize: 12.sp,
                                                                            textColor: ColorManger.newPrimary,
                                                                            color: Colors.white,
                                                                            name: "الغاء",
                                                                            onPressed: () {
                                                                              Navigator.pop(context);
                                                                            }),
                                                                      ),
                                                                      SizedBox(
                                                                        width:
                                                                            84.w,
                                                                        height:
                                                                            42.h,
                                                                        child: AppButton(
                                                                            textSize: 12.sp,
                                                                            textColor: Colors.white,
                                                                            color: ColorManger.newPrimary,
                                                                            name: "تأكيد",
                                                                            onPressed: () {
                                                                              cubit.rescheduleOrder(orderId: orderId);
                                                                            }),
                                                                      )
                                                                    ],
                                                                  )
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        );
                                                      });
                                                    },
                                                  ),
                                                ),
                                              );
                                            }),
                                      ],
                                    )
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 16.h,
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 16.w, vertical: 16.h),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                      color: ColorManger.lightBlack,
                                    ),
                                    borderRadius: BorderRadius.circular(
                                        ConstantManger.borderRadius),
                                    color: Colors.white),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "تفاصيل الدفع",
                                      style: StylesManger.rich(),
                                    ),
                                    SizedBox(
                                      height: 16.h,
                                    ),
                                    Container(
                                      height: 1,
                                      width: double.infinity,
                                      color: ColorManger.lightGrey,
                                    ),
                                    SizedBox(
                                      height: 16.h,
                                    ),
                                    paymentItem(
                                        title: "اجمالي الخصم",
                                        body:
                                            "${cubit.orderDetails.first.totalDiscount} ${"SAR".tr()}"),
                                    paymentItem(
                                        title: "ضريبة القيمة المضافة",
                                        body:
                                            "${cubit.orderDetails.first.vat} ${"SAR".tr()}"),
                                    paymentItem(
                                        title: "طريقة الدفع",
                                        body: cubit.orderDetails.first
                                            .paymentTypeName!),
                                    paymentItem(
                                        title: "المبلغ الاجمالي",
                                        body:
                                            "${cubit.orderDetails.first.price} ${"SAR".tr()}"),
                                    SizedBox(
                                      height: 16.h,
                                    ),
                                    Container(
                                      height: 1,
                                      width: double.infinity,
                                      color: ColorManger.lightGrey,
                                    ),
                                    SizedBox(
                                      height: 16.h,
                                    ),
                                    Column(
                                      children: [
                                        if (cubit.orderDetails.first
                                                .remainingPaymentAmount! >
                                            0)
                                          AppButton(
                                              textSize: 12.sp,
                                              radius:
                                                  ConstantManger.borderRadius,
                                              textColor: Colors.white,
                                              color: ColorManger.newPrimary,
                                              name: "ادفع الان",
                                              onPressed: () {
                                                Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (context) =>
                                                            PaymentView(
                                                              amount: (cubit
                                                                          .orderDetails
                                                                          .first
                                                                          .remainingPaymentAmount! *
                                                                      100)
                                                                  .toInt(),
                                                              description:
                                                                  "Q${cubit.orderDetails.first.partnerId}",
                                                              fromTele: false,
                                                            )));
                                              }),
                                        if (cubit.orderDetails.first
                                                .remainingPaymentAmount! >
                                            0)
                                          SizedBox(
                                            height: 16.h,
                                          ),
                                        AppButton(
                                            borderSide: Color(0xffEDFCFF),
                                            radius: ConstantManger.borderRadius,
                                            textSize: 12.sp,
                                            textColor: ColorManger.newPrimary,
                                            color: Color(0xffEDFCFF),
                                            name: "قيم الخدمة",
                                            onPressed: () {}),
                                      ],
                                    )
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 16.h,
                              )
                            ],
                          ),
                        ),
                      ),
                    )
                  ],
                );
        },
      ),
    );
  }

  Widget paymentItem({required String title, required String body}) {
    return Padding(
      padding: EdgeInsets.only(bottom: 16.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: StylesManger.small().copyWith(color: ColorManger.blueBlack),
          ),
          Text(
            body,
            style: StylesManger.small().copyWith(color: ColorManger.lightGrey),
          ),
        ],
      ),
    );
  }

  Padding apptSummryItem({required String title, required String body}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: StylesManger.rich().copyWith(color: Colors.black),
          ),
          Text(
            body,
            style: StylesManger.medium()
                .copyWith(fontSize: 14, color: ColorManger.buttonColor),
          )
        ],
      ),
    );
  }

  Widget cardDetailsItem(
      {required String svg, required String title, required String body}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          SvgPicture.asset(
            svg,
            height: 18,
            width: 18,
          ),
          const SizedBox(
            width: 5,
          ),
          Text(
            title,
            style: StylesManger.medium()
                .copyWith(color: Colors.black, fontSize: 13),
          ),
          const SizedBox(
            width: 5,
          ),
          Text(
            body,
            style: StylesManger.medium()
                .copyWith(color: ColorManger.buttonColor, fontSize: 13),
          ),
        ],
      ),
    );
  }

  Widget apttDetails(
      {required IconData icon, required String title, required String body}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          color: ColorManger.lightGrey,
          size: 20.r,
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style:
                  StylesManger.small().copyWith(color: ColorManger.lightGrey),
            ),
            SizedBox(
              width: 70.w,
              child: Text(
                body,
                style: StylesManger.small()
                    .copyWith(color: ColorManger.newPrimary),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            )
          ],
        )
      ],
    );
  }
}
