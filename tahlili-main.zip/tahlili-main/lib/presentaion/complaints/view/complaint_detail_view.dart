import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';

import '../../prescriptions/view/prescriptions_view.dart';
import '../../resources/color_manger.dart';
import '../../resources/styles_manger.dart';

class ComplaintDetailView extends StatelessWidget {
  const ComplaintDetailView(
      {super.key, required this.complaintId, required this.image});
  final int complaintId;
  final String? image;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AccountCubit>();
    cubit.getComplaintDetails(id: complaintId);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          "ComplaintDetails".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
      ),
      backgroundColor: Colors.white,
      body: BlocBuilder<AccountCubit, AccountState>(
        builder: (context, state) {
          return Column(
            children: [
              const AppBarDivider(),
              const SizedBox(
                height: 16,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  width: double.infinity,
                  decoration: BoxDecoration(
                      border: Border.all(color: ColorManger.grey),
                      borderRadius: BorderRadius.circular(5)),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            if (cubit.complaintDetails.isNotEmpty)
                              Text(
                                cubit.complaintDetails.first.complaintsType!
                                    .name!,
                                style: StylesManger.rich()
                                    .copyWith(color: Colors.black),
                              ),
                            Theme(
                              data: Theme.of(context).copyWith(
                                  cardColor: Colors.white,
                                  popupMenuTheme: const PopupMenuThemeData(
                                    color: Colors.white,
                                    elevation: 0,
                                  )),
                              child: PopupMenuButton(
                                padding: const EdgeInsets.only(bottom: 20),

                                // color: Colors.black,
                                position: PopupMenuPosition.under,
                                iconSize: 30,
                                icon: const Icon(
                                  FontAwesomeIcons.ellipsisH,
                                  color: Colors.black,
                                ),

                                itemBuilder: (context) {
                                  return [
                                    PopupMenuItem(
                                      value: 0,
                                      child: Column(
                                        children: [
                                          ListTile(
                                            leading: const Icon(
                                              Icons.remove_red_eye_outlined,
                                              color: Colors.black,
                                            ),
                                            title: Text(
                                              "View".tr(),
                                            ),
                                          ),
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          Container(
                                            margin: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            height: 1,
                                            width: double.infinity,
                                            color: ColorManger.grey,
                                          )
                                        ],
                                      ),
                                    ),
                                    PopupMenuItem(
                                      value: 1,
                                      child: ListTile(
                                        leading: Icon(
                                          Icons.delete,
                                          color: Colors.red[900],
                                        ),
                                        title: Text("Delete".tr()),
                                      ),
                                    )
                                  ];
                                },
                                onSelected: (value) async {
                                  switch (value) {
                                    case 0:
                                      // Navigator.push(
                                      //     context,
                                      //     MaterialPageRoute(
                                      //       builder: (context) => OrderDetailsView(
                                      //        order: cubit.orders[index],
                                      //       ),
                                      //     ));
                                      break;

                                    case 1:
                                      print("2");
                                      // await  context.read<MapCubit>().getNurseLocation(orderID: cubit.orders[index].id!);
                                      // Navigator.push(context, MaterialPageRoute(builder: (context)=>TrackingNurse()));
                                      break;
                                  }
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            if (cubit.complaintDetails.isNotEmpty)
                              SizedBox(
                                width: 250,
                                child: Text(
                                  cubit.complaintDetails.first.description!,
                                  style: StylesManger.rich()
                                      .copyWith(color: Colors.black),
                                ),
                              ),
                            if (cubit.complaintDetails.isNotEmpty)
                              Text(
                                DateFormat('dd-MM-yyyy').format(DateTime.parse(
                                    cubit
                                        .complaintDetails.first.creationTime!)),
                                style: StylesManger.medium()
                                    .copyWith(color: Colors.black),
                              )
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      if (image != null)
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => FullScreenImage(
                                        imageUrl:
                                            EndPoints.baseImageUrl + image!)));
                          },
                          child: Container(
                            margin: const EdgeInsets.symmetric(horizontal: 16),
                            height: 200,
                            width: double.infinity,
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    fit: BoxFit.fill,
                                    image: CachedNetworkImageProvider(
                                        EndPoints.baseImageUrl + image!)),
                                borderRadius: BorderRadius.circular(10.r)),
                          ),
                        ),
                      const SizedBox(
                        height: 23,
                      ),
                      Container(
                        height: 1,
                        width: double.infinity,
                        color: ColorManger.grey,
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Row(
                          children: [
                            SvgPicture.asset('assets/images/reply.svg'),
                            const SizedBox(
                              width: 10,
                            ),
                            if (cubit.complaintDetails.isNotEmpty)
                              cubit.complaintDetails.first.reply != null
                                  ? Expanded(
                                      child: Text(
                                          cubit.complaintDetails.first.reply!))
                                  : Text(
                                      "No reply yet",
                                      style: StylesManger.medium()
                                          .copyWith(color: ColorManger.grey),
                                    )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
