import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/data/requests/accounts/request_account.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/auth/cubit/auth_cubit.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/shared/app_drop_down.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';
import 'package:tahlili/presentaion/resources/strings_manager.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';
import 'package:tahlili/presentaion/resources/validation_manager.dart';

import '../../prescriptions/view/prescriptions_view.dart';
import '../../resources/color_manger.dart';
import '../../resources/shared/shared_widgets.dart';
import 'complaint_detail_view.dart';

class ComplaintsView extends StatelessWidget {
  const ComplaintsView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AccountCubit>();
    final authCubit = context.read<AuthCubit>();
    authCubit.getComplaintsTypes();
    cubit.getComplaints();
    // cubit.getUserEntityID();
    // print(cubit.userModel!.entityId!.toString());

    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          centerTitle: true,
          title: Text(
            "Complaints".tr(),
            style: StylesManger.rich().copyWith(color: Colors.black),
          ),
        ),
        backgroundColor: Colors.white,
        body: BlocBuilder<AccountCubit, AccountState>(
          builder: (context, state) {
            return Column(
              children: [
                const AppBarDivider(),
                const SizedBox(
                  height: 16,
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 24),
                        child: cubit.complaints.isNotEmpty
                            ? Column(
                                children: [
                                  ...List.generate(
                                      cubit.complaints.length,
                                      (index) => Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 16),
                                            child: ComplaintsItem(
                                                state: "جديد",
                                                image: cubit.complaints[index]
                                                            .results !=
                                                        null
                                                    ? cubit.complaints[index]
                                                        .results!.first
                                                    : null,
                                                complaintId:
                                                    cubit.complaints[index].id!,
                                                complaintType: cubit
                                                    .complaints[index]
                                                    .complaintsType!
                                                    .name!,
                                                complaintNo:
                                                    cubit.complaints[index].id!,
                                                complaintNote: cubit
                                                    .complaints[index]
                                                    .description!,
                                                date: DateFormat('dd-MM-yyyy')
                                                    .format(DateTime.parse(cubit
                                                        .complaints[index]
                                                        .creationTime!))),
                                          ))
                                ],
                              )
                            : noData()),
                  ),
                ),
              ],
            );
          },
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        floatingActionButton: GestureDetector(
          onTap: () {
            showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                builder: (context) => Padding(
                      padding: EdgeInsets.only(
                          bottom: MediaQuery.of(context).viewInsets.bottom),
                      child: BlocBuilder<AccountCubit, AccountState>(
                        builder: (context, state) {
                          return Container(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 16),
                              width: double.infinity,
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(20),
                                      topRight: Radius.circular(20))),
                              child: Form(
                                key: cubit.complaintForm,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const SizedBox(
                                      height: 16,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 10.0),
                                      child: Container(
                                        width: 40,
                                        height: 5,
                                        decoration: BoxDecoration(
                                          color: Colors.grey[400],
                                          borderRadius:
                                              BorderRadius.circular(10),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 16,
                                    ),
                                    Text(
                                      "Identity Information".tr(),
                                      style: StylesManger.rich()
                                          .copyWith(color: Colors.black),
                                    ),
                                    const SizedBox(
                                      height: 24,
                                    ),
                                    Text(
                                      "النوع",
                                      style: StylesManger.medium()
                                          .copyWith(color: Colors.black),
                                    ),
                                    SizedBox(
                                      height: 8.h,
                                    ),
                                    BlocBuilder<AuthCubit, AuthState>(
                                      builder: (context, state) {
                                        return AppDropdown(
                                            prfoileImage: [],
                                            buttonDecoration: BoxDecoration(
                                                border: Border.all(
                                                    color: ColorManger.grey),
                                                borderRadius:
                                                    BorderRadius.circular(10)),
                                            value: authCubit.complaint,
                                            hintText: "Complaints".tr(),
                                            list: authCubit.complaints,
                                            onChange: (value) {
                                              authCubit.setComplaint(value);
                                            });
                                      },
                                    ),
                                    const SizedBox(
                                      height: 32,
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "ارفاق ملف",
                                          style: StylesManger.medium()
                                              .copyWith(color: Colors.black),
                                        ),
                                        const SizedBox(
                                          height: 8,
                                        ),
                                        InkWell(
                                          onTap: () async {
                                            cubit
                                                .pickImage(ImageSource.gallery);
                                            //   XFile? file = await ImagePicker()
                                            //       .pickImage(
                                            //           source: ImageSource.gallery);
                                            //   if (file != null) {
                                            //     // Convert XFile to File

                                            // cubit.   image = File(file.path);
                                            //   }
                                          },
                                          child: Container(
                                            padding: const EdgeInsets.all(6),
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                border: Border.all(
                                                    color: ColorManger.grey)),
                                            child: Row(
                                              children: [
                                                Container(
                                                  height: 40,
                                                  width: 85,
                                                  decoration:
                                                      const BoxDecoration(
                                                    color: Color(0xffDFE0E2),
                                                  ),
                                                  child: Center(
                                                    child: Text(
                                                      "AttachFiles".tr(),
                                                      style:
                                                          StylesManger.medium()
                                                              .copyWith(
                                                                  color: Colors
                                                                      .black),
                                                    ),
                                                  ),
                                                ),
                                                const SizedBox(
                                                  width: 5,
                                                ),
                                                Text(
                                                  cubit.image != null
                                                      ? "A file has been attached"
                                                          .tr()
                                                      : "No file attached".tr(),
                                                  style: StylesManger.medium()
                                                      .copyWith(
                                                          color: Colors.black),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 32,
                                    ),
                                    authForm(
                                        maxLines: 3,
                                        hintText: "Notes".tr(),
                                        title: "Notes".tr(),
                                        controller: cubit.complaintController,
                                        validator: (value) {
                                          if (value != null &&
                                              value.isNotEmpty) {
                                            if (!ValidationManager
                                                .lengthValidation(
                                                    text: value, length: 10)) {
                                              return StringsManager.nameValid;
                                            }
                                          } else {
                                            return StringsManager.fieldRequierd;
                                          }
                                          return null;
                                        }),
                                    const SizedBox(
                                      height: 24,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        SizedBox(
                                          width: 180,
                                          child: AppButton(
                                              radius:
                                                  ConstantManger.borderRadius,
                                              color: ColorManger.newPrimary,
                                              name: "Submit".tr(),
                                              onPressed: () {
                                                if (cubit
                                                    .complaintForm.currentState!
                                                    .validate()) {
                                                  if (authCubit.complaintID !=
                                                      null) {
                                                    cubit.addComplaints(
                                                        context: context,
                                                        complaints: RequestComplaints(
                                                            cubit.patient.first
                                                                .id!,
                                                            authCubit
                                                                .complaintID!,
                                                            cubit
                                                                .complaintController
                                                                .text));
                                                  } else {
                                                    toast(
                                                        text: "pleaseComplaint"
                                                            .tr(),
                                                        color: Colors.red);
                                                  }
                                                }
                                              }),
                                        ),
                                        SizedBox(
                                          width: 180,
                                          child: AppButton(
                                              borderSide: Color(0xff6b757d),
                                              radius:
                                                  ConstantManger.borderRadius,
                                              textColor: Colors.white,
                                              color: Color(0xff6b757d),
                                              name: "Cancel".tr(),
                                              onPressed: () {
                                                Navigator.pop(context);
                                              }),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 30,
                                    )
                                  ],
                                ),
                              ));
                        },
                      ),
                    ));
          },
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 30, vertical: 40),
            height: 48.h,
            width: double.infinity,
            decoration: BoxDecoration(
                color: ColorManger.newPrimary,
                borderRadius:
                    BorderRadius.circular(ConstantManger.borderRadius)),
            child: Center(
              child: Text(
                "UploadComplaints".tr(),
                style: StylesManger.rich()
                    .copyWith(color: Colors.white, fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ));
  }

  Column noData() {
    return Column(
      children: [
        SizedBox(
          height: 165.h,
        ),
        SvgPicture.asset('assets/images/no_complaints.svg'),
        const SizedBox(
          height: 16,
        ),
        Text(
          "NoComplaintsToDisplay".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
      ],
    );
  }
}

class ComplaintsItem extends StatelessWidget {
  final String complaintType;
  final int complaintNo;
  final String complaintNote;
  final String date;
  final int complaintId;
  final String? image;
  final String state;
  const ComplaintsItem({
    super.key,
    required this.complaintType,
    required this.complaintNo,
    required this.complaintNote,
    required this.date,
    required this.complaintId,
    required this.image,
    required this.state,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      width: double.infinity,
      decoration: BoxDecoration(
          border: Border.all(color: ColorManger.grey),
          borderRadius: BorderRadius.circular(5)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          complaintDetailsItem(
              title: "رقم الموعد", body: complaintNo.toString()),
          SizedBox(
            height: 8.h,
          ),
          complaintDetailsItem(title: "لنوع", body: complaintType),
          SizedBox(
            height: 8.h,
          ),
          complaintDetailsItem(title: "تاريخ الارسال", body: date),
          SizedBox(
            height: 8.h,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "الحاله",
                style: StylesManger.rich().copyWith(color: Color(0xff424242)),
              ),
              Container(
                padding: EdgeInsets.all(4),
                decoration: BoxDecoration(
                    color: Color(0xff0d6dfc),
                    borderRadius: BorderRadius.circular(15)),
                child: Center(
                  child: Text(
                    state,
                    style: StylesManger.medium().copyWith(color: Colors.white),
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            height: 8.h,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "العمليات",
                style: StylesManger.rich().copyWith(color: Color(0xff424242)),
              ),
              GestureDetector(
                onTap: () {
                  showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                            actionsPadding: EdgeInsets.symmetric(
                                horizontal: 16.w, vertical: 8.h),
                            actions: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "تفاصيل الشكوي",
                                        style: StylesManger.rich()
                                            .copyWith(color: Color(0xff424242)),
                                      ),
                                      GestureDetector(
                                        onTap: () {
                                          Navigator.pop(context);
                                        },
                                        child: Icon(
                                          Icons.close,
                                          color: ColorManger.grey,
                                        ),
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    height: 8.h,
                                  ),
                                  Text(
                                    "الوصف",
                                    style: StylesManger.medium()
                                        .copyWith(color: Color(0xff424242)),
                                  ),
                                  Container(
                                    height: 250.h,
                                    padding: EdgeInsets.all(16),
                                    decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(20.r),
                                        border: Border.all(
                                            color: ColorManger.lightBlack)),
                                    child: Text(
                                      "ddddddddddddddddddddddddddddddddd",
                                      style: StylesManger.medium()
                                          .copyWith(color: Colors.black),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 8.h,
                                  ),
                                  Text(
                                    "المحادثه",
                                    style: StylesManger.medium()
                                        .copyWith(color: Color(0xff424242)),
                                  ),
                                  Container(
                                    padding: EdgeInsets.all(16),
                                    decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(20.r),
                                        border: Border.all(
                                            color: ColorManger.lightBlack)),
                                    child: Text(
                                      "ddddddddddddddddddddddddddddddddd",
                                      style: StylesManger.medium()
                                          .copyWith(color: Colors.red),
                                    ),
                                  )
                                ],
                              )
                            ],
                          ));
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) => ComplaintDetailView(
                  //             complaintId: complaintId, image: image)));
                },
                child: Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 20.w, vertical: 8.h),
                  decoration: BoxDecoration(
                      color: Color(0xff0ccaf0),
                      borderRadius: BorderRadius.circular(10)),
                  child: Center(
                      child: Icon(
                    Icons.info,
                    color: Colors.white,
                  )),
                ),
              ),
              GestureDetector(
                onTap: () {
                  showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                            actionsPadding: EdgeInsets.symmetric(
                                horizontal: 16.w, vertical: 8.h),
                            actions: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                // mainAxisSize: MainAxisSize.min,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "الملفات التي تم تحميلها",
                                        style: StylesManger.rich()
                                            .copyWith(color: Color(0xff424242)),
                                      ),
                                      GestureDetector(
                                        onTap: () {
                                          Navigator.pop(context);
                                        },
                                        child: Icon(
                                          Icons.close,
                                          color: ColorManger.grey,
                                        ),
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    height: 8.h,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(
                                        margin: const EdgeInsets.symmetric(
                                            horizontal: 16),
                                        height: 50,
                                        width: 150.w,
                                        decoration: BoxDecoration(
                                            image: DecorationImage(
                                                fit: BoxFit.fill,
                                                image:
                                                    CachedNetworkImageProvider(
                                                        EndPoints.baseImageUrl +
                                                            image!)),
                                            borderRadius:
                                                BorderRadius.circular(10.r)),
                                      ),
                                      GestureDetector(
                                        onTap: () {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      FullScreenImage(
                                                          imageUrl: EndPoints
                                                                  .baseImageUrl +
                                                              image!)));
                                        },
                                        child: Container(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 20.w, vertical: 8.h),
                                          decoration: BoxDecoration(
                                              color: Color(0xff0d6dfc),
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                          child: Center(
                                              child: Icon(
                                            Icons.remove_red_eye,
                                            color: Colors.white,
                                          )),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              )
                            ],
                          ));
                },
                child: Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 20.w, vertical: 8.h),
                  decoration: BoxDecoration(
                      color: Color(0xff14875f),
                      borderRadius: BorderRadius.circular(10)),
                  child: Center(
                      child: Icon(
                    Icons.photo_library_sharp,
                    color: Colors.white,
                  )),
                ),
              )
            ],
          ),
        ],
      ),
    );
  }

  Row complaintDetailsItem({
    required String title,
    required String body,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: StylesManger.rich().copyWith(color: Color(0xff424242)),
        ),
        Text(
          body,
          style: StylesManger.medium().copyWith(color: Color(0xff424242)),
        )
      ],
    );
  }
}
