import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:tahlili/presentaion/home/cubit/home_cubit.dart';
import 'package:tahlili/presentaion/home/view/widgest/new_home_widget.dart';
import 'package:tahlili/presentaion/resources/shared/app_drop_down.dart';

import '../../../app/end_points.dart';
import '../../../data/requests/order/request_order.dart';
import '../../../data/requests/wishlist/request_wishlist.dart';
import '../../account/cubit/account_cubit.dart';
import '../../resources/color_manger.dart';
import '../../resources/shared/appbar_divider.dart';
import '../../resources/shared/quick_order_dialog.dart';
import '../../resources/shared/view_details.dart';
import '../../resources/styles_manger.dart';
import '../../wishlist/cubit/wishlist_cubit.dart';
import '../view/widgest/home_item.dart';
import 'compare_view.dart';

class SearchView extends StatelessWidget {
  const SearchView({super.key});

  final String photo =
      'https://img.freepik.com/free-vector/science-logo-template-design_23-2150369141.jpg?size=338&ext=jpg&ga=GA1.1.1413502914.1701561600&semt=ais';
  @override
  Widget build(BuildContext context) {
    final cubit = context.read<HomeCubit>();

    cubit.search.clear();

    return BlocBuilder<HomeCubit, HomeState>(
      builder: (context, state) {
        return Scaffold(
          backgroundColor: ColorManger.pageColor,
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsetsDirectional.only(end: 23),
                child: Row(
                  children: [
                    IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                          cubit.clearSearch();
                        },
                        icon: const Icon(
                          Icons.arrow_back,
                          color: Colors.black,
                        )),
                    const SizedBox(
                      width: 12,
                    ),
                    Expanded(
                      child: TextFormField(
                        cursorColor: ColorManger.primary,
                        onFieldSubmitted: (value) {
                          cubit.getHomeSearch();
                        },
                        controller: cubit.searchController,
                        decoration: InputDecoration(
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide:
                                    BorderSide(color: ColorManger.buttonColor)),
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide:
                                    BorderSide(color: ColorManger.grey)),
                            contentPadding: EdgeInsets.zero,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide:
                                    BorderSide(color: ColorManger.grey)),
                            prefixIcon: IconButton(
                                onPressed: () {
                                  cubit.getHomeSearch();
                                },
                                icon: Icon(
                                  Icons.search,
                                  color: ColorManger.grey,
                                )),
                            hintText: "Search".tr(),
                            hintStyle: StylesManger.medium()
                                .copyWith(color: ColorManger.lightGrey)),
                      ),
                    )
                  ],
                ),
              ),
              const SizedBox(
                height: 16,
              ),
              const AppBarDivider(),
              const SizedBox(
                height: 16,
              ),
              Container(
                height: 50,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                margin: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: ColorManger.grey)),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SvgPicture.asset('assets/images/sort.svg'),
                    SizedBox(
                      width: 200,
                      child: AppDropdown(
                          prfoileImage: [],
                          value: cubit.filterValue,
                          hintText: "Sort By",
                          list: cubit.filterSort,
                          onChange: (value) {
                            cubit.setFilterValue(value);
                          }),
                    )
                  ],
                ),
              ),
              Expanded(
                child: state is LoadGetHomeSearchState
                    ? Center(
                        child: CircularProgressIndicator(),
                      )
                    : Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 5, horizontal: 12),
                        child: GridView.builder(
                            shrinkWrap: true,
                            itemCount: cubit.search.length,
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 2,
                                    childAspectRatio: .65,
                                    crossAxisSpacing: 10,
                                    mainAxisSpacing: 10),
                            itemBuilder: (context, index) => HomeNewCard(
                                image: cubit.search[index].imageAR != null
                                    ? context.locale.languageCode == 'ar'
                                        ? cubit.search[index].imageAR!
                                        : cubit.search[index].imageEN!
                                    : cubit.search[index].image!,
                                testId:
                                    cubit.search[index].itemType != "Package"
                                        ? cubit.search[index].itemId!
                                        : null,
                                partnerId: cubit.search[index].partnerId!,
                                labImage: cubit.search[index].partnerImage!,
                                labName: context.locale.languageCode == 'ar'
                                    ? cubit.search[index].partnerNameAr!
                                    : cubit.search[index].partnerNameEn!,
                                packageName: context.locale.languageCode == 'ar'
                                    ? cubit.search[index].nameAr!
                                    : cubit.search[index].nameEn!,
                                description: "description",
                                price: cubit.search[index].price!,
                                discount:
                                    cubit.search[index].priceBeforeDiscount,
                                packageId:
                                    cubit.search[index].itemType == "Package"
                                        ? cubit.search[index].itemId!
                                        : null)),
                      ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget searchPopUp(BuildContext context, int searchId, int partnerId) {
    return Theme(
      data: Theme.of(context).copyWith(
          cardColor: Colors.white,
          popupMenuTheme: const PopupMenuThemeData(
            color: Colors.white,
            elevation: 0,
          )),
      child: PopupMenuButton(
        padding: const EdgeInsets.only(bottom: 20),

        // color: Colors.black,
        position: PopupMenuPosition.under,
        iconSize: 30,
        icon: const Icon(
          FontAwesomeIcons.ellipsisH,
          color: Colors.black,
        ),

        itemBuilder: (context) {
          return [
            PopupMenuItem(
              value: 0,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.remove_red_eye_outlined,
                      color: Colors.black,
                    ),
                    title: Text(
                      "ViewDetails".tr(),
                    ),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 1,
                    width: double.infinity,
                    color: ColorManger.grey,
                  )
                ],
              ),
            ),
            PopupMenuItem(
              value: 1,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.compare_arrows_rounded,
                      color: Colors.black,
                    ),
                    title: Text("Compare".tr()),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 1,
                    width: double.infinity,
                    color: ColorManger.grey,
                  )
                ],
              ),
            ),
            PopupMenuItem(
              value: 2,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.favorite_border,
                      color: Colors.black,
                    ),
                    title: Text("Add to WishList".tr()),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 1,
                    width: double.infinity,
                    color: ColorManger.grey,
                  )
                ],
              ),
            ),
          ];
        },
        onSelected: (value) async {
          switch (value) {
            case 0:
              context
                  .read<HomeCubit>()
                  .getShownDealsDetails(itemId: searchId)
                  .whenComplete(() => showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                            actionsPadding: EdgeInsets.zero,
                            actions: [
                              ViewDetailsWidget(
                                  fromCart: false,
                                  deals: context
                                      .read<HomeCubit>()
                                      .dealsDetails
                                      .first)
                            ],
                          )));

              break;
            case 1:
              context
                  .read<HomeCubit>()
                  .itemsCompare(itemId: searchId, itemType: 4)
                  .whenComplete(() => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const CompareView())));

              break;

            case 2:
              context.read<WishlistCubit>().addToWishlit(
                      wishlist: RequestWishlist(
                    context.read<AccountCubit>().userModel!.entityId!,
                    searchId,
                    null,
                  ));
              break;
          }
        },
      ),
    );
  }
}
