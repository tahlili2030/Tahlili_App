import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:tahlili/presentaion/home/cubit/home_cubit.dart';
import '../../../app/end_points.dart';
import '../../../data/requests/order/request_order.dart';
import '../../../data/requests/wishlist/request_wishlist.dart';
import '../../account/cubit/account_cubit.dart';
import '../../resources/color_manger.dart';
import '../../resources/shared/appbar_divider.dart';
import '../../resources/shared/quick_order_dialog.dart';
import '../../resources/shared/view_details.dart';
import '../../resources/shared/view_details_test.dart';
import '../../resources/styles_manger.dart';
import '../../wishlist/cubit/wishlist_cubit.dart';
import 'compare_view.dart';

class GeneticsView extends StatelessWidget {
  const GeneticsView({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<HomeCubit>();

    return BlocBuilder<HomeCubit, HomeState>(
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            centerTitle: true,
            title: Text(
              'GeneticTests'.tr(),
              style: StylesManger.rich().copyWith(color: Colors.black),
            ),
          ),
          backgroundColor: Colors.white,
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const AppBarDivider(),
              const SizedBox(
                height: 16,
              ),
              Expanded(
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 5, horizontal: 12),
                  child: GridView.builder(
                      shrinkWrap: true,
                      itemCount: cubit.genetics.length,
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              childAspectRatio: .65,
                              crossAxisSpacing: 10,
                              mainAxisSpacing: 10),
                      itemBuilder: (context, index) => Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15),
                                border: Border.all(color: Colors.grey)),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  height: 130,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Stack(
                                    children: [
                                      Container(
                                        height: 130,
                                        decoration: BoxDecoration(
                                            image: DecorationImage(
                                                fit: BoxFit.fill,
                                                image: cubit.genetics[index]
                                                            .image !=
                                                        null
                                                    ? CachedNetworkImageProvider(context
                                                                .locale
                                                                .languageCode ==
                                                            'ar'
                                                        ? (EndPoints
                                                                .baseImageUrl +
                                                            cubit
                                                                .genetics[index]
                                                                .image!)
                                                        : EndPoints
                                                                .baseImageUrl +
                                                            (cubit
                                                                .genetics[index]
                                                                .image!))
                                                    : const CachedNetworkImageProvider(
                                                        'https://t3.ftcdn.net/jpg/04/34/72/82/360_F_434728286_OWQQvAFoXZLdGHlObozsolNeuSxhpr84.jpg'))),
                                      ),
                                      PositionedDirectional(
                                          top: -0,
                                          end: 5,
                                          child: categoryPopUp(
                                              context,
                                              cubit.genetics[index]
                                                  .partnerItemId!,
                                              cubit.genetics[index].partnerId!))
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Expanded(
                                  child: Text(
                                    context.locale.languageCode == 'ar'
                                        ? cubit.genetics[index].nameAr!
                                        : cubit.genetics[index].nameEn!,
                                    style: StylesManger.medium()
                                        .copyWith(fontSize: 10),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                Row(
                                  children: [
                                    if (cubit.genetics[index]
                                            .priceBeforeDiscount !=
                                        null)
                                      Text(
                                        '${cubit.genetics[index].priceBeforeDiscount} ${"SAR".tr()}',
                                        style: StylesManger.medium().copyWith(
                                            color: ColorManger.grey,
                                            decoration:
                                                TextDecoration.lineThrough),
                                      ),
                                    const SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      '${cubit.genetics[index].price} ${"SAR".tr()}',
                                      style: StylesManger.medium().copyWith(
                                        color: ColorManger.primary,
                                      ),
                                    )
                                  ],
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  context.locale.languageCode == 'ar'
                                      ? cubit.genetics[index].partnerNameAr!
                                      : cubit.genetics[index].partnerNameEn!,
                                  style: StylesManger.medium(),
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  children: [
                                    ...List.generate(
                                      cubit
                                          .genetics[index].certificates!.length,
                                      (cindex) => Container(
                                        margin:
                                            const EdgeInsetsDirectional.only(
                                                end: 5),
                                        height: 25,
                                        width: 25,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(100),
                                            image: DecorationImage(
                                                image: NetworkImage(EndPoints
                                                        .baseImageUrl +
                                                    cubit
                                                        .genetics[index]
                                                        .certificates![cindex]
                                                        .image!))),
                                      ),
                                    )
                                  ],
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    SizedBox(
                                        width: 160,
                                        height: 30,
                                        child: ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                minimumSize: const Size(
                                                    double.infinity, 60),
                                                backgroundColor:
                                                    ColorManger.primary,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                )),
                                            onPressed: () {
                                              showDialog(
                                                  context: context,
                                                  builder: (context) =>
                                                      QuickOrderDialog(
                                                        orderData:
                                                            RequestOrderData(
                                                                cubit
                                                                    .genetics[
                                                                        index]
                                                                    .partnerId!,
                                                                cubit
                                                                    .genetics[
                                                                        index]
                                                                    .nameEn!,
                                                                cubit
                                                                    .genetics[
                                                                        index]
                                                                    .price!,
                                                                cubit
                                                                    .genetics[
                                                                        index]
                                                                    .itemId!,
                                                                false),
                                                      ));
                                            },
                                            child: Center(
                                              child: Text(
                                                "OrderNow".tr(),
                                                style: StylesManger.rich()
                                                    .copyWith(
                                                        color: Colors.white,
                                                        fontSize: 10),
                                              ),
                                            ))),
                                  ],
                                )
                              ],
                            ),
                          )),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget categoryPopUp(BuildContext context, int itemId, int partnerId) {
    return Theme(
      data: Theme.of(context).copyWith(
          cardColor: Colors.white,
          popupMenuTheme: const PopupMenuThemeData(
            color: Colors.white,
            elevation: 0,
          )),
      child: PopupMenuButton(
        padding: const EdgeInsets.only(bottom: 20),

        // color: Colors.black,
        position: PopupMenuPosition.under,
        iconSize: 30,
        icon: const Icon(
          FontAwesomeIcons.ellipsisH,
          color: Colors.black,
        ),

        itemBuilder: (context) {
          return [
            PopupMenuItem(
              value: 0,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.remove_red_eye_outlined,
                      color: Colors.black,
                    ),
                    title: Text(
                      "ViewDetails".tr(),
                    ),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 1,
                    width: double.infinity,
                    color: ColorManger.grey,
                  )
                ],
              ),
            ),
            PopupMenuItem(
              value: 1,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.compare_arrows_rounded,
                      color: Colors.black,
                    ),
                    title: Text("Compare".tr()),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 1,
                    width: double.infinity,
                    color: ColorManger.grey,
                  )
                ],
              ),
            ),
            PopupMenuItem(
              value: 2,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.favorite_border,
                      color: Colors.black,
                    ),
                    title: Text("Add to WishList".tr()),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 1,
                    width: double.infinity,
                    color: ColorManger.grey,
                  )
                ],
              ),
            ),
          ];
        },
        onSelected: (value) async {
          switch (value) {
            case 0:
              context
                  .read<HomeCubit>()
                  .getTestsDetails(itemId: itemId)
                  .whenComplete(() => showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                            actionsPadding: EdgeInsets.zero,
                            actions: [
                              ViewDetailsTestWidget(
                                  fromCart: false,
                                  test: context.read<HomeCubit>().testDetails!)
                            ],
                          )));

              break;
            case 1:
              context
                  .read<HomeCubit>()
                  .itemsCompare(itemId: itemId, itemType: 4)
                  .whenComplete(() => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const CompareView())));

              break;

            case 2:
              context.read<WishlistCubit>().addToWishlit(
                      wishlist: RequestWishlist(
                    context.read<AccountCubit>().userModel!.entityId!,
                    itemId,
                    null,
                  ));
              break;
          }
        },
      ),
    );
  }
}
