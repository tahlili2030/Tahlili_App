import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/presentaion/home/cubit/home_cubit.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

import '../../../data/response/home/response_home.dart';
import '../../resources/shared/appbar_divider.dart';

class CompareView extends StatelessWidget {
  const CompareView({super.key});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<HomeCubit>();
    print(cubit.compares.length);
    for (var element in cubit.compares) {
      print(element.productName);
    }
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          "Compare".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
      ),
      backgroundColor: Colors.white,
      body: BlocBuilder<HomeCubit, HomeState>(
        builder: (context, state) {
          return Column(
            children: [
              const AppBarDivider(),
              const SizedBox(
                height: 16,
              ),
              Expanded(
                  child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ListView.separated(
                    itemBuilder: (context, index) => const SizedBox(
                          height: 10,
                        ),
                    separatorBuilder: (context, index) => CompareItem(
                          item: cubit.compares[index],
                        ),
                    itemCount: cubit.compares.length + 1),
              ))
            ],
          );
        },
      ),
    );
  }
}

class CompareItem extends StatefulWidget {
  final ResponseItemsCompare item;
  const CompareItem({
    super.key,
    required this.item,
  });

  @override
  State<CompareItem> createState() => _CompareItemState();
}

class _CompareItemState extends State<CompareItem> {
  bool isClosed = false;

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<HomeCubit, HomeState>(
      builder: (context, state) {
        return Container(
          padding:  EdgeInsets.symmetric(horizontal: 8.w,vertical: 16.h),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: ColorManger.grey)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    height: 65.h,
                    width: 65.w,
                    decoration: BoxDecoration(
                      color: Colors.red,
                        borderRadius: BorderRadius.circular(10),
                        image: DecorationImage(
                            fit: BoxFit.fill,
                            image: CachedNetworkImageProvider(
                                EndPoints.baseImageUrl + widget.item.image!))),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.item.productName!,
                        style: StylesManger.rich().copyWith(color: Colors.black,fontSize: 14.sp),
                      ),
                      SizedBox(height: 8.h,),
                      Text(
                  context.locale.languageCode=='ar'?
                       "${'Partner'.tr()} : ${widget.item.partnerNameAr!}":
                     "${'Partner'.tr()} : ${widget.item.partnerNameEn!}"  ,
                        style: StylesManger.medium().copyWith(color: Colors.black,fontSize: 14.sp),
                      ),
                      SizedBox(height: 8.h,),
                        Text(
                          '${"Turnaround Time".tr()}: 24 H',
                          style: StylesManger.medium()
                              .copyWith(fontSize: 14.sp, color: Colors.black),
                        ),
                         SizedBox(
                          height: 8.h,
                        ),
                        Text(
                          '${"NumberOfTests".tr()}: ${widget.item.numberOfTests}',
                          style: StylesManger.medium()
                              .copyWith(fontSize: 14.sp, color: Colors.black),
                        ),
                        
                    ],
                  ),
                  GestureDetector(
                      onTap: () {
                        setState(() {
                          isClosed = !isClosed;
                        });
                      },
                      child: Icon(
                        isClosed
                            ? 
                            Icons.keyboard_arrow_up_outlined:Icons.keyboard_arrow_down_outlined,
                        color:ColorManger.lightGrey,
                        size: 30,
                      ))
                ],
              ),
              const SizedBox(
                height: 16,
              ),
              !isClosed
                  ? const SizedBox()
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${"Partner".tr()}: ${context.locale.languageCode == 'ar' ? widget.item.partnerNameAr : widget.item.partnerNameEn}',
                          style: StylesManger.medium()
                              .copyWith(fontSize: 14, color: Colors.black),
                        ),
                       
                       
                        const SizedBox(
                          height: 8,
                        ),
                        Text(
                          '${"IncludedTests".tr()}: ',
                          style: StylesManger.medium()
                              .copyWith(fontSize: 14, color: Colors.black),
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ...List.generate(
                                widget.item.includedTests!.length,
                                (index) => Row(
                                  children: [
                                      Text('-',style: StylesManger.medium().copyWith(
                          color: Colors.black
                        ),),
                       const SizedBox(width: 5,),
                                    Text(
                                            context.locale.languageCode == 'ar'
                                                ? widget.item.includedTests![index]
                                                    .testNameAr!
                                                : widget.item.includedTests![index]
                                                    .testNameEn!,
                                            style: StylesManger.medium().copyWith(
                                                fontSize: 14, color: Colors.black),
                                          ),
                                  ],
                                ))
                          ],
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        Text(
                          '${"Price".tr()}: ${widget.item.price}',
                          style: StylesManger.medium()
                              .copyWith(fontSize: 14, color: Colors.black),
                        ),
                        const SizedBox(
                          height: 24,
                        ),
                        InkWell(
                          onTap: () {
                            context
                                .read<HomeCubit>()
                                .deleteCompareItme(widget.item);
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(40),
                                border: Border.all(color: ColorManger.primary)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.delete_forever_outlined,
                                  color: ColorManger.primary,
                                ),
                                const SizedBox(
                                  width: 5,
                                ),
                                Text(
                                  "Remove".tr(),
                                  style: StylesManger.rich(),
                                )
                              ],
                            ),
                          ),
                        )
                      ],
                    )
            ],
          ),
        );
      },
    );
  }
}
