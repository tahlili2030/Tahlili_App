import 'package:flutter/material.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

import '../../resources/color_manger.dart';

class PackageScreen extends StatelessWidget {
  const PackageScreen({super.key});
  final String photo =
      'https://img.freepik.com/free-vector/science-logo-template-design_23-2150369141.jpg?size=338&ext=jpg&ga=GA1.1.1413502914.1701561600&semt=ais';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorManger.offWhite,
      appBar: AppBar(
        backgroundColor: ColorManger.primary,
        title: Text(
          "Esstinal Health",
          style: StylesManger.rich().copyWith(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
        child: GridView.builder(
            itemCount: 15,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: .67,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10),
            itemBuilder: (context, index) => Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: Colors.grey)),
                  child: Column(
                    children: [
                      Container(
                        height: 130,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Stack(
                          children: [
                            Container(
                              height: 130,
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      fit: BoxFit.fill,
                                      image: NetworkImage(
                                          'https://www.hindustantimes.com/ht-img/img/2023/06/22/1600x900/kidney_failure_thumb_1661931572963_1687435298219.jpg'))),
                            ),
                            PositionedDirectional(
                              top: 5,
                              start: 5,
                              child: Container(
                                padding: const EdgeInsets.all(4),
                                height: 25,
                                decoration: BoxDecoration(
                                    color: ColorManger.grey,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      '27',
                                      style: StylesManger.medium()
                                          .copyWith(color: Colors.black),
                                    ),
                                    SizedBox(
                                      width: 2,
                                    ),
                                    Text(
                                      'test',
                                      style: StylesManger.medium()
                                          .copyWith(color: Colors.black),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            // PositionedDirectional(
                            //   top: -0,
                            //   end: 5,
                            //   child: Container(
                            //     height: 30.0,
                            //     width: 30.0,
                            //     child: Center(
                            //       child: Stack(children: [
                            //         Center(
                            //           child: Icon(Icons.favorite,
                            //               color: Colors.black, size: 30.0),
                            //         ),
                            //         Center(
                            //             child: Icon(Icons.favorite,
                            //                 color: Colors.white, size: 25.0))
                            //       ]),
                            //     ),
                            //   ),
                            // )
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Text(
                            "Essential Kidney Health",
                            style: StylesManger.medium().copyWith(fontSize: 10),
                          ),
                          const Spacer(),
                         Icon(Icons.favorite_border)
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        children: [
                          Text(
                            '300 SAR',
                            style: StylesManger.medium().copyWith(
                                color: ColorManger.grey,
                                decoration: TextDecoration.lineThrough),
                          ),
                          const SizedBox(
                            width: 5,
                          ),
                          Text(
                            '200 SAR',
                            style: StylesManger.medium().copyWith(
                              color: ColorManger.primary,
                            ),
                          )
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        children: [
                          Container(
                            height: 25,
                            width: 25,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                image: DecorationImage(
                                    image: NetworkImage(photo))),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "Nahdi Care",
                            style: StylesManger.medium(),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Container(
                            height: 25,
                            width: 25,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                image: DecorationImage(
                                    image: NetworkImage(photo))),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Container(
                            height: 25,
                            width: 25,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                image: DecorationImage(
                                    image: NetworkImage(photo))),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                              width: 160,
                              height: 30,
                              child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      minimumSize:
                                          const Size(double.infinity, 60),
                                      backgroundColor: ColorManger.primary,
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(8.0),
                                      )),
                                  onPressed: () {},
                                  child: Center(
                                    child: Text(
                                      "Reserve Now",
                                      style: StylesManger.rich().copyWith(
                                          color: Colors.white, fontSize: 10),
                                    ),
                                  ))),
                        ],
                      )
                    ],
                  ),
                )),
      ),
    );
  }
}
