// import 'package:flutter/material.dart';

// import '../../resources/color_manger.dart';
// import '../../resources/styles_manger.dart';

// class ShowPage extends StatelessWidget {
//   const ShowPage({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: ColorManger.offWhite,
//       appBar: AppBar(
//         backgroundColor: ColorManger.primary,
//         title: Text(
//           "Weekly Deals",
//           style: StylesManger.rich().copyWith(color: Colors.white),
//         ),
//         centerTitle: true,
//       ),
//       body: Padding(
//         padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
//         child: GridView.builder(
//             itemCount: 15,
//             gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//                 crossAxisCount: 2,
//                 childAspectRatio: 1,
//                 crossAxisSpacing: 10,
//                 mainAxisSpacing: 10),
//             itemBuilder: (context, index) => Container(
//                   padding: EdgeInsets.all(9),
//                   decoration: BoxDecoration(
//                       color: Colors.white,
//                       borderRadius: BorderRadius.circular(15),
//                       border: Border.all(color: Colors.grey)),
//                   child: Column(
//                     children: [
//                       Container(
//                         height: 100,
//                         decoration: BoxDecoration(
//                           image: DecorationImage(image: NetworkImage('https://www.hindustantimes.com/ht-img/img/2023/06/22/1600x900/kidney_failure_thumb_1661931572963_1687435298219.jpg')),
//                           borderRadius: BorderRadius.circular(10),
//                         ),

//                       ),

//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Text(
//                             "Essential Kidney Health",
//                             style: StylesManger.medium().copyWith(fontSize: 10),
//                           ),

//                          IconButton(onPressed: (){}, icon: Icon(Icons.favorite_border_rounded))
//                         ],
//                       ),

//                       Row(
//                         children: [
//                           Text(
//                             '300 SAR',
//                             style: StylesManger.medium().copyWith(
//                                 color: ColorManger.grey,
//                                 decoration: TextDecoration.lineThrough),
//                           ),
//                           const SizedBox(
//                             width: 5,
//                           ),
//                           Text(
//                             '200 SAR',
//                             style: StylesManger.medium().copyWith(
//                               color: ColorManger.primary,
//                             ),
//                           )
//                         ],
//                       ),



//                       ],
//                   ),
//                 )),
//       ),
//     );
//   }
// }
