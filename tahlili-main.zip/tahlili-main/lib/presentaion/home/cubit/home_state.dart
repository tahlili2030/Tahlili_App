part of 'home_cubit.dart';

@immutable
abstract class HomeState {}

final class HomeInitial extends HomeState {}

class LoadGetHomeInsurancesState extends HomeState {}

class SuccessGetHomeInsurancesState extends HomeState {
  final List<ResponseInsurance> insurances;

  SuccessGetHomeInsurancesState(this.insurances);
}

class FailureGetHomeInsurancesState extends HomeState {
  final String error;

  FailureGetHomeInsurancesState(this.error);
}

class LoadGetShownDealsState extends HomeState {}

class SuccessGetShownDealsState extends HomeState {
  final List<ResponseDeals> deals;

  SuccessGetShownDealsState(this.deals);
}

class FailureGetShwonDealsState extends HomeState {
  final String error;

  FailureGetShwonDealsState(this.error);
}

class LoadGetGeneticTestsState extends HomeState {}

class SuccessGetGeneticTestsState extends HomeState {
  final List<ResponseSearch> genetics;

  SuccessGetGeneticTestsState(this.genetics);
}

class FailureGetGeneticTestsState extends HomeState {
  final String error;

  FailureGetGeneticTestsState(this.error);
}

class LoadGetHomeCategoriesState extends HomeState {}

class SuccessGetHomeCategoriesState extends HomeState {
  final List<ResponseHomeCategory> categories;

  SuccessGetHomeCategoriesState(this.categories);
}

class FailureGetHomeCategoriesState extends HomeState {
  final String error;

  FailureGetHomeCategoriesState(this.error);
}

class LoadGetHomeLabState extends HomeState {}

class SuccessGetHomeLabState extends HomeState {
  final List<ResponseHomeLabs> homeLabs;

  SuccessGetHomeLabState(this.homeLabs);
}

class FailureGetHomeLabState extends HomeState {
  final String error;

  FailureGetHomeLabState(this.error);
}

class LoadGetHomeRecommendedPackagesState extends HomeState {}

class SuccessGetHomeRecommendedPackagesState extends HomeState {
  final List<ResponseHomePackages> homePackages;

  SuccessGetHomeRecommendedPackagesState(this.homePackages);
}

class FailureGetHomeRecommendedPackagesState extends HomeState {
  final String error;

  FailureGetHomeRecommendedPackagesState(this.error);
}

class LoadGetHomeFeedBackState extends HomeState {}

class SuccessGetHomeFeedBackState extends HomeState {
  final List<ResponseHomeFeedback> homeFeedbacks;

  SuccessGetHomeFeedBackState(this.homeFeedbacks);
}

class FailureGetHomeFeedBackState extends HomeState {
  final String error;

  FailureGetHomeFeedBackState(this.error);
}

class LoadGetHomeCouponsState extends HomeState {}

class SuccessGetHomeCouponsState extends HomeState {
  final List<ResponseCoupon> homeFeedbacks;

  SuccessGetHomeCouponsState(this.homeFeedbacks);
}

class FailureGetHomeCouponsState extends HomeState {
  final String error;

  FailureGetHomeCouponsState(this.error);
}

class LoadGetHomeSearchState extends HomeState {}

class SuccessGetHomeSearchState extends HomeState {
  final List<ResponseSearch> search;

  SuccessGetHomeSearchState(this.search);
}

class FailureGetHomeSearchState extends HomeState {
  final String error;

  FailureGetHomeSearchState(this.error);
}

class LoadGetPatientHistoriesState extends HomeState {}

class SuccessGetPatientHistoriesState extends HomeState {
  final ResponseAPI responseAPI;

  SuccessGetPatientHistoriesState(this.responseAPI);
}

class FailureGetPatientHistoriesState extends HomeState {
  final String error;

  FailureGetPatientHistoriesState(this.error);
}

class LoadChangeLanguageState extends HomeState {}

class SuccessChangeLanguageState extends HomeState {
  final ResponseAPI responseAPI;

  SuccessChangeLanguageState(this.responseAPI);
}

class FailureChangeLanguageState extends HomeState {
  final String error;

  FailureChangeLanguageState(this.error);
}

class LoadItemsCompareState extends HomeState {}

class SuccessItemsCompareState extends HomeState {
  final ResponseItemsCompare itemsCompare;

  SuccessItemsCompareState(this.itemsCompare);
}

class FailureItemsCompareState extends HomeState {
  final String error;

  FailureItemsCompareState(this.error);
}

class CahngeSliderIndexState extends HomeState {}

class ChangeCategoryIndex extends HomeState {}

class LoadGetUserTrailordPackageState extends HomeState {}

class FailureGetTrailordUserPackageState extends HomeState {}

class SuccessGetTrailordUserPackageState extends HomeState {}

class LoadGetUserRecommendedPackageState extends HomeState {}

class FailureGetUserRecommendedPackageState extends HomeState {}

class SuccessGetUserRecommendedPackageState extends HomeState {}

class LoadGetHomeAdsState extends HomeState {}

class SuccessGetHomeAdsState extends HomeState {}

class FailureGetHomeAdsState extends HomeState {}

class LoadGetTahliliPackagesState extends HomeState {}

class SuccessGetTahliliPackagesState extends HomeState {}

class FailureGetTahliliPackagesState extends HomeState {}

class LoadGetIndividualTestsState extends HomeState {}

class SuccessGetIndividualTestsState extends HomeState {}

class FailureGetIndividualTestsState extends HomeState {}

class LoadAddAdsClickState extends HomeState {}

class SuccessAddAdsClickState extends HomeState {}

class FailureAddAdsClickState extends HomeState {}

class DeleteCompareItemState extends HomeState {}

class LoadShowDealsDetailsState extends HomeState {}

class SuccessShowDealsDetailsState extends HomeState {}

class FailureShowDealsDetailsState extends HomeState {}

class ResetSearchState extends HomeState {}

class SetSortValueState extends HomeState {}

class LoadGetPartnerCountState extends HomeState {}

class SuccessGetPartnerCountState extends HomeState {}

class FailureGetPartnerCountState extends HomeState {}

class ChangeHomeTabIndicatorState extends HomeState {}
