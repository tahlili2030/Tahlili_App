import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';
import 'package:tahlili/app/pref_manager.dart';
import 'package:tahlili/data/local/local_classes.dart';
import 'package:tahlili/data/mappers/mappers.dart';
import 'package:tahlili/data/requests/home/request_home.dart';
import 'package:tahlili/data/response/response.dart';
import 'package:tahlili/domain/repository/home/home.dart';
import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../data/response/home/response_home.dart';
import '../../../domain/view_obj/home/home.dart';
import '../../resources/constant_manger.dart';

part 'home_state.dart';

class HomeCubit extends Cubit<HomeState> {
  HomeCubit(this._baseHomeRepository, this._preferancesManager)
      : super(HomeInitial());
  final BaseHomeRepository _baseHomeRepository;
  final PreferancesManager _preferancesManager;
  List<String> homeSliders = [
    'assets/images/slider1.png',
    'assets/images/slider2.png',
  ];
  List<String> servicesImages = [
    'assets/images/services/helth_insurances.png',
    'assets/images/services/Laboratory.png',
    'assets/images/services/Prescription.png',
    'assets/images/services/Telemedicine.png',
  ];
  List<String> enServices = [
    'استشاره طبيه فورية',
    'Laboratory Services',
    'Upload Lab Test Request',
    'Telemedicine Consultation',
  ];
  List<String> arServices = [
    "استشاره طبيه فورية",
    "خدمات المختبرات",
    "تحميل طلب التحاليل المخبرية",
    "استشارة الطبيب عن بُعد",
  ];

  List<String> homeTabs = ["العروض الأسبوعية", "باقات تحليلي"];
  int homeTabIndicator = 0;
  chnageHotTabIndicator(value) {
    homeTabIndicator = value;
    emit(ChangeHomeTabIndicatorState());
  }

  int sliderIndex = 0;
  setSliderIndex(int index) {
    sliderIndex = index;
    emit(CahngeSliderIndexState());
  }

  int? categoryIndex;
  setCategoryIndex(int index) {
    categoryIndex = index;
    emit(ChangeCategoryIndex());
  }

  bool featchedToken = false;
  bool fetched = false;
  void start() {
    // getInsurancesLookUp();
    getTahliliPackages();
    getIndividualTests();
    getHomeAds();
    getShownDeals();
    getHomeCategories();
    getGeneticTests();
    getHomeLab();
    getHomeRecommendedPackages();
    getHomeLab();

    // getHomeFeedBack();
    fetched = true;
  }

  startToken() {
    final token = _preferancesManager.getData(key: userToken);
    if (token != null) {
      getTrailordUserPackages();
      getRecommendedUserPackages();
      fetched = true;
    }
  }

  getInsurancesLookUp() async {
    try {
      emit(LoadGetHomeInsurancesState());
      final result = await _baseHomeRepository.getInsurancesLookUp();

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetHomeInsurancesState(failure.message));
      }, (insurances) {
        emit(SuccessGetHomeInsurancesState(insurances));
      });
    } catch (e) {
      emit(FailureGetHomeInsurancesState(e.toString()));
    }
  }

  List<ResponseDeals> deals = [];
  getShownDeals() async {
    deals = [];
    try {
      emit(LoadGetShownDealsState());
      final result = await _baseHomeRepository.getShownDeals();

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetShwonDealsState(failure.message));
      }, (deals) {
        this.deals.addAll(deals);
        emit(SuccessGetShownDealsState(deals));
      });
    } catch (e) {
      emit(FailureGetShwonDealsState(e.toString()));
    }
  }

  List<ResponseSearch> tahliliPackages = [];
  getTahliliPackages() async {
    tahliliPackages.clear();
    try {
      emit(LoadGetTahliliPackagesState());
      final result = await _baseHomeRepository.getTahliliPackages();

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetTahliliPackagesState());
      }, (tahliliPackages) {
        debugPrint("tahlili ${tahliliPackages.length}");
        this.tahliliPackages.addAll(tahliliPackages);
        emit(SuccessGetTahliliPackagesState());
      });
    } catch (e) {
      emit(FailureGetTahliliPackagesState());
    }
  }

  List<ResponseIndividualTests> individualTest = [];
  List<String> enTest = [];
  List<String> arTest = [];
  getIndividualTests() async {
    individualTest.clear();
    enTest.clear();
    arTest.clear();
    try {
      emit(LoadGetIndividualTestsState());
      final result = await _baseHomeRepository.getIndividualTests();

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetIndividualTestsState());
      }, (individualTest) {
        debugPrint("tests ${individualTest.length}");

        for (var i = 0; i < individualTest.length; i++) {
          if (individualTest[i].orderIndex != null) {
            this.individualTest.add(individualTest[i]);
          }
          List<String> day = ConstantManger.splitTelda(individualTest[i].name!);
          enTest.add(day[0]);
          arTest.add(day[1]);
        }
        emit(SuccessGetIndividualTestsState());
      });
    } catch (e) {
      emit(FailureGetIndividualTestsState());
    }
  }

  List<ResponseSearch> genetics = [];
  getGeneticTests() async {
    try {
      genetics = [];
      emit(LoadGetGeneticTestsState());
      final result = await _baseHomeRepository.getGeneticTests();

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetGeneticTestsState(failure.message));
      }, (genetics) {
        this.genetics.addAll(genetics);
        emit(SuccessGetGeneticTestsState(genetics));
      });
    } catch (e) {
      emit(FailureGetGeneticTestsState(e.toString()));
    }
  }

  List<ResponseHomeCategory> categories = [];
  List<String> enCategories = [];
  List<String> arCategories = [];
  getHomeCategories() async {
    try {
      categories = [];
      enCategories.clear();
      arCategories.clear();
      emit(LoadGetHomeCategoriesState());
      final result = await _baseHomeRepository.getHomeCategories();

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetHomeCategoriesState(failure.message));
      }, (categories) {
        this.categories.addAll(categories);
        for (var i = 0; i < categories.length; i++) {
          if (categories[i].orderIndex != null) {
            List<String> day = ConstantManger.splitTelda(categories[i].name!);
            enCategories.add(day[0]);
            arCategories.add(day[1]);
          }
        }
        emit(SuccessGetHomeCategoriesState(categories));
      });
    } catch (e) {
      emit(FailureGetHomeCategoriesState(e.toString()));
    }
  }

  List<ResponseHomeLabs> homeLabs = [];
  getHomeLab() async {
    try {
      homeLabs = [];
      emit(LoadGetHomeLabState());
      final result = await _baseHomeRepository.getHomeLabs();

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetHomeLabState(failure.message));
      }, (homeLabs) {
        this.homeLabs.addAll(homeLabs);
        emit(SuccessGetHomeLabState(homeLabs));
      });
    } catch (e) {
      emit(FailureGetHomeLabState(e.toString()));
    }
  }

  List<ResponseHomePackages> homePackages = [];
  getHomeRecommendedPackages() async {
    try {
      homePackages = [];
      emit(LoadGetHomeRecommendedPackagesState());
      final result = await _baseHomeRepository.getHomeRecommendedPackages(
          orderBy: 'soldItems', asc: false);

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetHomeRecommendedPackagesState(failure.message));
      }, (homePackages) {
        this.homePackages.addAll(homePackages);
        emit(SuccessGetHomeRecommendedPackagesState(homePackages));
      });
    } catch (e) {
      emit(FailureGetHomeRecommendedPackagesState(e.toString()));
    }
  }

  getHomeFeedBack() async {
    try {
      emit(LoadGetHomeFeedBackState());
      final result = await _baseHomeRepository.getHomeFeedBack();

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetHomeFeedBackState(failure.message));
      }, (homeFeedbacks) {
        debugPrint('feedBack count ${homeFeedbacks.length}');
        emit(SuccessGetHomeFeedBackState(homeFeedbacks));
      });
    } catch (e) {
      emit(FailureGetHomeFeedBackState(e.toString()));
    }
  }

  getHomeCoupon() async {
    try {
      emit(LoadGetHomeCouponsState());
      final result = await _baseHomeRepository.getHomeCoupon();

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetHomeCouponsState(failure.message));
      }, (homeCoupons) {
        debugPrint('feedBack count ${homeCoupons.length}');
        emit(SuccessGetHomeCouponsState(homeCoupons));
      });
    } catch (e) {
      emit(FailureGetHomeCouponsState(e.toString()));
    }
  }

  TextEditingController searchController = TextEditingController();
  List<ResponseSearch> search = [];
  String? filterQuery;
  Future getHomeSearch() async {
    search.clear();

    if (searchController.text.trim().isNotEmpty) {
      filterQuery = 'Tags.Contains("${searchController.text}")';
      // filterQuery = 'CategoryId.Contains(",11,")';
    }
    try {
      emit(LoadGetHomeSearchState());
      final result = await _baseHomeRepository.getHomeSearch(
          orderBy: orderBy, filterQuery: filterQuery, asc: asc);

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetHomeSearchState(failure.message));
      }, (search) {
        debugPrint('search count ${search.length}');
        for (var element in search) {
          this.search.add(element);
        }
        emit(SuccessGetHomeSearchState(search));
      });
    } catch (e) {
      emit(FailureGetHomeSearchState(e.toString()));
    }
  }

  String orderBy = "NameEn";
  bool asc = true;

  List<String> filterSort = [
    "Form A To Z",
    "Low Price",
    "High Price",
  ];
  int? filterValue;
  setFilterValue(value) {
    filterValue = value;
    searchFilter(filterValue!);
    getHomeSearch();
    emit(SetSortValueState());
  }

  //String? sort = "Name-Asc";
  searchFilter(int sort) {
    switch (sort) {
      case 0:
        orderBy = "NameEn";
        asc = true;
        break;
      // case "Name-Desc":
      //   orderBy = "NameEn";
      //   asc = false;
      //   break;
      case 1:
        orderBy = "Price";
        asc = true;
        break;
      case 2:
        orderBy = "Price";
        asc = false;
        break;
      // case "Nearest Lab-Asc":
      //   orderBy = "NameEn";
      //   asc = true;
      //   break;
      // default:
      //   orderBy = "NameEn";
      //   asc = true;
    }
  }

  List<ResponseSearch> categoryItem = [];
  getCategoryItems({required int categoryId}) async {
    categoryItem.clear();

    final filterQuery = 'CategoryId.Contains(",$categoryId,")';
    emit(LoadGetHomeSearchState());

    try {
      final result = await _baseHomeRepository.getHomeSearch(
          orderBy: "NameEn", filterQuery: filterQuery, asc: true);

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetHomeSearchState(failure.message));
      }, (categoryItem) {
        debugPrint('search count ${categoryItem.length}');
        this.categoryItem.addAll(categoryItem);
        emit(SuccessGetHomeSearchState(search));
      });
    } catch (e) {
      emit(FailureGetHomeSearchState(e.toString()));
    }
  }

  clearSearch() {
    orderBy = "NameEn";
    asc = true;
    searchController.clear();
    filterQuery = null;
    filterValue = null;
    emit(ResetSearchState());
  }

  getPatientsHistories() async {
    try {
      emit(LoadGetPatientHistoriesState());
      final result = await _baseHomeRepository.getPatientsHistories(
          patientHisotry: RequestPatientHisotry(0, 0, 0));

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureGetPatientHistoriesState(failure.message));
      }, (responseAPI) {
        debugPrint(responseAPI.message);
        emit(SuccessGetPatientHistoriesState(responseAPI));
      });
    } catch (e) {
      emit(FailureGetPatientHistoriesState(e.toString()));
    }
  }

  changeLanguage() async {
    try {
      emit(LoadChangeLanguageState());
      final result = await _baseHomeRepository.changeLanguage(langId: 0);

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureChangeLanguageState(failure.message));
      }, (responseAPI) {
        debugPrint(responseAPI.message);
        emit(SuccessChangeLanguageState(responseAPI));
      });
    } catch (e) {
      emit(FailureChangeLanguageState(e.toString()));
    }
  }

  List<ResponseItemsCompare> compares = [];
  Future itemsCompare({required int itemId, required int itemType}) async {
    try {
      emit(LoadItemsCompareState());
      final result = await _baseHomeRepository.itemsCompare(
          itemId: itemId, itemType: itemType);

      result.fold((failure) {
        debugPrint(failure.message);
        emit(FailureItemsCompareState(failure.message));
      }, (itemCompare) {
        // debugPrint(itemCompare.productId!.toString());
        if (!compares.contains(itemCompare)) {
          compares.add(itemCompare);
          print(compares.length);
          toast(text: "تم اضافه في قائمه المقارنه", color: Colors.green);
        }

        emit(SuccessItemsCompareState(itemCompare));
      });
    } catch (e) {
      emit(FailureItemsCompareState(e.toString()));
    }
  }

  deleteCompareItme(ResponseItemsCompare item) {
    compares.remove(item);
    emit(DeleteCompareItemState());
  }

  List<ResponseUserPackages> trailordPackage = [];
  getTrailordUserPackages() async {
    trailordPackage = [];
    emit(LoadGetUserTrailordPackageState());
    try {
      final result = await _baseHomeRepository.getUserPackages(isTailord: true);
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetTrailordUserPackageState());
      }, (userPackages) {
        debugPrint(userPackages.length.toString());
        trailordPackage.addAll(userPackages);
        emit(SuccessGetTrailordUserPackageState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetTrailordUserPackageState());
    }
  }

  List<ResponseUserPackages> recommendedPackage = [];
  getRecommendedUserPackages() async {
    recommendedPackage = [];
    emit(LoadGetUserRecommendedPackageState());
    try {
      final result =
          await _baseHomeRepository.getUserPackages(isTailord: false);
      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetUserRecommendedPackageState());
      }, (userPackages) {
        debugPrint(userPackages.length.toString());
        recommendedPackage.addAll(userPackages);
        emit(SuccessGetUserRecommendedPackageState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetUserRecommendedPackageState());
    }
  }

  List<ResponseHomeAds> homeAds = [];
  getHomeAds() async {
    homeAds = [];
    emit(LoadGetHomeAdsState());
    try {
      final result = await _baseHomeRepository.getHomeAds(adsId: "adsAreaId=9");

      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetHomeAdsState());
      }, (homeAds) {
        debugPrint(homeAds.length.toString());
        this.homeAds.addAll(homeAds);
        emit(SuccessGetHomeAdsState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetHomeAdsState());
    }
  }

  addAdsClicks({required int addId}) async {
    emit(LoadAddAdsClickState());
    try {
      final result = await _baseHomeRepository.addClick(adsId: addId);

      result.fold((error) {
        debugPrint(error.message);
        emit(FailureAddAdsClickState());
      }, (response) {
        debugPrint(response.message);

        emit(SuccessAddAdsClickState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureAddAdsClickState());
    }
  }

  List<ResponsePackageDetails> dealsDetails = [];
  Future getShownDealsDetails({required int itemId}) async {
    dealsDetails.clear();
    emit(LoadShowDealsDetailsState());
    try {
      final result =
          await _baseHomeRepository.getShownDealsDetails(itemId: itemId);

      result.fold((error) {
        debugPrint(error.message);
        emit(FailureShowDealsDetailsState());
      }, (dealsDetails) {
        debugPrint(dealsDetails.id!.toString());
        this.dealsDetails.add(dealsDetails);

        emit(SuccessShowDealsDetailsState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureShowDealsDetailsState());
    }
  }

  Future<void> launchUrlFun(uri) async {
    var url = Uri.parse(uri);
    if (!await launchUrl(url)) {
      toast(text: 'Could not launch $url', color: Colors.red);
    }
  }

  final TextEditingController prescriptionNotesController =
      TextEditingController();
  final prescriptionKey = GlobalKey<FormState>();

  ResponseTestDetails? testDetails;
  Future getTestsDetails({required int itemId}) async {
    testDetails = null;
    emit(LoadShowDealsDetailsState());
    try {
      final result = await _baseHomeRepository.getTestsDetails(itemId: itemId);

      result.fold((error) {
        debugPrint(error.message);
        emit(FailureShowDealsDetailsState());
      }, (dealsDetails) {
        debugPrint(dealsDetails.id!.toString());
        testDetails = dealsDetails;

        emit(SuccessShowDealsDetailsState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureShowDealsDetailsState());
    }
  }

  ResponsePartnerCount? partnerCount;
  Future getPartnerCount({required int partnerId}) async {
    partnerCount = null;
    emit(LoadGetPartnerCountState());
    try {
      final result =
          await _baseHomeRepository.getPartnerCount(partnerId: partnerId);

      result.fold((error) {
        debugPrint(error.message);
        emit(FailureGetPartnerCountState());
      }, (partnerCount) {
        debugPrint(partnerCount.packageCount!.toString());
        this.partnerCount = partnerCount;

        emit(SuccessGetPartnerCountState());
      });
    } catch (e) {
      debugPrint(e.toString());
      emit(FailureGetPartnerCountState());
    }
  }

  List<CategoryHomeModel> homeCatgoryModel = [
    CategoryHomeModel("assets/images/home/hair.svg", Color(0xff00A1B0)),
    CategoryHomeModel("assets/images/home/food.svg", Color(0xff5DB896)),
    CategoryHomeModel("assets/images/home/diabetic.svg", Color(0xff3A5F8A)),
    CategoryHomeModel("assets/images/home/alergic.svg", Color(0xff00A1B0)),
    CategoryHomeModel("assets/images/home/bones.svg", Color(0xff5DB896)),
    CategoryHomeModel("assets/images/home/gender.svg", Color(0xff3A5F8A)),
    CategoryHomeModel("assets/images/home/children.svg", Color(0xff00A1B0)),
    CategoryHomeModel("assets/images/home/labs.svg", Color(0xff00A1B0)),
  ];

  final List<ServicesHomeModel> servicesHomeModel = [
    ServicesHomeModel(
      "الاستشارات الطبية",
      "تقديم المشورة الطبية والتوجيه للمرضى والمراجعين من قبل أطباء متخصصين",
      "assets/images/home/telemed.svg",
      "assets/images/home/tele.png",
      "استشر الآن",
    ),
    ServicesHomeModel(
      "رفع طلب التحاليل الطبية",
      "يتم إفادتك بالتحاليل المكتوبة من قِبل الطبيب المعالج وتقديم الباقة المناسبة لك",
      "assets/images/home/prescription.svg",
      "assets/images/home/prescrption.png",
      "ارفع الطلب",
    ),
    ServicesHomeModel(
      "استشارة طبية فورية",
      "استشارة طبية عاجلة عبر الإنترنت طوال اليوم.                   ",
      "assets/images/home/instnant_telemed.svg",
      "assets/images/home/instant.png",
      "ابدء الاستشارة",
    ),
    ServicesHomeModel(
      "خدمات المختبرات",
      "باقات وتحاليل طبية مقدمة من عدة مختبرات معتمدة بجودة عالية",
      "assets/images/home/labs.svg",
      "assets/images/home/instant.png",
      "تصفح الخدمات",
    ),
  ];

  final ScrollController scrollController = ScrollController();

  void scrollToPosition(double position) {
    scrollController.animateTo(
      position,
      duration: Duration(seconds: 2),
      curve: Curves.easeInOut,
    );
  }
}
