import 'dart:developer';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/app/pref_manager.dart';
import 'package:tahlili/data/response/orders/response_order.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/home/cubit/home_cubit.dart';
import 'package:tahlili/presentaion/home/page/search_view.dart';
import 'package:tahlili/presentaion/home/view/widgest/genetics_widget.dart';
import 'package:tahlili/presentaion/home/view/widgest/home_item.dart';
import 'package:tahlili/presentaion/home/view/widgest/indivual_tests.dart';
import 'package:tahlili/presentaion/home/view/widgest/lab_widget.dart';
import 'package:tahlili/presentaion/home/view/widgest/new_home_widget.dart';
import 'package:tahlili/presentaion/home/view/widgest/tahlily_packages.dart';
import 'package:tahlili/presentaion/home/view/widgest/view_all/indvidual_tests.dart';
import 'package:tahlili/presentaion/home/view/widgest/view_all/weakly_deals.dart';
import 'package:tahlili/presentaion/map/cubit/map_cubit.dart';
import 'package:tahlili/presentaion/notification/view/notification_view.dart';
import 'package:tahlili/presentaion/orders/cubit/orders_cubit.dart';
import 'package:tahlili/presentaion/prescriptions/view/upload_prescription.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/shared/shared_widgets.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';
import 'package:tahlili/presentaion/telemedicine/view/normal_telemed/departments_screen.dart';
import 'package:tahlili/presentaion/telemedicine/view/instant_telemed/instant_telemed_view.dart';
import 'package:video_player/video_player.dart';
import '../../resources/locle/locale_cubit.dart';
import '../../telemedicine/view/instant_telemed/check_tele.dart';
import '../page/genetics_grid_view.dart';
import '../page/labs_view.dart';
import 'widgest/category_widget.dart';
import 'widgest/upComingAppts_widget.dart';
import 'widgest/upload_prescirption.dart';
import 'widgest/view_all/category.dart';
import 'widgest/view_all/tahlili_packages.dart';

class HomeView extends StatefulWidget {
  const HomeView(this._manager, {super.key});
  final PreferancesManager _manager;

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  late VideoPlayerController _controller;
  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(
        'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4'))
      ..initialize().then((_) {
        log("sasa");
        // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
        setState(() {
          log("asas");
        });
      });
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    print('*********************' + screenSize.height.toString());
    log(screenSize.height.toString());
    final token = widget._manager.getData(key: userToken);
    if (token != null) log(token);

    context.read<LocaleCubit>().getLocale(context: context);
    context.read<MapCubit>().getUserLocation();
    final cubit = context.read<HomeCubit>();
    final orderCubit = context.read<OrdersCubit>();
    orderCubit.getUpcomingAppts();
    context.read<AccountCubit>().getUserEntityID();
    !cubit.fetched ? cubit.start() : null;

    // !cubit.featchedToken ? cubit.startToken() : null;

    return Scaffold(
      backgroundColor: ColorManger.pageColor,
      appBar: AppBar(
        surfaceTintColor: Colors.white,
        leading: const SizedBox(),
        backgroundColor: Colors.white,
        actions: [
          // IconButton(
          //     onPressed: () {
          //       Navigator.push(
          //           context,
          //           MaterialPageRoute(
          //               builder: (context) => const TrackingNurse()));
          //     },
          //     icon: const Icon(Icons.location_on)),
          IconButton(
              padding: EdgeInsets.zero,
              visualDensity: VisualDensity.compact,
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const SearchView()));
                // if (context.read<MapCubit>().userLocation != null) {
                //   context.read<MapCubit>().initPostion();
                //   context.read<MapCubit>().getUserAdress(
                //       context.read<MapCubit>().userLocation!.latitude,
                //       context.read<MapCubit>().userLocation!.longitude);
                //   Navigator.push(
                //       context,
                //       MaterialPageRoute(
                //           builder: (context) => const AddressView()));
                // }
              },
              icon: Icon(
                Icons.search,
                color: ColorManger.blueBlack,
              )),
          IconButton(
              visualDensity: VisualDensity.compact,
              padding: EdgeInsets.zero,
              onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const NotificationView())),
              icon: Icon(
                Icons.notifications_none,
                color: ColorManger.blueBlack,
              )),
          // IconButton(
          //     onPressed: () async {

          //     },
          //     icon: Icon(
          //       token != null ? Icons.exit_to_app : Icons.login,
          //       color: ColorManger.primary,
          //       size: 24,
          //     )),
        ],
        flexibleSpace: Padding(
          padding: const EdgeInsetsDirectional.only(start: 16, top: 50),
          child: Row(
            children: [
              SvgPicture.asset(
                'assets/images/new_logo_with_text.svg',
                height: 22.h,
                width: 50.w,
                fit: BoxFit.fill,
              ),
            ],
          ),
        ),
      ),
      body: SingleChildScrollView(
        controller: cubit.scrollController,
        child: Padding(
          padding: const EdgeInsets.only(top: 2),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              BlocBuilder<HomeCubit, HomeState>(
                builder: (context, state) {
                  return cubit.homeSliders.isNotEmpty
                      ? Padding(
                          padding:
                              EdgeInsetsDirectional.symmetric(horizontal: 8.w),
                          child: CarouselSlider.builder(
                            itemCount: cubit.homeSliders.length,
                            itemBuilder: (BuildContext context, int index,
                                    int pageViewIndex) =>
                                GestureDetector(
                              onTap: () {
                                // cubit.addAdsClicks(
                                //     addId: cubit.homeSliders[index].id!);
                                // if (cubit.homeSliders[index].url != null) {
                                //   cubit.launchUrlFun(cubit.homeSliders[index].url);
                                // }
                              },
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16.0),
                                child: Container(
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20.r),
                                      image: DecorationImage(
                                          fit: BoxFit.fill,
                                          image: AssetImage(
                                              context.locale.languageCode ==
                                                      'en'
                                                  ? cubit.homeSliders[index]
                                                  : cubit.homeSliders[index]))),
                                ),
                              ),
                            ),
                            options: CarouselOptions(
                              onPageChanged: (index, reason) {
                                cubit.setSliderIndex(index);
                              },
                              height: 161.h,
                              aspectRatio: 16 / 9,
                              viewportFraction: 1,
                              enableInfiniteScroll: true,
                              reverse: false,
                              autoPlay: true,
                              autoPlayInterval: const Duration(seconds: 8),
                              autoPlayAnimationDuration:
                                  const Duration(milliseconds: 800),
                              autoPlayCurve: Curves.fastOutSlowIn,
                              enlargeCenterPage: true,
                              scrollDirection: Axis.horizontal,
                            ),
                          ),
                        )
                      : const Center(
                          child: CircularProgressIndicator(),
                        );
                },
              ),
              const SizedBox(
                height: 15,
              ),
              BlocBuilder<HomeCubit, HomeState>(
                builder: (context, state) {
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ...List.generate(
                          cubit.homeSliders.length,
                          (index) => Container(
                                margin:
                                    const EdgeInsets.symmetric(horizontal: 3),
                                height: 4,
                                width: 35,
                                decoration: BoxDecoration(
                                    color: cubit.sliderIndex == index
                                        ? ColorManger.newPrimary
                                        : Color(0xffc7eaed),
                                    borderRadius: BorderRadius.circular(20)),
                              ))
                    ],
                  );
                },
              ),
              v(56.h),
              Padding(
                padding: EdgeInsetsDirectional.symmetric(horizontal: 16.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'OurServices'.tr(),
                      style: StylesManger.medium().copyWith(fontSize: 24.sp),
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    GridView.builder(
                        physics: NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: cubit.servicesHomeModel.length,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisSpacing: 24.w,
                            mainAxisSpacing: 24.h,
                            crossAxisCount: 2,
                            mainAxisExtent: 200.h),
                        itemBuilder: (context, index) => InkWell(
                              onTap: () {
                                switch (index) {
                                  case 0:
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                DepartmentsView()));
                                    break;
                                  case 1:
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                UploadPrescriptionScreen()));
                                    break;
                                  case 2:
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                CheckInstantTeleView()));
                                    break;
                                  default:
                                    cubit.scrollToPosition(10000);
                                    break;
                                }
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(
                                        ConstantManger.borderRadius)),
                                child: Column(
                                  children: [
                                    Container(
                                      height: 107.h,
                                      decoration: BoxDecoration(
                                          image: DecorationImage(
                                            fit: BoxFit.fill,
                                            image: AssetImage(
                                              cubit.servicesHomeModel[index]
                                                  .cardImage,
                                            ),
                                          ),
                                          borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(
                                                ConstantManger.borderRadius),
                                            topRight: Radius.circular(
                                                ConstantManger.borderRadius),
                                          )),
                                    ),
                                    const Spacer(),
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        SvgPicture.asset(
                                          cubit.servicesHomeModel[index].image,
                                          height: 12.h,
                                          width: 12.w,
                                        ),
                                        SizedBox(
                                          width: 8.w,
                                        ),
                                        Text(
                                          cubit.servicesHomeModel[index].name,
                                          style: StylesManger.small().copyWith(
                                              color: ColorManger.newPrimary,
                                              fontWeight: FontWeight.w700),
                                          textAlign: TextAlign.start,
                                        )
                                      ],
                                    ),
                                    SizedBox(
                                      height: 4.h,
                                    ),
                                    Text(
                                      cubit
                                          .servicesHomeModel[index].description,
                                      style: StylesManger.extremelySmall()
                                          .copyWith(
                                              color: ColorManger.lightGrey,
                                              fontWeight: FontWeight.w400),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    SizedBox(
                                      height: 16.h,
                                    ),
                                    InkWell(
                                      onTap: () {
                                        switch (index) {
                                          case 0:
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        DepartmentsView()));
                                            break;
                                          case 1:
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        UploadPrescriptionScreen()));
                                            break;
                                          case 2:
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        CheckInstantTeleView()));
                                            break;
                                          default:
                                            cubit.scrollToPosition(10000);
                                            break;
                                        }
                                      },
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Text(
                                            cubit.servicesHomeModel[index]
                                                .btnName,
                                            style: StylesManger.small()
                                                .copyWith(
                                                    color:
                                                        ColorManger.newPrimary,
                                                    fontWeight:
                                                        FontWeight.w700),
                                          ),
                                          SizedBox(
                                            width: 8.w,
                                          ),
                                          Icon(
                                            Icons.arrow_forward,
                                            color: ColorManger.blueBlack,
                                            size: 20,
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: 14.h,
                                    )
                                  ],
                                ),
                              ),
                            )),
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //   children: [
                    //     serviceWidget(3, cubit, () {
                    //       if (token != null) {
                    //         Navigator.push(
                    //             context,
                    //             MaterialPageRoute(
                    //                 builder: (context) =>
                    //                     const DepartmentsView()));
                    //       }
                    //     }, context),
                    //     serviceWidget(1, cubit, () {
                    //       Navigator.push(
                    //           context,
                    //           MaterialPageRoute(
                    //               builder: (context) => LabsView(
                    //                     laboratoryServices: true,
                    //                   )));
                    //     }, context)
                    //   ],
                    // ),
                    // v(16),
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //   children: [
                    //     serviceWidget(0, cubit, () {
                    //       Navigator.push(
                    //           context,
                    //           MaterialPageRoute(
                    //               builder: (context) => InstantTelemedView()));
                    //       //     showDialog(
                    //       //         context: context,
                    //       //         builder: (context) => AlertDialog(
                    //       //           shape: RoundedRectangleBorder(
                    //       //               borderRadius: BorderRadius.all(Radius.circular(10.0))),
                    //       //               buttonPadding: EdgeInsets.zero,
                    //       //               contentPadding: EdgeInsets.symmetric(horizontal: 8.w,vertical: 8.h),
                    //       //               insetPadding: EdgeInsets.zero,
                    //       //               iconPadding: EdgeInsets.zero,
                    //       //               titlePadding: EdgeInsets.zero,
                    //       //               actionsPadding: EdgeInsets.zero,
                    //       //               content:Column(
                    //       //                 mainAxisSize: MainAxisSize.min,
                    //       //                  children: [
                    //       //                  Align(
                    //       //   alignment: AlignmentDirectional.topEnd,
                    //       //   child: InkWell(
                    //       //       onTap: () {
                    //       //         Navigator.pop(context);
                    //       //       },
                    //       //       child: const Icon(Icons.close,color: Colors.grey,)),
                    //       // ),
                    //       //  SizedBox(
                    //       //   height: 22.h,
                    //       // ),
                    //       //                 Container(
                    //       //                   width: double.infinity,
                    //       //                   height: 180.h,
                    //       //                   decoration: BoxDecoration(

                    //       //                     image: DecorationImage(image: AssetImage('assets/images/soon.png'))
                    //       //                   ),
                    //       //                 ),
                    //       //                 SizedBox(height:16.h),
                    //       //                 Container(
                    //       //                   padding: const EdgeInsets.symmetric(
                    //       //                       vertical: 20),
                    //       //                   decoration: BoxDecoration(
                    //       //                       color: Colors.white,
                    //       //                       borderRadius:
                    //       //                           BorderRadius.circular(10)),
                    //       //                   child: Center(
                    //       //                     child: Text(
                    //       //                       "ComingSoon"
                    //       //                           .tr(),
                    //       //                       style: StylesManger.rich().copyWith(
                    //       //                           color: Colors.black,
                    //       //                           fontSize: 16),
                    //       //                     ),
                    //       //                   ),
                    //       //                 )
                    //       //               ],
                    //       // )));
                    //     }, context),
                    //     serviceWidget(2, cubit, () {
                    //       showModalBottomSheet(
                    //           context: context,
                    //           isScrollControlled: true,
                    //           builder: (context) =>
                    //               UploadPrescitiption(cubit: cubit));
                    //     }, context),
                    //   ],
                    // ),

                    // BlocBuilder<OrdersCubit, OrdersState>(
                    //   builder: (context, state) {
                    //     return orderCubit.upcomingAppts.isEmpty
                    //         ? const SizedBox()
                    //         : Column(
                    //             crossAxisAlignment: CrossAxisAlignment.start,
                    //             children: [
                    //               v(24),
                    //               Text(
                    //                 "YourUpcomingAppointments".tr(),
                    //                 style: StylesManger.rich()
                    //                     .copyWith(color: Colors.black),
                    //               ),
                    //               const SizedBox(
                    //                 height: 16,
                    //               ),
                    //               SizedBox(
                    //                 height: 130,
                    //                 child: ListView.separated(
                    //                     scrollDirection: Axis.horizontal,
                    //                     itemBuilder: (context, index) =>
                    //                         UpcomingApptsWidget(
                    //                           appt: orderCubit
                    //                               .upcomingAppts[index],
                    //                         ),
                    //                     separatorBuilder: (context, index) =>
                    //                         const SizedBox(
                    //                           width: 10,
                    //                         ),
                    //                     itemCount:
                    //                         orderCubit.upcomingAppts.length),
                    //               ),
                    //             ],
                    //           );
                    //   },
                    // ),

                    v(56.h),
                    Align(
                      alignment: AlignmentDirectional.center,
                      child: Text(
                        'تعرف أكثر عن تحليلي'.tr(),
                        style: StylesManger.medium().copyWith(
                            fontSize: 24.sp, color: ColorManger.newPrimary),
                      ),
                    ),
                    SizedBox(
                      height: 16.h,
                    ),
                    InkWell(
                      onTap: () {
                        setState(() {
                          _controller.value.isPlaying
                              ? _controller.pause()
                              : _controller.play();
                        });
                      },
                      child: Container(
                        height: 171.h,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(
                              ConstantManger.borderRadius),
                        ),
                        child: _controller.value.isInitialized
                            ? VideoPlayer(_controller)
                            : Text("data"),
                      ),
                    ),
                    v(56.h),
                    Text(
                      'عروض وباقات تحليلي'.tr(),
                      style: StylesManger.medium().copyWith(
                        fontSize: 24.sp,
                      ),
                    ),
                    v(24.h),
                    BlocBuilder<HomeCubit, HomeState>(
                      builder: (context, state) {
                        return Row(
                          children: [
                            ...List.generate(
                                cubit.homeTabs.length,
                                (index) => GestureDetector(
                                      onTap: () {
                                        if (index == 0) {
                                          cubit.chnageHotTabIndicator(0);
                                        } else {
                                          cubit.chnageHotTabIndicator(1);
                                        }
                                      },
                                      child: Container(
                                        margin: EdgeInsetsDirectional.only(
                                            end: 8.w),
                                        padding: EdgeInsets.all(16),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(60.r),
                                            color:
                                                cubit.homeTabIndicator == index
                                                    ? Color(0xff5DB896)
                                                    : Color(0xffF9F9F9)),
                                        child: Center(
                                          child: Text(
                                            cubit.homeTabs[index],
                                            style: StylesManger.small().copyWith(
                                                color: cubit.homeTabIndicator ==
                                                        index
                                                    ? Colors.white
                                                    : ColorManger.lightGrey,
                                                fontWeight: FontWeight.w700),
                                          ),
                                        ),
                                      ),
                                    ))
                          ],
                        );
                      },
                    ),
                    SizedBox(
                      height: 24.h,
                    ),
                    // categoryHeader(
                    //     header: 'DealToday'.tr(),
                    //     onTap: () {
                    //       Navigator.push(
                    //           context,
                    //           MaterialPageRoute(
                    //               builder: (context) =>
                    //                   WeaklyDelasView(deals: cubit.deals)));
                    //     }),
                    // v(16),
                    BlocBuilder<HomeCubit, HomeState>(
                      builder: (context, state) {
                        return Column(
                          children: [
                            if (cubit.homeTabIndicator == 0)
                              cubit.deals.isNotEmpty
                                  ? GridView.builder(
                                      physics: NeverScrollableScrollPhysics(),
                                      shrinkWrap: true,
                                      itemCount: cubit.deals.length,
                                      gridDelegate:
                                          SliverGridDelegateWithFixedCrossAxisCount(
                                              crossAxisCount: 2,
                                              mainAxisExtent: 212.h,
                                              mainAxisSpacing: 24.h,
                                              crossAxisSpacing: 24.w),
                                      itemBuilder: (context, index) =>
                                          HomeNewCard(
                                            testId: null,
                                            partnerId:
                                                cubit.deals[index].partnerId!,
                                            discount: cubit.deals[index]
                                                .priceBeforeDiscount,
                                            packageId:
                                                cubit.deals[index].packageId!,
                                            labName:
                                                context.locale.languageCode ==
                                                        'ar'
                                                    ? cubit.deals[index]
                                                        .partner!.nameAr!
                                                    : cubit.deals[index]
                                                        .partner!.nameEn!,
                                            labImage: cubit
                                                .deals[index].partner!.image!,
                                            image: context
                                                        .locale.languageCode ==
                                                    'ar'
                                                ? cubit.deals[index].imageAR!
                                                : cubit.deals[index].imageEN!,
                                            packageName: cubit
                                                .deals[index].package!.nameAr!,
                                            description: "",
                                            price: cubit.deals[index].price!,
                                          ))
                                  : const Center(
                                      child: CircularProgressIndicator()),
                            if (cubit.homeTabIndicator == 1)
                              cubit.tahliliPackages.isNotEmpty
                                  ? GridView.builder(
                                      physics: NeverScrollableScrollPhysics(),
                                      shrinkWrap: true,
                                      itemCount: cubit.tahliliPackages.length,
                                      gridDelegate:
                                          SliverGridDelegateWithFixedCrossAxisCount(
                                              crossAxisCount: 2,
                                              mainAxisExtent: 230.h,
                                              mainAxisSpacing: 24.h,
                                              crossAxisSpacing: 24.w),
                                      itemBuilder: (context, index) =>
                                          HomeNewCard(
                                            testId: null,
                                            partnerId: cubit
                                                .tahliliPackages[index]
                                                .partnerId!,
                                            discount: cubit
                                                .tahliliPackages[index]
                                                .priceBeforeDiscount,
                                            packageId: cubit
                                                .tahliliPackages[index]
                                                .partnerItemId!,
                                            labName:
                                                context.locale.languageCode ==
                                                        'ar'
                                                    ? cubit
                                                        .tahliliPackages[index]
                                                        .partnerNameAr!
                                                    : cubit
                                                        .tahliliPackages[index]
                                                        .partnerNameEn!,
                                            labImage: cubit
                                                .tahliliPackages[index]
                                                .partnerImage!,
                                            image: cubit.tahliliPackages[index]
                                                        .imageAR !=
                                                    null
                                                ? context.locale.languageCode ==
                                                        'ar'
                                                    ? cubit
                                                        .tahliliPackages[index]
                                                        .imageAR!
                                                    : cubit
                                                        .tahliliPackages[index]
                                                        .imageEN!
                                                : cubit.tahliliPackages[index]
                                                    .image!,
                                            packageName: cubit
                                                .tahliliPackages[index].nameAr!,
                                            description: cubit
                                                .tahliliPackages[index]
                                                .description,
                                            price: cubit
                                                .tahliliPackages[index].price!,
                                          ))
                                  : const Center(
                                      child: CircularProgressIndicator()),
                          ],
                        );
                      },
                    ),
                    v(56.h),
                    Row(
                      children: [
                        Container(
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(60.r),
                              color: Color(0xffE3F5FD)),
                          child: Center(
                            child: Text(
                              "تحاليل الجينات الوراثية",
                              style: StylesManger.small()
                                  .copyWith(fontWeight: FontWeight.w700),
                            ),
                          ),
                        ),
                      ],
                    ),
                    v(24.h),
                    BlocBuilder<HomeCubit, HomeState>(
                      builder: (context, state) {
                        return cubit.genetics.isNotEmpty
                            ? GridView.builder(
                                physics: NeverScrollableScrollPhysics(),
                                shrinkWrap: true,
                                itemCount: cubit.genetics.length,
                                gridDelegate:
                                    SliverGridDelegateWithFixedCrossAxisCount(
                                        crossAxisCount: 2,
                                        mainAxisExtent: 230.h,
                                        mainAxisSpacing: 24.h,
                                        crossAxisSpacing: 24.w),
                                itemBuilder: (context, index) => HomeNewCard(
                                      testId: cubit.genetics[index].itemId,
                                      partnerId:
                                          cubit.genetics[index].partnerId!,
                                      discount: cubit
                                          .genetics[index].priceBeforeDiscount,
                                      packageId: cubit.genetics[index].itemId!,
                                      labName: context.locale.languageCode ==
                                              'ar'
                                          ? cubit.genetics[index].partnerNameAr!
                                          : cubit
                                              .genetics[index].partnerNameEn!,
                                      labImage:
                                          cubit.genetics[index].partnerImage!,
                                      image: cubit.genetics[index].image!,
                                      packageName:
                                          cubit.genetics[index].nameAr!,
                                      description:
                                          cubit.genetics[index].description!,
                                      price: cubit.genetics[index].price!,
                                    ))
                            : const Center(child: CircularProgressIndicator());
                      },
                    ),
                    v(56.h),
                    Text(
                      "جميع اقسام التحاليل والباقات",
                      style: StylesManger.medium().copyWith(fontSize: 24.sp),
                    ),
                    v(24),
                    BlocBuilder<HomeCubit, HomeState>(
                      builder: (context, state) {
                        return cubit.categories.isNotEmpty
                            ? GridView.builder(
                                shrinkWrap: true,
                                physics: NeverScrollableScrollPhysics(),
                                itemCount: cubit.arCategories.length,
                                gridDelegate:
                                    SliverGridDelegateWithFixedCrossAxisCount(
                                        crossAxisSpacing: 8.w,
                                        mainAxisSpacing: 8.h,
                                        crossAxisCount: 2,
                                        mainAxisExtent: 170.h),
                                itemBuilder: (context, index) => CategoryWidget(
                                    image: cubit.homeCatgoryModel[index].image,
                                    color: cubit.homeCatgoryModel[index].color,
                                    categoryName:
                                        context.locale.languageCode == 'ar'
                                            ? cubit.arCategories[index]
                                            : cubit.enCategories[index],
                                    categories: cubit.categories[index]))
                            : const Center(child: CircularProgressIndicator());
                      },
                    ),
                    SizedBox(
                      height: 56.h,
                    ),

                    Text(
                      'جميع المختبرات'.tr(),
                      style: StylesManger.medium().copyWith(fontSize: 24.sp),
                    ),
                    v(16),
                    BlocBuilder<HomeCubit, HomeState>(
                      builder: (context, state) {
                        return cubit.homeLabs.isNotEmpty
                            ? SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                child: Row(
                                  children: [
                                    ...List.generate(
                                        cubit.homeLabs.length,
                                        (index) => LabsWidget(
                                            homeLabs: cubit.homeLabs[index]))
                                  ],
                                ),
                              )
                            : const Center(child: CircularProgressIndicator());
                      },
                    ),
                    // v(24),
                    // categoryHeader(
                    //     header: 'MostRequestedPackages'.tr(), onTap: () {}),
                    // v(16),
                    // BlocBuilder<HomeCubit, HomeState>(
                    //   builder: (context, state) {
                    //     return cubit.categories.isNotEmpty
                    //         ? SingleChildScrollView(
                    //             scrollDirection: Axis.horizontal,
                    //             child: Row(
                    //               children: [
                    //                 ...List.generate(cubit.categories.length,
                    //                     (index) {
                    //                   final List<String> names = cubit
                    //                       .categories[index].name!
                    //                       .split(" ~ ");
                    //                   return InkWell(
                    //                     onTap: () {
                    //                       cubit.setCategoryIndex(index);
                    //                     },
                    //                     child: Container(
                    //                       padding: const EdgeInsets.symmetric(
                    //                           horizontal: 20),
                    //                       margin:
                    //                           const EdgeInsetsDirectional.only(
                    //                               end: 10),
                    //                       height: 45,
                    //                       decoration: BoxDecoration(
                    //                           color:
                    //                               cubit.categoryIndex == index
                    //                                   ? ColorManger.primary
                    //                                   : Colors.white,
                    //                           borderRadius:
                    //                               BorderRadius.circular(20),
                    //                           border: Border.all(
                    //                               color: ColorManger.primary,
                    //                               width: 1.5)),
                    //                       child: Center(
                    //                         child: Text(
                    //                           names[0],
                    //                           style: StylesManger.medium()
                    //                               .copyWith(
                    //                                   color:
                    //                                       cubit.categoryIndex ==
                    //                                               index
                    //                                           ? Colors.white
                    //                                           : ColorManger
                    //                                               .primary),
                    //                         ),
                    //                       ),
                    //                     ),
                    //                   );
                    //                 })
                    //               ],
                    //             ),
                    //           )
                    //         : const Center(
                    //             child: CircularProgressIndicator(),
                    //           );
                    //   },
                    // ),
                    // v(16),
                    // BlocBuilder<HomeCubit, HomeState>(
                    //   builder: (context, state) {
                    //     return cubit.homePackages.isNotEmpty
                    //         ? SizedBox(
                    //             height: 150,
                    //             child: ListView.builder(
                    //                 scrollDirection: Axis.horizontal,
                    //                 itemCount: cubit.homePackages.length,
                    //                 itemBuilder: (context, index) => InkWell(
                    //                       onTap: () {
                    //                         cubit.itemsCompare(
                    //                             itemId: cubit
                    //                                 .homePackages[index].id!);
                    //                       },
                    //                       child: PackagesWidget(
                    //                           homePackage:
                    //                               cubit.homePackages[index]),
                    //                     )))
                    //         : const Center(child: CircularProgressIndicator());
                    //   },
                    // ),
                    // if (token != null)
                    //   Column(
                    //     crossAxisAlignment: CrossAxisAlignment.start,
                    //     children: [
                    //       v(24),
                    //       categoryHeader(
                    //           header: 'RecommendedPackages'.tr(), onTap: () {}),
                    //       v(16),
                    //       BlocBuilder<HomeCubit, HomeState>(
                    //         builder: (context, state) {
                    //           return cubit.recommendedPackage.isNotEmpty
                    //               ? SizedBox(
                    //                   height: 150,
                    //                   child: ListView.builder(
                    //                       scrollDirection: Axis.horizontal,
                    //                       itemCount:
                    //                           cubit.recommendedPackage.length,
                    //                       itemBuilder: (context, index) =>
                    //                           UserPackageWidget(
                    //                               userPackages:
                    //                                   cubit.recommendedPackage[
                    //                                       index])))
                    //               : const Center(
                    //                   child: CircularProgressIndicator());
                    //         },
                    //       ),
                    //       v(24),
                    //       categoryHeader(
                    //           header: 'TailoredPackages'.tr(), onTap: () {}),
                    //       v(16),
                    //       BlocBuilder<HomeCubit, HomeState>(
                    //         builder: (context, state) {
                    //           return cubit.trailordPackage.isNotEmpty
                    //               ? SizedBox(
                    //                   height: 150,
                    //                   child: ListView.builder(
                    //                       scrollDirection: Axis.horizontal,
                    //                       itemCount:
                    //                           cubit.trailordPackage.length,
                    //                       itemBuilder: (context, index) =>
                    //                           UserPackageWidget(
                    //                               userPackages:
                    //                                   cubit.recommendedPackage[
                    //                                       index])))
                    //               : const Center(
                    //                   child: CircularProgressIndicator());
                    //         },
                    //       ),
                    //     ],
                    //   ),
                    v(24),
                    // Container(
                    //   margin:
                    //       const EdgeInsetsDirectional.only(end: 16, bottom: 10),
                    //   height: 200,
                    //   width: double.infinity,
                    //   decoration: BoxDecoration(
                    //       image: const DecorationImage(
                    //           image: AssetImage('assets/images/slider2.png'),
                    //           fit: BoxFit.fill),
                    //       borderRadius: BorderRadius.circular(10)),
                    // )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget categoryHeader({required String header, required VoidCallback onTap}) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            header,
            style: StylesManger.rich().copyWith(color: Colors.black),
          ),
          GestureDetector(
            onTap: onTap,
            child: Text(
              "ViewAll".tr(),
              style: StylesManger.medium().copyWith(
                  decoration: TextDecoration.underline,
                  color: ColorManger.buttonColor),
            ),
          )
        ],
      ),
    );
  }

  Widget serviceWidget(
      int index, HomeCubit cubit, VoidCallback onTap, BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 10.w),
        decoration: BoxDecoration(
          border: Border.all(color: Color(0xffAEB1B6)),
          color: Color(0xff),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage(cubit.servicesImages[index])),
              ),
            ),
            const SizedBox(
              width: 6,
            ),
            SizedBox(
              width: 100.w,
              child: Text(
                context.locale.languageCode == 'ar'
                    ? cubit.arServices[index]
                    : cubit.enServices[index],
                style: StylesManger.medium().copyWith(color: Color(0xff242B60)),
              ),
            )
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    context.read<HomeCubit>().scrollController.dispose();
    super.dispose();
  }
}
