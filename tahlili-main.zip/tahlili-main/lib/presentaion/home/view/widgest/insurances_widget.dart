import 'package:flutter/material.dart';

import '../../../../data/response/home/response_home.dart';

class InsurancesWidget extends StatelessWidget {
  final List<ResponseInsurance> insurances;
  const InsurancesWidget({super.key, required this.insurances});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 80,
      width: double.infinity,
      child: ListView.separated(
        shrinkWrap: true,
        scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) => Text(insurances[index].nameEn??''),
          separatorBuilder: (context, index) => const SizedBox(
                width: 10,
              ),
          itemCount: insurances.length),
    );
  }
}
