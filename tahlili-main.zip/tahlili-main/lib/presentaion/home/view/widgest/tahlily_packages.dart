import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/data/requests/wishlist/request_wishlist.dart';
import 'package:tahlili/presentaion/resources/shared/app_button.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';
import 'package:tahlili/presentaion/wishlist/cubit/wishlist_cubit.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../../data/requests/order/request_order.dart';
import '../../../../data/response/home/response_home.dart';
import '../../../account/cubit/account_cubit.dart';
import '../../../resources/color_manger.dart';
import '../../../resources/shared/quick_order_dialog.dart';
import '../../../resources/shared/view_details.dart';
import '../../cubit/home_cubit.dart';
import '../../page/compare_view.dart';

class TahlilyPackage extends StatelessWidget {
  final ResponseSearch tahliliPackage;
  const TahlilyPackage({
    super.key,
    required this.tahliliPackage,
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsetsDirectional.only(end: 10),
      width: 129.w,
      decoration: BoxDecoration(
          border: Border.all(color: ColorManger.grey),
          color: Colors.white,
          borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            height: 68.h,
            child: Stack(
              children: [
                GestureDetector(
                  onTap: () {
                    context
                        .read<HomeCubit>()
                        .getShownDealsDetails(itemId: tahliliPackage.itemId!)
                        .whenComplete(() => showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                                  actionsPadding: EdgeInsets.zero,
                                  actions: [
                                    ViewDetailsWidget(
                                        fromCart: false,
                                        deals: context
                                            .read<HomeCubit>()
                                            .dealsDetails
                                            .first)
                                  ],
                                )));
                  },
                  child: Container(
                    width: 129.w,
                    decoration: BoxDecoration(
                        borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10)),
                        image: DecorationImage(
                            fit: BoxFit.fitWidth,
                            image: tahliliPackage.imageAR != null
                                ? CachedNetworkImageProvider(
                                    EndPoints.baseImageUrl +
                                        (context.locale.languageCode == 'ar'
                                            ? tahliliPackage.imageAR!
                                            : tahliliPackage.imageEN!))
                                : CachedNetworkImageProvider(
                                    EndPoints.baseImageUrl +
                                        (tahliliPackage.image!)))),
                  ),
                ),
                PositionedDirectional(
                    top: 0, end: 10, child: homePopUp(context)),
                PositionedDirectional(
                    bottom: 0,
                    end: 5,
                    child: GestureDetector(
                      onTap: () {
                        showDialog(
                            context: context,
                            builder: (context) => QuickOrderDialog(
                                  orderData: RequestOrderData(
                                      tahliliPackage.partnerId!,
                                      tahliliPackage.nameEn!,
                                      tahliliPackage.price!,
                                      tahliliPackage.partnerItemId!,
                                      false),
                                ));
                      },
                      child: CircleAvatar(
                        radius: 12.r,
                        backgroundColor: Colors.white,
                        child: Center(
                          child: SvgPicture.asset(
                            'assets/images/shopping_cart.svg',
                            height: 11.h,
                            width: 12.w,
                          ),
                        ),
                      ),
                    ))
              ],
            ),
          ),
          SizedBox(
            height: 4.h,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      context
                          .read<HomeCubit>()
                          .getShownDealsDetails(itemId: tahliliPackage.itemId!)
                          .whenComplete(() => showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                    actionsPadding: EdgeInsets.zero,
                                    actions: [
                                      ViewDetailsWidget(
                                          fromCart: false,
                                          deals: context
                                              .read<HomeCubit>()
                                              .dealsDetails
                                              .first)
                                    ],
                                  )));
                    },
                    child: Text(
                      context.locale.languageCode == 'ar'
                          ? tahliliPackage.nameAr!
                          : tahliliPackage.nameEn!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: StylesManger.rich()
                          .copyWith(color: Colors.black, fontSize: 12.sp),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 4.h,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(
              tahliliPackage.price != null
                  ? "${tahliliPackage.price} ${"SAR".tr()}"
                  : '',
              style: StylesManger.medium().copyWith(
                color: ColorManger.primary,
              ),
            ),
          ),
          SizedBox(
            height: 4.h,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: SizedBox(
              height: 27.h,
              child: AppButton(
                  radius: 24.r,
                  textSize: 10.sp,
                  color: ColorManger.primary,
                  name: "OrderNow".tr(),
                  onPressed: () {
                    showDialog(
                        context: context,
                        builder: (context) => QuickOrderDialog(
                              orderData: RequestOrderData(
                                  tahliliPackage.partnerId!,
                                  tahliliPackage.nameEn!,
                                  tahliliPackage.price!,
                                  tahliliPackage.partnerItemId!,
                                  false),
                            ));
                  }),
            ),
          ),
          SizedBox(
            height: 8.h,
          ),
        ],
      ),
    );
  }

  Widget homePopUp(
    BuildContext context,
  ) {
    return Theme(
      data: Theme.of(context).copyWith(
          cardColor: Colors.white,
          popupMenuTheme: const PopupMenuThemeData(
            color: Colors.white,
            elevation: 0,
          )),
      child: PopupMenuButton(
        padding: const EdgeInsets.only(bottom: 20),

        // color: Colors.black,
        position: PopupMenuPosition.under,
        iconSize: 30,
        icon: const Icon(
          FontAwesomeIcons.ellipsisH,
          color: Colors.black,
        ),

        itemBuilder: (context) {
          return [
            PopupMenuItem(
              value: 0,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.remove_red_eye_outlined,
                      color: Colors.black,
                    ),
                    title: Text(
                      "ViewDetails".tr(),
                    ),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 1,
                    width: double.infinity,
                    color: ColorManger.grey,
                  )
                ],
              ),
            ),
            PopupMenuItem(
              value: 1,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.compare_arrows_rounded,
                      color: Colors.black,
                    ),
                    title: Text("Compare".tr()),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 1,
                    width: double.infinity,
                    color: ColorManger.grey,
                  )
                ],
              ),
            ),
            PopupMenuItem(
              value: 2,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.favorite_border,
                      color: Colors.black,
                    ),
                    title: Text("Add to WishList".tr()),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 1,
                    width: double.infinity,
                    color: ColorManger.grey,
                  )
                ],
              ),
            ),
          ];
        },
        onSelected: (value) async {
          switch (value) {
            case 0:
              context
                  .read<HomeCubit>()
                  .getShownDealsDetails(itemId: tahliliPackage.partnerItemId!)
                  .whenComplete(() => showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                            actionsPadding: EdgeInsets.zero,
                            actions: [
                              ViewDetailsWidget(
                                  fromCart: false,
                                  deals: context
                                      .read<HomeCubit>()
                                      .dealsDetails
                                      .first)
                            ],
                          )));

              break;
            case 1:
              context
                  .read<HomeCubit>()
                  .itemsCompare(
                      itemId: tahliliPackage.partnerItemId!, itemType: 4)
                  .whenComplete(() => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const CompareView())));

              break;

            case 2:
              context.read<WishlistCubit>().addToWishlit(
                      wishlist: RequestWishlist(
                    context.read<AccountCubit>().userModel!.entityId!,
                    tahliliPackage.partnerItemId,
                    null,
                  ));

              break;
          }
        },
      ),
    );
  }
}
