import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/data/response/home/response_home.dart';

import '../../../../app/end_points.dart';
import '../../../resources/color_manger.dart';
import '../../../resources/styles_manger.dart';

class IndvidualTestsWidget extends StatelessWidget {
  const IndvidualTestsWidget({super.key, required this.test, required this.testName});
  final ResponseIndividualTests test;
  final String testName;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 129.w,
     
      decoration: BoxDecoration(
        border: Border.all(
          color: ColorManger.grey
        ),
        borderRadius: BorderRadius.circular(10)
      ),
      child: Column(
         mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: 97.h,
            width:double.infinity,
            decoration: BoxDecoration(
              borderRadius:const BorderRadius.only(
                topLeft: Radius.circular(10),
                topRight: Radius.circular(10)
              ),
              image: DecorationImage(
                fit: BoxFit.fitWidth,
                image: CachedNetworkImageProvider(EndPoints.baseImageUrl+test.image!))
            ),
          ),
          SizedBox(height: 15.h,),
          Container(
            height: 40.h,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(testName,style: StylesManger.rich().copyWith(
              color: ColorManger.buttonColor,
              fontSize: 12
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            ),
          ),
         
        ],
      ),
    );
  }
}