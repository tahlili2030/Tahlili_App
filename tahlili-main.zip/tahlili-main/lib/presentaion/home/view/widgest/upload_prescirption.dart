import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';

import '../../../resources/color_manger.dart';
import '../../../resources/shared/app_button.dart';
import '../../../resources/shared/shared_widgets.dart';
import '../../../resources/strings_manager.dart';
import '../../../resources/styles_manger.dart';
import '../../../resources/validation_manager.dart';
import '../../cubit/home_cubit.dart';

class UploadPrescitiption extends StatelessWidget {
  const UploadPrescitiption({
    super.key,
    required this.cubit,
  });

  final HomeCubit cubit;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: BlocBuilder<HomeCubit, HomeState>(
        builder: (context, state) {
          return Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              width: double.infinity,
              decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20))),
              child: Form(
                key: cubit.prescriptionKey,
                child: BlocBuilder<AccountCubit, AccountState>(
                  builder: (context, state) {
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const SizedBox(
                          height: 16,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10.0),
                          child: Container(
                            width: 40,
                            height: 5,
                            decoration: BoxDecoration(
                              color: Colors.grey[400],
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 16,
                        ),
                        Text(
                          "Upload Lab Test Request",
                          style:
                              StylesManger.rich().copyWith(color: Colors.black),
                        ),
                        const SizedBox(
                          height: 32,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Upload File",
                              style: StylesManger.rich()
                                  .copyWith(color: Colors.black),
                            ),
                            const SizedBox(
                              height: 8,
                            ),
                            InkWell(
                              onTap: () async {
                                showModalBottomSheet(
                                    context: context,
                                    isScrollControlled: true,
                                    builder: (context) => Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 16),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              SizedBox(
                                                height: 16,
                                              ),
                                              GestureDetector(
                                                onTap: () {
                                                  context
                                                      .read<AccountCubit>()
                                                      .pickImage(
                                                          ImageSource.camera);
                                                },
                                                child: Text(
                                                  "Camera",
                                                  style: StylesManger.rich()
                                                      .copyWith(
                                                          color: Colors.black),
                                                ),
                                              ),
                                              SizedBox(
                                                height: 8,
                                              ),
                                              Container(
                                                height: 2,
                                                width: double.infinity,
                                                color: ColorManger.grey,
                                              ),
                                              SizedBox(
                                                height: 8,
                                              ),
                                              GestureDetector(
                                                onTap: () {
                                                  context
                                                      .read<AccountCubit>()
                                                      .pickImage(
                                                          ImageSource.gallery);
                                                },
                                                child: Text(
                                                  "Gallery",
                                                  style: StylesManger.rich()
                                                      .copyWith(
                                                          color: Colors.black),
                                                ),
                                              ),
                                              SizedBox(
                                                height: 16,
                                              ),
                                            ],
                                          ),
                                        ));
                              },
                              child: Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border:
                                        Border.all(color: ColorManger.grey)),
                                child: Row(
                                  children: [
                                    Container(
                                      height: 40,
                                      width: 85,
                                      decoration: const BoxDecoration(
                                        color: Color(0xffDFE0E2),
                                      ),
                                      child: Center(
                                        child: Text(
                                          "Choose file",
                                          style: StylesManger.medium()
                                              .copyWith(color: Colors.black),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      context.read<AccountCubit>().image != null
                                          ? "A file has been choosen"
                                          : "No file chosen",
                                      style: StylesManger.rich()
                                          .copyWith(color: Colors.black),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 24,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(
                              width: 180,
                              child: AppButton(
                                  radius: 30,
                                  color: ColorManger.primary,
                                  name: "Submit",
                                  onPressed: () {
                                    // context
                                    //     .read<AccountCubit>()
                                    //     .addPrescription(
                                    //       languageCode: context.locale.languageCode
                                    //     )
                                    //     .whenComplete(
                                    //         () => Navigator.pop(context));
                                  }),
                            ),
                            SizedBox(
                              width: 180,
                              child: AppButton(
                                  radius: 30,
                                  textColor: ColorManger.primary,
                                  color: Colors.white,
                                  name: "Cancel",
                                  onPressed: () {
                                    Navigator.pop(context);
                                  }),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 30,
                        )
                      ],
                    );
                  },
                ),
              ));
        },
      ),
    );
  }
}
