import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';

import '../../../../data/response/home/response_home.dart';
import '../../page/categoryItem_view.dart';

class CategoryWidget extends StatelessWidget {
  final ResponseHomeCategory categories;
  final String categoryName;
  final String image;
  final Color color;
  const CategoryWidget(
      {super.key,
      required this.categories,
      required this.categoryName,
      required this.image,
      required this.color});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => CategoryItemView(
                      categoryName: categoryName,
                      categoryId: categories.id!,
                    )));
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        width: 160.w,
        decoration: BoxDecoration(
            border: Border.all(color: ColorManger.lightBlack),
            borderRadius: BorderRadius.circular(ConstantManger.borderRadius)),
        child: Column(
          children: [
            SizedBox(
              height: 37.h,
            ),
            CircleAvatar(
              radius: 45.r,
              backgroundColor: Color(0xffF5F5F5),
              child: Center(
                child: SvgPicture.asset(
                  image,
                  color: color,
                  width: 40.w,
                  height: 32.h,
                ),
              ),
            ),
            SizedBox(
              height: 8.h,
            ),
            Text(
              categoryName,
              style: StylesManger.small()
                  .copyWith(fontWeight: FontWeight.w700, color: color),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
