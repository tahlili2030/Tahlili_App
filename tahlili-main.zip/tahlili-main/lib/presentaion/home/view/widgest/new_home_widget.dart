import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/data/requests/order/request_order.dart';
import 'package:tahlili/data/requests/wishlist/request_wishlist.dart';
import 'package:tahlili/presentaion/page_details/cubit/page_details_cubit.dart';
import 'package:tahlili/presentaion/page_details/page_details.dart';
import 'package:tahlili/presentaion/resources/color_manger.dart';
import 'package:tahlili/presentaion/resources/constant_manger.dart';
import 'package:tahlili/presentaion/resources/styles_manger.dart';
import 'package:tahlili/presentaion/wishlist/cubit/wishlist_cubit.dart';

import '../../cubit/home_cubit.dart';
import '../../page/compare_view.dart';

class HomeNewCard extends StatelessWidget {
  HomeNewCard(
      {super.key,
      required this.image,
      required this.testId,
      required this.partnerId,
      required this.labImage,
      required this.labName,
      required this.packageName,
      required this.description,
      required this.price,
      required this.discount,
      required this.packageId,
      this.fromWishList = false});
  final String? image;
  final String? labImage;
  final String labName;
  final String packageName;
  final String? description;
  final double price;
  final double? discount;
  final int? packageId;
  final int? testId;
  final int partnerId;
  bool fromWishList;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        print(packageId);
        log(packageName);
        context
            .read<HomeCubit>()
            .getShownDealsDetails(itemId: packageId!)
            .whenComplete(() {
          context.read<PageDetailsCubit>().clearData();
          context.read<PageDetailsCubit>().orderData = RequestOrderData(
              partnerId,
              packageName,
              price,
              testId == null ? packageId! : testId!,
              testId == null ? false : true);

          Navigator.push(context,
              MaterialPageRoute(builder: (context) => PageDetailsView()));
        });
      },
      child: Container(
        padding: EdgeInsets.all(8),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(ConstantManger.borderRadius)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (image != null)
              SizedBox(
                height: 88.h,
                width: double.infinity,
                child: Stack(
                  children: [
                    Container(
                      height: 88.h,
                      width: double.infinity,
                      decoration: BoxDecoration(

                          // borderRadius: BorderRadius.circular(0.r),
                          image: DecorationImage(
                              fit: BoxFit.fill,
                              image: CachedNetworkImageProvider(
                                  EndPoints.baseImageUrl + image!))),
                    ),
                    PositionedDirectional(
                        top: 0.h,
                        start: 0.w,
                        child: BlocBuilder<WishlistCubit, WishlistState>(
                          builder: (context, state) {
                            return state is LoadAddToWishlistState
                                ? Center(
                                    child: CircularProgressIndicator(
                                      // value: 15.r,
                                      color: ColorManger.newPrimary,
                                    ),
                                  )
                                : GestureDetector(
                                    onTap: () {
                                      if (fromWishList) {
                                        context
                                            .read<WishlistCubit>()
                                            .deleteWishlistItem(
                                                itemId: packageId!);
                                      } else {
                                        context
                                            .read<WishlistCubit>()
                                            .addToWishlit(
                                                wishlist: RequestWishlist(
                                              12,
                                              packageId,
                                              testId,
                                            ));
                                      }
                                    },
                                    child: CircleAvatar(
                                      radius: 15.r,
                                      backgroundColor: Color(0xffedfcff),
                                      child: Icon(
                                        Icons.favorite_border,
                                        color: ColorManger.newPrimary,
                                        size: 20,
                                      ),
                                    ),
                                  );
                          },
                        ))
                  ],
                ),
              ),
            SizedBox(
              height: 8.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                if (labImage != null)
                  CircleAvatar(
                    radius: 8.r,
                    backgroundImage: CachedNetworkImageProvider(
                        EndPoints.baseImageUrl + labImage!),
                  ),
                if (labImage != null)
                  SizedBox(
                    width: 8.w,
                  ),
                Text(
                  labName,
                  style: StylesManger.extremelySmall().copyWith(
                      fontWeight: FontWeight.w400, color: Color(0xff556b78)),
                )
              ],
            ),
            SizedBox(
              height: 8.h,
            ),
            Text(
              packageName,
              style: StylesManger.extremelySmall(),
              maxLines: 1,
            ),
            SizedBox(
              height: 8.h,
            ),
            description != null
                ? Text(
                    description!,
                    style: StylesManger.extremelySmall().copyWith(
                        fontWeight: FontWeight.w400,
                        color: ColorManger.lightGrey),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  )
                : SizedBox(
                    height: 10.h,
                  ),
            SizedBox(
              height: 8.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.device_thermostat_outlined,
                          color: Colors.black,
                          size: 10.sp,
                        ),
                        SizedBox(
                          width: 1,
                        ),
                        Text(
                          "عدد التحاليل",
                          style: StylesManger.extremelySmall()
                              .copyWith(color: ColorManger.blueBlack),
                        )
                      ],
                    ),
                    Text(
                      "8 تحاليل",
                      style: StylesManger.extremelySmall()
                          .copyWith(color: ColorManger.newPrimary),
                    )
                  ],
                ),
                Column(
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.watch_later_outlined,
                          color: Colors.black,
                          size: 10.sp,
                        ),
                        SizedBox(
                          width: 3,
                        ),
                        Text(
                          "مده استلام النتيجه",
                          style: StylesManger.extremelySmall()
                              .copyWith(color: ColorManger.blueBlack),
                        )
                      ],
                    ),
                    Text(
                      "24 ساعه",
                      style: StylesManger.extremelySmall()
                          .copyWith(color: ColorManger.newPrimary),
                    )
                  ],
                ),
              ],
            ),
            SizedBox(
              height: 8.h,
            ),
            Row(
              children: [
                Column(
                  children: [
                    if (discount != null && discount != 0)
                      Text("${discount!.round()} ${"SAR".tr()}",
                          style: StylesManger.extremelySmall().copyWith(
                            fontSize: 12.sp,
                            color: ColorManger.lightGrey,
                            decoration: TextDecoration.lineThrough,
                          )),
                    Text("${price.round()} ${"SAR".tr()}",
                        style: StylesManger.extremelySmall().copyWith(
                          fontSize: 12.sp,
                          color: ColorManger.newPrimary,
                        )),
                  ],
                ),
                const Spacer(),
                InkWell(
                  onTap: () {
                    context
                        .read<HomeCubit>()
                        .itemsCompare(itemId: packageId!, itemType: 4)
                        .whenComplete(() => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const CompareView())));
                  },
                  child: Container(
                    padding: EdgeInsets.all(10),
                    height: 25.h,
                    width: 30.w,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.circular(ConstantManger.borderRadius),
                      color: Color(0xffEDFCFF),
                    ),
                    child: Center(
                        child: SvgPicture.asset(
                      'assets/images/home/compare.svg',
                      height: 20.h,
                      width: 20.w,
                    )),
                  ),
                ),
                SizedBox(
                  width: 8.w,
                ),
                GestureDetector(
                  onTap: () {
                    print(packageId);
                    log(packageName);
                    context
                        .read<HomeCubit>()
                        .getShownDealsDetails(itemId: packageId!)
                        .whenComplete(() {
                      context.read<PageDetailsCubit>().clearData();
                      context.read<PageDetailsCubit>().orderData =
                          RequestOrderData(
                              partnerId,
                              packageName,
                              price,
                              testId == null ? packageId! : testId!,
                              testId == null ? false : true);

                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => PageDetailsView()));
                    });
                  },
                  child: Container(
                    padding: EdgeInsets.all(10),
                    height: 25.h,
                    width: 30.w,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.circular(ConstantManger.borderRadius),
                      color: Color(0xff00A1B0),
                    ),
                    child: Center(
                      child: Icon(
                        Icons.shopping_cart_outlined,
                        color: Colors.white,
                        size: 15,
                      ),
                    ),
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
