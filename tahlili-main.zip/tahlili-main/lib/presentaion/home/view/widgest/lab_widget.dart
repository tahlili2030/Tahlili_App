import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/presentaion/home/cubit/home_cubit.dart';
import 'package:tahlili/presentaion/home/page/search_view.dart';

import '../../../../data/response/home/response_home.dart';
import '../../../resources/color_manger.dart';
import '../../../resources/shared/partners_lab.dart';
import '../../../resources/styles_manger.dart';

class LabsWidget extends StatelessWidget {
  final ResponseHomeLabs homeLabs;
  const LabsWidget({super.key, required this.homeLabs});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        context
            .read<HomeCubit>()
            .getPartnerCount(partnerId: homeLabs.id!)
            .whenComplete(() {
          showDialog(
              context: context,
              builder: (context) => AlertDialog(
                    actionsPadding: EdgeInsets.zero,
                    actions: [
                      PartnerDialog(
                        labName: context.locale.languageCode == 'ar'
                            ? homeLabs.nameAr!
                            : homeLabs.nameEn!,
                        labImage: homeLabs.image!,
                        nOfPackages: context
                            .read<HomeCubit>()
                            .partnerCount!
                            .packageCount!,
                        nOftests:
                            context.read<HomeCubit>().partnerCount!.testCount!,
                        packageBtn: () {
                          context.read<HomeCubit>().filterQuery =
                              '(PartnerId=${homeLabs.id})&&(ItemType="Package")';
                          Navigator.pop(context);
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => SearchView()));
                          context
                              .read<HomeCubit>()
                              .getHomeSearch()
                              .whenComplete(() {});
                        },
                        testBtn: () {
                          context.read<HomeCubit>().filterQuery =
                              '(PartnerId=${homeLabs.id})&&(ItemType="Test")';
                          Navigator.pop(context);
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => SearchView()));
                          context
                              .read<HomeCubit>()
                              .getHomeSearch()
                              .whenComplete(() {});
                        },
                      )
                    ],
                  ));
        });
      },
      child: Container(
        margin: const EdgeInsetsDirectional.only(end: 10),
        padding: const EdgeInsets.all(8),
        width: 220.w,
        decoration: BoxDecoration(
            border: Border.all(color: ColorManger.lightBlack),
            color: Colors.white,
            borderRadius: BorderRadius.circular(10)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 90.h,
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        fit: BoxFit.fill,
                        image: CachedNetworkImageProvider(
                            EndPoints.baseImageUrl + homeLabs.image!))),
              ),
            ),
            SizedBox(
              height: 8.h,
            ),
            Text(
              context.locale.languageCode == 'ar'
                  ? homeLabs.nameAr.orEmpty()
                  : homeLabs.nameEn.orEmpty(),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: StylesManger.small()
                  .copyWith(color: Colors.black, fontWeight: FontWeight.w700),
            ),
            SizedBox(
              height: 5.h,
            ),
            // Text(
            //   "الوصف الخاص بالخدمة الوصف الخاص بالخدمةالوصف الخاص بالخدمةالوصف ",
            //   maxLines: 2,
            //   overflow: TextOverflow.ellipsis,
            //   style: StylesManger.extremelySmall().copyWith(
            //       color: ColorManger.lightGrey, fontWeight: FontWeight.w400),
            // ),
            // SizedBox(
            //   height: 8.h,
            // ),
            Row(
              children: [
                SvgPicture.asset(
                  'assets/images/map_marker.svg',
                  height: 12.h,
                  width: 48.w,
                  color: ColorManger.newPrimary,
                ),
                const SizedBox(
                  width: 5,
                ),
                Text(
                  homeLabs.labsNumber != null
                      ? homeLabs.labsNumber!.toString()
                      : "",
                  style: StylesManger.small().copyWith(
                    fontWeight: FontWeight.w700,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(
                  width: 5,
                ),
                Text(
                  'Labs'.tr(),
                  style: StylesManger.small().copyWith(
                    fontWeight: FontWeight.w700,
                    color: Colors.black,
                  ),
                ),
                const Spacer(),
                if (homeLabs.fbServiceAvg != null)
                  RatingBar.builder(
                    initialRating: homeLabs.fbServiceAvg!,
                    itemSize: 16,
                    minRating: 1,
                    direction: Axis.horizontal,
                    allowHalfRating: true,
                    itemCount: 5,
                    itemBuilder: (context, _) => Icon(
                      Icons.star,
                      color: ColorManger.newPrimary,
                    ),
                    onRatingUpdate: (rating) {
                      print(rating);
                    },
                  ),
              ],
            ),
            const SizedBox(
              height: 5,
            ),
          ],
        ),
      ),
    );
  }
}
