import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../../../../data/response/home/response_home.dart';
import '../../../resources/color_manger.dart';
import '../../../resources/styles_manger.dart';

class UserPackageWidget extends StatelessWidget {
  final ResponseUserPackages userPackages;
  const UserPackageWidget({super.key, required this.userPackages});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsetsDirectional.only(end: 10),
      padding: const EdgeInsets.all(8),
      width: 180,
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 80,
            child: Stack(
              children: [
                Container(
                  width: double.infinity,
                  decoration: const BoxDecoration(
                      image: DecorationImage(
                          fit: BoxFit.fill,
                          image: CachedNetworkImageProvider(
                              'https://www.verywellhealth.com/thmb/gtkcHq1dLyrcjv6BrlzqnsvW1kI=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/GettingBackOnTrack5AnswerMayBeInYourBloodRecirc1-ebfe7529cfb84e40af3d1c9881a7023a.jpg'))),
                ),
                userPackages.numOfTests != null
                    ? PositionedDirectional(
                        top: 0,
                        start: 10,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          height: 25,
                          width: 50,
                          decoration: BoxDecoration(
                              color: ColorManger.primary,
                              borderRadius: BorderRadius.circular(10)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                userPackages.numOfTests!.toString(),
                                style: StylesManger.medium()
                                    .copyWith(color: Colors.white),
                              ),
                              Text(
                                'test',
                                style: StylesManger.medium()
                                    .copyWith(color: Colors.white),
                              )
                            ],
                          ),
                        ),
                      )
                    : const SizedBox()
              ],
            ),
          ),
          const SizedBox(
            height: 5,
          ),
          Expanded(
            child: Text(
              userPackages.nameEn != null 
                  ? userPackages.nameEn!
                  : '',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: StylesManger.medium()
                  .copyWith(color: ColorManger.primary),
            ),
          ),
          const SizedBox(
            height: 5,
          ),
          Text(
           userPackages.minPrice != null ? "${userPackages.minPrice} SAR" : '',
            style: StylesManger.medium().copyWith(
              color: ColorManger.primary,
            ),
          ),
          
          
        ],
      ),
    );
  }
}
