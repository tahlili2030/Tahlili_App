import 'package:flutter/material.dart';

import '../../../../data/response/home/response_home.dart';

class FeedBackWidget extends StatelessWidget {
  final List<ResponseHomeFeedback> homeFeedbacks;
  const FeedBackWidget({super.key, required this.homeFeedbacks});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 80,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) => Text(homeFeedbacks[index].feedback??''),
          separatorBuilder: (context, index) => const SizedBox(
                width: 10,
              ),
          itemCount: homeFeedbacks.length),
    );
  }
}
