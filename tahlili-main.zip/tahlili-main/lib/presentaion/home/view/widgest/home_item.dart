// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:easy_localization/easy_localization.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:flutter_svg/flutter_svg.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:tahlili/app/end_points.dart';
// import 'package:tahlili/data/requests/order/request_order.dart';
// import 'package:tahlili/presentaion/home/page/compare_view.dart';
// import 'package:tahlili/presentaion/resources/shared/app_button.dart';
// import 'package:tahlili/presentaion/resources/styles_manger.dart';

// import '../../../../data/requests/wishlist/request_wishlist.dart';
// import '../../../../data/response/home/response_home.dart';
// import '../../../account/cubit/account_cubit.dart';
// import '../../../resources/color_manger.dart';
// import '../../../resources/shared/view_details.dart';
// import '../../../wishlist/cubit/wishlist_cubit.dart';
// import '../../cubit/home_cubit.dart';

// class DealsWidget extends StatelessWidget {
//   final ResponseDeals deals;
//   const DealsWidget({super.key, required this.deals});

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       margin: const EdgeInsetsDirectional.only(end: 10),
//       width: 129.w,
//       padding: EdgeInsets.only(bottom: 8.h),
//       decoration: BoxDecoration(
//           border: Border.all(color: ColorManger.grey),
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(10)),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//          mainAxisSize: MainAxisSize.min,
//         children: [
//           SizedBox(
//             height: 57.h,
//             child: Stack(
//               children: [
//                 GestureDetector(
//                   onTap: (){
//                      context
//                   .read<HomeCubit>()
//                   .getShownDealsDetails(itemId: deals.packageId!)
//                   .whenComplete(() => showDialog(
//                       context: context,
//                       builder: (context) => AlertDialog(
//                             actionsPadding: EdgeInsets.zero,
//                             actions: [
//                               ViewDetailsWidget(
//                                 fromCart: false,
//                                   deals: context
//                                       .read<HomeCubit>()
//                                       .dealsDetails
//                                       .first)
//                             ],
//                           )));
//                   },
//                   child: Container(
//                     width: double.infinity,
//                     decoration: BoxDecoration(
//                         borderRadius: const BorderRadius.only(
//                             topLeft: Radius.circular(10),
//                             topRight: Radius.circular(10)),
//                         image: DecorationImage(
//                             fit: BoxFit.fitWidth,
//                             image: CachedNetworkImageProvider(
//                                 EndPoints.baseImageUrl +
//                                     (context.locale.languageCode == 'ar'
//                                         ? deals.package!.imageAR!
//                                         : deals.package!.imageEN!)))),
//                   ),
//                 ),
//                 PositionedDirectional(
//                     top: 0, end: 10, child: homePopUp(context))
//               ],
//             ),
//           ),
//            SizedBox(
//             height: 8.h,
//           ),
//           Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               GestureDetector(
//                 onTap: (){
//                    context
//                 .read<HomeCubit>()
//                 .getShownDealsDetails(itemId: deals.packageId!)
//                 .whenComplete(() => showDialog(
//                     context: context,
//                     builder: (context) => AlertDialog(
//                           actionsPadding: EdgeInsets.zero,
//                           actions: [
//                             ViewDetailsWidget(
//                               fromCart: false,
//                                 deals: context
//                                     .read<HomeCubit>()
//                                     .dealsDetails
//                                     .first)
//                           ],
//                         )));
//                 },
//                 child: Padding(
//                  padding: const EdgeInsets.symmetric(horizontal: 5),
//                   child: Text(
//                     deals.package != null
//                         ? context.locale.languageCode == 'ar'
//                             ? deals.package!.nameAr!
//                             : deals.package!.nameEn!
//                         : '',
//                     maxLines: 1,
//                     overflow: TextOverflow.ellipsis,
//                     style: StylesManger.medium()
//                         .copyWith(color: Colors.black),
//                   ),
//                 ),
//               ),
//                SizedBox(
//                 height: 8.h,
//               ),
//               Container(
               
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.start,
//                   children: [
//                     Text(
//                       deals.priceBeforeDiscount != null
//                           ? "${deals.priceBeforeDiscount} ${"SAR".tr()}"
//                           : '',
//                       style: StylesManger.medium().copyWith(
//                           color: ColorManger.grey,
//                           decoration: TextDecoration.lineThrough),
//                     ),
//                     const SizedBox(
//                       width: 5,
//                     ),
//                     Text(
//                       deals.price != null ? "${deals.price} ${"SAR".tr()}" : '',
//                       style: StylesManger.medium().copyWith(
//                         color: ColorManger.primary,
//                       ),
//                     )
//                   ],
//                 ),
//               ),
//             ],
//           )
//         ],
//       ),
//     );
//   }

//   Widget homePopUp(
//     BuildContext context,
//   ) {
//     return Theme(
//       data: Theme.of(context).copyWith(
//           cardColor: Colors.white,
//           popupMenuTheme: const PopupMenuThemeData(
//             color: Colors.white,
//             elevation: 0,
//           )),
//       child: PopupMenuButton(
//         padding: const EdgeInsets.only(bottom: 20),

//         // color: Colors.black,
//         position: PopupMenuPosition.under,
//         iconSize: 30,
//         icon: const Icon(
//           FontAwesomeIcons.ellipsisH,
//           color: Colors.black,
//         ),

//         itemBuilder: (context) {
//           return [
//             PopupMenuItem(
//               value: 0,
//               child: Column(
//                 children: [
//                   ListTile(
//                     leading: const Icon(
//                       Icons.remove_red_eye_outlined,
//                       color: Colors.black,
//                     ),
//                     title: Text(
//                       "ViewDetails".tr(),
//                     ),
//                   ),
//                   const SizedBox(
//                     height: 5,
//                   ),
//                   Container(
//                     margin: const EdgeInsets.symmetric(horizontal: 10),
//                     height: 1,
//                     width: double.infinity,
//                     color: ColorManger.grey,
//                   )
//                 ],
//               ),
//             ),
//             PopupMenuItem(
//               value: 1,
//               child: Column(
//                 children: [
//                   ListTile(
//                     leading: const Icon(
//                       Icons.compare_arrows_rounded,
//                       color: Colors.black,
//                     ),
//                     title: Text("Compare".tr()),
//                   ),
//                   const SizedBox(
//                     height: 5,
//                   ),
//                   Container(
//                     margin: const EdgeInsets.symmetric(horizontal: 10),
//                     height: 1,
//                     width: double.infinity,
//                     color: ColorManger.grey,
//                   )
//                 ],
//               ),
//             ),
//             PopupMenuItem(
//               value: 2,
//               child: Column(
//                 children: [
//                   ListTile(
//                     leading: const Icon(
//                       Icons.favorite_border,
//                       color: Colors.black,
//                     ),
//                     title: Text("Add to WishList".tr()),
//                   ),
//                   const SizedBox(
//                     height: 5,
//                   ),
//                   Container(
//                     margin: const EdgeInsets.symmetric(horizontal: 10),
//                     height: 1,
//                     width: double.infinity,
//                     color: ColorManger.grey,
//                   )
//                 ],
//               ),
//             ),
//           ];
//         },
//         onSelected: (value) async {
//           switch (value) {
//             case 0:
//               context
//                   .read<HomeCubit>()
//                   .getShownDealsDetails(itemId: deals.packageId!)
//                   .whenComplete(() => showDialog(
//                       context: context,
//                       builder: (context) => AlertDialog(
//                             actionsPadding: EdgeInsets.zero,
//                             actions: [
//                               ViewDetailsWidget(
//                                 fromCart: false,
//                                   deals: context
//                                       .read<HomeCubit>()
//                                       .dealsDetails
//                                       .first)
//                             ],
//                           )));

//               break;
//             case 1:
//               context
//                   .read<HomeCubit>()
//                   .itemsCompare(itemId: deals.packageId!, itemType: 4)
//                   .whenComplete(() => Navigator.push(
//                       context,
//                       MaterialPageRoute(
//                           builder: (context) => const CompareView())));

//               break;

//             case 2:
//               context.read<WishlistCubit>().addToWishlit(
//                   wishlist: RequestWishlist(
//                       context.read<AccountCubit>().userModel!.entityId!,
//                       deals.partnerId!,
//                       null,
//                       deals.packageId));
//               break;
//           }
//         },
//       ),
//     );
//   }
// }
