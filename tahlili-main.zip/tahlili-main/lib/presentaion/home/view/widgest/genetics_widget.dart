import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../../../../app/end_points.dart';
import '../../../../data/requests/order/request_order.dart';
import '../../../../data/requests/wishlist/request_wishlist.dart';
import '../../../../data/response/home/response_home.dart';
import '../../../account/cubit/account_cubit.dart';
import '../../../resources/color_manger.dart';
import '../../../resources/shared/app_button.dart';
import '../../../resources/shared/quick_order_dialog.dart';
import '../../../resources/shared/view_details.dart';
import '../../../resources/shared/view_details_test.dart';
import '../../../resources/styles_manger.dart';
import '../../../wishlist/cubit/wishlist_cubit.dart';
import '../../cubit/home_cubit.dart';
import '../../page/compare_view.dart';

class GeneticsWidget extends StatelessWidget {
  final ResponseSearch test;
  const GeneticsWidget({super.key, required this.test});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsetsDirectional.only(end: 10),
      width: 129.w,
      decoration: BoxDecoration(
          border: Border.all(color: ColorManger.grey),
          color: Colors.white,
          borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            height: 67.h,
            child: Stack(
              children: [
                GestureDetector(
                  onTap: () {
                    context
                        .read<HomeCubit>()
                        .getTestsDetails(itemId: test.partnerItemId!)
                        .whenComplete(() => showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                                  actionsPadding: EdgeInsets.zero,
                                  actions: [
                                    ViewDetailsTestWidget(
                                        fromCart: false,
                                        test: context
                                            .read<HomeCubit>()
                                            .testDetails!)
                                  ],
                                )));
                  },
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                        borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10)),
                        image: DecorationImage(
                            fit: BoxFit.fitWidth,
                            image: CachedNetworkImageProvider(
                                EndPoints.baseImageUrl + test.image!))),
                  ),
                ),
                PositionedDirectional(
                    top: 0, end: 10, child: homePopUp(context)),
                PositionedDirectional(
                    bottom: 0,
                    end: 5,
                    child: GestureDetector(
                      onTap: () {
                        showDialog(
                            context: context,
                            builder: (context) => QuickOrderDialog(
                                  orderData: RequestOrderData(
                                      test.partnerId!,
                                      test.nameEn!,
                                      test.price!,
                                      test.partnerItemId!,
                                      true),
                                ));
                      },
                      child: CircleAvatar(
                        radius: 12.r,
                        backgroundColor: Colors.white,
                        child: Center(
                          child: SvgPicture.asset(
                            'assets/images/shopping_cart.svg',
                            height: 11.h,
                            width: 12.w,
                          ),
                        ),
                      ),
                    ))
              ],
            ),
          ),
          SizedBox(
            height: 5,
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  context
                      .read<HomeCubit>()
                      .getTestsDetails(itemId: test.partnerItemId!)
                      .whenComplete(() => showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                                actionsPadding: EdgeInsets.zero,
                                actions: [
                                  ViewDetailsTestWidget(
                                      fromCart: false,
                                      test: context
                                          .read<HomeCubit>()
                                          .testDetails!)
                                ],
                              )));
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: Text(
                    context.locale.languageCode == 'ar'
                        ? test.nameAr!
                        : test.nameEn!,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: StylesManger.medium().copyWith(color: Colors.black),
                  ),
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    test.priceBeforeDiscount != null
                        ? "${test.priceBeforeDiscount} ${"SAR".tr()}"
                        : '',
                    style: StylesManger.medium().copyWith(
                        color: ColorManger.grey,
                        decoration: TextDecoration.lineThrough),
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                  Text(
                    test.price != null ? "${test.price} ${"SAR".tr()}" : '',
                    style: StylesManger.medium().copyWith(
                      color: ColorManger.primary,
                    ),
                  )
                ],
              ),
              SizedBox(
                height: 5,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5),
                child: SizedBox(
                  height: 27.h,
                  child: AppButton(
                      radius: 24.r,
                      textSize: 10.sp,
                      color: ColorManger.primary,
                      name: "OrderNow".tr(),
                      onPressed: () {
                        showDialog(
                            context: context,
                            builder: (context) => QuickOrderDialog(
                                  orderData: RequestOrderData(
                                      test.partnerId!,
                                      test.nameEn!,
                                      test.price!,
                                      test.partnerItemId!,
                                      true),
                                ));
                      }),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 8.h,
          ),
        ],
      ),
    );
  }

  Widget homePopUp(
    BuildContext context,
  ) {
    return Theme(
      data: Theme.of(context).copyWith(
          cardColor: Colors.white,
          popupMenuTheme: const PopupMenuThemeData(
            color: Colors.white,
            elevation: 0,
          )),
      child: PopupMenuButton(
        padding: const EdgeInsets.only(bottom: 20),

        // color: Colors.black,
        position: PopupMenuPosition.under,
        iconSize: 30,
        icon: const Icon(
          FontAwesomeIcons.ellipsisH,
          color: Colors.black,
        ),

        itemBuilder: (context) {
          return [
            PopupMenuItem(
              value: 0,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.remove_red_eye_outlined,
                      color: Colors.black,
                    ),
                    title: Text(
                      "ViewDetails".tr(),
                    ),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 1,
                    width: double.infinity,
                    color: ColorManger.grey,
                  )
                ],
              ),
            ),
            PopupMenuItem(
              value: 1,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.compare_arrows_rounded,
                      color: Colors.black,
                    ),
                    title: Text("Compare".tr()),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 1,
                    width: double.infinity,
                    color: ColorManger.grey,
                  )
                ],
              ),
            ),
            PopupMenuItem(
              value: 2,
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(
                      Icons.favorite_border,
                      color: Colors.black,
                    ),
                    title: Text("Add to WishList".tr()),
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    height: 1,
                    width: double.infinity,
                    color: ColorManger.grey,
                  )
                ],
              ),
            ),
          ];
        },
        onSelected: (value) async {
          switch (value) {
            case 0:
              context
                  .read<HomeCubit>()
                  .getTestsDetails(itemId: test.partnerItemId!)
                  .whenComplete(() => showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                            actionsPadding: EdgeInsets.zero,
                            actions: [
                              ViewDetailsTestWidget(
                                  fromCart: false,
                                  test: context.read<HomeCubit>().testDetails!)
                            ],
                          )));

              break;
            case 1:
              context
                  .read<HomeCubit>()
                  .itemsCompare(itemId: test.partnerItemId!, itemType: 4)
                  .whenComplete(() => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const CompareView())));

              break;

            case 2:
              context.read<WishlistCubit>().addToWishlit(
                      wishlist: RequestWishlist(
                    context.read<AccountCubit>().userModel!.entityId!,
                    null,
                    test.partnerItemId,
                  ));

              break;
          }
        },
      ),
    );
  }
}
