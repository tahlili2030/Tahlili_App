import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/presentaion/home/cubit/home_cubit.dart';
import 'package:tahlili/presentaion/home/view/widgest/indivual_tests.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';

import '../../../../../data/response/home/response_home.dart';
import '../../../../resources/styles_manger.dart';

class IndividualTestView extends StatelessWidget {
  const IndividualTestView({super.key, required this.individualTest});
  final List<ResponseIndividualTests> individualTest;

  @override
  Widget build(BuildContext context) {
    final cubit=context.read<HomeCubit>();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          "Indvidual Tests",
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          const AppBarDivider(),
          const SizedBox(
            height: 16,
          ),
          Expanded(
              child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GridView.builder(
                itemCount: individualTest.length,
                gridDelegate:  SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 16,
                    crossAxisSpacing: 16,
                    mainAxisExtent: 155.h),
                itemBuilder: (context, index) => IndvidualTestsWidget(
                    test: individualTest[index], testName:
                    context.locale.languageCode=='ar'?cubit.arTest[index]: cubit.enTest[index])),
          ))
        ],
      ),
    );
  }
}
