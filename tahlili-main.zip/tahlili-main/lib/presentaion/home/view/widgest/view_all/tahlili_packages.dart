import 'package:flutter/material.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';

import '../../../../../data/response/home/response_home.dart';
import '../../../../resources/styles_manger.dart';
import '../tahlily_packages.dart';

class TahliliPackagesView extends StatelessWidget {
  const TahliliPackagesView({super.key, required this.tahliliPackages});
  final List<ResponseSearch> tahliliPackages ;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          "Tahlily Packages",
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          const AppBarDivider(),
          const SizedBox(
            height: 16,
          ),
          Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: GridView.builder(
                  itemCount: tahliliPackages.length,
                    gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 16,
                        crossAxisSpacing: 16,
                        mainAxisExtent: 200
                        ),
                    itemBuilder: (context,index)=>TahlilyPackage(

                                            tahliliPackage:
                                                tahliliPackages[index])),
              ))
        ],
      ),
    );
  }
}
