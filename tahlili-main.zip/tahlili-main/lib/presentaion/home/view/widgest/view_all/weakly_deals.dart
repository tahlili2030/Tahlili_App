// import 'package:flutter/material.dart';
// import 'package:tahlili/presentaion/home/view/widgest/home_item.dart';
// import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';

// import '../../../../../data/response/home/response_home.dart';
// import '../../../../resources/styles_manger.dart';

// class WeaklyDelasView extends StatelessWidget {
//   const WeaklyDelasView({super.key, required this.deals});
//   final List<ResponseDeals> deals;

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Colors.white,
//         centerTitle: true,
//         title: Text(
//           "Weekly Deals",
//           style: StylesManger.rich().copyWith(color: Colors.black),
//         ),
//       ),
//       backgroundColor: Colors.white,
//       body: Column(
//         children: [
//           const AppBarDivider(),
//           const SizedBox(
//             height: 16,
//           ),
//           Expanded(
//               child: Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 16),
//                 child: GridView.builder(
//                   itemCount: deals.length,
//                     gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(
//                         crossAxisCount: 2,
//                         mainAxisSpacing: 16,
//                         crossAxisSpacing: 16,
//                         mainAxisExtent: 140
//                         ),
//                     itemBuilder: (context,index)=>DealsWidget(deals: deals[index])),
//               ))
//         ],
//       ),
//     );
//   }
// }
