import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tahlili/presentaion/home/cubit/home_cubit.dart';
import 'package:tahlili/presentaion/home/view/widgest/category_widget.dart';
import 'package:tahlili/presentaion/resources/shared/appbar_divider.dart';

import '../../../../../data/response/home/response_home.dart';
import '../../../../resources/styles_manger.dart';
import '../../../page/categoryItem_view.dart';

class CategoryView extends StatelessWidget {
  const CategoryView({super.key, required this.categories});
  final List<ResponseHomeCategory> categories;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<HomeCubit>();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          "Categories".tr(),
          style: StylesManger.rich().copyWith(color: Colors.black),
        ),
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: [
          const AppBarDivider(),
          const SizedBox(
            height: 16,
          ),
          Expanded(
              child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GridView.builder(
                itemCount: categories.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 16,
                    crossAxisSpacing: 16,
                    mainAxisExtent: 140),
                itemBuilder: (context, index) => GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => CategoryItemView(
                                      categoryName:
                                          context.locale.languageCode == 'ar'
                                              ? cubit.arCategories[index]
                                              : cubit.enCategories[index],
                                      categoryId: categories[index].id!,
                                    )));
                      },
                      // child: CategoryWidget(
                      //     categories: categories[index], categoryName:context.locale.languageCode=='ar'?
                      //     cubit.arCategories[index]:
                      //      cubit.enCategories[index]),
                    )),
          ))
        ],
      ),
    );
  }
}
