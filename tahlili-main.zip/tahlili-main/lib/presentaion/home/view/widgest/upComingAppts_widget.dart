import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';

import '../../../../data/response/orders/response_order.dart';
import '../../../resources/color_manger.dart';
import '../../../resources/styles_manger.dart';

class UpcomingApptsWidget extends StatelessWidget {
  const UpcomingApptsWidget({
    super.key, required this.appt,
  });
 final ResponseUpcomimgAppts appt;

  @override
  Widget build(BuildContext context) {
    return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
              border:
                  Border.all(color: ColorManger.grey),
              borderRadius:
                  BorderRadius.circular(10)),
          child: Row(
            children: [
              Container(
                margin: const EdgeInsets.symmetric(
                    vertical: 5),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                    color:Color(0xffDFE0E2),
                    borderRadius:
                        BorderRadius.circular(10)),
                child: Center(
                  child: Text(
                 DateFormat('dd MMM').format(DateTime.parse(appt.visitDateTime!))   ,
                    style: StylesManger.rich()
                        .copyWith(
                            color: Colors.black),
                  ),
                ),
              ),
              const SizedBox(
                width: 30,
              ),
              Column(
                children: [
                  Text(

                 appt.atHome!?  "Home Visit":"Lab visit",
                    style:
                        StylesManger.rich().copyWith(
                      color: Colors.black,
                      fontWeight: FontWeight.w400,
                      fontSize: 13.sp
                    ),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  Text(
                 "${DateFormat('dd MMM yyyy').format(DateTime.parse(appt.visitDateTime!))} At",
                    style:
                        StylesManger.rich().copyWith(
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  Text(
                   DateFormat('hh:mm a').format(DateTime.parse(appt.visitDateTime!)),
                    style:
                        StylesManger.rich().copyWith(
                      color: Colors.black,
                    ),
                  ),
                ],
              )
            ],
          ),
        );
  }
}
