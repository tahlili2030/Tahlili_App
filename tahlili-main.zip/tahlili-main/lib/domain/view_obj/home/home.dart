import 'package:flutter/material.dart';

class CategoryHomeModel {
  final String image;
  final Color color;

  CategoryHomeModel(
    this.image,
    this.color,
  );
}

class ServicesHomeModel {
  final String name;
  final String description;
  final String image;
  final String cardImage;
  final String btnName;

  ServicesHomeModel(
    this.name,
    this.description,
    this.image,
    this.cardImage,
    this.btnName,
  );
}
