class ObjLogin{
  final String messages;

  ObjLogin({
    required this.messages
  });
}

class ObjRegister{
  final String message;


  ObjRegister(this.message);
  
}