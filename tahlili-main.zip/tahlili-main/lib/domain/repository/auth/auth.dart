import 'package:tahlili/data/failure/failure.dart';
import 'package:tahlili/data/requests/auth/request_auth.dart';
import 'package:tahlili/data/response/auth/response_auth.dart';
import 'package:tahlili/data/response/home/response_home.dart';
import 'package:tahlili/domain/view_obj/auth/auth.dart';
import 'package:dartz/dartz.dart';

import '../../../data/requests/auth/request_contact_us.dart';
import '../../../data/response/response.dart';
abstract class BaseAuthRepository {
Future<Either<String, ResponseAPI>> login({
  required RequestLogin login
});
Future<Either<String, ResponseRegister>> register({
  required RequestRegister register
});
Future<Either<String,ResponseAPI>> contactUs({required RequestContactUs requestContactUs});

Future<Either<String,ResponseOtp>> verifyOtp({required RequestOtp requestOtp});

Future<Either<Failure,List<ResponseLookup>>> getLookUp({
  required String tableName
});
}