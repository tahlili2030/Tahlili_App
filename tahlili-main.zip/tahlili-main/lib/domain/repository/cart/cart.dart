import 'package:dartz/dartz.dart';
import 'package:tahlili/data/failure/failure.dart';
import 'package:tahlili/data/requests/cart/request_cart.dart';
import 'package:tahlili/data/requests/order/request_order.dart';
import 'package:tahlili/data/response/cart/response_cart.dart';
import 'package:tahlili/data/response/response.dart';

abstract class BaseCartRepository{
  Future<Either<Failure,List<ResponseCart>>> getCart({required String filterQuery});
  Future<Either<Failure,ResponseAPI>> addToCart({
    required RequestCart requestCart,
    required String userId
  });
   Future<Either<Failure,ResponseAPI>> deleteCartItem({
    required int cartId
  });
   Future<Either<Failure,ResponseAPI>> createOrder({
    required RequestOrder order
  });
   Future<Either<Failure,ResponseAPI>> createLabOrder({
    required RequestOrder order
  });
}