import 'package:dartz/dartz.dart';
import 'package:tahlili/data/failure/failure.dart';
import 'package:tahlili/data/requests/wishlist/request_wishlist.dart';
import 'package:tahlili/data/response/response.dart';
import 'package:tahlili/data/response/wishlist/response_wishlist.dart';

abstract class BaseWishlistRepository {
  Future<Either<Failure, List<ResponseWishlist>>> getWishlist({bool? asc});
  Future<Either<Failure, ResponseAPI>> addToWishlit(
      {required RequestWishlist requestWishlist});

       Future<Either<Failure, ResponseAPI>> deleteWishlistItem(
      {required int itemId});
}
