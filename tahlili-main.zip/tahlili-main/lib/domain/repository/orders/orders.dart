import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:tahlili/data/failure/failure.dart';
import 'package:tahlili/data/requests/order/request_order.dart';
import 'package:tahlili/data/response/home/response_home.dart';
import 'package:tahlili/data/response/orders/response_order.dart';
import 'package:tahlili/data/response/response.dart';

abstract class BaseOrdersRepository {
  Future<Either<ResponseAPI, ResponseAPI>> createHomeOrder(
      {required RequestQuickOrder order});
  Future<Either<DioException, ResponseAPI>> createLabOrder(
      {required RequestQuickOrder order});
  Future<Either<Failure, List<ResponseOrder>>> getOrders({required bool? asc});

  Future<Either<Failure, ResponseOrderDetails>> getOrderDetails(
      {required int orderId});

  Future<Either<Failure, List<ResponseTeleMedOrders>>> getTelemedOrders();
  Future<Either<Failure, ResponseTelemedDetails>> getTelemedOrderDetails(
      {required int orderId});
  Future<Either<Failure, ResponseWorkingHours>> getLabWorkingHours();
  Future<Either<Failure, List<ResponseLabWorkingHoursForAppt>>>
      getLabWorkingHoursForAppt(
          {required int labId, required bool atHomeTiming});
  Future<Either<Failure, ResponseNurseFees>> getNurseFees(
      {required int? partnerPackageId,
      required int? partnerTestId,
      required bool? isMale});
  Future<Either<Failure, List<ResponseLookup>>> getDepartments(
      {required String filterQuery});

  Future<Either<Failure, List<ResponseTeleDoctor>>> getTeleDoctors(
      {required String filterQuery});
  Future<Either<Failure, List<ResponseBusyTelemedicnice>>> getBusyTele(
      {required String date});

  Future<Either<Failure, ResponseAPI>> createTeleOrder(
      {required RequestTele requestTele});

  Future<Either<Failure, List<ResponseLabBranches>>> getLabBranches(
      {required int partnerId, required int itemId, required bool isTest});

  Future<Either<Failure, ResponseAPI>> cancelTelemedAppt(
      {required int telemedId});

  Future<Either<Failure, List<ResponseUpcomimgAppts>>> getUpcomingAppts();

  Future<Either<Failure, ResponseOrderStateId>> getOrderCurrentState(
      {required int orderId});

  Future<Either<Failure, List<ResponsiveNewApointment>>> getNewAppointments(
      {required bool? now, required bool asc});

  Future<Either<Failure, ResponseAPI>> rescheduleOrder(
      {required int orderId, required String date, required String time});
}
