import 'package:dartz/dartz.dart';
import 'package:tahlili/data/requests/accounts/request_account.dart';
import 'package:tahlili/data/response/auth/response_auth.dart';
import 'package:tahlili/data/response/response.dart';

import '../../../data/failure/failure.dart';
import '../../../data/response/account/reponse_account.dart';
import '../../../data/response/orders/response_order.dart';

abstract class BaseAccountReposiotry{
    Future<Either<Failure,List<ResponseRefund>>> getRefunds();
    Future<Either<Failure,ResponseAPI>> requestRefund({
      required RequestRefund refund
    });
  Future<Either<Failure,ResponseDashboard>> getDashboard();
   Future<Either<Failure,List<ResponsePatientWallet>>> getPatientWallet();
   Future<Either<Failure,List<ResponsePrescriptions>>> getPrescriptions();
   Future<Either<Failure,List<ResponseAddresses>>> getPatientAddresses({
    required int patientId
   });



   Future<Either<Failure,List<ResponsePrescriptions>>> getPrescriptionDetails({
    required int prescriptionId
   });

    Future<Either<String,ResponseAPI>> addPrescription({
    required RequestPrescriptions prescriptions
   });
   Future<Either<Failure,int>> getUserEntityID();

   Future<Either<Failure,ResponseUserEntity>> getUserData({
    required String userID,
    required int userEntityID
   });

   Future<Either<String,ResponseAPI>> addProfile({
    required String userID,
    required RequestAddProfile addProfile
   });

   Future<Either<String,ResponseAPI>> uploadFile({
    required RequestUploadFile file
   });

   Future<Either<String,ResponseAPI>> addComplaints({
    required RequestComplaints complaints
   });

   Future<Either<Failure,List<ResponseComplaints>>> getComplaints();
   Future<Either<Failure,ResponseComplaintDetail>> getComplaintsDetails({
    required int id
   });
   Future<Either<String,ResponseAPI>> savePayment({
    required Map<String,dynamic> map
   });

   Future<Either<Failure,ResponsePatient>> getPatient({
    required int patientEntityId
   });
   Future<Either<String,ResponseAPI>> editProfile({
    required int patientEntityId,
    required RequestEditProfile editProfile
   });

   Future<Either<Failure,List<ResponsePatientProfile>>> getPatientProfiles({
    required String patientUserId
   });

   Future<Either<Failure,List<ResponseAddresses>>> getAddresses({
    required String patientId
   });

    Future<Either<Failure,List<ResponseWalletTracking>>> getWalletTracking();

}