import 'package:dartz/dartz.dart';
import 'package:tahlili/data/failure/failure.dart';
import 'package:tahlili/data/response/response.dart';

import '../../../data/response/notofication/notification.dart';

abstract class BaseNotificationRepository{
  Future<Either<Failure,List<ResponseNotifcation>>> getNotification();
  Future<Either<Failure,ResponseAPI>> updateNotifcation({
    required int notificationId,
      required String userId,
      required String title,
      required bool seen
  });
  Future<Either<Failure,ResponseAPI>> sendNotifcation({
    required Map<String ,dynamic >map
  });

}