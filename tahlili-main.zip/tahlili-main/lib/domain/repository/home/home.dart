import 'package:dartz/dartz.dart';
import 'package:tahlili/data/failure/failure.dart';
import 'package:tahlili/data/requests/home/request_home.dart';
import 'package:tahlili/data/response/home/response_home.dart';
import 'package:tahlili/data/response/response.dart';

abstract class BaseHomeRepository {
  Future<Either<Failure, List<ResponseInsurance>>> getInsurancesLookUp();
  Future<Either<Failure, List<ResponseDeals>>> getShownDeals();
  Future<Either<Failure, List<ResponseSearch>>> getTahliliPackages();
  Future<Either<Failure, List<ResponseSearch>>> getGeneticTests();
  Future<Either<Failure, List<ResponseHomeCategory>>> getHomeCategories();
  Future<Either<Failure, List<ResponseHomeLabs>>> getHomeLabs();
  Future<Either<Failure, List<ResponseHomePackages>>> getHomeRecommendedPackages({
     String? orderBy,
     bool? asc
  });

  Future<Either<Failure, List<ResponseHomeFeedback>>> getHomeFeedBack();
  Future<Either<Failure,List<ResponseCoupon>>> getHomeCoupon({String? showInHomePage});
   Future<Either<Failure,List<ResponseSearch>>> getHomeSearch({
     required String? orderBy,
    required String ?filterQuery,
    required bool ?asc,
   });
   Future<Either<Failure,ResponseAPI>> getPatientsHistories({
    required RequestPatientHisotry patientHisotry
   });
   Future<Either<Failure,ResponseAPI>> changeLanguage({
    required int langId
   });
    Future<Either<Failure,ResponseItemsCompare>> itemsCompare({
      required int itemId,
      required int itemType
    });

    Future<Either<Failure,List<ResponseUserPackages>>> getUserPackages({
      required bool isTailord
    });

    Future<Either<Failure,List<ResponseHomeAds>>> getHomeAds({
      required String adsId
    });
    Future<Either<Failure,ResponseAPI>> addClick({
      required int adsId
    });

    Future<Either<Failure,List<ResponseIndividualTests>>> getIndividualTests();

    Future<Either<Failure,ResponsePackageDetails>> getShownDealsDetails({
      required int itemId
    });

     Future<Either<Failure,ResponseTestDetails>> getTestsDetails({
      required int itemId
    });

     Future<Either<Failure,ResponsePartnerCount>> getPartnerCount({
      required int partnerId
    });
}
