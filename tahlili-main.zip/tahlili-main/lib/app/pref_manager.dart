import 'package:shared_preferences/shared_preferences.dart';

import 'langauge_manager.dart';

const String prefsKeyLang = "PREFS_KEY_LANG";

const String userToken = "User_Token";

const String userID = "User_ID";

const String onBording='On_Bording';

class PreferancesManager {
  final SharedPreferences _preferences;

  PreferancesManager(this._preferences);

  Future<String> getLanguage() async {
    final language = _preferences.getString(prefsKeyLang);

    if (language != null && language.isNotEmpty) {
      return language;
    }else{
      return LanguageType.english.getValue();
    }
  }
  Future setLanguage(String lang)async{
    await _preferences.setString(prefsKeyLang, lang);

  }

    Future<bool> saveData({
    required String key,
    required dynamic value,
  }) async {
    if (value is String) return await _preferences.setString(key, value);
    if (value is int) return await _preferences.setInt(key, value);
    if (value is bool) return await _preferences.setBool(key, value);
    if (value is double) return await _preferences.setDouble(key, value);
    return await _preferences.setStringList(key, value);
  }

   dynamic getData({
    required String key,
  }) {
    return _preferences.get(key);
  }

   dynamic getListOFData({
    required String key,
  }) {
    return _preferences.getStringList(key);
  }

   Future<bool> removeData({
    required String key,
  }) async {
    return await _preferences.remove(key);
  }
}
