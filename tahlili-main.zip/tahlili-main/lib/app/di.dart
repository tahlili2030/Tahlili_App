import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dio/dio.dart';
import 'package:get_it/get_it.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:tahlili/data/data_services/account/account.dart';
import 'package:tahlili/data/data_services/auth/auth.dart';
import 'package:tahlili/data/data_services/cart/cart.dart';
import 'package:tahlili/data/data_services/home/home.dart';
import 'package:tahlili/data/data_services/map/map.dart';
import 'package:tahlili/data/data_services/notification/notification.dart';
import 'package:tahlili/data/data_services/order/order.dart';
import 'package:tahlili/data/data_services/wishlist/wishlist.dart';
import 'package:tahlili/data/repository_impl/account/account.dart';
import 'package:tahlili/data/repository_impl/auth/auth.dart';
import 'package:tahlili/data/repository_impl/cart/cart.dart';
import 'package:tahlili/data/repository_impl/home/home.dart';
import 'package:tahlili/data/repository_impl/map/maps.dart';
import 'package:tahlili/data/repository_impl/notification/notification.dart';
import 'package:tahlili/data/repository_impl/orders/orders.dart';
import 'package:tahlili/data/repository_impl/wishlist/wishlist.dart';
import 'package:tahlili/domain/repository/account/account.dart';
import 'package:tahlili/domain/repository/auth/auth.dart';
import 'package:tahlili/domain/repository/cart/cart.dart';
import 'package:tahlili/domain/repository/home/home.dart';
import 'package:tahlili/domain/repository/notification/notification.dart';
import 'package:tahlili/domain/repository/orders/orders.dart';
import 'package:tahlili/domain/repository/wishlist/wishlist.dart';

import '../data/network/app_api.dart';
import '../data/network/dio_factory.dart';
import '../data/network/network_info.dart';
import 'pref_manager.dart';

final instance = GetIt.instance;

Future<void> initAppModule() async {
  // app module, its a module where we put all generic dependencies


  // shared prefs instance
  final sharedPrefs = await SharedPreferences.getInstance();

  instance.registerLazySingleton<SharedPreferences>(() => sharedPrefs);

  // app prefs instance
  instance.registerLazySingleton<PreferancesManager>(
      () => PreferancesManager(instance()));

  // network info
  instance.registerLazySingleton<BaseNetworkInfo>(
      () => NetworkInfo(Connectivity()));

  // dio factory
  instance.registerLazySingleton<DioFactory>(() => DioFactory(instance()));

  Dio dio = await instance<DioFactory>().getDio();

  /// We have made Singleton instance of Dio to be used with AppServiceClint
  /// and to have a way to set base options after done authentication.
  instance.registerLazySingleton<Dio>(() => dio);

  //app service client
  instance.registerLazySingleton<AppServiceClint>(
      () => AppServiceClint(instance<Dio>()));

  // remote data services

  instance.registerLazySingleton<BaseAuthDataServices>(
      () => AuthDataServices(instance<AppServiceClint>()));

      instance.registerLazySingleton<BaseHomeDataServices>(
      () => HomeDataServices(instance<AppServiceClint>()));

        instance.registerLazySingleton<BaseWishlistDataServices>(
      () => WishlistDataServices(instance<AppServiceClint>()));

       instance.registerLazySingleton<BaseCartDataServices>(
      () => CartDataServices(instance<AppServiceClint>()));

      instance.registerLazySingleton<BaseOrdersDataServices>(
      () => OrdersDataServices(instance<AppServiceClint>()));

      instance.registerLazySingleton<BaseAccountDataServices>(
      () => AccountDataServices(instance<AppServiceClint>()));

      instance.registerLazySingleton<BaseNotificationDataServices>(
      () => NotificationDataServices(instance<AppServiceClint>()));

      instance.registerLazySingleton<BaseMapDataServices>(
      () => MapDataServices(instance()));

  // repository

  instance.registerLazySingleton<BaseAuthRepository>(
      () => AuthRepositoryImpl(instance(), instance()));

  instance.registerLazySingleton<BaseHomeRepository>(
      () => HomeRepositoryImpl(instance(), instance()));

      instance.registerLazySingleton<BaseWishlistRepository>(
      () => WishlistRepositoryImp(instance(), instance()));

       instance.registerLazySingleton<BaseCartRepository>(
      () => CartRepositoryImpl(instance(), instance()));

      instance.registerLazySingleton<BaseOrdersRepository>(
      () => OrdersRepositoryImpl(instance(), instance()));

      instance.registerLazySingleton<BaseAccountReposiotry>(
      () => AccountReposiotryImpl(instance(), instance()));

       instance.registerLazySingleton<BaseNotificationRepository>(
      () => NotificationRepositoryImpl(instance(), instance()));

        instance.registerLazySingleton<BaseMapRepository>(
      () => MapRepositoryImpl(instance(),instance()));
}
