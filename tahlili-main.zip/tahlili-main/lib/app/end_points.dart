class EndPoints{
  static const String baseUrl='https://dev-api.tahliliapp.store/';

  static const googleAPiKey ='AIzaSyAMAtKsIaI4fHhs8_csX6abGtaBgy3oNjY';

  static const baseImageUrl='https://dev-static.tahliliapp.store/';


}