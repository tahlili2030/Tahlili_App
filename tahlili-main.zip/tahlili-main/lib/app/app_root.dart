import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tahlili/app/di.dart';
import 'package:tahlili/presentaion/account/cubit/account_cubit.dart';
import 'package:tahlili/presentaion/auth/cubit/auth_cubit.dart';
import 'package:tahlili/presentaion/bnb/cubit/bnb_cubit.dart';
import 'package:tahlili/presentaion/cart/cubit/cart_cubit.dart';
import 'package:tahlili/presentaion/complaints/view/complaint_detail_view.dart';
import 'package:tahlili/presentaion/contact_us/cubit/contact_us_cubit.dart';
import 'package:tahlili/presentaion/home/cubit/home_cubit.dart';
import 'package:tahlili/presentaion/home/page/show_page.dart';
import 'package:tahlili/presentaion/map/cubit/map_cubit.dart';
import 'package:tahlili/presentaion/medical/cubit/medical_cubit.dart';
import 'package:tahlili/presentaion/notification/cubit/notification_cubit.dart';
import 'package:tahlili/presentaion/onBording/cubit/on_bording_cubit.dart';
import 'package:tahlili/presentaion/orders/cubit/orders_cubit.dart';
import 'package:tahlili/presentaion/orders/view/home/home_order_first_page.dart';
import 'package:tahlili/presentaion/orders/view/lab/lab_order_page.dart';
import 'package:tahlili/presentaion/prescriptions/cubit/prescription_cubit.dart';
import 'package:tahlili/presentaion/splash/view/splash_screen.dart';
import 'package:tahlili/presentaion/telemedicine/cubit/telemedicine_cubit.dart';
import 'package:tahlili/presentaion/telemedicine/view/normal_telemed/departments_screen.dart';
import 'package:tahlili/presentaion/wishlist/cubit/wishlist_cubit.dart';
import 'package:easy_localization/easy_localization.dart';
import '../presentaion/cart/view/home_cart_view.dart';
import '../presentaion/complaints/view/complaint_view.dart';
import '../presentaion/contact_us/view/contact_us_view.dart';
import '../presentaion/lab_appointments/cubit/appointments_cubit.dart';
import '../presentaion/lab_appointments/view/lab_appointmnets.dart';
import '../presentaion/orders/view/home/home_order_second_page.dart';
import '../presentaion/page_details/cubit/page_details_cubit.dart';
import '../presentaion/resources/locle/locale_cubit.dart';
import '../presentaion/telemedicine/view/normal_telemed/check_tele.dart';
import '../presentaion/telemedicine/view/normal_telemed/family_tele.dart';

class AppRoot extends StatelessWidget {
  const AppRoot._internal();
  static const _instance = AppRoot._internal();
  factory AppRoot() => _instance;

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (context) => AuthCubit(instance(), instance())),
        BlocProvider(create: (context) => HomeCubit(instance(), instance())),
        BlocProvider(create: (context) => WishlistCubit(instance())),
        BlocProvider(create: (context) => CartCubit(instance(), instance())),
        BlocProvider(create: (context) => ContactUsCubit(instance())),
        BlocProvider(
            create: (context) =>
                OrdersCubit(instance(), instance(), instance())),
        BlocProvider(
            create: (context) =>
                AccountCubit(instance(), instance(), instance())),
        BlocProvider(
            create: (context) => NotificationCubit(instance(), instance())),
        BlocProvider(
            create: (context) => TelemedicineCubit(instance(), instance())),
        BlocProvider(create: (context) => OnBordingCubit()),
        BlocProvider(create: (context) => MedicalCubit(instance())),
        BlocProvider(create: (context) => BnbCubit(instance())),
        BlocProvider(
            create: (context) => MapCubit(instance(), instance(), instance())),
        BlocProvider(create: (context) => AppointmentsCubit(instance())),
        BlocProvider(create: (context) => PageDetailsCubit()),
        BlocProvider(create: (context) => LocaleCubit(instance())),
        BlocProvider(
            create: (context) => PrescriptionCubit(instance(), instance())),
      ],
      child: ScreenUtilInit(
        designSize: const Size(360, 690),
        minTextAdapt: true,
        splitScreenMode: true,
        useInheritedMediaQuery: true,
        child: MaterialApp(
          localizationsDelegates: context.localizationDelegates,
          supportedLocales: context.supportedLocales,
          locale: context.locale,
          debugShowCheckedModeBanner: false,
          // theme: ThemeManger.getLightTheme(),
          // onGenerateRoute: RouteManger.route,
          // initialRoute: RouteName.splashView,
          home: SplashScreen(instance()),
          // home: HomeCartView(),
        ),
      ),
    );
  }
}
