import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/data/response/home/response_home.dart';
// import 'package:tahlili/data/response/home/response_home.dart';
import 'package:tahlili/domain/view_obj/auth/auth.dart';
// import 'package:tahlili/domain/view_obj/home/home.dart';
// import 'package:tahlili/presentaion/resources/constant_manger.dart';

import '../local/local_classes.dart';
import '../response/auth/response_auth.dart';

extension RegisterMapper on ResponseRegister {
  ObjRegister toDomain() => ObjRegister(message.orEmpty());
}

// extension InsurancesMappers on ResponseInsurance {
//   ObjInsurance toDomain() =>
//       ObjInsurance(id.orZero(), nameEn.orEmpty(), nameAr.orEmpty());
// }

// extension DealsMappers on ResponseDeals {
//   ObjDeals toDomain() => ObjDeals(
//       id: id.orZero(),
//       partnerId: partnerId.orZero(),
//       packageId: packageId.orZero(),
//       price: price.orZero(),
//       tat: tat.orZero(),
//       priceBeforeDiscount: priceBeforeDiscount.orZero(),
//       package: package.toDomain(),
//       partner: partner.toDomain(),
//       imageEN: imageEN.orEmpty(),
//       imageAR: imageAR.orEmpty(),
//       showInDeals: showInDeals,
//       dealEndDate: dealEndDate.orEmpty());
// }
// extension PackageMappers on ResponsePackage {
//   ObjPackages toDomain() => ObjPackages(
//       id: id.orZero(),
//       nameEn: nameEn.orEmpty(),
//       nameAr: nameAr.orEmpty(),
//       imageEN: imageEN.orEmpty(),
//       imageAR: imageAR.orEmpty(),
//       targetedGender: targetedGender,
//       packagesBmis: packagesBmis ,
//       packagesAges: packagesAges ,
//       packagesCategories: packagesCategories ,
//       pType: pType,
//       soldItems: soldItems.orZero(),
//       tahliliCode: tahliliCode.orEmpty());
// }

// extension PartnerMapper on ResponsePartner? {
//   ObjPartner toDomain() => ObjPartner(
//       id:this?.id.orZero()??ConstantManger.emptyInt,
//       nameEn:this?. nameEn.orEmpty()??,
//       nameAr: this?.nameAr.orEmpty()??,
//       hotline:this?. hotline.orEmpty()??,
//       nBNurseAvg: fBNurseAvg.orZero(),
//       fBServiceAvg: fBServiceAvg.orZero(),
//       image: image.orEmpty(),
//       phone: phone.orEmpty(),
//       taxNumber: taxNumber.orEmpty());
// }

// extension PackageBmisMappers on ResponsePackageBmis {
//   ObjPackageBmis toDomain() =>
//       ObjPackageBmis(id: id.orZero(), name: name.orEmpty());
// }

// extension PackageCatgoryMappers on ResponsePackageCatgory {
//   ObjPackageCatgory toDomain() => ObjPackageCatgory(
//       categoryId: categoryId,
//       categoryName: categoryName.orEmpty(),
//       packageNameEn: packageNameEn.orEmpty(),
//       packageNameAr: packageNameAr.orEmpty(),
//       pType: pType.orZero(),
//       soldItems: soldItems.orZero());
// }

// extension LookupMappers on ResponseLookup {
//   ObjLookup toDomain() => ObjLookup(
//       id: id.orZero(), name: name.orEmpty(), orderIndex:orderIndx.orZero());
// }

// extension PackagesAgeMappers on ResponsePackagesAge {
//   ObjPackagesAge toDomain() => ObjPackagesAge(ageId: ageId.orZero(), ageName: ageName.orEmpty());
// }



extension ResponseItemsCompareExtension on ResponseItemsCompare {
  ItemsCompare toHive() {
    return ItemsCompare(
      productId,
      productName,
      itemTypeId,
      itemTypeName,
      image,
      partnerNameEn,
      partnerNameAr,
      numberOfTests,
      tat,
      price,
      abbreviation,
      includedTests?.toHiveList(),
      includedMarker?.toHiveList(),
    );
  }
}

extension ResponseIncludedTestsListExtension on List<ResponseIncludedTests>? {
  List<IncludedTests>? toHiveList() {
    return this?.map((response) {
      return IncludedTests(
        response.testNameEn,
        response.testNameAr,
        response.includedMarker?.toHiveList(),
      );
    }).toList();
  }
}

extension ResponseIncludedMarkerListExtension on List<ResponseIncludedMarker>? {
  List<IncludedMarker>? toHiveList() {
    return this?.map((response) {
      return IncludedMarker(
        response.marker,
      );
    }).toList();
  }
}
