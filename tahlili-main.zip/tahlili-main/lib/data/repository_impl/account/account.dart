import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/data/data_services/account/account.dart';
import 'package:tahlili/data/failure/failure.dart';
import 'package:tahlili/data/network/network_info.dart';
import 'package:tahlili/data/requests/accounts/request_account.dart';
import 'package:tahlili/data/response/auth/response_auth.dart';
import 'package:tahlili/data/response/response.dart';
import 'package:tahlili/domain/repository/account/account.dart';

import '../../network/error_handler.dart';
import '../../response/account/reponse_account.dart';
import '../../response/orders/response_order.dart';

class AccountReposiotryImpl implements BaseAccountReposiotry {
  final BaseNetworkInfo _baseNetworkInfo;
  final BaseAccountDataServices _dataServices;

  AccountReposiotryImpl(this._baseNetworkInfo, this._dataServices);
  @override
  Future<Either<Failure, ResponseDashboard>> getDashboard() async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.getDashboard();
        return Right(response);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponsePatientWallet>>>
      getPatientWallet() async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.getPatientWallet();
        return Right(response);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponsePrescriptions>>>
      getPrescriptions() async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.getPrescriptions();
        return Right(response);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseAddresses>>> getPatientAddresses(
      {required int patientId}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response =
            await _dataServices.getPatientAddresses(patientId: patientId);
        return Right(response);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }



  @override
  Future<Either<String, ResponseAPI>> addPrescription(
      {required RequestPrescriptions prescriptions}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response =
            await _dataServices.addPrescription(prescriptions: prescriptions);

          return Right(response);

      }on DioException catch (e) {
        return Left(e.response!.data['message']);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure().message);
    }
  }

  @override
  Future<Either<Failure, List<ResponsePrescriptions>>> getPrescriptionDetails(
      {required int prescriptionId}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.getPrescriptionDetails(
            prescriptionId: prescriptionId);
        return Right(response);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, int>> getUserEntityID() async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.getUserEntityID();
        return Right(response);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseUserEntity>> getUserData(
      {required String userID, required int userEntityID}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.getUserData(
            userID: userID, userEntityID: userEntityID);
        return Right(response);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<String, ResponseAPI>> addProfile(
      {required String userID, required RequestAddProfile addProfile}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.addProfile(
            userID: userID, requestAddProfile: addProfile);
        return Right(response);
      }on DioException catch (e) {
        return Left(e.response!.data['message']);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure().message);
    }
  }

  @override
  Future<Either<String, ResponseAPI>> uploadFile(
      {required RequestUploadFile file}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.uploadFile(file: file);
        return Right(response);
      }on DioException catch (e) {
        return Left(e.response!.data['message']);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure().message);
    }
  }

  @override
  Future<Either<String, ResponseAPI>> addComplaints(
      {required RequestComplaints complaints}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response =
            await _dataServices.addComplaints(complaints: complaints);
        return Right(response);
      }on DioException catch (e) {
        return Left(e.response!.data['message']);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure().message);
    }
  }

  @override
  Future<Either<String, ResponseAPI>> savePayment(
      {required Map<String, dynamic> map}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.savePayment(map: map);
        return Right(response);
      } catch (e) {
        return Left(e.toString());
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure().message);
    }
  }

  @override
  Future<Either<Failure, ResponsePatient>> getPatient(
      {required int patientEntityId}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response =
            await _dataServices.getPatient(userEntityID: patientEntityId);
        return Right(response);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<String, ResponseAPI>> editProfile(
      {required int patientEntityId,
      required RequestEditProfile editProfile}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.editProfile(
            userEntityID: patientEntityId, editProfile: editProfile);
        return Right(response);
      }on DioException catch (e) {
        return Left(e.response!.data['message']);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure().message);
    }
  }

  @override
  Future<Either<Failure, List<ResponsePatientProfile>>> getPatientProfiles(
      {required String patientUserId}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.getPatientProfiles(
            patientUserId: patientUserId);
        return Right(response);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseAddresses>>> getAddresses({required String patientId})async {
     if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.getAddresses(
            patientId: patientId);
        return Right(response);
      } catch (e) {
        return Left(Failure(1, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseComplaints>>> getComplaints() async{
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.getComplaints();
        return Right(response);
      } catch (e) {
        return Left(Failure(1, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseComplaintDetail>> getComplaintsDetails({required int id}) async{
     if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.getComplaintsDetails(id: id);
        return Right(response);
      } catch (e) {
        return Left(Failure(1, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseWalletTracking>>> getWalletTracking()async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.getWalletTracking();
        return Right(response);
      } catch (e) {
        return Left(Failure(1, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }
   @override
  Future<Either<Failure, List<ResponseRefund>>> getRefunds()async {
   if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _dataServices.getRefunds();

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }
  
  @override
  Future<Either<Failure, ResponseAPI>> requestRefund({required RequestRefund refund})async {
   if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _dataServices.requestRefund(refund: refund);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }
}
