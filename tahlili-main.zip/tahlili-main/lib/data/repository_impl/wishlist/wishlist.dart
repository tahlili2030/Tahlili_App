import 'package:dartz/dartz.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/data/data_services/wishlist/wishlist.dart';
import 'package:tahlili/data/failure/failure.dart';
import 'package:tahlili/data/network/network_info.dart';
import 'package:tahlili/data/requests/wishlist/request_wishlist.dart';
import 'package:tahlili/data/response/response.dart';
import 'package:tahlili/data/response/wishlist/response_wishlist.dart';
import 'package:tahlili/domain/repository/wishlist/wishlist.dart';

import '../../network/error_handler.dart';

class WishlistRepositoryImp implements BaseWishlistRepository {
  final BaseNetworkInfo _baseNetworkInfo;
  final BaseWishlistDataServices _wishlistDataServices;

  WishlistRepositoryImp(this._baseNetworkInfo, this._wishlistDataServices);
  @override
  Future<Either<Failure, List<ResponseWishlist>>> getWishlist(
      {bool? asc}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _wishlistDataServices.getWisList(asc: asc);

        return Right(response);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseAPI>> addToWishlit(
      {required RequestWishlist requestWishlist}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _wishlistDataServices.addToWishlit(
            requestWishlist: requestWishlist);
             if (response.statusCode == 200) {
          return Right(response);
        } else {
        return  Left(Failure(response.statusCode.orZero(), response.message.orEmpty()));
        }

        
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }
  
  @override
  Future<Either<Failure, ResponseAPI>> deleteWishlistItem({required int itemId})async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _wishlistDataServices.deleteWishlistItem(
            itemId: itemId);
             if (response.statusCode == 200) {
          return Right(response);
        } else {
        return  Left(Failure(response.statusCode.orZero(), response.message.orEmpty()));
        }

      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }
}
