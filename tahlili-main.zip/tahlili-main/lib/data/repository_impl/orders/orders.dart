import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:tahlili/data/data_services/order/order.dart';
import 'package:tahlili/data/failure/failure.dart';
import 'package:tahlili/data/network/network_info.dart';
import 'package:tahlili/data/requests/order/request_order.dart';
import 'package:tahlili/data/response/home/response_home.dart';
import 'package:tahlili/data/response/orders/response_order.dart';
import 'package:tahlili/data/response/response.dart';
import 'package:tahlili/domain/repository/orders/orders.dart';

import '../../network/error_handler.dart';

class OrdersRepositoryImpl implements BaseOrdersRepository {
  final BaseNetworkInfo _baseNetworkInfo;
  final BaseOrdersDataServices _ordersDataServices;

  OrdersRepositoryImpl(this._baseNetworkInfo, this._ordersDataServices);
  @override
  Future<Either<Failure, List<ResponseOrder>>> getOrders(
      {required bool? asc}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _ordersDataServices.getOrders(asc: asc);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseWorkingHours>> getLabWorkingHours() async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _ordersDataServices.getLabWorkingHours();

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseNurseFees>> getNurseFees(
      {required int? partnerTestId,
      required int? partnerPackageId,
      required bool? isMale}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _ordersDataServices.getNurseFees(
            partnerTestId: partnerTestId,
            partnerPackageId: partnerPackageId,
            isMale: isMale);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<ResponseAPI, ResponseAPI>> createHomeOrder(
      {required RequestQuickOrder order}) async {
    final rsponse = await _ordersDataServices.createHomeOrder(order: order);
    if (rsponse.statusCode == 200) {
      return Right(rsponse);
    } else {
      return Left(rsponse);
    }
  }

  @override
  Future<Either<Failure, List<ResponseLookup>>> getDepartments(
      {required String filterQuery}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse =
            await _ordersDataServices.getDepartments(filterQuery: filterQuery);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseTeleDoctor>>> getTeleDoctors(
      {required String filterQuery}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse =
            await _ordersDataServices.getTeleDoctors(filterQuery: filterQuery);

        return Right(rsponse);
      } catch (e) {
        return Left(Failure(1, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseBusyTelemedicnice>>> getBusyTele(
      {required String date}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _ordersDataServices.getBusyTele(date: date);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseAPI>> createTeleOrder(
      {required RequestTele requestTele}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse =
            await _ordersDataServices.createTeleOrder(requestTele: requestTele);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<DioException, ResponseAPI>> createLabOrder(
      {required RequestQuickOrder order}) async {
    try {
      final rsponse = await _ordersDataServices.createLabOrder(order: order);
      return Right(rsponse);
    } on DioError catch (e) {
      return Left(e);
    }
  }

  @override
  Future<Either<Failure, List<ResponseTeleMedOrders>>>
      getTelemedOrders() async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _ordersDataServices.getTelemedOrders();

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseLabBranches>>> getLabBranches(
      {required int partnerId,
      required int itemId,
      required bool isTest}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _ordersDataServices.getLabBranches(
            partnerId: partnerId, itemId: itemId, isTest: isTest);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseAPI>> cancelTelemedAppt(
      {required int telemedId}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse =
            await _ordersDataServices.cancelTelemedAppt(telemedId: telemedId);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseOrderDetails>> getOrderDetails(
      {required int orderId}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse =
            await _ordersDataServices.getOrderDetails(orderId: orderId);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseUpcomimgAppts>>>
      getUpcomingAppts() async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _ordersDataServices.getUpcomingAppts();

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseTelemedDetails>> getTelemedOrderDetails(
      {required int orderId}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse =
            await _ordersDataServices.getTelemedOrderDetails(orderId: orderId);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseOrderStateId>> getOrderCurrentState(
      {required int orderId}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse =
            await _ordersDataServices.getOrderCurrentState(orderId: orderId);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponsiveNewApointment>>> getNewAppointments(
      {required bool? now, required bool asc}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse =
            await _ordersDataServices.getNewAppointments(now: now, asc: asc);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseLabWorkingHoursForAppt>>>
      getLabWorkingHoursForAppt(
          {required int labId, required bool atHomeTiming}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _ordersDataServices.getLabWorkingHoursForAppt(
            labId: labId, atHomeTiming: atHomeTiming);

        return Right(rsponse);
      } catch (e) {
        return Left(Failure(1, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseAPI>> rescheduleOrder(
      {required int orderId,
      required String date,
      required String time}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _ordersDataServices.rescheduleOrder(
            orderId: orderId, date: date, time: time);

        return Right(rsponse);
      } catch (e) {
        return Left(Failure(1, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }
}
