import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/data/data_services/auth/auth.dart';
import 'package:tahlili/data/failure/failure.dart';
import 'package:tahlili/data/mappers/mappers.dart';
import 'package:tahlili/data/network/error_handler.dart';
import 'package:tahlili/data/network/network_info.dart';
import 'package:tahlili/data/requests/auth/request_auth.dart';
import 'package:tahlili/data/requests/auth/request_contact_us.dart';
import 'package:tahlili/data/response/auth/response_auth.dart';
import 'package:tahlili/data/response/home/response_home.dart';
import 'package:tahlili/data/response/response.dart';
import 'package:tahlili/domain/repository/auth/auth.dart';
import 'package:tahlili/domain/view_obj/auth/auth.dart';

class AuthRepositoryImpl implements BaseAuthRepository {
  final BaseAuthDataServices _dataServices;
  final BaseNetworkInfo _baseNetworkInfo;

  AuthRepositoryImpl(this._dataServices, this._baseNetworkInfo);
  @override
  Future<Either<String, ResponseAPI>> login(
      {required RequestLogin login}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.login(login: login);
      return Right(response);
      }on DioException catch (e) {
        return Left(e.response!.data['message']);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure().message);
    }
  }

  @override
  Future<Either<String, ResponseRegister>> register(
      {required RequestRegister register}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.register(register: register);

          return Right(response);

      }on DioException catch (e) {

        return Left(e.response!.data['message']);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure().message);
    }
  }

  @override
  Future<Either<String, ResponseAPI>> contactUs(
      {required RequestContactUs requestContactUs}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response =
            await _dataServices.contactUs(requestContactUs: requestContactUs);

          return Right(response);

      }on DioException catch (e) {
        return Left(e.response!.data['message']);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure().message);
    }
  }

  @override
  Future<Either<String, ResponseOtp>> verifyOtp(
      {required RequestOtp requestOtp}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.verifyOtp(requestOtp: requestOtp);

        return Right(response);
      }on DioException catch (e) {
         return Left(e.response!.data['message']);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure().message);
    }
  }

  @override
  Future<Either<Failure, List<ResponseLookup>>> getLookUp({required String tableName}) async{
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.getLookUp(tableName: tableName);

        return Right(response);
      } catch (e) {
        return Left(Failure(0, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }
}
