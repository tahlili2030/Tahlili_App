import 'package:dartz/dartz.dart';
import 'package:http/http.dart' as http;
import 'package:tahlili/data/data_services/map/map.dart';
import 'package:tahlili/data/network/network_info.dart';
import 'package:tahlili/app/extenstions.dart';

import '../../failure/failure.dart';
import '../../network/error_handler.dart';
import '../../requests/accounts/request_account.dart';
import '../../response/orders/response_order.dart';
import '../../response/response.dart';

abstract class BaseMapRepository {
  Future<String> getLocationId(String location);
  Future<Map<String, dynamic>> getPlace(String placeID);
  Future<http.Response> getLocation(String location);
  Future<Either<Failure,ResponseAPI>> addNewAddress({
    required RequestAddress address
   });
    Future<Either<Failure,ResponseAPI>> updatePatientAddress({
    required int addressId,
    required RequestAddress address
   });
    Future<Either<Failure,ResponseAPI>> deletePatientAddress({
    required int addressId,
   });
   Future<Either<Failure,ResponseLocation>> getNurseLocation({
    required int orderID
   });
}

class MapRepositoryImpl implements BaseMapRepository {
  final BaseMapDataServices _dataServices;
  final BaseNetworkInfo _baseNetworkInfo;

  MapRepositoryImpl(this._dataServices, this._baseNetworkInfo);
  @override
  Future<String> getLocationId(String location) async {
    return await _dataServices.getLocationId(location);
  }

  @override
  Future<Map<String, dynamic>> getPlace(String location) async {
    return await _dataServices.getPlace(location);
  }

  @override
  Future<http.Response> getLocation(String location) async {
    return await _dataServices.getLocation(location);
  }
   @override
  Future<Either<Failure, ResponseAPI>> addNewAddress(
      {required RequestAddress address}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.addNewAddress(address: address);
        if (response.statusCode == 200) {
          return Right(response);
        } else {
          return Left(Failure(
              response.statusCode.orZero(), response.message.orEmpty()));
        }
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseLocation>> getNurseLocation({required int orderID})async {
     if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.getNurseLocation(orderId: orderID);

          return Right(response);



      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }
  @override
  Future<Either<Failure, ResponseAPI>> updatePatientAddress(
      {required int addressId, required RequestAddress address}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.updatePatientAddress(
            address: address, addressId: addressId);
        if (response.statusCode == 200) {
          return Right(response);
        } else {
          return Left(Failure(
              response.statusCode.orZero(), response.message.orEmpty()));
        }
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseAPI>> deletePatientAddress({required int addressId}) async{
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _dataServices.deletePatientAddress(
             addressId: addressId);
        if (response.statusCode == 200) {
          return Right(response);
        } else {
          return Left(Failure(
              response.statusCode.orZero(), response.message.orEmpty()));
        }
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }
}
