import 'package:dartz/dartz.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/data/data_services/notification/notification.dart';
import 'package:tahlili/data/failure/failure.dart';
import 'package:tahlili/data/network/network_info.dart';
import 'package:tahlili/data/response/response.dart';
import 'package:tahlili/domain/repository/notification/notification.dart';

import '../../network/error_handler.dart';
import '../../response/notofication/notification.dart';

class NotificationRepositoryImpl implements BaseNotificationRepository {
  final BaseNetworkInfo _baseNetworkInfo;
  final BaseNotificationDataServices _notificationDataServices;

  NotificationRepositoryImpl(
      this._baseNetworkInfo, this._notificationDataServices);
  @override
  Future<Either<Failure, List<ResponseNotifcation>>> getNotification() async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _notificationDataServices.getNotification();

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseAPI>> sendNotifcation(
      {required Map<String, dynamic> map}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse =
            await _notificationDataServices.sendNotifcaton(map: map);

        if (rsponse.statusCode == 200) {
          return Right(rsponse);
        } else {
          return Left(
              Failure(rsponse.statusCode.orZero(), rsponse.message.orEmpty()));
        }
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseAPI>> updateNotifcation(
      {required int notificationId,
      required String userId,
      required String title,
      required bool seen}) async {
   if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _notificationDataServices.updateNotifcation(notificationId: notificationId, userId: userId, title: title, seen: seen);

        if (rsponse.statusCode == 200) {
          return Right(rsponse);
        } else {
          return Left(
              Failure(rsponse.statusCode.orZero(), rsponse.message.orEmpty()));
        }
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }
}
