import 'package:dartz/dartz.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/data/data_services/cart/cart.dart';
import 'package:tahlili/data/failure/failure.dart';
import 'package:tahlili/data/requests/cart/request_cart.dart';
import 'package:tahlili/data/requests/order/request_order.dart';
import 'package:tahlili/data/response/cart/response_cart.dart';
import 'package:tahlili/data/response/response.dart';
import 'package:tahlili/domain/repository/cart/cart.dart';
import '../../network/error_handler.dart';
import '../../network/network_info.dart';

class CartRepositoryImpl implements BaseCartRepository {
  final BaseNetworkInfo _baseNetworkInfo;
  final BaseCartDataServices _cartDataServices;

  CartRepositoryImpl(this._baseNetworkInfo, this._cartDataServices);
  @override
  Future<Either<Failure, List<ResponseCart>>> getCart({required String filterQuery}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _cartDataServices.getCart(filterQuery:filterQuery);

        return Right(response);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseAPI>> addToCart(
      {required RequestCart requestCart,
      required String userId}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response =
            await _cartDataServices.addToCart(requestCart: requestCart,userId: userId);

        if (response.statusCode == 200) {
          return Right(response);
        } else {
        return  Left(Failure(response.statusCode.orZero(), response.message.orEmpty()));
        }
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseAPI>> deleteCartItem({required int cartId})async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response =
            await _cartDataServices.deleteCartItem(cartId: cartId);

        if (response.statusCode == 200) {
          return Right(response);
        } else {
        return  Left(Failure(response.statusCode.orZero(), response.message.orEmpty()));
        }
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseAPI>> createOrder({required RequestOrder order})async {
   if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response =
            await _cartDataServices.createOrder(order: order);

        if (response.statusCode == 200) {
          return Right(response);
        } else {
        return  Left(Failure(response.statusCode.orZero(), response.message.orEmpty()));
        }
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseAPI>> createLabOrder({required RequestOrder order})async {
  if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response =
            await _cartDataServices.createLabOrder(order: order);

        if (response.statusCode == 200) {
          return Right(response);
        } else {
        return  Left(Failure(response.statusCode.orZero(), response.message.orEmpty()));
        }
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }
}
