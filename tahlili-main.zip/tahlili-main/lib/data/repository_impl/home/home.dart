import 'package:dartz/dartz.dart';
import 'package:tahlili/app/extenstions.dart';
import 'package:tahlili/data/data_services/home/home.dart';
import 'package:tahlili/data/failure/failure.dart';
import 'package:tahlili/data/network/network_info.dart';
import 'package:tahlili/data/requests/home/request_home.dart';
import 'package:tahlili/data/response/home/response_home.dart';
import 'package:tahlili/data/response/response.dart';
import 'package:tahlili/domain/repository/home/home.dart';

import '../../network/error_handler.dart';

class HomeRepositoryImpl implements BaseHomeRepository {
  final BaseHomeDataServices _homeDataServices;
  final BaseNetworkInfo _baseNetworkInfo;

  HomeRepositoryImpl(this._homeDataServices, this._baseNetworkInfo);
  @override
  Future<Either<Failure, List<ResponseInsurance>>> getInsurancesLookUp() async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final response = await _homeDataServices.getInsurancesLookUp();

        /// response.map((e) => objInsurances.add(e.toDomain()));

        return Right(response);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseDeals>>> getShownDeals() async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getShownDeals();

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseSearch>>> getGeneticTests() async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getGeneticTests();

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseHomeCategory>>>
      getHomeCategories() async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getHomeCategories();

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseHomeLabs>>> getHomeLabs() async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getHomeLabs();

        return Right(rsponse);
      } catch (e) {
        return Left(Failure(1, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseHomePackages>>>
      getHomeRecommendedPackages({String? orderBy, bool? asc}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getHomeRecommendedPackages(
            orderBy: orderBy, asc: asc);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseHomeFeedback>>> getHomeFeedBack() async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getHomeFeedBack();

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseCoupon>>> getHomeCoupon(
      {String? showInHomePage}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getHomeCoupon(
            showInHomePage: showInHomePage);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseSearch>>> getHomeSearch({
     required String? orderBy,
    required String ?filterQuery,
    required bool ?asc,
  }) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getHomeSearch(orderBy: orderBy,filterQuery: filterQuery,
        asc: asc);

        return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseAPI>> getPatientsHistories(
      {required RequestPatientHisotry patientHisotry}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getPatientsHistories(
            patientHisotry: patientHisotry);

        if (rsponse.statusCode == 200) {
          return Right(rsponse);
        } else {
          return Left(
              Failure(rsponse.statusCode.orZero(), rsponse.message.orEmpty()));
        }
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseAPI>> changeLanguage(
      {required int langId}) async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.chnageLnguage(langId: langId);

        if (rsponse.statusCode == 200) {
          return Right(rsponse);
        } else {
          return Left(
              Failure(rsponse.statusCode.orZero(), rsponse.message.orEmpty()));
        }
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseItemsCompare>> itemsCompare({
    required int itemId,
    required int itemType,
  }) async{
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.itemsCompare(itemId: itemId, itemType: itemType);


         return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseUserPackages>>> getUserPackages({required bool isTailord})async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getUserPackages(isTailord: isTailord);


         return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseHomeAds>>> getHomeAds({required String adsId})async {
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getHomeAds(adsId: adsId);


         return Right(rsponse);
      } catch (e) {
        return Left(ErrorHandler.handle(e).failure);
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseSearch>>> getTahliliPackages() async{
   if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getTahliliPackages();


         return Right(rsponse);
      } catch (e) {
        return Left(Failure(1, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, List<ResponseIndividualTests>>> getIndividualTests() async{
    if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getIndividualTests();


         return Right(rsponse);
      } catch (e) {
        return Left(Failure(1, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponseAPI>> addClick({required int adsId})async {
   if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.addClick(adsId: adsId);


         return Right(rsponse);
      } catch (e) {
        return Left(Failure(1, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }

  @override
  Future<Either<Failure, ResponsePackageDetails>> getShownDealsDetails({required int itemId})async {
     if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getShownDealsDetails(itemId: itemId);


         return Right(rsponse);
      } catch (e) {
        return Left(Failure(1, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }
  
  @override
  Future<Either<Failure, ResponseTestDetails>> getTestsDetails({required int itemId})async{
     if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getTestsDetails(itemId: itemId);


         return Right(rsponse);
      } catch (e) {
        return Left(Failure(1, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }
  
  @override
  Future<Either<Failure, ResponsePartnerCount>> getPartnerCount({required int partnerId}) async{
   if (await _baseNetworkInfo.checkConnection()) {
      try {
        final rsponse = await _homeDataServices.getPartnerCount(partnerId: partnerId);


         return Right(rsponse);
      } catch (e) {
        return Left(Failure(1, e.toString()));
      }
    } else {
      return Left(DataSource.NO_INTERNET_CONNECTION.failure());
    }
  }
}
