import 'dart:io';

import 'package:dio/dio.dart';

import 'package:retrofit/http.dart';
import 'package:tahlili/data/response/auth/response_auth.dart';
import 'package:tahlili/data/response/cart/response_cart.dart';
import 'package:tahlili/data/response/home/response_home.dart';
import 'package:tahlili/data/response/wishlist/response_wishlist.dart';

import '../../app/end_points.dart';
import '../response/account/reponse_account.dart';
import '../response/notofication/notification.dart';
import '../response/orders/response_order.dart';
import '../response/response.dart';

part 'app_api.g.dart';

@RestApi(baseUrl: EndPoints.baseUrl)
abstract class AppServiceClint {
  factory AppServiceClint(Dio dio, {String baseUrl}) = _AppServiceClint;

  @GET('Lookups')
  Future<List<ResponseLookup>> getLookUp(@Query('tableName') String tableName);

// auth
  @POST('Patients/RegisterPatient')
  Future<ResponseRegister> register(
    @Field("phone") String phone,
    @Field("email") String email,
    @Field("firstName") String fName,
    @Field("lastName") String lName,
    @Field("genderId") String genderID,
    @Field("nationalityId") String nationalityID,
    @Field("languageId") String languageID,
    @Field("userId") String userID,
    @Field("birthDate") String birthDate,
    @Field("idNumber") String idNumber,
  );

  @POST('Patients/PatientLogin')
  Future<ResponseAPI> login(@Field('phone') String phone);

  @POST('Account/VerifyOTP')
  Future<ResponseOtp> verifyOtp(
      @Field('phoneNumber') String phone, @Field('otp') String otp);

//Account

  @GET('Patients/GetId')
  Future<int> getUserEntityID();

  @GET('Account/{id}')
  Future<ResponseUserEntity> getUserData(
      @Path('id') String userID, @Query('patientEntityId') int userEntityID);

  @POST('Patients/AddProfile')
  Future<ResponseAPI> addPatientProfile(
      @Query('patientUserId') String userID,
      @Field('idNumber') String idNumber,
      @Field('firstName') String firstName,
      @Field('middleName') String middleName,
      @Field('lastName') String lastName,
      @Field('genderId') int genderId,
      @Field('nationalityId') int nationalityId,
      @Field('languageId') int languageId,
      @Field('birthDate') String birthDate,
      @Field('userId') String userId,
      @Field('copyOrdersAddressToProfile') bool copyOrdersAddressToProfile);
  @GET('Patients/{id}')
  Future<ResponsePatient> getPatient(@Path('id') int userEntityID);

  @PUT('Patients/{id}')
  Future<ResponseAPI> editProfile(
      @Path('id') int userEntityID, @Body() String rawData);

  @GET('Patients/GetProfiles')
  Future<List<ResponsePatientProfile>> getPatientProfiles(
      @Query('patientUserId') String patientUserId);

  @POST('Files/UploadFile')
  @MultiPart()
  Future<ResponseAPI> uploadFile(
      @Query('id') String id,
      @Query('entityName') String entityName,
      @Query('isPdf') bool isPdf,
      @Part(value: 'files') File file);

  @GET('/PatientsWallets')
  Future<List<ResponsePatientWallet>> getPatientWallet();
  @POST('Account/SendEmail')
  Future<ResponseAPI> contactUs(
    @Field('firstName') String firstName,
    @Field('lastName') String lastName,
    @Field('email') String email,
    @Field('phone') String phone,
    @Field('description') String description,
  );

  @GET('Account/GetDashboardData')
  Future<ResponseDashboard> getDashboard();

  @GET('Prescriptions?Asc=false')
  Future<List<ResponsePrescriptions>> getPrescriptions();

  @GET('Prescriptions/GetDetails/{id}')
  Future<List<ResponsePrescriptions>> getPrescriptionDetails(
      @Path('id') String prescriptionId);

  @POST('Prescriptions')
  Future<ResponseAPI> addPrescription(@Body() String rawData);

  @GET('/PatientsAddresses/GetPatientsAddresses/{PatientId}')
  Future<List<ResponseAddresses>> getPatientAddresses(
      @Path('PatientId') String patientId);

  @GET('/PatientsAddresses/GetPatientsAddresses')
  Future<List<ResponseAddresses>> getAddresses(
      @Query('UserId') String patientId);

  @POST('/PatientsAddresses/AddNewAddress')
  Future<ResponseAPI> addNewAddress(@Body() String rawData);

  @PUT('/PatientsAddresses/UpdateAddress/{id}')
  Future<ResponseAPI> updatePatientAddress(
      @Path('id') int addressId, @Body() String rawData);
  @DELETE('PatientsAddresses/DeleteAddress/{id}')
  Future<ResponseAPI> deletePatientAddress(
    @Path('id') int addressId,
  );

  @GET('/Complaints')
  Future<List<ResponseComplaints>> getComplaints();

  @POST('/Complaints')
  Future<ResponseAPI> addComplaints(
    @Field('patientId') int patientId,
    @Field('complaintsTypeId') int complaintsTypeId,
    @Field('description') String description,
  );

  @GET('/Complaints/GetDetails/{id}')
  Future<ResponseComplaintDetail> getComplaintsDetails(@Path('id') int id);

  @GET('/Complaints/GetImage')
  Future<ResponseAPI> getComplaintsImage(@Query('id') String id);

  @POST('Payments/SavePayment')
  Future<ResponseAPI> savePayment(@Body() String rawData);

  @GET('PatientsWalletsTracking')
  Future<List<ResponseWalletTracking>> getWalletTracking();

// home

  @GET('Advertisements/App')
  Future<List<ResponseHomeAds>> getHomeAds(@Query('FilterQuery') String adsId);

  @PUT('Advertisements/ClicksCount/{id}')
  Future<ResponseAPI> addClick(@Path('id') int id);
  @GET('Insurances')
  Future<List<ResponseInsurance>> getInsurancesLookUp();

  @GET('PartnersPackages/ShowInDeals')
  Future<List<ResponseDeals>> getShownDeals();
  @GET('PartnersPackages/{id}')
  Future<ResponsePackageDetails> getShownDealsDetails(@Path('id') int itemId);
  @GET('PartnersTests/{id}')
  Future<ResponseTestDetails> getTestsDetails(@Path('id') int itemId);

  @GET('Partners/GetPartnerTestSAndPackagesCount')
  Future<ResponsePartnerCount> getPartnerCount(
      @Query('partnerId') int partnerId);

  @GET(
      'PartnersItems/TahliliItems?FilterQuery=partnerId%3D24%26%26%20itemType%3D%22test%22%20%26%26%20classificationId.Contains%28%22%2C13%2C%22%29')
  Future<List<ResponseSearch>> getGeneticTests();
  @GET('Tests/GetAll')
  Future<List<ResponseTests>> getTestById(
      @Query('FilterQuery') String filterQuery);

  @GET('Classifications')
  Future<List<ResponseIndividualTests>> getIndividualTest();

  @GET('Categories')
  Future<List<ResponseHomeCategory>> getHomeCategories();

  @GET('Partners/GetPartnerForIndex')
  Future<List<ResponseHomeLabs>> getHomeLabs();

  @GET('PartnersItems/TahliliItems')
  Future<List<ResponseSearch>> getTahliliPackages();

  @GET('Packages')
  Future<List<ResponseHomePackages>> getHomeRecommendedPackages(
      @Query('OrderBy') String? orderBy, @Query('Asc') bool? asc);

  @GET('PatientsAppFeedback/GetPatientsFeedbacksInHomePage')
  Future<List<ResponseHomeFeedback>> getHomeFeedBack();

  @GET('Coupons')
  Future<List<ResponseCoupon>> getHomeCoupon(
      @Query('FilterQuery') String? showInHomePage);

  @GET('/partnersItems')
  Future<List<ResponseSearch>> getHomeSearch(
    @Query('OrderBy') String? orderBy,
    @Query('FilterQuery') String? filterQuery,
    @Query('Asc') bool? asc,
  );

  @POST('/PatientsHistories')
  Future<ResponseAPI> getPatientsHistories(
    @Field('patientId') int patientId,
    @Field('testId') int testId,
    @Field('packageId') int packageId,
  );

  @PUT('/Patients/ChangeLanguage')
  Future<ResponseAPI> changeLang(
    @Field('languageId') int languageId,
  );

  @POST('/Comparisons')
  Future<ResponseItemsCompare> itemCmpare(
    @Query('partnerPackageId') int? partnerPackageId,
    @Query('partnerTestId') int? partnerTestId,
  );

  @GET('Packages/GetTailoredOrRecommendedPackages')
  Future<List<ResponseUserPackages>> getUserPackages(
      @Query('IsDynamic') bool isTailord);

  // Notification
  @GET('/Notifications')
  Future<List<ResponseNotifcation>> getNotification();

  @PUT('/Notifications/{id}')
  Future<ResponseAPI> updateNotifciations(
      @Path('id') int notificationId, @Body() String rawData);

  @POST('/Notifications')
  Future<ResponseAPI> sendNotifcaton(@Body() String rawData);

  // WishList
  @GET('WishLists')
  Future<List<ResponseWishlist>> getWisList(@Query('Asc') bool? asc);

  @POST('WishLists')
  Future<ResponseAPI> addToWishlit(
    @Field('patientId') int patientId,
    @Field('partnerPackageId') int? partnerPackageId,
    @Field('partnerTestId') int? partnerTestId,
  );

  @DELETE('WishLists/{id}')
  Future<ResponseAPI> deleteWishlistItem(
    @Path('id') String itemId,
  );

  //Cart
  @GET('CartsItems')
  Future<List<ResponseCart>> getCart(@Query('FilterQuery') String filterQuery);

  @POST('CartsItems')
  Future<ResponseAPI> addToCart(
    @Field('patientId') int patientId,
    @Field('labId') int? labId,
    @Field('partnerTestId') int? partnerTestId,
    @Field('partnerPackageId') int? partnerPackageId,
    @Field('userId') String userId,
    @Field('vistDate') String vistDate,
    @Field('addressId') int? addressId,
  );

  @DELETE('CartsItems/{id}')
  Future<ResponseAPI> deleteCartItem(@Path('id') String cartId);

  // Orders

  @POST('Orders/CreateQuickOrderAtHome')
  Future<ResponseAPI> createHomeQOrder(@Body() String rawData);
  @POST('Orders/CreateQuickOrderAtLab')
  Future<ResponseAPI> creatLabOrder(@Body() String rawData);
  @GET('Orders')
  Future<List<ResponseOrder>> getOrders(@Query('Asc') bool? asc);
  @GET('Orders/GetOrdersDetailsForPatientApp/{id}')
  Future<ResponseOrderDetails> getOrderDetails(@Path('id') int orderId);
  @POST('Orders')
  Future<ResponseAPI> createHomeOrder(@Body() String rawData);
  @POST('Orders/CreateOrderAtLab')
  Future<ResponseAPI> createLabOrder(@Body() String rawData);

  @GET('Nurses/GetLocation')
  Future<ResponseLocation> getNurseLocation(@Query("orderId") String orderId);
  @GET('Labs/GetTahliliLab')
  Future<ResponseWorkingHours> getLabWorkingHours();

  @GET('Labs/GetLabsWorkingTimes')
  Future<List<ResponseLabWorkingHoursForAppt>> getLabWorkingHoursForAppt(
    @Query("labId") int labId,
    @Query("AtHomeTiming") bool atHomeTiming,
  );

  @GET('Labs/GetLabsForQuickOrderByPartnerId')
  Future<List<ResponseLabBranches>> getLabBranches(
    @Query('partnerId') int partnerId,
    @Query('itemId') int itemId,
    @Query('isTest') bool isTest,
  );

  @GET('Orders/GetNurseFeesForQuickOrder')
  Future<ResponseNurseFees> getNurseFees(
    @Query('partnerTestId') int? partnerTestId,
    @Query('partnerPackageId') int? partnerPackageId,
    @Query('isMale') bool? isMale,
  );

  @GET('Orders/GetAppointments')
  Future<List<ResponseUpcomimgAppts>> getUpcomingAppts(
      @Query('upcoming') bool upcoming);

  @GET('OrdersTelemedicines/GetCurrentOrderStateId')
  Future<ResponseOrderStateId> getOrderCurrentState(@Query('id') int orderId);

  @GET("OrdersSummary")
  Future<List<ResponsiveNewApointment>> getNewAppointments(
    @Query("now") bool? now,
    @Query("Asc") bool asc,
    @Query("VisitDateTime") String visitDateTime,
  );

  @POST("Orders/RescheduleOrder")
  Future<ResponseAPI> rescheduleOrder(
      @Query('OrderId') int orderId, @Body() String rawData);

//////////////////////////////////////TELEMEDICNE///////////////////////////////

  @GET('DoctorsDepartments')
  Future<List<ResponseLookup>> getDepartments(
      @Query('FilterQuery') String filterQuery);

  @GET('Doctors/GetAll')
  Future<List<ResponseTeleDoctor>> getTeleDoctors(
      @Query('FilterQuery') String filterQuery, @Query('getAll') bool getAll);

  @GET('OrdersTelemedicines/GetBusySlots')
  Future<List<ResponseBusyTelemedicnice>> getBusyTele(
      @Query('date') String date);

  @POST('OrdersTelemedicines')
  Future<ResponseAPI> createTeleOrder(@Body() String rawData);

  @GET('OrdersTelemedicines')
  Future<List<ResponseTeleMedOrders>> getTelemedOrders(@Query('Asc') bool asc);
  @GET('OrdersTelemedicines/{id}')
  Future<ResponseTelemedDetails> getTelemedOrderDetails(
      @Path('id') int orderId);

  @POST('OrdersTelemedicines/Cancel')
  Future<ResponseAPI> cancelTelemedAppt(@Query('Id') int telemedId);

  @GET('Refunds')
  Future<List<ResponseRefund>> getRefunds();

  @POST('Refunds')
  Future<ResponseAPI> requestRefund(@Body() String rawData);
}
