// ignore_for_file: constant_identifier_names

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';
import '../../app/end_points.dart';
import '../../app/pref_manager.dart';

const String APPLICATION_JSON = "application/json";
const String CONTENT_TYPE = "content-type";
const String ACCEPT = "accept";
const String AUTHORIZATION = "authorization";
const String DEFAULT_LANGUAGE = "language";

class DioFactory {
  final PreferancesManager _preferancesManager;

  DioFactory(this._preferancesManager);

  Future<Dio> getDio() async {
    final Dio dio = Dio();
final token=await _preferancesManager.getData(key: userToken);
    Map<String, String> headers = {
      CONTENT_TYPE: APPLICATION_JSON,
      ACCEPT: APPLICATION_JSON,
      AUTHORIZATION: "Bearer $token",
      DEFAULT_LANGUAGE: await _preferancesManager.getLanguage()
    };

    dio.options = BaseOptions(
        baseUrl: EndPoints.baseUrl,
        headers: headers,
        receiveTimeout: const Duration(minutes: 1),
        sendTimeout: const Duration(minutes: 1));

    if (!kReleaseMode) {
      // its debug mode so print app logs
      dio.interceptors.add(PrettyDioLogger(
        requestHeader: true,
        requestBody: true,
        responseHeader: true,
      ));
    }

    return dio;
  }
}
