// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'local_classes.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class ItemsCompareAdapter extends TypeAdapter<ItemsCompare> {
  @override
  final int typeId = 0;

  @override
  ItemsCompare read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ItemsCompare(
      fields[0] as int?,
      fields[1] as String?,
      fields[2] as int?,
      fields[3] as String?,
      fields[4] as String?,
      fields[5] as String?,
      fields[6] as String?,
      fields[7] as int?,
      fields[8] as int?,
      fields[9] as String?,
      fields[10] as String?,
      (fields[11] as List?)?.cast<IncludedTests>(),
      (fields[12] as List?)?.cast<IncludedMarker>(),
    );
  }

  @override
  void write(BinaryWriter writer, ItemsCompare obj) {
    writer
      ..writeByte(13)
      ..writeByte(0)
      ..write(obj.productId)
      ..writeByte(1)
      ..write(obj.productName)
      ..writeByte(2)
      ..write(obj.itemTypeId)
      ..writeByte(3)
      ..write(obj.itemTypeName)
      ..writeByte(4)
      ..write(obj.image)
      ..writeByte(5)
      ..write(obj.partnerNameEn)
      ..writeByte(6)
      ..write(obj.partnerNameAr)
      ..writeByte(7)
      ..write(obj.numberOfTests)
      ..writeByte(8)
      ..write(obj.tat)
      ..writeByte(9)
      ..write(obj.price)
      ..writeByte(10)
      ..write(obj.abbreviation)
      ..writeByte(11)
      ..write(obj.includedTests)
      ..writeByte(12)
      ..write(obj.includedMarker);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ItemsCompareAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class IncludedTestsAdapter extends TypeAdapter<IncludedTests> {
  @override
  final int typeId = 1;

  @override
  IncludedTests read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return IncludedTests(
      fields[0] as String?,
      fields[1] as String?,
      (fields[2] as List?)?.cast<IncludedMarker>(),
    );
  }

  @override
  void write(BinaryWriter writer, IncludedTests obj) {
    writer
      ..writeByte(3)
      ..writeByte(0)
      ..write(obj.testNameEn)
      ..writeByte(1)
      ..write(obj.testNameAr)
      ..writeByte(2)
      ..write(obj.includedMarker);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is IncludedTestsAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class IncludedMarkerAdapter extends TypeAdapter<IncludedMarker> {
  @override
  final int typeId = 2;

  @override
  IncludedMarker read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return IncludedMarker(
      fields[0] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, IncludedMarker obj) {
    writer
      ..writeByte(1)
      ..writeByte(0)
      ..write(obj.marker);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is IncludedMarkerAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
