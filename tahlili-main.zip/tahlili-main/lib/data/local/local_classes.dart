import 'package:hive/hive.dart';

part 'local_classes.g.dart';
@HiveType(typeId: 0,adapterName: "ItemsCompareAdapter")
class ItemsCompare extends HiveObject {
  @HiveField(0)
  int? productId;
  
  @HiveField(1)
  String? productName;
  
  @HiveField(2)
  int? itemTypeId;
  
  @HiveField(3)
  String? itemTypeName;
  
  @HiveField(4)
  String? image;
  
  @HiveField(5)
  String? partnerNameEn;
  
  @HiveField(6)
  String? partnerNameAr;
  
  @HiveField(7)
  int? numberOfTests;
  
  @HiveField(8)
  int? tat;
  
  @HiveField(9)
  String? price;
  
  @HiveField(10)
  String? abbreviation;
  
  @HiveField(11)
  List<IncludedTests>? includedTests;
  
  @HiveField(12)
  List<IncludedMarker>? includedMarker;

  ItemsCompare(this.productId, this.productName, this.itemTypeId, this.itemTypeName, this.image, this.partnerNameEn, this.partnerNameAr, this.numberOfTests, this.tat, this.price, this.abbreviation, this.includedTests, this.includedMarker);

  
}

@HiveType(typeId: 1,adapterName: "IncludedTestsAdapter")
class IncludedTests extends HiveObject {
  @HiveField(0)
  String? testNameEn;
  
  @HiveField(1)
  String? testNameAr;
  
  @HiveField(2)
  List<IncludedMarker>? includedMarker;

  IncludedTests(this.testNameEn, this.testNameAr, this.includedMarker);

}

@HiveType(typeId: 2,adapterName:"IncludedMarkerAdapter" )
class IncludedMarker extends HiveObject {
  @HiveField(0)
  String? marker;

  IncludedMarker(this.marker);

}
