import 'dart:convert';

import 'package:tahlili/data/network/app_api.dart';
import 'package:tahlili/data/requests/cart/request_cart.dart';
import 'package:tahlili/data/requests/order/request_order.dart';
import 'package:tahlili/data/response/cart/response_cart.dart';
import 'package:tahlili/data/response/response.dart';

abstract class BaseCartDataServices {
  Future<List<ResponseCart>> getCart({required String filterQuery});
  Future<ResponseAPI> addToCart({required RequestCart requestCart,
  required String userId});
  Future<ResponseAPI> deleteCartItem({required int cartId});

  Future<ResponseAPI> createOrder({
    required RequestOrder order
  });
  Future<ResponseAPI> createLabOrder({
    required RequestOrder order
  });
}

class CartDataServices implements BaseCartDataServices {
  final AppServiceClint _clint;

  CartDataServices(this._clint);
  @override
  Future<List<ResponseCart>> getCart({required String filterQuery}) async {
    return await _clint.getCart(filterQuery);
  }

  @override
  Future<ResponseAPI> addToCart({required RequestCart requestCart,
  required String userId}) async {
    return await _clint.addToCart(
        requestCart.patientId,
        requestCart.labId,
        requestCart.partnerTestId,
        requestCart.partnerPackageId,
        userId,
        requestCart.vistDate,
        requestCart.addressId);
  }

  @override
  Future<ResponseAPI> deleteCartItem({required int cartId}) async {
    return await _clint.deleteCartItem(cartId.toString());
  }

  @override
  Future<ResponseAPI> createOrder({required RequestOrder order}) {
    final map={
  "couponName": order.couponName,
  "paymentTypeId": order.paymentTypeId,
  "patientUserId": order.patientUserId,
  "useWallet": order.useWallet,
  "isMale": order.isMale
};
final rawData=jsonEncode(map);
   return _clint.createHomeOrder(rawData);
  }

  @override
  Future<ResponseAPI> createLabOrder({required RequestOrder order}) {
    final map={
  "couponName": order.couponName,
  "paymentTypeId": order.paymentTypeId,
  "patientUserId":order.patientUserId,
  "useWallet": order.useWallet
};
final rawData=jsonEncode(map);
   return _clint.createLabOrder(rawData);
  }
}
