import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:tahlili/app/end_points.dart';
import 'package:tahlili/data/network/app_api.dart';
import 'package:tahlili/data/response/orders/response_order.dart';

import '../../requests/accounts/request_account.dart';
import '../../response/response.dart';

abstract class BaseMapDataServices {
  Future<String> getLocationId(String location);
  Future<Map<String, dynamic>> getPlace(String placeID);
  Future<http.Response> getLocation(String location);
  Future<ResponseAPI> addNewAddress({required RequestAddress address});
   Future<ResponseAPI> updatePatientAddress({
    required RequestAddress address,
    required int addressId,
  });
  Future<ResponseAPI> deletePatientAddress({

    required int addressId,
  });
  Future<ResponseLocation> getNurseLocation({
    required int orderId
  });
}

class MapDataServices implements BaseMapDataServices {
  final AppServiceClint _clint;

  MapDataServices(this._clint);
  @override
  Future<String> getLocationId(String location) async {
    String url =
        'https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=$location&inputtype=textquery&key=${EndPoints.googleAPiKey}';
    var response = await http.get(Uri.parse(url));
    var json = jsonDecode(response.body);
    var placId = json['candidates'][0]['place_id'];
    print(placId);
    return placId;
  }

  @override
  Future<Map<String, dynamic>> getPlace(String placeID) async {

    String url =
        "https://maps.googleapis.com/maps/api/place/details/json?place_id=$placeID&key=${EndPoints.googleAPiKey}";
    var response = await http.get(Uri.parse(url));
    var json = jsonDecode(response.body);
    var results = json['result'] as Map<String, dynamic>;
    print(results);
    return results;
  }

  @override
  Future<http.Response> getLocation(String location) async {
    http.Response response;
    response = await http.get(
        Uri.parse(
            "http://mvs.bslmeiyu.com/api/v1/config/place-api-autocomplete?search_text=$location"),
        headers: {"Content-Type": "application/json"});
    print(jsonDecode(response.body));
    return response;
  }

  @override
  Future<ResponseAPI> addNewAddress({required RequestAddress address}) async {
    final map={
  "userId": address.userId,
  "name": address.name,
  "address": address.address,
  "cityId": address.cityId,
  "location": address.location,
  "longitude": address.longitude,
  "latitude": address.latitude,
  "defaultAddress": address.defaultAddress,
  "districtId": address.districtId
};
final rawData=jsonEncode(map);
    return _clint.addNewAddress(rawData);
  }

  @override
  Future<ResponseLocation> getNurseLocation({required int orderId})async {
    return _clint.getNurseLocation(orderId.toString());
  }

  @override
  Future<ResponseAPI> updatePatientAddress({required RequestAddress address, required int addressId}) {
    final map={

  "name": address.name,
  "address": address.address,
  "cityId": address.cityId,
  "location": address.location,
  "longitude": address.longitude,
  "latitude": address.latitude,
  "defaultAddress": address.defaultAddress,
  "districtId": address.districtId
};
final rawData=jsonEncode(map);
    return _clint.updatePatientAddress(addressId,rawData);
  }

  @override
  Future<ResponseAPI> deletePatientAddress({required int addressId}) {
    return _clint.deletePatientAddress(addressId);
  }



//   Future<List<Prediction>> searchLocation(BuildContext context, String text) async {
//     List<Prediction> _predictionList = [];
//   if(text != null && text.isNotEmpty) {
//     http.Response response = await getLocation(text);
//     var data = jsonDecode(response.body.toString());
//     print("my status is "+data['status']);
//     if (data['status'] != 'OK') {
//       _predictionList = [];
//       data['predictions'].forEach((prediction)
//         => _predictionList.add(Prediction.fromJson(prediction)));
//     } else {
//       // ApiChecker.checkApi(response);
//     }
//   }
// }
}
