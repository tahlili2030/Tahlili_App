import 'package:tahlili/data/network/app_api.dart';
import 'package:tahlili/data/requests/wishlist/request_wishlist.dart';
import 'package:tahlili/data/response/response.dart';

import '../../response/wishlist/response_wishlist.dart';

abstract class BaseWishlistDataServices {
  Future<List<ResponseWishlist>> getWisList({bool? asc});
  Future<ResponseAPI> addToWishlit({required RequestWishlist requestWishlist});

  Future<ResponseAPI> deleteWishlistItem({required int itemId});
}

class WishlistDataServices implements BaseWishlistDataServices {
  final AppServiceClint _clint;

  WishlistDataServices(this._clint);
  @override
  Future<List<ResponseWishlist>> getWisList({bool? asc}) async {
    return await _clint.getWisList(asc);
  }

  @override
  Future<ResponseAPI> addToWishlit(
      {required RequestWishlist requestWishlist}) async {
    return await _clint.addToWishlit(requestWishlist.patientId,
        requestWishlist.partnerPackageId, requestWishlist.partnerTestId);
  }

  @override
  Future<ResponseAPI> deleteWishlistItem({required int itemId}) async {
    return await _clint.deleteWishlistItem(itemId.toString());
  }
}
