import 'package:tahlili/data/network/app_api.dart';
import 'package:tahlili/data/requests/home/request_home.dart';
import 'package:tahlili/data/response/home/response_home.dart';
import 'package:tahlili/data/response/response.dart';

abstract class BaseHomeDataServices {
  Future<List<ResponseInsurance>> getInsurancesLookUp();
  Future<List<ResponseDeals>> getShownDeals();
  Future<List<ResponseSearch>> getGeneticTests();

   Future<List<ResponseIndividualTests>> getIndividualTests();

  Future<List<ResponseSearch>> getTahliliPackages();
  Future<List<ResponseHomeCategory>> getHomeCategories();
  Future<List<ResponseHomeLabs>> getHomeLabs();
  Future<List<ResponseHomePackages>> getHomeRecommendedPackages(
      {String? orderBy, bool? asc});
  Future<List<ResponseHomeFeedback>> getHomeFeedBack();
  Future<List<ResponseCoupon>> getHomeCoupon({String? showInHomePage});
  Future<List<ResponseSearch>> getHomeSearch({
    required String ?orderBy,
    required String ?filterQuery,
    required bool ?asc,
  });

  Future<ResponseAPI> getPatientsHistories({required RequestPatientHisotry patientHisotry});
  Future<ResponseAPI> chnageLnguage({required int langId});
  Future<ResponseItemsCompare> itemsCompare({
    required int itemId,
    required int itemType
  });

  Future<List<ResponseUserPackages>> getUserPackages({
    required bool isTailord
  });

  Future<List<ResponseHomeAds>> getHomeAds({
    required String adsId
  });
  Future<ResponseAPI> addClick({
    required int adsId
  });
  Future<ResponsePackageDetails> getShownDealsDetails({
    required int itemId
  });
  Future<ResponseTestDetails> getTestsDetails({
    required int itemId
  });

  Future<ResponsePartnerCount> getPartnerCount({
    required int partnerId
  });


}

class HomeDataServices implements BaseHomeDataServices {
  final AppServiceClint _clint;

  HomeDataServices(this._clint);
  @override
  Future<List<ResponseInsurance>> getInsurancesLookUp() async {
    return await _clint.getInsurancesLookUp();
  }

  @override
  Future<List<ResponseDeals>> getShownDeals() async {
    return await _clint.getShownDeals();
  }

  @override
  Future<List<ResponseSearch>> getGeneticTests() async {
    return await _clint.getGeneticTests();
  }

  @override
  Future<List<ResponseHomeCategory>> getHomeCategories() async {
    return await _clint.getHomeCategories();
  }

  @override
  Future<List<ResponseHomeLabs>> getHomeLabs() async {
    return await _clint.getHomeLabs();
  }

  @override
  Future<List<ResponseHomePackages>> getHomeRecommendedPackages(
      {String? orderBy, bool? asc}) async {
    return await _clint.getHomeRecommendedPackages(orderBy, asc);
  }

  @override
  Future<List<ResponseHomeFeedback>> getHomeFeedBack() async {
    return await _clint.getHomeFeedBack();
  }

  @override
  Future<List<ResponseCoupon>> getHomeCoupon({String? showInHomePage}) async {
    return await _clint.getHomeCoupon(showInHomePage);
  }

  @override
  Future<List<ResponseSearch>> getHomeSearch({
     required String? orderBy,
    required String ?filterQuery,
    required bool ?asc
  }) async {
    return await _clint.getHomeSearch(orderBy,filterQuery,asc);
  }

  @override
  Future<ResponseAPI> getPatientsHistories(
      {required RequestPatientHisotry patientHisotry}) async {
    return await _clint.getPatientsHistories(patientHisotry.patientId,
        patientHisotry.testId, patientHisotry.packageId);
  }

  @override
  Future<ResponseAPI> chnageLnguage({required int langId})async {
    return _clint.changeLang(langId);
  }

  @override
  Future<ResponseItemsCompare> itemsCompare({
    required int itemId,
    required int itemType
  }) async{
   return _clint.itemCmpare(itemId, itemType);
  }

  @override
  Future<List<ResponseUserPackages>> getUserPackages({required bool isTailord}) async{
   return _clint.getUserPackages(isTailord);
  }

  @override
  Future<List<ResponseHomeAds>> getHomeAds({required String adsId}) async{
    return _clint.getHomeAds(adsId);
  }

  @override
  Future<List<ResponseSearch>> getTahliliPackages() {
   return _clint.getTahliliPackages();
  }

  @override
  Future<List<ResponseIndividualTests>> getIndividualTests() {
   return _clint.getIndividualTest();
  }

  @override
  Future<ResponseAPI> addClick({required int adsId}) {
   return _clint.addClick(adsId);
  }

  @override
  Future<ResponsePackageDetails> getShownDealsDetails({required int itemId}) {
    return _clint.getShownDealsDetails(itemId);
  }
  
  @override
  Future<ResponseTestDetails> getTestsDetails({required int itemId}) {
    return _clint.getTestsDetails(itemId);
  }
  
  @override
  Future<ResponsePartnerCount> getPartnerCount({required int partnerId}) {
   return _clint.getPartnerCount(partnerId);
  }
}
