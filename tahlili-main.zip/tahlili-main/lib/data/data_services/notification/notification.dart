import 'dart:convert';

import 'package:tahlili/data/network/app_api.dart';
import 'package:tahlili/data/response/notofication/notification.dart';
import 'package:tahlili/data/response/response.dart';

abstract class BaseNotificationDataServices {
  Future<List<ResponseNotifcation>> getNotification();
  Future<ResponseAPI> updateNotifcation(
      {required int notificationId,
      required String userId,
      required String title,
      required bool seen});
  Future<ResponseAPI> sendNotifcaton({required Map<String, dynamic> map});
}

class NotificationDataServices implements BaseNotificationDataServices {
  final AppServiceClint _clint;

  NotificationDataServices(this._clint);
  @override
  Future<List<ResponseNotifcation>> getNotification() async {
    return _clint.getNotification();
  }

  @override
  Future<ResponseAPI> sendNotifcaton(
      {required Map<String, dynamic> map}) async {
    final rawData = jsonEncode(map);
    return _clint.sendNotifcaton(rawData);
  }

  @override
  Future<ResponseAPI> updateNotifcation(
      {required int notificationId,
      required String userId,
      required String title,
      required bool seen}) {
    final map = {"userId": userId, "title": title, "seen": seen};
    final rawData = jsonEncode(map);
    return _clint.updateNotifciations(notificationId, rawData);
  }
}
