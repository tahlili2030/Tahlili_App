import 'package:tahlili/data/network/app_api.dart';
import 'package:tahlili/data/requests/auth/request_auth.dart';
import 'package:tahlili/data/requests/auth/request_contact_us.dart';
import 'package:tahlili/data/response/home/response_home.dart';
import 'package:tahlili/data/response/response.dart';

import '../../response/auth/response_auth.dart';

abstract class BaseAuthDataServices {
  Future<ResponseAPI> login({required RequestLogin login});
  Future<ResponseRegister> register({required RequestRegister register});
  Future<ResponseAPI> contactUs({required RequestContactUs requestContactUs});
  Future<ResponseOtp> verifyOtp({required RequestOtp requestOtp});

  Future<List<ResponseLookup>> getLookUp({required String tableName});
}

class AuthDataServices implements BaseAuthDataServices {
  final AppServiceClint _clint;

  AuthDataServices(this._clint);
  @override
  Future<ResponseAPI> login({required RequestLogin login}) async {
    return await _clint.login(login.phoneNumber);
  }

  @override
  Future<ResponseRegister> register({required RequestRegister register}) async {
    final response = await _clint.register(
      register.phone,
      register.email,
      register.fName,
      register.lName,
      register.genderID,
      register.nationalityID,
      register.languageID,
      register.userID,
      register.birhthDate,
      register.idNumber,
    );
    print(response.message);
    return response;
  }

  @override
  Future<ResponseAPI> contactUs(
      {required RequestContactUs requestContactUs}) async {
    return await _clint.contactUs(
        requestContactUs.firstName,
        requestContactUs.lastName,
        requestContactUs.email,
        requestContactUs.phone,
        requestContactUs.description);
  }

  @override
  Future<ResponseOtp> verifyOtp({required RequestOtp requestOtp}) async {
    return await _clint.verifyOtp(requestOtp.phone, requestOtp.otp);
  }

  @override
  Future<List<ResponseLookup>> getLookUp({required String tableName}) async {
    return _clint.getLookUp(tableName);
  }
}
