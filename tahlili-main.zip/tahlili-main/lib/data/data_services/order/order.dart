import 'dart:convert';

import 'package:tahlili/data/network/app_api.dart';
import 'package:tahlili/data/response/home/response_home.dart';
import 'package:tahlili/data/response/orders/response_order.dart';
import 'package:tahlili/data/response/response.dart';

import '../../requests/order/request_order.dart';

abstract class BaseOrdersDataServices {
  Future<ResponseAPI> createHomeOrder({required RequestQuickOrder order});
  Future<ResponseAPI> createLabOrder({required RequestQuickOrder order});
  Future<List<ResponseOrder>> getOrders({required bool? asc});

  Future<ResponseOrderDetails> getOrderDetails({required int orderId});

  Future<List<ResponseTeleMedOrders>> getTelemedOrders();

  Future<ResponseTelemedDetails> getTelemedOrderDetails({required int orderId});
  Future<ResponseWorkingHours> getLabWorkingHours();

  Future<List<ResponseLabWorkingHoursForAppt>> getLabWorkingHoursForAppt({
    required int labId,
    required bool atHomeTiming,
  });
  Future<ResponseNurseFees> getNurseFees(
      {required int? partnerPackageId,
      required int? partnerTestId,
      required bool? isMale});

  Future<List<ResponseLookup>> getDepartments({required String filterQuery});

  Future<List<ResponseTeleDoctor>> getTeleDoctors(
      {required String filterQuery});

  Future<List<ResponseBusyTelemedicnice>> getBusyTele({required String date});
  Future<ResponseAPI> createTeleOrder({required RequestTele requestTele});

  Future<List<ResponseLabBranches>> getLabBranches({
    required int partnerId,
    required int itemId,
    required bool isTest,
  });

  Future<ResponseAPI> cancelTelemedAppt({required int telemedId});

  Future<List<ResponseUpcomimgAppts>> getUpcomingAppts();

  Future<ResponseOrderStateId> getOrderCurrentState({required int orderId});

  Future<List<ResponsiveNewApointment>> getNewAppointments(
      {required bool? now, required bool asc});

  Future<ResponseAPI> rescheduleOrder(
      {required int orderId, required String date, required String time});
}

class OrdersDataServices implements BaseOrdersDataServices {
  final AppServiceClint _clint;

  OrdersDataServices(this._clint);
  @override
  Future<List<ResponseOrder>> getOrders({required bool? asc}) async {
    return await _clint.getOrders(false);
  }

  @override
  Future<ResponseWorkingHours> getLabWorkingHours() {
    return _clint.getLabWorkingHours();
  }

  @override
  Future<ResponseNurseFees> getNurseFees(
      {required int? partnerTestId,
      required int? partnerPackageId,
      required bool? isMale}) {
    return _clint.getNurseFees(partnerTestId, partnerPackageId, isMale);
  }

  @override
  Future<ResponseAPI> createHomeOrder({required RequestQuickOrder order}) {
    final map = {
      "isMale": order.isMale,
      "isTest": order.isTest,
      "itemId": order.itemId,
      "addressId": order.addressId,
      "couponName": order.couponName,
      "preferredDate": order.prefearedDate,
      "preferredTime": order.prefearedTime,
      "paymentTypeId": order.paymnetTypeId,
      "patientId": order.patientId,
      "patientUserId": order.patientUserId,
      "useWallet": order.useWallet
    };
    final rawData = jsonEncode(map);
    return _clint.createHomeQOrder(rawData);
  }

  @override
  Future<List<ResponseLookup>> getDepartments({required String filterQuery}) {
    return _clint.getDepartments(filterQuery);
  }

  @override
  Future<List<ResponseTeleDoctor>> getTeleDoctors(
      {required String filterQuery}) {
    return _clint.getTeleDoctors(filterQuery, true);
  }

  @override
  Future<List<ResponseBusyTelemedicnice>> getBusyTele({required String date}) {
    return _clint.getBusyTele(date);
  }

  @override
  Future<ResponseAPI> createTeleOrder({required RequestTele requestTele}) {
    final map = {
      "departmentId": requestTele.departmentId,
      "doctorId": requestTele.doctorId,
      "visitDateTime": requestTele.visitDateTime,
      "patientId": requestTele.patientId,
      "notes": requestTele.notes,
      "isInstant": requestTele.isInstant
    };
    final rawData = jsonEncode(map);
    return _clint.createTeleOrder(rawData);
  }

  @override
  Future<ResponseAPI> createLabOrder({required RequestQuickOrder order}) {
    final map = {
      "couponName": "string",
      "isTest": order.isTest,
      "itemId": order.itemId,
      "preferredDate": order.prefearedDate,
      "preferredTime": order.prefearedTime,
      "paymentTypeId": order.paymnetTypeId,
      "labId": order.labId,
      "patientId": order.patientId,
      "patientUserId": order.patientUserId,
      "useWallet": order.useWallet
    };
    final rawData = jsonEncode(map);
    return _clint.creatLabOrder(rawData);
  }

  @override
  Future<List<ResponseTeleMedOrders>> getTelemedOrders() {
    return _clint.getTelemedOrders(false);
  }

  @override
  Future<List<ResponseLabBranches>> getLabBranches(
      {required int partnerId, required int itemId, required bool isTest}) {
    return _clint.getLabBranches(partnerId, itemId, isTest);
  }

  @override
  Future<ResponseAPI> cancelTelemedAppt({required int telemedId}) async {
    return _clint.cancelTelemedAppt(telemedId);
  }

  @override
  Future<ResponseOrderDetails> getOrderDetails({required int orderId}) {
    return _clint.getOrderDetails(orderId);
  }

  @override
  Future<List<ResponseUpcomimgAppts>> getUpcomingAppts() {
    return _clint.getUpcomingAppts(true);
  }

  @override
  Future<ResponseTelemedDetails> getTelemedOrderDetails(
      {required int orderId}) {
    return _clint.getTelemedOrderDetails(orderId);
  }

  @override
  Future<ResponseOrderStateId> getOrderCurrentState({required int orderId}) {
    return _clint.getOrderCurrentState(orderId);
  }

  @override
  Future<List<ResponsiveNewApointment>> getNewAppointments(
      {required bool? now, required bool asc}) {
    return _clint.getNewAppointments(now, asc, "visitDateTime");
  }

  @override
  Future<List<ResponseLabWorkingHoursForAppt>> getLabWorkingHoursForAppt(
      {required int labId, required bool atHomeTiming}) async {
    return _clint.getLabWorkingHoursForAppt(labId, atHomeTiming);
  }

  @override
  Future<ResponseAPI> rescheduleOrder(
      {required int orderId, required String date, required String time}) {
    final map = {
      "orderScheduling": {"preferredDate": date, "preferredTime": time}
    };
    final rawData = jsonEncode(map);
    return _clint.rescheduleOrder(orderId, rawData);
  }
}
