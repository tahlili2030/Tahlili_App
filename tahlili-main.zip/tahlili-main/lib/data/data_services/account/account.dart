import 'dart:convert';

import 'package:tahlili/data/network/app_api.dart';
import 'package:tahlili/data/requests/accounts/request_account.dart';
import 'package:tahlili/data/response/auth/response_auth.dart';

import '../../response/account/reponse_account.dart';
import '../../response/orders/response_order.dart';
import '../../response/response.dart';

abstract class BaseAccountDataServices {
  Future<ResponseDashboard> getDashboard();
  Future<List<ResponsePatientWallet>> getPatientWallet();
  Future<List<ResponsePrescriptions>> getPrescriptions();
  Future<List<ResponseAddresses>> getPatientAddresses({required int patientId});

  Future<List<ResponseAddresses>> getAddresses({required String patientId});

  Future<List<ResponsePrescriptions>> getPrescriptionDetails(
      {required int prescriptionId});
  Future<ResponseAPI> addPrescription(
      {required RequestPrescriptions prescriptions});

  Future<int> getUserEntityID();

  Future<ResponseUserEntity> getUserData(
      {required String userID, required int userEntityID});
  Future<ResponseAPI> addProfile(
      {required String userID, required RequestAddProfile requestAddProfile});

  Future<ResponseAPI> uploadFile({required RequestUploadFile file});

  Future<ResponseAPI> addComplaints({required RequestComplaints complaints});

  Future<List<ResponseComplaints>> getComplaints();
  Future<ResponseComplaintDetail> getComplaintsDetails({required int id});

  Future<ResponseAPI> savePayment({required Map<String, dynamic> map});
  Future<ResponsePatient> getPatient({required int userEntityID});
  Future<ResponseAPI> editProfile(
      {required int userEntityID, required RequestEditProfile editProfile});
  Future<List<ResponsePatientProfile>> getPatientProfiles(
      {required String patientUserId});
  Future<List<ResponseWalletTracking>> getWalletTracking();
  Future<List<ResponseRefund>> getRefunds();

  Future<ResponseAPI> requestRefund({required RequestRefund refund});
}

class AccountDataServices implements BaseAccountDataServices {
  final AppServiceClint _clint;

  AccountDataServices(this._clint);
  @override
  Future<ResponseDashboard> getDashboard() async {
    return await _clint.getDashboard();
  }

  @override
  Future<List<ResponsePatientWallet>> getPatientWallet() async {
    return await _clint.getPatientWallet();
  }

  @override
  Future<List<ResponsePrescriptions>> getPrescriptions() async {
    return _clint.getPrescriptions();
  }

  @override
  Future<List<ResponseAddresses>> getPatientAddresses(
      {required int patientId}) async {
    return _clint.getPatientAddresses(patientId.toString());
  }

  @override
  Future<ResponseAPI> addPrescription(
      {required RequestPrescriptions prescriptions}) {
    final map = {
      "patientId": prescriptions.patientId,
      "date": prescriptions.date,
      "description": prescriptions.description
    };
    final rawData = jsonEncode(map);
    return _clint.addPrescription(rawData);
  }

  @override
  Future<List<ResponsePrescriptions>> getPrescriptionDetails(
      {required int prescriptionId}) async {
    return _clint.getPrescriptionDetails(prescriptionId.toString());
  }

  @override
  Future<int> getUserEntityID() async {
    return _clint.getUserEntityID();
  }

  @override
  Future<ResponseUserEntity> getUserData(
      {required String userID, required int userEntityID}) async {
    return _clint.getUserData(userID, userEntityID);
  }

  @override
  Future<ResponseAPI> addProfile(
      {required String userID,
      required RequestAddProfile requestAddProfile}) async {
    return _clint.addPatientProfile(
        userID,
        requestAddProfile.idNumber,
        requestAddProfile.firstName,
        requestAddProfile.middleName,
        requestAddProfile.lastName,
        requestAddProfile.genderId,
        requestAddProfile.nationalityId,
        requestAddProfile.languageId,
        requestAddProfile.birthDate,
        requestAddProfile.userId,
        requestAddProfile.copyOrdersAddressToProfile);
  }

  @override
  Future<ResponseAPI> uploadFile({required RequestUploadFile file}) async {
    return _clint.uploadFile(file.id, file.entityName, file.isPdf, file.file);
  }

  @override
  Future<ResponseAPI> addComplaints(
      {required RequestComplaints complaints}) async {
    return await _clint.addComplaints(
      complaints.patientId,
      complaints.complaintsTypeId,
      complaints.description,
    );
  }

  @override
  Future<ResponseAPI> savePayment({required Map<String, dynamic> map}) async {
    final rawData = jsonEncode(map);
    return _clint.savePayment(rawData);
  }

  @override
  Future<ResponsePatient> getPatient({required int userEntityID}) {
    return _clint.getPatient(userEntityID);
  }

  @override
  Future<ResponseAPI> editProfile(
      {required int userEntityID, required RequestEditProfile editProfile}) {
    final map = {
      "idNumber": editProfile.idNumber,
      "firstName": editProfile.firstName,
      "middleName": editProfile.middleName,
      "lastName": editProfile.lastName,
      "birthDate": editProfile.birthDate,
      "phone": editProfile.phone,
      "genderId": editProfile.genderId,
      "nationalityId": editProfile.nationalityId,
      "relationshipId": editProfile.relationShipId
    };
    final rawData = jsonEncode(map);

    return _clint.editProfile(userEntityID, rawData);
  }

  @override
  Future<List<ResponsePatientProfile>> getPatientProfiles(
      {required String patientUserId}) {
    return _clint.getPatientProfiles(patientUserId);
  }

  @override
  Future<List<ResponseAddresses>> getAddresses({required String patientId}) {
    return _clint.getAddresses(patientId);
  }

  @override
  Future<List<ResponseComplaints>> getComplaints() {
    return _clint.getComplaints();
  }

  @override
  Future<ResponseComplaintDetail> getComplaintsDetails({required int id}) {
    return _clint.getComplaintsDetails(id);
  }

  @override
  Future<List<ResponseWalletTracking>> getWalletTracking() {
    return _clint.getWalletTracking();
  }

  @override
  Future<List<ResponseRefund>> getRefunds() {
    return _clint.getRefunds();
  }

  @override
  Future<ResponseAPI> requestRefund({required RequestRefund refund}) {
    final map = {
      "patientId": refund.patientId,
      "date": refund.date,
      "amount": refund.amount,
      "notes": ""
    };
    final rawData = jsonEncode(map);
    return _clint.requestRefund(rawData);
  }
}
