// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'response_order.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ResponseOrder _$ResponseOrderFromJson(Map<String, dynamic> json) =>
    ResponseOrder(
      id: json['id'] as int?,
      currentOrderState: json['currentOrderState'] as String?,
      currentOrderStateId: json['currentOrderStateId'] as num?,
      nurseId: json['nurseId'] as num?,
      labId: json['labId'] as num?,
      partnerId: json['partnerId'] as num?,
      date: json['date'] as String?,
      patientFirstName: json['patientFirstName'] as String?,
      patientLastName: json['patientLastName'] as String?,
      labNameEn: json['labNameEn'] as String?,
      labNameAr: json['labNameAr'] as String?,
      nurseNameEn: json['nurseNameEn'] as String?,
      nurseNameAr: json['nurseNameAr'] as String?,
      price: json['price'] as num?,
      vat: json['vat'] as num?,
      priceWithVAT: json['priceWithVAT'] as num?,
      visitDateTime: json['visitDateTime'] as String?,
      paymentTypeId: json['paymentTypeId'] as num?,
      paymentTypeName: json['paymentTypeName'] as String?,
      parent: json['parent'] as num?,
      isTahliliLateResponsibility: json['isTahliliLateResponsibility'] as bool?,
      reason: json['reason'] as String?,
    );

Map<String, dynamic> _$ResponseOrderToJson(ResponseOrder instance) =>
    <String, dynamic>{
      'id': instance.id,
      'currentOrderState': instance.currentOrderState,
      'currentOrderStateId': instance.currentOrderStateId,
      'nurseId': instance.nurseId,
      'labId': instance.labId,
      'partnerId': instance.partnerId,
      'date': instance.date,
      'patientFirstName': instance.patientFirstName,
      'patientLastName': instance.patientLastName,
      'labNameEn': instance.labNameEn,
      'labNameAr': instance.labNameAr,
      'nurseNameEn': instance.nurseNameEn,
      'nurseNameAr': instance.nurseNameAr,
      'price': instance.price,
      'vat': instance.vat,
      'priceWithVAT': instance.priceWithVAT,
      'visitDateTime': instance.visitDateTime,
      'paymentTypeId': instance.paymentTypeId,
      'paymentTypeName': instance.paymentTypeName,
      'parent': instance.parent,
      'isTahliliLateResponsibility': instance.isTahliliLateResponsibility,
      'reason': instance.reason,
    };

ResponseOrderDetails _$ResponseOrderDetailsFromJson(
        Map<String, dynamic> json) =>
    ResponseOrderDetails(
      couponId: json['couponId'] as int?,
      couponDiscount: (json['couponDiscount'] as num?)?.toDouble(),
      totalDiscount: (json['totalDiscount'] as num?)?.toDouble(),
      phoneNumber: json['phoneNumber'] as String?,
      childOrdersIds: json['childOrdersIds'] as int?,
      patientName: json['patientName'] as String?,
      id: json['id'] as int?,
      priceWithVAT: (json['priceWithVAT'] as num?)?.toDouble(),
      nurseFees: (json['nurseFees'] as num?)?.toDouble(),
      isMale: json['isMale'] as bool?,
      isPediatric: json['isPediatric'] as bool?,
      date: json['date'] as String?,
      labNameEn: json['labNameEn'] as String?,
      labNameAr: json['labNameAr'] as String?,
      nurseNameEn: json['nurseNameEn'] as String?,
      nurseNameAr: json['nurseNameAr'] as String?,
      paymentTypeId: json['paymentTypeId'] as int?,
      paymentTypeName: json['paymentTypeName'] as String?,
      currentOrderStateId: json['currentOrderStateId'] as int?,
      currentOrderState: json['currentOrderState'] as String?,
      patientId: json['patientId'] as int?,
      labId: json['labId'] as int?,
      nurseId: json['nurseId'] as int?,
      partnerId: json['partnerId'] as int?,
      partnerNameEn: json['partnerNameEn'] as String?,
      partnerNameAr: json['partnerNameAr'] as String?,
      address: json['address'] as String?,
      atHome: json['atHome'] as bool?,
      preferredDate: json['preferredDate'] as String?,
      preferredTime: json['preferredTime'] as String?,
      visitDateTime: json['visitDateTime'] as String?,
      price: (json['price'] as num?)?.toDouble(),
      vat: (json['vat'] as num?)?.toDouble(),
      paymentFailed: json['paymentFailed'] as bool?,
      remainingPaymentAmount:
          (json['remainingPaymentAmount'] as num?)?.toDouble(),
      deducedFromWalletCredit:
          (json['deducedFromWalletCredit'] as num?)?.toDouble(),
      deducedFromWalletMoney:
          (json['deducedFromWalletMoney'] as num?)?.toDouble(),
      deducedFromMoney: (json['deducedFromMoney'] as num?)?.toDouble(),
      ordersItems: (json['ordersItems'] as List<dynamic>?)
          ?.map((e) => OrdersItems.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ResponseOrderDetailsToJson(
        ResponseOrderDetails instance) =>
    <String, dynamic>{
      'couponId': instance.couponId,
      'couponDiscount': instance.couponDiscount,
      'totalDiscount': instance.totalDiscount,
      'phoneNumber': instance.phoneNumber,
      'childOrdersIds': instance.childOrdersIds,
      'patientName': instance.patientName,
      'id': instance.id,
      'priceWithVAT': instance.priceWithVAT,
      'nurseFees': instance.nurseFees,
      'isMale': instance.isMale,
      'isPediatric': instance.isPediatric,
      'date': instance.date,
      'labNameEn': instance.labNameEn,
      'labNameAr': instance.labNameAr,
      'nurseNameEn': instance.nurseNameEn,
      'nurseNameAr': instance.nurseNameAr,
      'paymentTypeId': instance.paymentTypeId,
      'paymentTypeName': instance.paymentTypeName,
      'currentOrderStateId': instance.currentOrderStateId,
      'currentOrderState': instance.currentOrderState,
      'patientId': instance.patientId,
      'labId': instance.labId,
      'nurseId': instance.nurseId,
      'partnerId': instance.partnerId,
      'partnerNameEn': instance.partnerNameEn,
      'partnerNameAr': instance.partnerNameAr,
      'address': instance.address,
      'atHome': instance.atHome,
      'preferredDate': instance.preferredDate,
      'preferredTime': instance.preferredTime,
      'visitDateTime': instance.visitDateTime,
      'price': instance.price,
      'vat': instance.vat,
      'paymentFailed': instance.paymentFailed,
      'remainingPaymentAmount': instance.remainingPaymentAmount,
      'deducedFromWalletCredit': instance.deducedFromWalletCredit,
      'deducedFromWalletMoney': instance.deducedFromWalletMoney,
      'deducedFromMoney': instance.deducedFromMoney,
      'ordersItems': instance.ordersItems,
    };

OrdersItems _$OrdersItemsFromJson(Map<String, dynamic> json) => OrdersItems(
      testId: json['testId'] as int?,
      packageId: json['packageId'] as int?,
      partnerId: json['partnerId'] as int?,
      priceBefore: (json['priceBefore'] as num?)?.toDouble(),
      priceAfter: (json['priceAfter'] as num?)?.toDouble(),
      test: json['test'] == null
          ? null
          : ResponseTests.fromJson(json['test'] as Map<String, dynamic>),
      package: json['package'] == null
          ? null
          : ResponsePackage.fromJson(json['package'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$OrdersItemsToJson(OrdersItems instance) =>
    <String, dynamic>{
      'testId': instance.testId,
      'packageId': instance.packageId,
      'partnerId': instance.partnerId,
      'priceBefore': instance.priceBefore,
      'priceAfter': instance.priceAfter,
      'test': instance.test,
      'package': instance.package,
    };

ResponseLocation _$ResponseLocationFromJson(Map<String, dynamic> json) =>
    ResponseLocation(
      json['id'] as int,
      json['location'] as String,
    );

Map<String, dynamic> _$ResponseLocationToJson(ResponseLocation instance) =>
    <String, dynamic>{
      'id': instance.id,
      'location': instance.location,
    };

ResponseWorkingHours _$ResponseWorkingHoursFromJson(
        Map<String, dynamic> json) =>
    ResponseWorkingHours(
      partnerId: json['partnerId'] as int?,
      latitude: json['latitude'] as int?,
      longitude: json['longitude'] as int?,
      labsWorkingTimesAtHomes:
          (json['labsWorkingTimesAtHomes'] as List<dynamic>?)
              ?.map((e) => ResponseLabsWorkingTimesAtHomes.fromJson(
                  e as Map<String, dynamic>))
              .toList(),
      lisId: json['lisId'] as int?,
      districtId: json['districtId'] as int?,
      id: json['id'] as int?,
      image: json['image'] as String?,
    );

Map<String, dynamic> _$ResponseWorkingHoursToJson(
        ResponseWorkingHours instance) =>
    <String, dynamic>{
      'partnerId': instance.partnerId,
      'latitude': instance.latitude,
      'longitude': instance.longitude,
      'labsWorkingTimesAtHomes': instance.labsWorkingTimesAtHomes,
      'lisId': instance.lisId,
      'districtId': instance.districtId,
      'id': instance.id,
      'image': instance.image,
    };

ResponseLabsWorkingTimesAtHomes _$ResponseLabsWorkingTimesAtHomesFromJson(
        Map<String, dynamic> json) =>
    ResponseLabsWorkingTimesAtHomes(
      weekDay: json['weekDay'] == null
          ? null
          : ResponseLookup.fromJson(json['weekDay'] as Map<String, dynamic>),
      startTime: json['startTime'] as String?,
      endTime: json['endTime'] as String?,
    );

Map<String, dynamic> _$ResponseLabsWorkingTimesAtHomesToJson(
        ResponseLabsWorkingTimesAtHomes instance) =>
    <String, dynamic>{
      'weekDay': instance.weekDay,
      'startTime': instance.startTime,
      'endTime': instance.endTime,
    };

ResponseNurseFees _$ResponseNurseFeesFromJson(Map<String, dynamic> json) =>
    ResponseNurseFees(
      json['labId'] as int,
      (json['nurseFees'] as num).toDouble(),
    );

Map<String, dynamic> _$ResponseNurseFeesToJson(ResponseNurseFees instance) =>
    <String, dynamic>{
      'labId': instance.labId,
      'nurseFees': instance.nurseFees,
    };

ResponseTeleDoctor _$ResponseTeleDoctorFromJson(Map<String, dynamic> json) =>
    ResponseTeleDoctor(
      id: json['id'] as int?,
      nameEn: json['nameEn'] as String?,
      nameAr: json['nameAr'] as String?,
      image: json['image'] as String?,
      degreeId: json['degreeId'] as int?,
      department: (json['doctorsDoctorsDepartments'] as List<dynamic>?)
          ?.map((e) =>
              DoctorsDoctorsDepartments.fromJson(e as Map<String, dynamic>))
          .toList(),
      degree: json['degree'] == null
          ? null
          : ResponseLookup.fromJson(json['degree'] as Map<String, dynamic>),
      experienceYears: json['experienceYears'] as int?,
      price: json['price'] as int?,
      sessionTime: json['sessionTime'] as int?,
      doctorsWorkingTimes: (json['doctorsWorkingTimes'] as List<dynamic>?)
          ?.map((e) => ResponseLabsWorkingTimesAtHomes.fromJson(
              e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ResponseTeleDoctorToJson(ResponseTeleDoctor instance) =>
    <String, dynamic>{
      'id': instance.id,
      'nameEn': instance.nameEn,
      'nameAr': instance.nameAr,
      'image': instance.image,
      'degreeId': instance.degreeId,
      'doctorsDoctorsDepartments': instance.department,
      'degree': instance.degree,
      'experienceYears': instance.experienceYears,
      'price': instance.price,
      'sessionTime': instance.sessionTime,
      'doctorsWorkingTimes': instance.doctorsWorkingTimes,
    };

DoctorsDoctorsDepartments _$DoctorsDoctorsDepartmentsFromJson(
        Map<String, dynamic> json) =>
    DoctorsDoctorsDepartments(
      department: json['department'] == null
          ? null
          : ResponseLookup.fromJson(json['department'] as Map<String, dynamic>),
      doctorId: json['doctorId'] as int?,
      departmentId: json['departmentId'] as int?,
    );

Map<String, dynamic> _$DoctorsDoctorsDepartmentsToJson(
        DoctorsDoctorsDepartments instance) =>
    <String, dynamic>{
      'department': instance.department,
      'doctorId': instance.doctorId,
      'departmentId': instance.departmentId,
    };

ResponseBusyTelemedicnice _$ResponseBusyTelemedicniceFromJson(
        Map<String, dynamic> json) =>
    ResponseBusyTelemedicnice(
      json['doctorId'] as int,
      json['time'] as String,
    );

Map<String, dynamic> _$ResponseBusyTelemedicniceToJson(
        ResponseBusyTelemedicnice instance) =>
    <String, dynamic>{
      'doctorId': instance.doctorId,
      'time': instance.time,
    };

ResponseTeleMedOrders _$ResponseTeleMedOrdersFromJson(
        Map<String, dynamic> json) =>
    ResponseTeleMedOrders(
      id: json['id'] as int?,
      priceWithVAT: (json['priceWithVAT'] as num?)?.toDouble(),
      currentOrderStateId: json['currentOrderStateId'] as int?,
      paymentTypeId: json['paymentTypeId'] as int?,
      vat: (json['vat'] as num?)?.toDouble(),
      doctorFees: (json['doctorFees'] as num?)?.toDouble(),
      visitDateTime: json['visitDateTime'] as String?,
      date: json['date'] as String?,
      currentOrderState: json['currentOrderState'] == null
          ? null
          : ResponseLookup.fromJson(
              json['currentOrderState'] as Map<String, dynamic>),
      paymentType: json['paymentType'] == null
          ? null
          : ResponseLookup.fromJson(
              json['paymentType'] as Map<String, dynamic>),
      doctor: json['doctor'] == null
          ? null
          : ResponseTeleDoctor.fromJson(json['doctor'] as Map<String, dynamic>),
      zoomURL: json['zoomURL'] as String?,
    );

Map<String, dynamic> _$ResponseTeleMedOrdersToJson(
        ResponseTeleMedOrders instance) =>
    <String, dynamic>{
      'id': instance.id,
      'priceWithVAT': instance.priceWithVAT,
      'currentOrderStateId': instance.currentOrderStateId,
      'paymentTypeId': instance.paymentTypeId,
      'vat': instance.vat,
      'doctorFees': instance.doctorFees,
      'visitDateTime': instance.visitDateTime,
      'date': instance.date,
      'currentOrderState': instance.currentOrderState,
      'paymentType': instance.paymentType,
      'doctor': instance.doctor,
      'zoomURL': instance.zoomURL,
    };

ResponseTelemedDetails _$ResponseTelemedDetailsFromJson(
        Map<String, dynamic> json) =>
    ResponseTelemedDetails(
      id: json['id'] as int?,
      date: json['date'] as String?,
      visitDateTime: json['visitDateTime'] as String?,
      priceWithVAT: json['priceWithVAT'] as int?,
      zoomURL: json['zoomURL'] as String?,
      patientName: json['patientName'] as String?,
      notes: json['notes'] as String?,
      currentOrderState: json['currentOrderState'] == null
          ? null
          : ResponseLookup.fromJson(
              json['currentOrderState'] as Map<String, dynamic>),
      doctor: json['doctor'] == null
          ? null
          : ResponseTeleDoctor.fromJson(json['doctor'] as Map<String, dynamic>),
      diagnostic: json['diagnostic'],
    );

Map<String, dynamic> _$ResponseTelemedDetailsToJson(
        ResponseTelemedDetails instance) =>
    <String, dynamic>{
      'id': instance.id,
      'date': instance.date,
      'visitDateTime': instance.visitDateTime,
      'priceWithVAT': instance.priceWithVAT,
      'zoomURL': instance.zoomURL,
      'patientName': instance.patientName,
      'notes': instance.notes,
      'currentOrderState': instance.currentOrderState,
      'doctor': instance.doctor,
      'diagnostic': instance.diagnostic,
    };

ResponseLabBranches _$ResponseLabBranchesFromJson(Map<String, dynamic> json) =>
    ResponseLabBranches(
      nameAr: json['nameAr'] as String?,
      partnerId: json['partnerId'] as int?,
      email: json['email'] as String?,
      googleMapsLink: json['googleMapsLink'] as String?,
      latitude: (json['latitude'] as num?)?.toDouble(),
      longitude: (json['longitude'] as num?)?.toDouble(),
      openingHours: json['openingHours'],
      userId: json['userId'] as int?,
      fbNurseAvg: (json['fbNurseAvg'] as num?)?.toDouble(),
      fbServiceAvg: (json['fbServiceAvg'] as num?)?.toDouble(),
      labsWorkingTimes: (json['labsWorkingTimes'] as List<dynamic>?)
          ?.map((e) => ResponseLabsWorkingTimesAtHomes.fromJson(
              e as Map<String, dynamic>))
          .toList(),
      labsWorkingTimesAtHomes:
          (json['labsWorkingTimesAtHomes'] as List<dynamic>?)
              ?.map((e) => ResponseLabsWorkingTimesAtHomes.fromJson(
                  e as Map<String, dynamic>))
              .toList(),
      lisId: json['lisId'] as int?,
      districtId: json['districtId'] as int?,
      district: json['district'],
      lis: json['lis'],
      id: json['id'] as int?,
      nameEn: json['nameEn'] as String?,
      partner: json['partner'] == null
          ? null
          : ResponsePartner.fromJson(json['partner'] as Map<String, dynamic>),
      phone: json['phone'] as String?,
      address: json['address'] as String?,
      image: json['image'] as String?,
    );

Map<String, dynamic> _$ResponseLabBranchesToJson(
        ResponseLabBranches instance) =>
    <String, dynamic>{
      'nameAr': instance.nameAr,
      'partnerId': instance.partnerId,
      'email': instance.email,
      'googleMapsLink': instance.googleMapsLink,
      'latitude': instance.latitude,
      'longitude': instance.longitude,
      'openingHours': instance.openingHours,
      'userId': instance.userId,
      'fbNurseAvg': instance.fbNurseAvg,
      'fbServiceAvg': instance.fbServiceAvg,
      'labsWorkingTimes': instance.labsWorkingTimes,
      'labsWorkingTimesAtHomes': instance.labsWorkingTimesAtHomes,
      'lisId': instance.lisId,
      'districtId': instance.districtId,
      'district': instance.district,
      'lis': instance.lis,
      'id': instance.id,
      'nameEn': instance.nameEn,
      'partner': instance.partner,
      'phone': instance.phone,
      'address': instance.address,
      'image': instance.image,
    };

ResponseRefund _$ResponseRefundFromJson(Map<String, dynamic> json) =>
    ResponseRefund(
      id: json['id'] as int?,
      refundId: json['refundId'] as int?,
      refundStateId: json['currentRefundStateId'] as int?,
      dateCreated: json['date'] as String?,
      notes: json['notes'] as String?,
      userId: json['userId'] as String?,
      amount: (json['amount'] as num?)?.toDouble(),
      refundState: json['currentRefundState'] == null
          ? null
          : ResponseLookup.fromJson(
              json['currentRefundState'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ResponseRefundToJson(ResponseRefund instance) =>
    <String, dynamic>{
      'id': instance.id,
      'refundId': instance.refundId,
      'currentRefundStateId': instance.refundStateId,
      'date': instance.dateCreated,
      'notes': instance.notes,
      'userId': instance.userId,
      'currentRefundState': instance.refundState,
      'amount': instance.amount,
    };

ResponseUpcomimgAppts _$ResponseUpcomimgApptsFromJson(
        Map<String, dynamic> json) =>
    ResponseUpcomimgAppts(
      visitDateTime: json['visitDateTime'] as String?,
      atHome: json['atHome'] as bool?,
      nurse: json['nurse'] == null
          ? null
          : ResponseNurse.fromJson(json['nurse'] as Map<String, dynamic>),
      lab: json['lab'] == null
          ? null
          : ResponseLabBranches.fromJson(json['lab'] as Map<String, dynamic>),
      partner: json['partner'] == null
          ? null
          : ResponsePartner.fromJson(json['partner'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ResponseUpcomimgApptsToJson(
        ResponseUpcomimgAppts instance) =>
    <String, dynamic>{
      'visitDateTime': instance.visitDateTime,
      'atHome': instance.atHome,
      'nurse': instance.nurse,
      'lab': instance.lab,
      'partner': instance.partner,
    };

ResponseNurse _$ResponseNurseFromJson(Map<String, dynamic> json) =>
    ResponseNurse(
      id: json['id'] as int?,
      nameEn: json['nameEn'] as String?,
      nameAr: json['nameAr'] as String?,
    );

Map<String, dynamic> _$ResponseNurseToJson(ResponseNurse instance) =>
    <String, dynamic>{
      'id': instance.id,
      'nameEn': instance.nameEn,
      'nameAr': instance.nameAr,
    };

ResponseOrderStateId _$ResponseOrderStateIdFromJson(
        Map<String, dynamic> json) =>
    ResponseOrderStateId(
      id: json['id'] as int?,
      currentOrderStateId: json['currentOrderStateId'] as int?,
      zoomURL: json['zoomURL'] as String?,
    );

Map<String, dynamic> _$ResponseOrderStateIdToJson(
        ResponseOrderStateId instance) =>
    <String, dynamic>{
      'id': instance.id,
      'currentOrderStateId': instance.currentOrderStateId,
      'zoomURL': instance.zoomURL,
    };

ResponsiveNewApointment _$ResponsiveNewApointmentFromJson(
        Map<String, dynamic> json) =>
    ResponsiveNewApointment(
      orderId: json['orderId'],
      patientUserId: json['patientUserId'],
      patientName: json['patientName'],
      visitDateTime: json['visitDateTime'],
      priceWithVAT: json['priceWithVAT'],
      currentOrderStateId: json['currentOrderStateId'],
      visitLocation: json['visitLocation'],
      labNameEn: json['labNameEn'],
      labNameAr: json['labNameAr'],
      partnerNameEn: json['partnerNameEn'],
      partnerNameAr: json['partnerNameAr'],
      doctorNameEn: json['doctorNameEn'],
      doctorNameAr: json['doctorNameAr'],
      doctorImage: json['doctorImage'],
      doctorId: json['doctorId'],
      paymentTypeId: json['paymentTypeId'],
      isInstant: json['isInstant'],
      type: json['type'],
      atHome: json['atHome'],
      isMale: json['isMale'],
      invoicesCount: json['invoicesCount'],
    );

Map<String, dynamic> _$ResponsiveNewApointmentToJson(
        ResponsiveNewApointment instance) =>
    <String, dynamic>{
      'orderId': instance.orderId,
      'patientUserId': instance.patientUserId,
      'patientName': instance.patientName,
      'visitDateTime': instance.visitDateTime,
      'priceWithVAT': instance.priceWithVAT,
      'currentOrderStateId': instance.currentOrderStateId,
      'visitLocation': instance.visitLocation,
      'labNameEn': instance.labNameEn,
      'labNameAr': instance.labNameAr,
      'partnerNameEn': instance.partnerNameEn,
      'partnerNameAr': instance.partnerNameAr,
      'doctorNameEn': instance.doctorNameEn,
      'doctorNameAr': instance.doctorNameAr,
      'doctorImage': instance.doctorImage,
      'doctorId': instance.doctorId,
      'paymentTypeId': instance.paymentTypeId,
      'isInstant': instance.isInstant,
      'type': instance.type,
      'atHome': instance.atHome,
      'isMale': instance.isMale,
      'invoicesCount': instance.invoicesCount,
    };

ResponseLabWorkingHoursForAppt _$ResponseLabWorkingHoursForApptFromJson(
        Map<String, dynamic> json) =>
    ResponseLabWorkingHoursForAppt(
      weekDay: json['weekDay'] == null
          ? null
          : WeekDay.fromJson(json['weekDay'] as Map<String, dynamic>),
      startTime: json['startTime'] as String?,
      endTime: json['endTime'] as String?,
    );

Map<String, dynamic> _$ResponseLabWorkingHoursForApptToJson(
        ResponseLabWorkingHoursForAppt instance) =>
    <String, dynamic>{
      'weekDay': instance.weekDay,
      'startTime': instance.startTime,
      'endTime': instance.endTime,
    };

WeekDay _$WeekDayFromJson(Map<String, dynamic> json) => WeekDay(
      id: json['id'] as int?,
      name: json['name'] as String?,
      orderIndex: json['orderIndex'] as int?,
    );

Map<String, dynamic> _$WeekDayToJson(WeekDay instance) => <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'orderIndex': instance.orderIndex,
    };
