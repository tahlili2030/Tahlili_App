import 'package:json_annotation/json_annotation.dart';
import 'package:tahlili/data/response/home/response_home.dart';
part 'response_order.g.dart';

@JsonSerializable()
class ResponseOrder {
  @JsonKey(name: 'id')
  final int? id;
  @JsonKey(name: 'currentOrderState')
  final String? currentOrderState;
  @JsonKey(name: 'currentOrderStateId')
  final num? currentOrderStateId;
  @JsonKey(name: 'nurseId')
  final num? nurseId;
  @JsonKey(name: 'labId')
  final num? labId;
  @JsonKey(name: 'partnerId')
  final num? partnerId;
  @JsonKey(name: 'date')
  final String? date;
  @JsonKey(name: 'patientFirstName')
  final String? patientFirstName;
  @JsonKey(name: 'patientLastName')
  final String? patientLastName;
  @JsonKey(name: 'labNameEn')
  final String? labNameEn;
  @JsonKey(name: 'labNameAr')
  final String? labNameAr;
  @JsonKey(name: 'nurseNameEn')
  final String? nurseNameEn;
  @JsonKey(name: 'nurseNameAr')
  final String? nurseNameAr;
  @JsonKey(name: 'price')
  final num? price;
  @JsonKey(name: 'vat')
  final num? vat;
  @JsonKey(name: 'priceWithVAT')
  final num? priceWithVAT;
  @JsonKey(name: 'visitDateTime')
  final String? visitDateTime;
  @JsonKey(name: 'paymentTypeId')
  final num? paymentTypeId;
  @JsonKey(name: 'paymentTypeName')
  final String? paymentTypeName;
  @JsonKey(name: 'parent')
  final num? parent;
  @JsonKey(name: 'isTahliliLateResponsibility')
  final bool? isTahliliLateResponsibility;
  @JsonKey(name: 'reason')
  final String? reason;

  ResponseOrder(
      {this.id,
      this.currentOrderState,
      this.currentOrderStateId,
      this.nurseId,
      this.labId,
      this.partnerId,
      this.date,
      this.patientFirstName,
      this.patientLastName,
      this.labNameEn,
      this.labNameAr,
      this.nurseNameEn,
      this.nurseNameAr,
      this.price,
      this.vat,
      this.priceWithVAT,
      this.visitDateTime,
      this.paymentTypeId,
      this.paymentTypeName,
      this.parent,
      this.isTahliliLateResponsibility,
      this.reason});
  factory ResponseOrder.fromJson(Map<String, dynamic> json) =>
      _$ResponseOrderFromJson(json);
}

@JsonSerializable()
class ResponseOrderDetails {
  @JsonKey(name: 'couponId')
  int? couponId;
  @JsonKey(name: 'couponDiscount')
  double? couponDiscount;
  @JsonKey(name: 'totalDiscount')
  double? totalDiscount;
  @JsonKey(name: 'phoneNumber')
  String? phoneNumber;
  @JsonKey(name: 'childOrdersIds')
  int? childOrdersIds;
  @JsonKey(name: 'patientName')
  String? patientName;
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'priceWithVAT')
  double? priceWithVAT;
  @JsonKey(name: 'nurseFees')
  double? nurseFees;
  @JsonKey(name: 'isMale')
  bool? isMale;
  @JsonKey(name: 'isPediatric')
  bool? isPediatric;
  @JsonKey(name: 'date')
  String? date;
  @JsonKey(name: 'labNameEn')
  String? labNameEn;
  @JsonKey(name: 'labNameAr')
  String? labNameAr;
  @JsonKey(name: 'nurseNameEn')
  String? nurseNameEn;
  @JsonKey(name: 'nurseNameAr')
  String? nurseNameAr;
  @JsonKey(name: 'paymentTypeId')
  int? paymentTypeId;
  @JsonKey(name: 'paymentTypeName')
  String? paymentTypeName;
  @JsonKey(name: 'currentOrderStateId')
  int? currentOrderStateId;
  @JsonKey(name: 'currentOrderState')
  String? currentOrderState;
  @JsonKey(name: 'patientId')
  int? patientId;
  @JsonKey(name: 'labId')
  int? labId;
  @JsonKey(name: 'nurseId')
  int? nurseId;
  @JsonKey(name: 'partnerId')
  int? partnerId;
  @JsonKey(name: 'partnerNameEn')
  String? partnerNameEn;
  @JsonKey(name: 'partnerNameAr')
  String? partnerNameAr;
  @JsonKey(name: 'address')
  String? address;
  @JsonKey(name: 'atHome')
  bool? atHome;
  @JsonKey(name: 'preferredDate')
  String? preferredDate;
  @JsonKey(name: 'preferredTime')
  String? preferredTime;
  @JsonKey(name: 'visitDateTime')
  String? visitDateTime;
  @JsonKey(name: 'price')
  double? price;
  @JsonKey(name: 'vat')
  double? vat;
  @JsonKey(name: 'paymentFailed')
  bool? paymentFailed;
  @JsonKey(name: 'remainingPaymentAmount')
  double? remainingPaymentAmount;
  @JsonKey(name: 'deducedFromWalletCredit')
  double? deducedFromWalletCredit;
  @JsonKey(name: 'deducedFromWalletMoney')
  double? deducedFromWalletMoney;
  @JsonKey(name: 'deducedFromMoney')
  double? deducedFromMoney;
  @JsonKey(name: 'ordersItems')
  List<OrdersItems>? ordersItems;

  ResponseOrderDetails(
      {this.couponId,
      this.couponDiscount,
      this.totalDiscount,
      this.phoneNumber,
      this.childOrdersIds,
      this.patientName,
      this.id,
      this.priceWithVAT,
      this.nurseFees,
      this.isMale,
      this.isPediatric,
      this.date,
      this.labNameEn,
      this.labNameAr,
      this.nurseNameEn,
      this.nurseNameAr,
      this.paymentTypeId,
      this.paymentTypeName,
      this.currentOrderStateId,
      this.currentOrderState,
      this.patientId,
      this.labId,
      this.nurseId,
      this.partnerId,
      this.partnerNameEn,
      this.partnerNameAr,
      this.address,
      this.atHome,
      this.preferredDate,
      this.preferredTime,
      this.visitDateTime,
      this.price,
      this.vat,
      this.paymentFailed,
      this.remainingPaymentAmount,
      this.deducedFromWalletCredit,
      this.deducedFromWalletMoney,
      this.deducedFromMoney,
      this.ordersItems});
  factory ResponseOrderDetails.fromJson(Map<String, dynamic> json) =>
      _$ResponseOrderDetailsFromJson(json);
}

@JsonSerializable()
class OrdersItems {
  @JsonKey(name: 'testId')
  int? testId;
  @JsonKey(name: 'packageId')
  int? packageId;
  @JsonKey(name: 'partnerId')
  int? partnerId;
  @JsonKey(name: 'priceBefore')
  double? priceBefore;
  @JsonKey(name: 'priceAfter')
  double? priceAfter;
  @JsonKey(name: 'test')
  ResponseTests? test;
  @JsonKey(name: 'package')
  ResponsePackage? package;

  OrdersItems(
      {this.testId,
      this.packageId,
      this.partnerId,
      this.priceBefore,
      this.priceAfter,
      this.test,
      this.package});
  factory OrdersItems.fromJson(Map<String, dynamic> json) =>
      _$OrdersItemsFromJson(json);
}

@JsonSerializable()
class ResponseLocation {
  @JsonKey(name: 'id')
  final int id;
  @JsonKey(name: 'location')
  final String location;

  ResponseLocation(this.id, this.location);

  factory ResponseLocation.fromJson(Map<String, dynamic> json) =>
      _$ResponseLocationFromJson(json);
}

@JsonSerializable()
class ResponseWorkingHours {
  @JsonKey(name: 'partnerId')
  int? partnerId;
  @JsonKey(name: 'latitude')
  int? latitude;
  @JsonKey(name: 'longitude')
  int? longitude;
  @JsonKey(name: 'labsWorkingTimesAtHomes')
  List<ResponseLabsWorkingTimesAtHomes>? labsWorkingTimesAtHomes;
  @JsonKey(name: 'lisId')
  int? lisId;
  @JsonKey(name: 'districtId')
  int? districtId;
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'image')
  String? image;

  ResponseWorkingHours(
      {this.partnerId,
      this.latitude,
      this.longitude,
      this.labsWorkingTimesAtHomes,
      this.lisId,
      this.districtId,
      this.id,
      this.image});
  factory ResponseWorkingHours.fromJson(Map<String, dynamic> json) =>
      _$ResponseWorkingHoursFromJson(json);
}

@JsonSerializable()
class ResponseLabsWorkingTimesAtHomes {
  @JsonKey(name: 'weekDay')
  ResponseLookup? weekDay;
  @JsonKey(name: 'startTime')
  String? startTime;
  @JsonKey(name: 'endTime')
  String? endTime;

  ResponseLabsWorkingTimesAtHomes({this.weekDay, this.startTime, this.endTime});
  factory ResponseLabsWorkingTimesAtHomes.fromJson(Map<String, dynamic> json) =>
      _$ResponseLabsWorkingTimesAtHomesFromJson(json);
}

@JsonSerializable()
class ResponseNurseFees {
  @JsonKey(name: 'labId')
  final int labId;
  @JsonKey(name: 'nurseFees')
  final double nurseFees;

  ResponseNurseFees(this.labId, this.nurseFees);
  factory ResponseNurseFees.fromJson(Map<String, dynamic> json) =>
      _$ResponseNurseFeesFromJson(json);
}

@JsonSerializable()
class ResponseTeleDoctor {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'nameEn')
  String? nameEn;
  @JsonKey(name: 'nameAr')
  String? nameAr;
  @JsonKey(name: 'image')
  String? image;

  @JsonKey(name: 'degreeId')
  int? degreeId;
  @JsonKey(name: 'doctorsDoctorsDepartments')
  List<DoctorsDoctorsDepartments>? department;
  @JsonKey(name: 'degree')
  ResponseLookup? degree;
  @JsonKey(name: 'experienceYears')
  int? experienceYears;
  @JsonKey(name: 'price')
  int? price;
  @JsonKey(name: 'sessionTime')
  int? sessionTime;
  @JsonKey(name: 'doctorsWorkingTimes')
  List<ResponseLabsWorkingTimesAtHomes>? doctorsWorkingTimes;

  ResponseTeleDoctor(
      {this.id,
      this.nameEn,
      this.nameAr,
      this.image,
      this.degreeId,
      this.department,
      this.degree,
      this.experienceYears,
      this.price,
      this.sessionTime,
      this.doctorsWorkingTimes});

  factory ResponseTeleDoctor.fromJson(Map<String, dynamic> json) =>
      _$ResponseTeleDoctorFromJson(json);
}

@JsonSerializable()
class DoctorsDoctorsDepartments {
  @JsonKey(name: 'department')
  ResponseLookup? department;
  @JsonKey(name: 'doctorId')
  int? doctorId;
  @JsonKey(name: 'departmentId')
  int? departmentId;

  DoctorsDoctorsDepartments(
      {this.department, this.doctorId, this.departmentId});

  factory DoctorsDoctorsDepartments.fromJson(Map<String, dynamic> json) =>
      _$DoctorsDoctorsDepartmentsFromJson(json);
}

@JsonSerializable()
class ResponseBusyTelemedicnice {
  @JsonKey(name: 'doctorId')
  final int doctorId;
  @JsonKey(name: 'time')
  final String time;

  ResponseBusyTelemedicnice(this.doctorId, this.time);
  factory ResponseBusyTelemedicnice.fromJson(Map<String, dynamic> json) =>
      _$ResponseBusyTelemedicniceFromJson(json);
}

@JsonSerializable()
class ResponseTeleMedOrders {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'priceWithVAT')
  double? priceWithVAT;
  @JsonKey(name: 'currentOrderStateId')
  int? currentOrderStateId;
  @JsonKey(name: 'paymentTypeId')
  int? paymentTypeId;
  @JsonKey(name: 'vat')
  double? vat;
  @JsonKey(name: 'doctorFees')
  double? doctorFees;
  @JsonKey(name: 'visitDateTime')
  String? visitDateTime;
  @JsonKey(name: 'date')
  String? date;
  @JsonKey(name: 'currentOrderState')
  ResponseLookup? currentOrderState;
  @JsonKey(name: 'paymentType')
  ResponseLookup? paymentType;
  @JsonKey(name: 'doctor')
  ResponseTeleDoctor? doctor;
  @JsonKey(name: 'zoomURL')
  String? zoomURL;

  ResponseTeleMedOrders(
      {this.id,
      this.priceWithVAT,
      this.currentOrderStateId,
      this.paymentTypeId,
      this.vat,
      this.doctorFees,
      this.visitDateTime,
      this.date,
      this.currentOrderState,
      this.paymentType,
      this.doctor,
      this.zoomURL});

  factory ResponseTeleMedOrders.fromJson(Map<String, dynamic> json) =>
      _$ResponseTeleMedOrdersFromJson(json);
}

@JsonSerializable()
class ResponseTelemedDetails {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'date')
  String? date;
  @JsonKey(name: 'visitDateTime')
  String? visitDateTime;
  @JsonKey(name: 'priceWithVAT')
  int? priceWithVAT;
  @JsonKey(name: 'zoomURL')
  String? zoomURL;
  @JsonKey(name: 'patientName')
  String? patientName;
  @JsonKey(name: 'notes')
  String? notes;
  @JsonKey(name: 'currentOrderState')
  ResponseLookup? currentOrderState;
  @JsonKey(name: 'doctor')
  ResponseTeleDoctor? doctor;
  @JsonKey(name: 'diagnostic')
  dynamic diagnostic;

  ResponseTelemedDetails(
      {this.id,
      this.date,
      this.visitDateTime,
      this.priceWithVAT,
      this.zoomURL,
      this.patientName,
      this.notes,
      this.currentOrderState,
      this.doctor,
      this.diagnostic});

  factory ResponseTelemedDetails.fromJson(Map<String, dynamic> json) =>
      _$ResponseTelemedDetailsFromJson(json);
}

@JsonSerializable()
class ResponseLabBranches {
  @JsonKey(name: 'nameAr')
  String? nameAr;
  @JsonKey(name: 'partnerId')
  int? partnerId;
  @JsonKey(name: 'email')
  String? email;
  @JsonKey(name: 'googleMapsLink')
  String? googleMapsLink;
  @JsonKey(name: 'latitude')
  double? latitude;
  @JsonKey(name: 'longitude')
  double? longitude;
  @JsonKey(name: 'openingHours')
  dynamic openingHours;
  @JsonKey(name: 'userId')
  int? userId;
  @JsonKey(name: 'fbNurseAvg')
  double? fbNurseAvg;
  @JsonKey(name: 'fbServiceAvg')
  double? fbServiceAvg;
  @JsonKey(name: 'labsWorkingTimes')
  List<ResponseLabsWorkingTimesAtHomes>? labsWorkingTimes;
  @JsonKey(name: 'labsWorkingTimesAtHomes')
  List<ResponseLabsWorkingTimesAtHomes>? labsWorkingTimesAtHomes;
  @JsonKey(name: 'lisId')
  int? lisId;
  @JsonKey(name: 'districtId')
  int? districtId;
  @JsonKey(name: 'district')
  dynamic district;
  @JsonKey(name: 'lis')
  dynamic lis;
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'nameEn')
  String? nameEn;
  @JsonKey(name: 'partner')
  ResponsePartner? partner;
  @JsonKey(name: 'phone')
  String? phone;
  @JsonKey(name: 'address')
  String? address;
  @JsonKey(name: 'image')
  String? image;

  ResponseLabBranches(
      {this.nameAr,
      this.partnerId,
      this.email,
      this.googleMapsLink,
      this.latitude,
      this.longitude,
      this.openingHours,
      this.userId,
      this.fbNurseAvg,
      this.fbServiceAvg,
      this.labsWorkingTimes,
      this.labsWorkingTimesAtHomes,
      this.lisId,
      this.districtId,
      this.district,
      this.lis,
      this.id,
      this.nameEn,
      this.partner,
      this.phone,
      this.address,
      this.image});

  factory ResponseLabBranches.fromJson(Map<String, dynamic> json) =>
      _$ResponseLabBranchesFromJson(json);
}

@JsonSerializable()
class ResponseRefund {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'refundId')
  int? refundId;
  @JsonKey(name: 'currentRefundStateId')
  int? refundStateId;
  @JsonKey(name: 'date')
  String? dateCreated;
  @JsonKey(name: 'notes')
  String? notes;
  @JsonKey(name: 'userId')
  String? userId;
  @JsonKey(name: 'currentRefundState')
  ResponseLookup? refundState;
  @JsonKey(name: 'amount')
  double? amount;

  ResponseRefund(
      {this.id,
      this.refundId,
      this.refundStateId,
      this.dateCreated,
      this.notes,
      this.userId,
      this.amount,
      this.refundState});
  factory ResponseRefund.fromJson(Map<String, dynamic> json) =>
      _$ResponseRefundFromJson(json);
}

@JsonSerializable()
class ResponseUpcomimgAppts {
  @JsonKey(name: 'visitDateTime')
  String? visitDateTime;
  @JsonKey(name: 'atHome')
  bool? atHome;
  @JsonKey(name: 'nurse')
  ResponseNurse? nurse;
  @JsonKey(name: 'lab')
  ResponseLabBranches? lab;
  @JsonKey(name: 'partner')
  ResponsePartner? partner;

  ResponseUpcomimgAppts(
      {this.visitDateTime, this.atHome, this.nurse, this.lab, this.partner});

  factory ResponseUpcomimgAppts.fromJson(Map<String, dynamic> json) =>
      _$ResponseUpcomimgApptsFromJson(json);
}

@JsonSerializable()
class ResponseNurse {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'nameEn')
  String? nameEn;
  @JsonKey(name: 'nameAr')
  String? nameAr;

  ResponseNurse({this.id, this.nameEn, this.nameAr});

  factory ResponseNurse.fromJson(Map<String, dynamic> json) =>
      _$ResponseNurseFromJson(json);
}

@JsonSerializable()
class ResponseOrderStateId {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'currentOrderStateId')
  int? currentOrderStateId;
  @JsonKey(name: 'zoomURL')
  String? zoomURL;

  ResponseOrderStateId({this.id, this.currentOrderStateId, this.zoomURL});

  factory ResponseOrderStateId.fromJson(Map<String, dynamic> json) =>
      _$ResponseOrderStateIdFromJson(json);
}

@JsonSerializable()
class ResponsiveNewApointment {
  @JsonKey(name: 'orderId')
  dynamic orderId;
  @JsonKey(name: 'patientUserId')
  dynamic patientUserId;
  @JsonKey(name: 'patientName')
  dynamic patientName;
  @JsonKey(name: 'visitDateTime')
  dynamic visitDateTime;
  @JsonKey(name: 'priceWithVAT')
  dynamic priceWithVAT;
  @JsonKey(name: 'currentOrderStateId')
  dynamic currentOrderStateId;
  @JsonKey(name: 'visitLocation')
  dynamic visitLocation;
  @JsonKey(name: 'labNameEn')
  dynamic labNameEn;
  @JsonKey(name: 'labNameAr')
  dynamic labNameAr;
  @JsonKey(name: 'partnerNameEn')
  dynamic partnerNameEn;
  @JsonKey(name: 'partnerNameAr')
  dynamic partnerNameAr;
  @JsonKey(name: 'doctorNameEn')
  dynamic doctorNameEn;
  @JsonKey(name: 'doctorNameAr')
  dynamic doctorNameAr;
  @JsonKey(name: 'doctorImage')
  dynamic doctorImage;
  @JsonKey(name: 'doctorId')
  dynamic doctorId;
  @JsonKey(name: 'paymentTypeId')
  dynamic paymentTypeId;
  @JsonKey(name: 'isInstant')
  dynamic isInstant;
  @JsonKey(name: 'type')
  dynamic type;
  @JsonKey(name: 'atHome')
  dynamic atHome;
  @JsonKey(name: 'isMale')
  dynamic isMale;
  @JsonKey(name: 'invoicesCount')
  dynamic invoicesCount;

  ResponsiveNewApointment(
      {this.orderId,
      this.patientUserId,
      this.patientName,
      this.visitDateTime,
      this.priceWithVAT,
      this.currentOrderStateId,
      this.visitLocation,
      this.labNameEn,
      this.labNameAr,
      this.partnerNameEn,
      this.partnerNameAr,
      this.doctorNameEn,
      this.doctorNameAr,
      this.doctorImage,
      this.doctorId,
      this.paymentTypeId,
      this.isInstant,
      this.type,
      this.atHome,
      this.isMale,
      this.invoicesCount});

  factory ResponsiveNewApointment.fromJson(Map<String, dynamic> json) =>
      _$ResponsiveNewApointmentFromJson(json);
}

@JsonSerializable()
class ResponseLabWorkingHoursForAppt {
  @JsonKey(name: 'weekDay')
  WeekDay? weekDay;
  @JsonKey(name: 'startTime')
  String? startTime;
  @JsonKey(name: 'endTime')
  String? endTime;

  ResponseLabWorkingHoursForAppt({this.weekDay, this.startTime, this.endTime});
  factory ResponseLabWorkingHoursForAppt.fromJson(Map<String, dynamic> json) =>
      _$ResponseLabWorkingHoursForApptFromJson(json);
}

@JsonSerializable()
class WeekDay {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'name')
  String? name;
  @JsonKey(name: 'orderIndex')
  int? orderIndex;

  WeekDay({this.id, this.name, this.orderIndex});
  factory WeekDay.fromJson(Map<String, dynamic> json) =>
      _$WeekDayFromJson(json);
}
