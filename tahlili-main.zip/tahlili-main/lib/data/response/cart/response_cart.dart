import 'package:json_annotation/json_annotation.dart';
import 'package:tahlili/data/response/auth/response_auth.dart';
import 'package:tahlili/data/response/home/response_home.dart';
part 'response_cart.g.dart';

@JsonSerializable()
class ResponseCart {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'vistDate')
  String? vistDate;
  @JsonKey(name: 'partner')
  ResponsePartner? partner;
  @JsonKey(name: 'lab')
  dynamic lab;
  @JsonKey(name: 'patient')
  ResponsePatient? patient;
  @JsonKey(name: 'package')
  ResponsePackage? package;
  @JsonKey(name: 'test')
  ResponseTestCart? test;
  @JsonKey(name: 'image')
  String? image;
  @JsonKey(name: 'addressName')
  String? addressName;
  @JsonKey(name: 'addressId')
  int? addressId;
  @JsonKey(name: 'partnerTestId')
  int? partnerTestId;
  @JsonKey(name: 'partnerPackageId')
  int? partnerPackageId;

  ResponseCart({
    this.id,
    this.vistDate,
    this.partner,
    this.lab,
    this.patient,
    this.package,
    this.test,
    this.image,
    this.addressName,
    this.addressId,
    this.partnerTestId,
    this.partnerPackageId,
  });
  factory ResponseCart.fromJson(Map<String, dynamic> json) =>
      _$ResponseCartFromJson(json);
}

@JsonSerializable()
class ResponseTestCart {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'nameEn')
  String? nameEn;
  @JsonKey(name: 'nameAr')
  String? nameAr;
  @JsonKey(name: 'abbreviation')
  dynamic abbreviation;
  @JsonKey(name: 'image')
  String? image;
  @JsonKey(name: 'price')
  int? price;
  @JsonKey(name: 'tat')
  int? tat;

  ResponseTestCart(
      {this.id,
      this.nameEn,
      this.nameAr,
      this.abbreviation,
      this.image,
      this.price,
      this.tat});

  factory ResponseTestCart.fromJson(Map<String, dynamic> json) =>
      _$ResponseTestCartFromJson(json);
}
