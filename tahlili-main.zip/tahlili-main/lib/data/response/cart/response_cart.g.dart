// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'response_cart.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ResponseCart _$ResponseCartFromJson(Map<String, dynamic> json) => ResponseCart(
      id: json['id'] as int?,
      vistDate: json['vistDate'] as String?,
      partner: json['partner'] == null
          ? null
          : ResponsePartner.fromJson(json['partner'] as Map<String, dynamic>),
      lab: json['lab'],
      patient: json['patient'] == null
          ? null
          : ResponsePatient.fromJson(json['patient'] as Map<String, dynamic>),
      package: json['package'] == null
          ? null
          : ResponsePackage.fromJson(json['package'] as Map<String, dynamic>),
      test: json['test'] == null
          ? null
          : ResponseTestCart.fromJson(json['test'] as Map<String, dynamic>),
      image: json['image'] as String?,
      addressName: json['addressName'] as String?,
      addressId: json['addressId'] as int?,
      partnerTestId: json['partnerTestId'] as int?,
      partnerPackageId: json['partnerPackageId'] as int?,
    );

Map<String, dynamic> _$ResponseCartToJson(ResponseCart instance) =>
    <String, dynamic>{
      'id': instance.id,
      'vistDate': instance.vistDate,
      'partner': instance.partner,
      'lab': instance.lab,
      'patient': instance.patient,
      'package': instance.package,
      'test': instance.test,
      'image': instance.image,
      'addressName': instance.addressName,
      'addressId': instance.addressId,
      'partnerTestId': instance.partnerTestId,
      'partnerPackageId': instance.partnerPackageId,
    };

ResponseTestCart _$ResponseTestCartFromJson(Map<String, dynamic> json) =>
    ResponseTestCart(
      id: json['id'] as int?,
      nameEn: json['nameEn'] as String?,
      nameAr: json['nameAr'] as String?,
      abbreviation: json['abbreviation'],
      image: json['image'] as String?,
      price: json['price'] as int?,
      tat: json['tat'] as int?,
    );

Map<String, dynamic> _$ResponseTestCartToJson(ResponseTestCart instance) =>
    <String, dynamic>{
      'id': instance.id,
      'nameEn': instance.nameEn,
      'nameAr': instance.nameAr,
      'abbreviation': instance.abbreviation,
      'image': instance.image,
      'price': instance.price,
      'tat': instance.tat,
    };
