import 'package:json_annotation/json_annotation.dart';
import 'package:tahlili/data/response/home/response_home.dart';
part 'response_wishlist.g.dart';

@JsonSerializable()
class ResponseWishlist {
  @JsonKey(name: 'id')
  final int? id;
  @JsonKey(name: 'patientId')
  final int? patientId;
  @JsonKey(name: 'partnerId')
  final int? partnerId;
  @JsonKey(name: 'testId')
  final int? testId;
  @JsonKey(name: 'packageId')
  final int? packageId;
  @JsonKey(name: 'imageEN')
  final String? imageEN;
  @JsonKey(name: 'imageAR')
  final String? imageAR;
  @JsonKey(name: 'price')
  final double? price;
  @JsonKey(name: 'minPrice')
  final double? minPrice;
  @JsonKey(name: 'partner')
  final ResponsePartner? partner;
  @JsonKey(name: 'partnersPackage')
  final ResponsePackage? package;
  @JsonKey(name: 'test')
  final ResponseTests? test;

  ResponseWishlist(
      {this.id,
      this.patientId,
      this.partnerId,
      this.testId,
      this.packageId,
      this.imageEN,
      this.imageAR,
      this.price,
      this.minPrice,
      this.partner,
      this.package,
      this.test});

  factory ResponseWishlist.fromJson(Map<String, dynamic> json) =>
      _$ResponseWishlistFromJson(json);
}
