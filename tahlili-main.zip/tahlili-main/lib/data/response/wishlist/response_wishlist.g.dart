// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'response_wishlist.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ResponseWishlist _$ResponseWishlistFromJson(Map<String, dynamic> json) =>
    ResponseWishlist(
      id: json['id'] as int?,
      patientId: json['patientId'] as int?,
      partnerId: json['partnerId'] as int?,
      testId: json['testId'] as int?,
      packageId: json['packageId'] as int?,
      imageEN: json['imageEN'] as String?,
      imageAR: json['imageAR'] as String?,
      price: (json['price'] as num?)?.toDouble(),
      minPrice: (json['minPrice'] as num?)?.toDouble(),
      partner: json['partner'] == null
          ? null
          : ResponsePartner.fromJson(json['partner'] as Map<String, dynamic>),
      package: json['partnersPackage'] == null
          ? null
          : ResponsePackage.fromJson(
              json['partnersPackage'] as Map<String, dynamic>),
      test: json['test'] == null
          ? null
          : ResponseTests.fromJson(json['test'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ResponseWishlistToJson(ResponseWishlist instance) =>
    <String, dynamic>{
      'id': instance.id,
      'patientId': instance.patientId,
      'partnerId': instance.partnerId,
      'testId': instance.testId,
      'packageId': instance.packageId,
      'imageEN': instance.imageEN,
      'imageAR': instance.imageAR,
      'price': instance.price,
      'minPrice': instance.minPrice,
      'partner': instance.partner,
      'partnersPackage': instance.package,
      'test': instance.test,
    };
