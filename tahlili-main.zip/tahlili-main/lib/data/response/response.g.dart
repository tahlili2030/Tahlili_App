// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ResponseAPI _$ResponseAPIFromJson(Map<String, dynamic> json) => ResponseAPI(
      json['statusCode'] as int?,
      json['message'] as String?,
      json['id'] as int?,
    );

Map<String, dynamic> _$ResponseAPIToJson(ResponseAPI instance) =>
    <String, dynamic>{
      'statusCode': instance.statusCode,
      'message': instance.message,
      'id': instance.id,
    };
