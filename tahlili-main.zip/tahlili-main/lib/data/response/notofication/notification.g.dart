// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'notification.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ResponseNotifcation _$ResponseNotifcationFromJson(Map<String, dynamic> json) =>
    ResponseNotifcation(
      id: json['id'] as int?,
      userId: json['userId'] as String?,
      title: json['title'] as String?,
      subTitle: json['subTitle'] as String?,
      date: json['date'] as String?,
      url: json['url'] as String?,
      seen: json['seen'] as bool?,
      orderId: json['orderId'] as int?,
    );

Map<String, dynamic> _$ResponseNotifcationToJson(
        ResponseNotifcation instance) =>
    <String, dynamic>{
      'id': instance.id,
      'userId': instance.userId,
      'title': instance.title,
      'subTitle': instance.subTitle,
      'date': instance.date,
      'url': instance.url,
      'seen': instance.seen,
      'orderId': instance.orderId,
    };
