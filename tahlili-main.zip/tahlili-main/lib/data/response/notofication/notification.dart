
import 'package:json_annotation/json_annotation.dart';
part 'notification.g.dart';
@JsonSerializable()
class ResponseNotifcation {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'userId')
  String? userId;
  @JsonKey(name: 'title')
  String? title;
  @JsonKey(name: 'subTitle')
  String? subTitle;
  @JsonKey(name: 'date')
  String? date;
  @JsonKey(name: 'url')
  String? url;
  @JsonKey(name: 'seen')
  bool? seen;
  @JsonKey(name: 'orderId')
  int? orderId;

  ResponseNotifcation(
      {this.id,
      this.userId,
      this.title,
      this.subTitle,
      this.date,
      this.url,
      this.seen,
      this.orderId});

      factory ResponseNotifcation.fromJson(Map<String, dynamic> json) =>
      _$ResponseNotifcationFromJson(json);

  }