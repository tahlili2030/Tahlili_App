import 'package:json_annotation/json_annotation.dart';
import 'package:tahlili/data/response/auth/response_auth.dart';
import 'package:tahlili/data/response/home/response_home.dart';
part 'reponse_account.g.dart';

@JsonSerializable()
class ResponseDashboard {
  @JsonKey(name: 'totalOrder')
  int? totalOrder;
  @JsonKey(name: 'totalPendingOrder')
  int? totalPendingOrder;
  @JsonKey(name: 'totalWishlist')
  int? totalWishlist;

  ResponseDashboard(
      {this.totalOrder, this.totalPendingOrder, this.totalWishlist});

  factory ResponseDashboard.fromJson(Map<String, dynamic> json) =>
      _$ResponseDashboardFromJson(json);
}

@JsonSerializable()
class ResponsePatientWallet {
  @JsonKey(name: 'id')
  final int id;
  @JsonKey(name: 'userId')
  final String userId;
  @JsonKey(name: 'walletCredit')
  final double walletCredit;

  ResponsePatientWallet(this.id, this.userId, this.walletCredit);
  factory ResponsePatientWallet.fromJson(Map<String, dynamic> json) =>
      _$ResponsePatientWalletFromJson(json);
}

@JsonSerializable()
class ResponsePrescriptions {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'patientId')
  int? patientId;
  @JsonKey(name: 'date')
  String? date;
  @JsonKey(name: 'isChecked')
  bool? isChecked;
  @JsonKey(name: 'isContacted')
  bool? isContacted;
  @JsonKey(name: 'isHandled')
  bool? isHandled;
  @JsonKey(name: 'patient')
  ResponseBasePatient? patient;
  @JsonKey(name: 'image')
  String? image;
  @JsonKey(name: 'results')
  List<String>?results;

  ResponsePrescriptions(
      {this.id,
      this.patientId,
      this.date,
      this.isChecked,
      this.isContacted,
      this.isHandled,
      this.patient,
      this.image,
      this.results});

  factory ResponsePrescriptions.fromJson(Map<String, dynamic> json) =>
      _$ResponsePrescriptionsFromJson(json);
}

@JsonSerializable()
class ResponseBasePatient {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'firstName')
  String? firstName;
  @JsonKey(name: 'lastName')
  String? lastName;
  @JsonKey(name: 'idNumber')
  String? idNumber;
  @JsonKey(name: 'birthDate')
  String? birthDate;
  @JsonKey(name: 'phone')
  String? phone;
  @JsonKey(name: 'gender')
  ResponseLookup? gender;
  @JsonKey(name: 'image')
  String? image;
  @JsonKey(name: 'userId')
  String? userId;
  @JsonKey(name: 'genderId')
  int? genderId;
  @JsonKey(name: 'nationalityId')
  int? nationalityId;
  @JsonKey(name: 'languageId')
  int? languageId;
  @JsonKey(name: 'email')
  String? email;
  @JsonKey(name: 'nationality')
  ResponseLookup? nationality;
  @JsonKey(name: 'language')
  ResponseLookup? language;
  @JsonKey(name: 'fbAvg')
  double? fbAvg;
  @JsonKey(name: 'walletCredit')
  double? walletCredit;

  ResponseBasePatient(
      {this.id,
      this.firstName,
      this.lastName,
      this.idNumber,
      this.birthDate,
      this.phone,
      this.gender,
      this.image,
      this.userId,
      this.genderId,
      this.nationalityId,
      this.languageId,
      this.email,
      this.nationality,
      this.language,
      this.fbAvg,
      this.walletCredit});
  factory ResponseBasePatient.fromJson(Map<String, dynamic> json) =>
      _$ResponseBasePatientFromJson(json);
}

@JsonSerializable()
class ResponseAddresses {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'userId')
  String? userId;
  @JsonKey(name: 'name')
  String? name;
  @JsonKey(name: 'address')
  String? address;
  @JsonKey(name: 'location')
  String? location;
  @JsonKey(name: 'longitude')
  double? longitude;
  @JsonKey(name: 'latitude')
  double? latitude;
  @JsonKey(name: 'cityId')
  int? cityId;
  @JsonKey(name: 'city')
  ResponseCity? city;
  // @JsonKey(name: 'districtId')
  // int? districtId;
  @JsonKey(name: 'district')
  ResponseDistrict? district;
  @JsonKey(name: 'defaultAddress')
  bool? defaultAddress;

  ResponseAddresses(
      {this.id,
      this.userId,
      this.name,
      this.address,
      this.location,
      this.longitude,
      this.latitude,
      this.cityId,
      this.city,
      this.defaultAddress,
      this.district,
      // this.districtId
      });
      factory ResponseAddresses.fromJson(Map<String, dynamic> json) =>
      _$ResponseAddressesFromJson(json);
}

@JsonSerializable()
class ResponseCity {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'name')
  String? name;
  @JsonKey(name: 'orderIndex')
  int? orderIndex;


  ResponseCity({this.id, this.name, this.orderIndex, });
  factory ResponseCity.fromJson(Map<String, dynamic> json) =>
      _$ResponseCityFromJson(json);
}
@JsonSerializable()
class ResponseComplaints {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'patientId')
  int? patientId;
  @JsonKey(name: 'complaintsTypeId')
  int? complaintsTypeId;
  @JsonKey(name: 'creationTime')
  String? creationTime;
  @JsonKey(name: 'isChecked')
  bool? isChecked;
  @JsonKey(name: 'isContacted')
  bool? isContacted;
  @JsonKey(name: 'isClosed')
  bool? isClosed;
  @JsonKey(name: 'handlingTime')
  int? handlingTime;
  @JsonKey(name: 'image')
  String? image;
  @JsonKey(name: 'patient')
  ResponsePatient? patient;
  @JsonKey(name: 'complaintsType')
  ResponseLookup? complaintsType;
  @JsonKey(name: 'description')
  String? description;
  @JsonKey(name: 'reply')
  String? reply;
  @JsonKey(name: 'closedTime')
  String? closedTime;
   @JsonKey(name: 'results')
  List<String>?results;

  ResponseComplaints(
      {this.id,
      this.patientId,
      this.complaintsTypeId,
      this.creationTime,
      this.isChecked,
      this.isContacted,
      this.isClosed,
      this.handlingTime,
      this.image,
      this.patient,
      this.complaintsType,
      this.results});
      factory ResponseComplaints.fromJson(Map<String, dynamic> json) =>
      _$ResponseComplaintsFromJson(json);
}
@JsonSerializable()
class ResponseComplaintDetail {
  @JsonKey(name: 'description')
  String? description;
  @JsonKey(name: 'reply')
  String? reply;
  @JsonKey(name: 'closedTime')
  String? closedTime;
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'patientId')
  int? patientId;
  @JsonKey(name: 'complaintsTypeId')
  int? complaintsTypeId;
  @JsonKey(name: 'creationTime')
  String? creationTime;
  @JsonKey(name: 'isChecked')
  bool? isChecked;
  @JsonKey(name: 'isContacted')
  bool? isContacted;
  @JsonKey(name: 'isClosed')
  bool? isClosed;
  @JsonKey(name: 'handlingTime')
  String? handlingTime;
  @JsonKey(name: 'image')
  String? image;
  @JsonKey(name: 'patient')
  ResponsePatient? patient;
  @JsonKey(name: 'complaintsType')
  ResponseLookup? complaintsType;
    @JsonKey(name: 'results')
  List<String>?results;

  ResponseComplaintDetail(
      {this.description,
      this.reply,
      this.closedTime,
      this.id,
      this.patientId,
      this.complaintsTypeId,
      this.creationTime,
      this.isChecked,
      this.isContacted,
      this.isClosed,
      this.handlingTime,
      this.image,
      this.patient,
      this.complaintsType,
      this.results});

       factory ResponseComplaintDetail.fromJson(Map<String, dynamic> json) =>
      _$ResponseComplaintDetailFromJson(json);
}
@JsonSerializable()
class ResponseUserEntity {
  @JsonKey(name: 'id')
  String? id;
  @JsonKey(name: 'entityId')
  int? entityId;
  @JsonKey(name: 'entityNameEn')
  String? entityNameEn;
  @JsonKey(name: 'entityNameAr')
  String? entityNameAr;
  @JsonKey(name: 'email')
  String? email;
  @JsonKey(name: 'phoneNumber')
  String? phoneNumber;
  @JsonKey(name: 'phoneNumberConfirmed')
  bool? phoneNumberConfirmed;
  @JsonKey(name: 'twoFactorEnabled')
  bool? twoFactorEnabled;
  @JsonKey(name: 'emailConfirmed')
  bool? emailConfirmed;
  @JsonKey(name: 'roles')
  List<String>? roles;
  @JsonKey(name: 'role')
  String? role;

  ResponseUserEntity(
      {this.id,
      this.entityId,
      this.entityNameEn,
      this.entityNameAr,
      this.email,
      this.phoneNumber,
      this.phoneNumberConfirmed,
      this.twoFactorEnabled,
      this.emailConfirmed,
      this.roles,
      this.role});

       factory ResponseUserEntity.fromJson(Map<String, dynamic> json) =>
      _$ResponseUserEntityFromJson(json);

}
@JsonSerializable()
class ResponsePatientProfile {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'gender')
  String? gender;
  @JsonKey(name: 'firstName')
  String? firstName;
  @JsonKey(name: 'middleName')
  String? middleName;
  @JsonKey(name: 'lastName')
  String? lastName;
  @JsonKey(name: 'image')
  String? image;
  @JsonKey(name: 'userId')
  String? userId;
  @JsonKey(name: 'nationalityId')
  int? nationalityId;
  @JsonKey(name: 'idNumber')
  String? idNumber;
  @JsonKey(name: 'genderId')
  int? genderId;
  @JsonKey(name: 'relationshipId')
  int? relationshipId;
  @JsonKey(name: 'birthDate')
  String? birthDate;
  @JsonKey(name: 'languageId')
  int? languageId;
  @JsonKey(name: 'walletCredit')
  double? walletCredit;
  @JsonKey(name: 'walletMoney')
  double? walletMoney;
  @JsonKey(name: 'phone')
  String? phone;

  ResponsePatientProfile(
      {this.id,
      this.gender,
      this.firstName,
      this.middleName,
      this.lastName,
      this.image,
      this.userId,
      this.nationalityId,
      this.idNumber,
      this.genderId,
      this.relationshipId,
      this.birthDate,
      this.languageId,
      this.walletCredit,
      this.walletMoney,
      this.phone});

       factory ResponsePatientProfile.fromJson(Map<String, dynamic> json) =>
      _$ResponsePatientProfileFromJson(json);
}

@JsonSerializable()
class ResponseDistrict {
  @JsonKey(name: 'geographicalRegion')
 dynamic geographicalRegion;
 @JsonKey(name: 'zone')
  ResponseLookup? zone;
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'name')
  String? name;
  @JsonKey(name: 'orderIndex')
  int? orderIndex;

  ResponseDistrict(
      {this.geographicalRegion,
      this.zone,
      this.id,
      this.name,
      this.orderIndex});
      factory ResponseDistrict.fromJson(Map<String, dynamic> json) =>
      _$ResponseDistrictFromJson(json);
}
@JsonSerializable()
class ResponseWalletTracking {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'userId')
  String? userId;
  @JsonKey(name: 'patientId')
  int? patientId;
  @JsonKey(name: 'dateTime')
  String? dateTime;
  @JsonKey(name: 'amountMoney')
  double? amountMoney;
  @JsonKey(name: 'amountCredit')
  double? amountCredit;
  @JsonKey(name: 'notes')
  String? notes;

  ResponseWalletTracking(
      {this.id,
      this.userId,
      this.patientId,
      this.dateTime,
      this.amountMoney,
      this.amountCredit,
      this.notes});

       factory ResponseWalletTracking.fromJson(Map<String, dynamic> json) =>
      _$ResponseWalletTrackingFromJson(json);
}