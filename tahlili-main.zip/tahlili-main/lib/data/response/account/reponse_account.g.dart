// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'reponse_account.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ResponseDashboard _$ResponseDashboardFromJson(Map<String, dynamic> json) =>
    ResponseDashboard(
      totalOrder: json['totalOrder'] as int?,
      totalPendingOrder: json['totalPendingOrder'] as int?,
      totalWishlist: json['totalWishlist'] as int?,
    );

Map<String, dynamic> _$ResponseDashboardToJson(ResponseDashboard instance) =>
    <String, dynamic>{
      'totalOrder': instance.totalOrder,
      'totalPendingOrder': instance.totalPendingOrder,
      'totalWishlist': instance.totalWishlist,
    };

ResponsePatientWallet _$ResponsePatientWalletFromJson(
        Map<String, dynamic> json) =>
    ResponsePatientWallet(
      json['id'] as int,
      json['userId'] as String,
      (json['walletCredit'] as num).toDouble(),
    );

Map<String, dynamic> _$ResponsePatientWalletToJson(
        ResponsePatientWallet instance) =>
    <String, dynamic>{
      'id': instance.id,
      'userId': instance.userId,
      'walletCredit': instance.walletCredit,
    };

ResponsePrescriptions _$ResponsePrescriptionsFromJson(
        Map<String, dynamic> json) =>
    ResponsePrescriptions(
      id: json['id'] as int?,
      patientId: json['patientId'] as int?,
      date: json['date'] as String?,
      isChecked: json['isChecked'] as bool?,
      isContacted: json['isContacted'] as bool?,
      isHandled: json['isHandled'] as bool?,
      patient: json['patient'] == null
          ? null
          : ResponseBasePatient.fromJson(
              json['patient'] as Map<String, dynamic>),
      image: json['image'] as String?,
      results:
          (json['results'] as List<dynamic>?)?.map((e) => e as String).toList(),
    );

Map<String, dynamic> _$ResponsePrescriptionsToJson(
        ResponsePrescriptions instance) =>
    <String, dynamic>{
      'id': instance.id,
      'patientId': instance.patientId,
      'date': instance.date,
      'isChecked': instance.isChecked,
      'isContacted': instance.isContacted,
      'isHandled': instance.isHandled,
      'patient': instance.patient,
      'image': instance.image,
      'results': instance.results,
    };

ResponseBasePatient _$ResponseBasePatientFromJson(Map<String, dynamic> json) =>
    ResponseBasePatient(
      id: json['id'] as int?,
      firstName: json['firstName'] as String?,
      lastName: json['lastName'] as String?,
      idNumber: json['idNumber'] as String?,
      birthDate: json['birthDate'] as String?,
      phone: json['phone'] as String?,
      gender: json['gender'] == null
          ? null
          : ResponseLookup.fromJson(json['gender'] as Map<String, dynamic>),
      image: json['image'] as String?,
      userId: json['userId'] as String?,
      genderId: json['genderId'] as int?,
      nationalityId: json['nationalityId'] as int?,
      languageId: json['languageId'] as int?,
      email: json['email'] as String?,
      nationality: json['nationality'] == null
          ? null
          : ResponseLookup.fromJson(
              json['nationality'] as Map<String, dynamic>),
      language: json['language'] == null
          ? null
          : ResponseLookup.fromJson(json['language'] as Map<String, dynamic>),
      fbAvg: (json['fbAvg'] as num?)?.toDouble(),
      walletCredit: (json['walletCredit'] as num?)?.toDouble(),
    );

Map<String, dynamic> _$ResponseBasePatientToJson(
        ResponseBasePatient instance) =>
    <String, dynamic>{
      'id': instance.id,
      'firstName': instance.firstName,
      'lastName': instance.lastName,
      'idNumber': instance.idNumber,
      'birthDate': instance.birthDate,
      'phone': instance.phone,
      'gender': instance.gender,
      'image': instance.image,
      'userId': instance.userId,
      'genderId': instance.genderId,
      'nationalityId': instance.nationalityId,
      'languageId': instance.languageId,
      'email': instance.email,
      'nationality': instance.nationality,
      'language': instance.language,
      'fbAvg': instance.fbAvg,
      'walletCredit': instance.walletCredit,
    };

ResponseAddresses _$ResponseAddressesFromJson(Map<String, dynamic> json) =>
    ResponseAddresses(
      id: json['id'] as int?,
      userId: json['userId'] as String?,
      name: json['name'] as String?,
      address: json['address'] as String?,
      location: json['location'] as String?,
      longitude: (json['longitude'] as num?)?.toDouble(),
      latitude: (json['latitude'] as num?)?.toDouble(),
      cityId: json['cityId'] as int?,
      city: json['city'] == null
          ? null
          : ResponseCity.fromJson(json['city'] as Map<String, dynamic>),
      defaultAddress: json['defaultAddress'] as bool?,
      district: json['district'] == null
          ? null
          : ResponseDistrict.fromJson(json['district'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ResponseAddressesToJson(ResponseAddresses instance) =>
    <String, dynamic>{
      'id': instance.id,
      'userId': instance.userId,
      'name': instance.name,
      'address': instance.address,
      'location': instance.location,
      'longitude': instance.longitude,
      'latitude': instance.latitude,
      'cityId': instance.cityId,
      'city': instance.city,
      'district': instance.district,
      'defaultAddress': instance.defaultAddress,
    };

ResponseCity _$ResponseCityFromJson(Map<String, dynamic> json) => ResponseCity(
      id: json['id'] as int?,
      name: json['name'] as String?,
      orderIndex: json['orderIndex'] as int?,
    );

Map<String, dynamic> _$ResponseCityToJson(ResponseCity instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'orderIndex': instance.orderIndex,
    };

ResponseComplaints _$ResponseComplaintsFromJson(Map<String, dynamic> json) =>
    ResponseComplaints(
      id: json['id'] as int?,
      patientId: json['patientId'] as int?,
      complaintsTypeId: json['complaintsTypeId'] as int?,
      creationTime: json['creationTime'] as String?,
      isChecked: json['isChecked'] as bool?,
      isContacted: json['isContacted'] as bool?,
      isClosed: json['isClosed'] as bool?,
      handlingTime: json['handlingTime'] as int?,
      image: json['image'] as String?,
      patient: json['patient'] == null
          ? null
          : ResponsePatient.fromJson(json['patient'] as Map<String, dynamic>),
      complaintsType: json['complaintsType'] == null
          ? null
          : ResponseLookup.fromJson(
              json['complaintsType'] as Map<String, dynamic>),
      results:
          (json['results'] as List<dynamic>?)?.map((e) => e as String).toList(),
    )
      ..description = json['description'] as String?
      ..reply = json['reply'] as String?
      ..closedTime = json['closedTime'] as String?;

Map<String, dynamic> _$ResponseComplaintsToJson(ResponseComplaints instance) =>
    <String, dynamic>{
      'id': instance.id,
      'patientId': instance.patientId,
      'complaintsTypeId': instance.complaintsTypeId,
      'creationTime': instance.creationTime,
      'isChecked': instance.isChecked,
      'isContacted': instance.isContacted,
      'isClosed': instance.isClosed,
      'handlingTime': instance.handlingTime,
      'image': instance.image,
      'patient': instance.patient,
      'complaintsType': instance.complaintsType,
      'description': instance.description,
      'reply': instance.reply,
      'closedTime': instance.closedTime,
      'results': instance.results,
    };

ResponseComplaintDetail _$ResponseComplaintDetailFromJson(
        Map<String, dynamic> json) =>
    ResponseComplaintDetail(
      description: json['description'] as String?,
      reply: json['reply'] as String?,
      closedTime: json['closedTime'] as String?,
      id: json['id'] as int?,
      patientId: json['patientId'] as int?,
      complaintsTypeId: json['complaintsTypeId'] as int?,
      creationTime: json['creationTime'] as String?,
      isChecked: json['isChecked'] as bool?,
      isContacted: json['isContacted'] as bool?,
      isClosed: json['isClosed'] as bool?,
      handlingTime: json['handlingTime'] as String?,
      image: json['image'] as String?,
      patient: json['patient'] == null
          ? null
          : ResponsePatient.fromJson(json['patient'] as Map<String, dynamic>),
      complaintsType: json['complaintsType'] == null
          ? null
          : ResponseLookup.fromJson(
              json['complaintsType'] as Map<String, dynamic>),
      results:
          (json['results'] as List<dynamic>?)?.map((e) => e as String).toList(),
    );

Map<String, dynamic> _$ResponseComplaintDetailToJson(
        ResponseComplaintDetail instance) =>
    <String, dynamic>{
      'description': instance.description,
      'reply': instance.reply,
      'closedTime': instance.closedTime,
      'id': instance.id,
      'patientId': instance.patientId,
      'complaintsTypeId': instance.complaintsTypeId,
      'creationTime': instance.creationTime,
      'isChecked': instance.isChecked,
      'isContacted': instance.isContacted,
      'isClosed': instance.isClosed,
      'handlingTime': instance.handlingTime,
      'image': instance.image,
      'patient': instance.patient,
      'complaintsType': instance.complaintsType,
      'results': instance.results,
    };

ResponseUserEntity _$ResponseUserEntityFromJson(Map<String, dynamic> json) =>
    ResponseUserEntity(
      id: json['id'] as String?,
      entityId: json['entityId'] as int?,
      entityNameEn: json['entityNameEn'] as String?,
      entityNameAr: json['entityNameAr'] as String?,
      email: json['email'] as String?,
      phoneNumber: json['phoneNumber'] as String?,
      phoneNumberConfirmed: json['phoneNumberConfirmed'] as bool?,
      twoFactorEnabled: json['twoFactorEnabled'] as bool?,
      emailConfirmed: json['emailConfirmed'] as bool?,
      roles:
          (json['roles'] as List<dynamic>?)?.map((e) => e as String).toList(),
      role: json['role'] as String?,
    );

Map<String, dynamic> _$ResponseUserEntityToJson(ResponseUserEntity instance) =>
    <String, dynamic>{
      'id': instance.id,
      'entityId': instance.entityId,
      'entityNameEn': instance.entityNameEn,
      'entityNameAr': instance.entityNameAr,
      'email': instance.email,
      'phoneNumber': instance.phoneNumber,
      'phoneNumberConfirmed': instance.phoneNumberConfirmed,
      'twoFactorEnabled': instance.twoFactorEnabled,
      'emailConfirmed': instance.emailConfirmed,
      'roles': instance.roles,
      'role': instance.role,
    };

ResponsePatientProfile _$ResponsePatientProfileFromJson(
        Map<String, dynamic> json) =>
    ResponsePatientProfile(
      id: json['id'] as int?,
      gender: json['gender'] as String?,
      firstName: json['firstName'] as String?,
      middleName: json['middleName'] as String?,
      lastName: json['lastName'] as String?,
      image: json['image'] as String?,
      userId: json['userId'] as String?,
      nationalityId: json['nationalityId'] as int?,
      idNumber: json['idNumber'] as String?,
      genderId: json['genderId'] as int?,
      relationshipId: json['relationshipId'] as int?,
      birthDate: json['birthDate'] as String?,
      languageId: json['languageId'] as int?,
      walletCredit: (json['walletCredit'] as num?)?.toDouble(),
      walletMoney: (json['walletMoney'] as num?)?.toDouble(),
      phone: json['phone'] as String?,
    );

Map<String, dynamic> _$ResponsePatientProfileToJson(
        ResponsePatientProfile instance) =>
    <String, dynamic>{
      'id': instance.id,
      'gender': instance.gender,
      'firstName': instance.firstName,
      'middleName': instance.middleName,
      'lastName': instance.lastName,
      'image': instance.image,
      'userId': instance.userId,
      'nationalityId': instance.nationalityId,
      'idNumber': instance.idNumber,
      'genderId': instance.genderId,
      'relationshipId': instance.relationshipId,
      'birthDate': instance.birthDate,
      'languageId': instance.languageId,
      'walletCredit': instance.walletCredit,
      'walletMoney': instance.walletMoney,
      'phone': instance.phone,
    };

ResponseDistrict _$ResponseDistrictFromJson(Map<String, dynamic> json) =>
    ResponseDistrict(
      geographicalRegion: json['geographicalRegion'],
      zone: json['zone'] == null
          ? null
          : ResponseLookup.fromJson(json['zone'] as Map<String, dynamic>),
      id: json['id'] as int?,
      name: json['name'] as String?,
      orderIndex: json['orderIndex'] as int?,
    );

Map<String, dynamic> _$ResponseDistrictToJson(ResponseDistrict instance) =>
    <String, dynamic>{
      'geographicalRegion': instance.geographicalRegion,
      'zone': instance.zone,
      'id': instance.id,
      'name': instance.name,
      'orderIndex': instance.orderIndex,
    };

ResponseWalletTracking _$ResponseWalletTrackingFromJson(
        Map<String, dynamic> json) =>
    ResponseWalletTracking(
      id: json['id'] as int?,
      userId: json['userId'] as String?,
      patientId: json['patientId'] as int?,
      dateTime: json['dateTime'] as String?,
      amountMoney: (json['amountMoney'] as num?)?.toDouble(),
      amountCredit: (json['amountCredit'] as num?)?.toDouble(),
      notes: json['notes'] as String?,
    );

Map<String, dynamic> _$ResponseWalletTrackingToJson(
        ResponseWalletTracking instance) =>
    <String, dynamic>{
      'id': instance.id,
      'userId': instance.userId,
      'patientId': instance.patientId,
      'dateTime': instance.dateTime,
      'amountMoney': instance.amountMoney,
      'amountCredit': instance.amountCredit,
      'notes': instance.notes,
    };
