import 'package:json_annotation/json_annotation.dart';
part 'response.g.dart';
@JsonSerializable()
class ResponseAPI {
  @JsonKey(name: "statusCode")
  final int? statusCode;
  @JsonKey(name: "message")
  final String? message;
  @JsonKey(name: "id")
  final int? id;

  ResponseAPI(this.statusCode, this.message, this.id);

  factory ResponseAPI.fromJson(Map<String,dynamic>json)=>_$ResponseAPIFromJson(json);
}
