import 'package:json_annotation/json_annotation.dart';

part 'response_home.g.dart';

@JsonSerializable()
class ResponseInsurance {
  @JsonKey(name: 'id')
  final int? id;
  @JsonKey(name: 'nameEn')
  final String? nameEn;
  @JsonKey(name: 'nameAr')
  final String? nameAr;
  @JsonKey(name: 'image')
  final String? image;
  @JsonKey(name: 'phone')
  final String? phone;

  ResponseInsurance(this.id, this.nameEn, this.nameAr, this.image, this.phone);

  factory ResponseInsurance.fromJson(Map<String, dynamic> json) =>
      _$ResponseInsuranceFromJson(json);
}

@JsonSerializable()
class ResponseDeals {
  @JsonKey(name: 'id')
  final int? id;
  @JsonKey(name: 'partnerId')
  final int? partnerId;
  @JsonKey(name: 'packageId')
  final int? packageId;
  @JsonKey(name: 'partnerItemId')
  final int? partnerItemId;
  @JsonKey(name: 'price')
  final double? price;
  @JsonKey(name: 'tat')
  final int? tat;
  @JsonKey(name: 'priceBeforeDiscount')
  final double? priceBeforeDiscount;
  @JsonKey(name: 'package')
  final ResponsePackage? package;
  @JsonKey(name: 'partner')
  final ResponsePartner? partner;
  @JsonKey(name: 'imageEN')
  final String? imageEN;
  @JsonKey(name: 'imageAR')
  final String? imageAR;
  @JsonKey(name: 'showInDeals')
  final bool? showInDeals;
  @JsonKey(name: 'dealEndDate')
  final String? dealEndDate;

  ResponseDeals(
      this.id,
      this.partnerId,
      this.packageId,
      this.partnerItemId,
      this.price,
      this.tat,
      this.priceBeforeDiscount,
      this.package,
      this.partner,
      this.imageEN,
      this.imageAR,
      this.showInDeals,
      this.dealEndDate);
  factory ResponseDeals.fromJson(Map<String, dynamic> json) =>
      _$ResponseDealsFromJson(json);
}

@JsonSerializable()
class ResponsePackage {
  @JsonKey(name: 'id')
  final int? id;
  @JsonKey(name: 'nameEn')
  final String? nameEn;
  @JsonKey(name: 'nameAr')
  final String? nameAr;
  @JsonKey(name: 'imageEN')
  final String? imageEN;
  @JsonKey(name: 'imageAR')
  final String? imageAR;
  @JsonKey(name: 'image')
  final String? image;
  @JsonKey(name: 'targetedGender')
  final ResponseLookup? targetedGender;
  @JsonKey(name: 'packagesBmis')
  final List<ResponsePackageBmis>? packagesBmis;
  @JsonKey(name: 'packagesAges')
  final List<ResponsePackagesAge>? packagesAges;
  @JsonKey(name: 'packagesCategories')
  final List<ResponsePackageCatgory>? packagesCategories;
  @JsonKey(name: 'pType')
  final ResponseLookup? pType;
  @JsonKey(name: 'soldItems')
  final int? soldItems;
  @JsonKey(name: 'tahliliCode')
  final String? tahliliCode;
  @JsonKey(name: 'price')
  final double? price;
  @JsonKey(name: 'packagesTests')
  final List<ResponseTests>? packagesTests;
  @JsonKey(name: 'tat')
  final int? tat;
  @JsonKey(name: 'partner')
  final ResponsePartner? partner;
  @JsonKey(name: 'package')
  final ResponsePartner? package;

  ResponsePackage(
      this.id,
      this.nameEn,
      this.nameAr,
      this.imageEN,
      this.imageAR,
      this.targetedGender,
      this.packagesBmis,
      this.packagesAges,
      this.packagesCategories,
      this.pType,
      this.soldItems,
      this.image,
      this.tahliliCode,
      this.price,
      this.packagesTests,
      this.tat,
      this.partner,
      this.package);

  factory ResponsePackage.fromJson(Map<String, dynamic> json) =>
      _$ResponsePackageFromJson(json);
}

@JsonSerializable()
class ResponseLookup {
  @JsonKey(name: 'id')
  final int? id;
  @JsonKey(name: 'name')
  final String? name;
  @JsonKey(name: 'orderIndx')
  final int? orderIndx;
  @JsonKey(name: 'image')
  final String? image;

  ResponseLookup(this.id, this.name, this.orderIndx, this.image);
  factory ResponseLookup.fromJson(Map<String, dynamic> json) =>
      _$ResponseLookupFromJson(json);
}

@JsonSerializable()
class ResponsePartner {
  @JsonKey(name: 'Id')
  final int? id;
  @JsonKey(name: 'nameEn')
  final String? nameEn;
  @JsonKey(name: 'nameAr')
  final String? nameAr;
  @JsonKey(name: 'imageEN')
  final String? imageEN;
  @JsonKey(name: 'imageAR')
  final String? imageAR;
  @JsonKey(name: 'Hotline')
  final String? hotline;
  @JsonKey(name: 'FBNurseAvg')
  final double? fBNurseAvg;
  @JsonKey(name: 'FBServiceAvg')
  final double? fBServiceAvg;
  @JsonKey(name: 'image')
  final String? image;
  @JsonKey(name: 'Phone')
  final String? phone;
  @JsonKey(name: 'TaxNumber')
  final String? taxNumber;

  ResponsePartner(
      this.id,
      this.nameEn,
      this.nameAr,
      this.hotline,
      this.fBNurseAvg,
      this.fBServiceAvg,
      this.image,
      this.phone,
      this.taxNumber,
      this.imageEN,
      this.imageAR);
  factory ResponsePartner.fromJson(Map<String, dynamic> json) =>
      _$ResponsePartnerFromJson(json);
}

@JsonSerializable()
class ResponsePackageBmis {
  @JsonKey(name: 'BmiId ')
  final int? id;
  @JsonKey(name: 'BmiName ')
  final String? name;

  ResponsePackageBmis(this.id, this.name);
  factory ResponsePackageBmis.fromJson(Map<String, dynamic> json) =>
      _$ResponsePackageBmisFromJson(json);
}

@JsonSerializable()
class ResponsePackageCatgory {
  @JsonKey(name: 'categoryId')
  final int? categoryId;
  @JsonKey(name: 'categoryName')
  final String? categoryName;
  @JsonKey(name: 'packageNameEn')
  final String? packageNameEn;
  @JsonKey(name: 'packageNameAr')
  final String? packageNameAr;
  @JsonKey(name: 'pType')
  final int? pType;
  @JsonKey(name: 'soldItems')
  final int? soldItems;

  ResponsePackageCatgory(this.categoryId, this.categoryName, this.packageNameEn,
      this.packageNameAr, this.pType, this.soldItems);

  factory ResponsePackageCatgory.fromJson(Map<String, dynamic> json) =>
      _$ResponsePackageCatgoryFromJson(json);
}

@JsonSerializable()
class ResponsePackagesAge {
  @JsonKey(name: 'AgeId ')
  final int? ageId;
  @JsonKey(name: 'AgeName')
  final String? ageName;

  ResponsePackagesAge(this.ageId, this.ageName);
  factory ResponsePackagesAge.fromJson(Map<String, dynamic> json) =>
      _$ResponsePackagesAgeFromJson(json);
}

@JsonSerializable()
class ResponseGenetics {
  @JsonKey(name: 'tests')
  final List<ResponseTests>? tests;
  @JsonKey(name: 'image')
  final String? image;
  @JsonKey(name: 'id')
  final int? id;
  @JsonKey(name: 'name')
  final String? name;
  @JsonKey(name: 'orderIndex')
  final int? orderIndex;

  ResponseGenetics(
      {this.tests, this.image, this.id, this.name, this.orderIndex});

  factory ResponseGenetics.fromJson(Map<String, dynamic> json) =>
      _$ResponseGeneticsFromJson(json);
}

@JsonSerializable()
class ResponseTests {
  @JsonKey(name: 'symbol')
  final String? symbol;
  @JsonKey(name: 'abbreviation')
  final String? abbreviation;
  @JsonKey(name: 'image')
  final String? image;
  @JsonKey(name: 'id')
  final int? id;
  @JsonKey(name: 'nameEn')
  final String? nameEn;
  @JsonKey(name: 'nameAr')
  final String? nameAr;
  @JsonKey(name: 'testNameEn')
  final String? testNameEn;
  @JsonKey(name: 'testNameAr')
  final String? testNameAr;
  @JsonKey(name: 'referencePrice')
  final double? referencePrice;
  @JsonKey(name: 'minPrice')
  final double? minPrice;
  @JsonKey(name: 'providedBy')
  final double? providedBy;
  @JsonKey(name: 'referenceTAT')
  final int? referenceTAT;
  @JsonKey(name: 'tahliliCode')
  final String? tahliliCode;
  @JsonKey(name: 'isActive')
  final bool? isActive;

  ResponseTests(
      this.testNameEn, this.testNameAr, this.minPrice, this.providedBy,
      {this.symbol,
      this.abbreviation,
      this.image,
      this.id,
      this.nameEn,
      this.nameAr,
      this.referencePrice,
      this.referenceTAT,
      this.tahliliCode,
      this.isActive});

  factory ResponseTests.fromJson(Map<String, dynamic> json) =>
      _$ResponseTestsFromJson(json);
}

@JsonSerializable()
class ResponseHomeCategory {
  @JsonKey(name: 'imageEN')
  final String? imageEn;
  @JsonKey(name: 'imageAR')
  final String? imageAr;
  @JsonKey(name: 'packagesCategories')
  final List<ResponsePackageCatgory>? packagesCategories;
  @JsonKey(name: 'packageCount')
  final int? packageCount;
  @JsonKey(name: 'soldItemsSum')
  final int? soldItemsSum;
  @JsonKey(name: 'id')
  final int? id;
  @JsonKey(name: 'name')
  final String? name;
  @JsonKey(name: 'orderIndex')
  final int? orderIndex;

  ResponseHomeCategory(
      this.imageEn,
      this.imageAr,
      this.packagesCategories,
      this.packageCount,
      this.soldItemsSum,
      this.id,
      this.name,
      this.orderIndex);

  factory ResponseHomeCategory.fromJson(Map<String, dynamic> json) =>
      _$ResponseHomeCategoryFromJson(json);
}

@JsonSerializable()
class ResponseHomeLabs {
  @JsonKey(name: 'id')
  final int? id;
  @JsonKey(name: 'nameEn')
  final String? nameEn;
  @JsonKey(name: 'nameAr')
  final String? nameAr;
  @JsonKey(name: 'image')
  final String? image;
  @JsonKey(name: 'hotline')
  final String? hotline;
  @JsonKey(name: 'phone')
  final String? phone;
  @JsonKey(name: 'fbServiceAvg')
  final double? fbServiceAvg;
  @JsonKey(name: 'fbServiceCount')
  final double? fbServiceCount;
  @JsonKey(name: 'contactEmail')
  final String? contactEmail;
  @JsonKey(name: 'numberOfProducts')
  final int? numberOfProducts;
  @JsonKey(name: 'certificates')
  final int? certificate;
  @JsonKey(name: 'labsNumber')
  final int? labsNumber;
  @JsonKey(name: 'partnersCertificatesImages')
  final List<PartnersCertificatesImages>? certificates;

  ResponseHomeLabs(
      this.id,
      this.nameEn,
      this.nameAr,
      this.image,
      this.fbServiceAvg,
      this.fbServiceCount,
      this.contactEmail,
      this.numberOfProducts,
      this.certificate,
      this.labsNumber,
      this.certificates,
      this.hotline,
      this.phone);
  factory ResponseHomeLabs.fromJson(Map<String, dynamic> json) =>
      _$ResponseHomeLabsFromJson(json);
}

@JsonSerializable()
class PartnersCertificatesImages {
  @JsonKey(name: 'certificateId')
  int? certificateId;
  @JsonKey(name: 'certificateName')
  String? certificateName;
  @JsonKey(name: 'images')
  String? images;

  PartnersCertificatesImages(
      {this.certificateId, this.certificateName, this.images});
  factory PartnersCertificatesImages.fromJson(Map<String, dynamic> json) =>
      _$PartnersCertificatesImagesFromJson(json);
}

@JsonSerializable()
class ResponsePartnersCertificatesImages {
  @JsonKey(name: 'id')
  final int? id;
  @JsonKey(name: 'certificateName')
  final String? name;
  @JsonKey(name: 'orderIndex')
  final int? orderIndex;
  @JsonKey(name: 'image')
  final String? image;

  ResponsePartnersCertificatesImages(
      this.id, this.name, this.image, this.orderIndex);
  factory ResponsePartnersCertificatesImages.fromJson(
          Map<String, dynamic> json) =>
      _$ResponsePartnersCertificatesImagesFromJson(json);
}

@JsonSerializable()
class ResponseHomePackages {
  @JsonKey(name: 'id')
  final int? id;
  @JsonKey(name: 'nameEn')
  final String? nameEn;
  @JsonKey(name: 'nameAr')
  final String? nameAr;
  @JsonKey(name: 'ownerPartner')
  final ResponseOwnerPartner? ownerPartner;
  @JsonKey(name: 'referencePrice')
  final double? referencePrice;
  @JsonKey(name: 'referenceTAT')
  final int? referenceTAT;
  @JsonKey(name: 'imageEN')
  final String? imageEN;
  @JsonKey(name: 'imageAR')
  final String? imageAR;
  @JsonKey(name: 'tahliliCode')
  final String? tahliliCode;
  @JsonKey(name: 'providedBy')
  final int? providedBy;
  @JsonKey(name: 'minPrice')
  final double? minPrice;

  ResponseHomePackages(
      {this.id,
      this.nameEn,
      this.nameAr,
      this.ownerPartner,
      this.referencePrice,
      this.referenceTAT,
      this.imageEN,
      this.imageAR,
      this.tahliliCode,
      this.providedBy,
      this.minPrice});

  factory ResponseHomePackages.fromJson(Map<String, dynamic> json) =>
      _$ResponseHomePackagesFromJson(json);
}

@JsonSerializable()
class ResponseOwnerPartner {
  @JsonKey(name: 'id')
  final int? id;
  @JsonKey(name: 'nameEn')
  final String? nameEn;
  @JsonKey(name: 'nameAr')
  final String? nameAr;
  @JsonKey(name: 'hotline')
  final String? hotline;
  @JsonKey(name: 'fbNurseAvg')
  final double? fbNurseAvg;
  @JsonKey(name: 'fbServiceAvg')
  final double? fbServiceAvg;
  @JsonKey(name: 'image')
  final String? image;
  @JsonKey(name: 'phone')
  final String? phone;
  @JsonKey(name: 'taxNumber')
  final String? taxNumber;

  ResponseOwnerPartner(
      {this.id,
      this.nameEn,
      this.nameAr,
      this.hotline,
      this.fbNurseAvg,
      this.fbServiceAvg,
      this.image,
      this.phone,
      this.taxNumber});

  factory ResponseOwnerPartner.fromJson(Map<String, dynamic> json) =>
      _$ResponseOwnerPartnerFromJson(json);
}

@JsonSerializable()
class ResponseHomeFeedback {
  @JsonKey(name: 'patientId')
  final int? patientId;
  @JsonKey(name: 'image')
  final String? image;
  @JsonKey(name: 'gender')
  final String? gender;
  @JsonKey(name: 'userId')
  final int? userId;
  @JsonKey(name: 'patientNameEn')
  final String? patientNameEn;
  @JsonKey(name: 'patientNameAr')
  final String? patientNameAr;
  @JsonKey(name: 'dateAndTime')
  final String? dateAndTime;
  @JsonKey(name: 'rate')
  final int? rate;
  @JsonKey(name: 'title')
  final String? title;
  @JsonKey(name: 'showInHomePage')
  final bool? showInHomePage;
  @JsonKey(name: 'feedback')
  final String? feedback;

  ResponseHomeFeedback(
      {this.patientId,
      this.image,
      this.gender,
      this.userId,
      this.patientNameEn,
      this.patientNameAr,
      this.dateAndTime,
      this.rate,
      this.title,
      this.showInHomePage,
      this.feedback});

  factory ResponseHomeFeedback.fromJson(Map<String, dynamic> json) =>
      _$ResponseHomeFeedbackFromJson(json);
}

@JsonSerializable()
class ResponseCoupon {
  @JsonKey(name: 'description')
  String? description;
  @JsonKey(name: 'notificationMessage')
  String? notificationMessage;
  @JsonKey(name: 'maxUse')
  int? maxUse;
  @JsonKey(name: 'websiteURL')
  String? websiteURL;
  @JsonKey(name: 'videoURL')
  String? videoURL;
  @JsonKey(name: 'couponsPackages')
  List<ResponseCouponsPackages>? couponsPackages;
  @JsonKey(name: 'couponsTests')
  List<ResponseCouponsTests>? couponsTests;
  @JsonKey(name: 'couponsCategories')
  List? couponsCategories;
  @JsonKey(name: 'couponsClassifications')
  List? couponsClassifications;
  @JsonKey(name: 'couponsNotificationTypes')
  List? couponsNotificationTypes;
  @JsonKey(name: 'couponsPartners')
  List<ResponseCouponsPartners>? couponsPartners;
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'title')
  String? title;
  @JsonKey(name: 'noOfUses')
  int? noOfUses;
  @JsonKey(name: 'startDate')
  String? startDate;
  @JsonKey(name: 'endDate')
  String? endDate;
  @JsonKey(name: 'image')
  String? image;
  @JsonKey(name: 'percentage')
  int? percentage;
  @JsonKey(name: 'maxDiscount')
  int? maxDiscount;
  @JsonKey(name: 'showInHomePage')
  bool? showInHomePage;
  @JsonKey(name: 'tahliliPercentage')
  int? tahliliPercentage;

  ResponseCoupon(
      {this.description,
      this.notificationMessage,
      this.maxUse,
      this.websiteURL,
      this.videoURL,
      this.couponsPackages,
      this.couponsTests,
      this.couponsCategories,
      this.couponsClassifications,
      this.couponsNotificationTypes,
      this.couponsPartners,
      this.id,
      this.title,
      this.noOfUses,
      this.startDate,
      this.endDate,
      this.image,
      this.percentage,
      this.maxDiscount,
      this.showInHomePage,
      this.tahliliPercentage});
  factory ResponseCoupon.fromJson(Map<String, dynamic> json) =>
      _$ResponseCouponFromJson(json);
}

@JsonSerializable()
class ResponseCouponsPackages {
  @JsonKey(name: 'CouponId')
  final int? couponId;
  @JsonKey(name: 'PackageId')
  final int? packageId;

  ResponseCouponsPackages(this.couponId, this.packageId);
  factory ResponseCouponsPackages.fromJson(Map<String, dynamic> json) =>
      _$ResponseCouponsPackagesFromJson(json);
}

@JsonSerializable()
class ResponseCouponsPartners {
  @JsonKey(name: 'CouponId')
  final int? couponId;
  @JsonKey(name: 'PartnerId')
  final int? partnerId;

  ResponseCouponsPartners(this.couponId, this.partnerId);
  factory ResponseCouponsPartners.fromJson(Map<String, dynamic> json) =>
      _$ResponseCouponsPartnersFromJson(json);
}

@JsonSerializable()
class ResponseCouponsTests {
  @JsonKey(name: 'CouponId')
  final int? couponId;
  @JsonKey(name: 'TestId')
  final int? testId;

  ResponseCouponsTests(this.couponId, this.testId);

  factory ResponseCouponsTests.fromJson(Map<String, dynamic> json) =>
      _$ResponseCouponsTestsFromJson(json);
}

@JsonSerializable()
class ResponseSearch {
  @JsonKey(name: 'abb')
  String? abb;
  @JsonKey(name: 'tags')
  String? tags;
  @JsonKey(name: 'partnerItemId')
  int? partnerItemId;
  @JsonKey(name: 'itemType')
  String? itemType;
  @JsonKey(name: 'itemId')
  int? itemId;
  @JsonKey(name: 'partnerId')
  int? partnerId;
  @JsonKey(name: 'price')
  double? price;
  @JsonKey(name: 'priceBeforeDiscount')
  double? priceBeforeDiscount;
  @JsonKey(name: 'partnerNameEn')
  String? partnerNameEn;
  @JsonKey(name: 'partnerNameAr')
  String? partnerNameAr;
  @JsonKey(name: 'nameEn')
  String? nameEn;
  @JsonKey(name: 'nameAr')
  String? nameAr;
  @JsonKey(name: 'classificationId')
  String? classificationId;
  @JsonKey(name: 'categoryId')
  String? categoryId;
  @JsonKey(name: 'description')
  String? description;
  @JsonKey(name: 'partnerRating')
  double? partnerRating;
  @JsonKey(name: 'certificateIds')
  String? certificateIds;
  @JsonKey(name: 'numOfTests')
  int? numOfTests;
  @JsonKey(name: 'tat')
  int? tat;
  @JsonKey(name: 'image')
  String? image;
  @JsonKey(name: 'imageEN')
  String? imageEN;
  @JsonKey(name: 'imageAR')
  String? imageAR;
  @JsonKey(name: 'partnerImage')
  String? partnerImage;
  @JsonKey(name: 'nurseFees')
  double? nurseFees;
  @JsonKey(name: 'minDistance')
  double? minDistance;
  @JsonKey(name: 'certificates')
  List<ResponsePartnersCertificatesImages>? certificates;

  ResponseSearch(
      {this.abb,
      this.tags,
      this.partnerItemId,
      this.itemType,
      this.itemId,
      this.partnerId,
      this.price,
      this.priceBeforeDiscount,
      this.partnerNameEn,
      this.partnerNameAr,
      this.nameEn,
      this.nameAr,
      this.classificationId,
      this.categoryId,
      this.partnerRating,
      this.certificateIds,
      this.numOfTests,
      this.tat,
      this.image,
      this.imageEN,
      this.imageAR,
      this.partnerImage,
      this.nurseFees,
      this.minDistance,
      this.certificates,
      this.description});
  factory ResponseSearch.fromJson(Map<String, dynamic> json) =>
      _$ResponseSearchFromJson(json);
}

@JsonSerializable()
class ResponseItemsCompare {
  @JsonKey(name: 'productId')
  final int? productId;
  @JsonKey(name: 'productName')
  final String? productName;
  @JsonKey(name: 'itemTypeId')
  final int? itemTypeId;
  @JsonKey(name: 'itemTypeName')
  final String? itemTypeName;
  @JsonKey(name: 'image')
  final String? image;
  @JsonKey(name: 'partnerNameEn')
  final String? partnerNameEn;
  @JsonKey(name: 'partnerNameAr')
  final String? partnerNameAr;
  @JsonKey(name: 'numberOfTests')
  final int? numberOfTests;
  @JsonKey(name: 'tat')
  final int? tat;
  @JsonKey(name: 'price')
  final String? price;
  @JsonKey(name: 'abbreviation')
  final String? abbreviation;
  @JsonKey(name: 'includedTests')
  final List<ResponseIncludedTests>? includedTests;
  @JsonKey(name: 'includedMarker')
  final List<ResponseIncludedMarker>? includedMarker;

  ResponseItemsCompare({
    this.productId,
    this.productName,
    this.itemTypeId,
    this.itemTypeName,
    this.image,
    this.partnerNameEn,
    this.partnerNameAr,
    this.numberOfTests,
    this.tat,
    this.price,
    this.abbreviation,
    this.includedTests,
    this.includedMarker,
  });

  factory ResponseItemsCompare.fromJson(Map<String, dynamic> json) =>
      _$ResponseItemsCompareFromJson(json);

  @override
  List<Object?> get props => [
        productId,
        productName,
        itemTypeId,
        itemTypeName,
        image,
        partnerNameEn,
        partnerNameAr,
        numberOfTests,
        tat,
        price,
        abbreviation,
        includedTests,
        includedMarker,
      ];
}

@JsonSerializable()
class ResponseIncludedTests {
  @JsonKey(name: 'testNameEn')
  String? testNameEn;
  @JsonKey(name: 'testNameAr')
  String? testNameAr;
  @JsonKey(name: 'includedMarker')
  List<ResponseIncludedMarker>? includedMarker;

  ResponseIncludedTests(
      {this.testNameEn, this.testNameAr, this.includedMarker});
  factory ResponseIncludedTests.fromJson(Map<String, dynamic> json) =>
      _$ResponseIncludedTestsFromJson(json);
}

@JsonSerializable()
class ResponseIncludedMarker {
  @JsonKey(name: 'marker')
  String? marker;

  ResponseIncludedMarker({this.marker});
  factory ResponseIncludedMarker.fromJson(Map<String, dynamic> json) =>
      _$ResponseIncludedMarkerFromJson(json);
}

@JsonSerializable()
class ResponseUserPackages {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'numOfTests')
  int? numOfTests;
  @JsonKey(name: 'nameEn')
  String? nameEn;
  @JsonKey(name: 'nameAr')
  String? nameAr;
  @JsonKey(name: 'imageEN')
  String? imageEN;
  @JsonKey(name: 'imageAR')
  String? imageAR;
  @JsonKey(name: 'targetedGender')
  ResponseLookup? targetedGender;
  @JsonKey(name: 'packagesAges')
  List<ResponsePackagesAge>? packagesAges;
  @JsonKey(name: 'tahliliCode')
  String? tahliliCode;
  @JsonKey(name: 'providedBy')
  int? providedBy;
  @JsonKey(name: 'minPrice')
  num? minPrice;

  ResponseUserPackages(
      {this.id,
      this.numOfTests,
      this.nameEn,
      this.nameAr,
      this.imageEN,
      this.imageAR,
      this.targetedGender,
      this.packagesAges,
      this.tahliliCode,
      this.providedBy,
      this.minPrice});
  factory ResponseUserPackages.fromJson(Map<String, dynamic> json) =>
      _$ResponseUserPackagesFromJson(json);
}

@JsonSerializable()
class ResponseHomeAds {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'adsAreaId')
  int? adsAreaId;
  @JsonKey(name: 'startDate')
  String? startDate;
  @JsonKey(name: 'endDate')
  String? endDate;
  @JsonKey(name: 'clicksCount')
  int? clicksCount;
  @JsonKey(name: 'impressions')
  int? impressions;
  @JsonKey(name: 'imageEN')
  String? imageEN;
  @JsonKey(name: 'imageAR')
  String? imageAR;
  @JsonKey(name: 'adsArea')
  ResponseAdsArea? adsArea;
  @JsonKey(name: 'url')
  String? url;

  ResponseHomeAds(
      {this.id,
      this.adsAreaId,
      this.startDate,
      this.endDate,
      this.clicksCount,
      this.impressions,
      this.imageEN,
      this.imageAR,
      this.adsArea,
      this.url});

  factory ResponseHomeAds.fromJson(Map<String, dynamic> json) =>
      _$ResponseHomeAdsFromJson(json);
}

@JsonSerializable()
class ResponseAdsArea {
  @JsonKey(name: 'size')
  String? size;
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'name')
  String? name;
  @JsonKey(name: 'orderIndex')
  int? orderIndex;

  ResponseAdsArea({this.size, this.id, this.name, this.orderIndex});

  factory ResponseAdsArea.fromJson(Map<String, dynamic> json) =>
      _$ResponseAdsAreaFromJson(json);
}

@JsonSerializable()
class ResponseIndividualTests {
  @JsonKey(name: 'id')
  final int? id;
  @JsonKey(name: 'name')
  final String? name;
  @JsonKey(name: 'image')
  final String? image;
  @JsonKey(name: 'orderIndex')
  final int? orderIndex;
  @JsonKey(name: 'numberOfTests')
  final int? numberOfTests;

  ResponseIndividualTests(
      this.id, this.name, this.image, this.orderIndex, this.numberOfTests);

  factory ResponseIndividualTests.fromJson(Map<String, dynamic> json) =>
      _$ResponseIndividualTestsFromJson(json);
}

@JsonSerializable()
class ResponsePackageDetails {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'partnerId')
  int? partnerId;
  @JsonKey(name: 'packageId')
  int? packageId;
  @JsonKey(name: 'price')
  double? price;
  @JsonKey(name: 'tat')
  double? tat;
  @JsonKey(name: 'showInDeals')
  bool? showInDeals;
  @JsonKey(name: 'priceBeforeDiscount')
  double? priceBeforeDiscount;
  @JsonKey(name: 'package')
  ResponsePackage? package;
  @JsonKey(name: 'partner')
  ResponsePartner? partner;
  @JsonKey(name: 'dealEndDate')
  String? dealEndDate;
  @JsonKey(name: 'imageEN')
  String? imageEN;
  @JsonKey(name: 'imageAR')
  String? imageAR;

  ResponsePackageDetails(
      {this.id,
      this.partnerId,
      this.packageId,
      this.price,
      this.tat,
      this.showInDeals,
      this.priceBeforeDiscount,
      this.package,
      this.partner,
      this.dealEndDate,
      this.imageEN,
      this.imageAR});
  factory ResponsePackageDetails.fromJson(Map<String, dynamic> json) =>
      _$ResponsePackageDetailsFromJson(json);
}

@JsonSerializable()
class ResponseTestDetails {
  @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'price')
  double? price;
  @JsonKey(name: 'tat')
  double? tat;
  @JsonKey(name: 'priceBeforeDiscount')
  double? priceBeforeDiscount;
  @JsonKey(name: 'image')
  String? image;
  @JsonKey(name: 'partnerId')
  int? partnerId;
  @JsonKey(name: 'testId')
  int? testId;
  @JsonKey(name: 'test')
  ResponseTests? test;
  @JsonKey(name: 'partner')
  ResponsePartner? partner;
  @JsonKey(name: 'crelioId')
  int? crelioId;

  ResponseTestDetails(
      {this.id,
      this.price,
      this.tat,
      this.priceBeforeDiscount,
      this.image,
      this.partnerId,
      this.testId,
      this.test,
      this.partner,
      this.crelioId});
  factory ResponseTestDetails.fromJson(Map<String, dynamic> json) =>
      _$ResponseTestDetailsFromJson(json);
}

@JsonSerializable()
class ResponsePartnerCount {
  @JsonKey(name: 'testCount')
  int? testCount;
  @JsonKey(name: 'packageCount')
  int? packageCount;

  ResponsePartnerCount({this.testCount, this.packageCount});
  factory ResponsePartnerCount.fromJson(Map<String, dynamic> json) =>
      _$ResponsePartnerCountFromJson(json);
}
