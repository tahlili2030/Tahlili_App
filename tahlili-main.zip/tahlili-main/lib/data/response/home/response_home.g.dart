// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'response_home.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ResponseInsurance _$ResponseInsuranceFromJson(Map<String, dynamic> json) =>
    ResponseInsurance(
      json['id'] as int?,
      json['nameEn'] as String?,
      json['nameAr'] as String?,
      json['image'] as String?,
      json['phone'] as String?,
    );

Map<String, dynamic> _$ResponseInsuranceToJson(ResponseInsurance instance) =>
    <String, dynamic>{
      'id': instance.id,
      'nameEn': instance.nameEn,
      'nameAr': instance.nameAr,
      'image': instance.image,
      'phone': instance.phone,
    };

ResponseDeals _$ResponseDealsFromJson(Map<String, dynamic> json) =>
    ResponseDeals(
      json['id'] as int?,
      json['partnerId'] as int?,
      json['packageId'] as int?,
      json['partnerItemId'] as int?,
      (json['price'] as num?)?.toDouble(),
      json['tat'] as int?,
      (json['priceBeforeDiscount'] as num?)?.toDouble(),
      json['package'] == null
          ? null
          : ResponsePackage.fromJson(json['package'] as Map<String, dynamic>),
      json['partner'] == null
          ? null
          : ResponsePartner.fromJson(json['partner'] as Map<String, dynamic>),
      json['imageEN'] as String?,
      json['imageAR'] as String?,
      json['showInDeals'] as bool?,
      json['dealEndDate'] as String?,
    );

Map<String, dynamic> _$ResponseDealsToJson(ResponseDeals instance) =>
    <String, dynamic>{
      'id': instance.id,
      'partnerId': instance.partnerId,
      'packageId': instance.packageId,
      'partnerItemId': instance.partnerItemId,
      'price': instance.price,
      'tat': instance.tat,
      'priceBeforeDiscount': instance.priceBeforeDiscount,
      'package': instance.package,
      'partner': instance.partner,
      'imageEN': instance.imageEN,
      'imageAR': instance.imageAR,
      'showInDeals': instance.showInDeals,
      'dealEndDate': instance.dealEndDate,
    };

ResponsePackage _$ResponsePackageFromJson(Map<String, dynamic> json) =>
    ResponsePackage(
      json['id'] as int?,
      json['nameEn'] as String?,
      json['nameAr'] as String?,
      json['imageEN'] as String?,
      json['imageAR'] as String?,
      json['targetedGender'] == null
          ? null
          : ResponseLookup.fromJson(
              json['targetedGender'] as Map<String, dynamic>),
      (json['packagesBmis'] as List<dynamic>?)
          ?.map((e) => ResponsePackageBmis.fromJson(e as Map<String, dynamic>))
          .toList(),
      (json['packagesAges'] as List<dynamic>?)
          ?.map((e) => ResponsePackagesAge.fromJson(e as Map<String, dynamic>))
          .toList(),
      (json['packagesCategories'] as List<dynamic>?)
          ?.map(
              (e) => ResponsePackageCatgory.fromJson(e as Map<String, dynamic>))
          .toList(),
      json['pType'] == null
          ? null
          : ResponseLookup.fromJson(json['pType'] as Map<String, dynamic>),
      json['soldItems'] as int?,
      json['image'] as String?,
      json['tahliliCode'] as String?,
      (json['price'] as num?)?.toDouble(),
      (json['packagesTests'] as List<dynamic>?)
          ?.map((e) => ResponseTests.fromJson(e as Map<String, dynamic>))
          .toList(),
      json['tat'] as int?,
      json['partner'] == null
          ? null
          : ResponsePartner.fromJson(json['partner'] as Map<String, dynamic>),
      json['package'] == null
          ? null
          : ResponsePartner.fromJson(json['package'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ResponsePackageToJson(ResponsePackage instance) =>
    <String, dynamic>{
      'id': instance.id,
      'nameEn': instance.nameEn,
      'nameAr': instance.nameAr,
      'imageEN': instance.imageEN,
      'imageAR': instance.imageAR,
      'image': instance.image,
      'targetedGender': instance.targetedGender,
      'packagesBmis': instance.packagesBmis,
      'packagesAges': instance.packagesAges,
      'packagesCategories': instance.packagesCategories,
      'pType': instance.pType,
      'soldItems': instance.soldItems,
      'tahliliCode': instance.tahliliCode,
      'price': instance.price,
      'packagesTests': instance.packagesTests,
      'tat': instance.tat,
      'partner': instance.partner,
      'package': instance.package,
    };

ResponseLookup _$ResponseLookupFromJson(Map<String, dynamic> json) =>
    ResponseLookup(
      json['id'] as int?,
      json['name'] as String?,
      json['orderIndx'] as int?,
      json['image'] as String?,
    );

Map<String, dynamic> _$ResponseLookupToJson(ResponseLookup instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'orderIndx': instance.orderIndx,
      'image': instance.image,
    };

ResponsePartner _$ResponsePartnerFromJson(Map<String, dynamic> json) =>
    ResponsePartner(
      json['Id'] as int?,
      json['nameEn'] as String?,
      json['nameAr'] as String?,
      json['Hotline'] as String?,
      (json['FBNurseAvg'] as num?)?.toDouble(),
      (json['FBServiceAvg'] as num?)?.toDouble(),
      json['image'] as String?,
      json['Phone'] as String?,
      json['TaxNumber'] as String?,
      json['imageEN'] as String?,
      json['imageAR'] as String?,
    );

Map<String, dynamic> _$ResponsePartnerToJson(ResponsePartner instance) =>
    <String, dynamic>{
      'Id': instance.id,
      'nameEn': instance.nameEn,
      'nameAr': instance.nameAr,
      'imageEN': instance.imageEN,
      'imageAR': instance.imageAR,
      'Hotline': instance.hotline,
      'FBNurseAvg': instance.fBNurseAvg,
      'FBServiceAvg': instance.fBServiceAvg,
      'image': instance.image,
      'Phone': instance.phone,
      'TaxNumber': instance.taxNumber,
    };

ResponsePackageBmis _$ResponsePackageBmisFromJson(Map<String, dynamic> json) =>
    ResponsePackageBmis(
      json['BmiId '] as int?,
      json['BmiName '] as String?,
    );

Map<String, dynamic> _$ResponsePackageBmisToJson(
        ResponsePackageBmis instance) =>
    <String, dynamic>{
      'BmiId ': instance.id,
      'BmiName ': instance.name,
    };

ResponsePackageCatgory _$ResponsePackageCatgoryFromJson(
        Map<String, dynamic> json) =>
    ResponsePackageCatgory(
      json['categoryId'] as int?,
      json['categoryName'] as String?,
      json['packageNameEn'] as String?,
      json['packageNameAr'] as String?,
      json['pType'] as int?,
      json['soldItems'] as int?,
    );

Map<String, dynamic> _$ResponsePackageCatgoryToJson(
        ResponsePackageCatgory instance) =>
    <String, dynamic>{
      'categoryId': instance.categoryId,
      'categoryName': instance.categoryName,
      'packageNameEn': instance.packageNameEn,
      'packageNameAr': instance.packageNameAr,
      'pType': instance.pType,
      'soldItems': instance.soldItems,
    };

ResponsePackagesAge _$ResponsePackagesAgeFromJson(Map<String, dynamic> json) =>
    ResponsePackagesAge(
      json['AgeId '] as int?,
      json['AgeName'] as String?,
    );

Map<String, dynamic> _$ResponsePackagesAgeToJson(
        ResponsePackagesAge instance) =>
    <String, dynamic>{
      'AgeId ': instance.ageId,
      'AgeName': instance.ageName,
    };

ResponseGenetics _$ResponseGeneticsFromJson(Map<String, dynamic> json) =>
    ResponseGenetics(
      tests: (json['tests'] as List<dynamic>?)
          ?.map((e) => ResponseTests.fromJson(e as Map<String, dynamic>))
          .toList(),
      image: json['image'] as String?,
      id: json['id'] as int?,
      name: json['name'] as String?,
      orderIndex: json['orderIndex'] as int?,
    );

Map<String, dynamic> _$ResponseGeneticsToJson(ResponseGenetics instance) =>
    <String, dynamic>{
      'tests': instance.tests,
      'image': instance.image,
      'id': instance.id,
      'name': instance.name,
      'orderIndex': instance.orderIndex,
    };

ResponseTests _$ResponseTestsFromJson(Map<String, dynamic> json) =>
    ResponseTests(
      json['testNameEn'] as String?,
      json['testNameAr'] as String?,
      (json['minPrice'] as num?)?.toDouble(),
      (json['providedBy'] as num?)?.toDouble(),
      symbol: json['symbol'] as String?,
      abbreviation: json['abbreviation'] as String?,
      image: json['image'] as String?,
      id: json['id'] as int?,
      nameEn: json['nameEn'] as String?,
      nameAr: json['nameAr'] as String?,
      referencePrice: (json['referencePrice'] as num?)?.toDouble(),
      referenceTAT: json['referenceTAT'] as int?,
      tahliliCode: json['tahliliCode'] as String?,
      isActive: json['isActive'] as bool?,
    );

Map<String, dynamic> _$ResponseTestsToJson(ResponseTests instance) =>
    <String, dynamic>{
      'symbol': instance.symbol,
      'abbreviation': instance.abbreviation,
      'image': instance.image,
      'id': instance.id,
      'nameEn': instance.nameEn,
      'nameAr': instance.nameAr,
      'testNameEn': instance.testNameEn,
      'testNameAr': instance.testNameAr,
      'referencePrice': instance.referencePrice,
      'minPrice': instance.minPrice,
      'providedBy': instance.providedBy,
      'referenceTAT': instance.referenceTAT,
      'tahliliCode': instance.tahliliCode,
      'isActive': instance.isActive,
    };

ResponseHomeCategory _$ResponseHomeCategoryFromJson(
        Map<String, dynamic> json) =>
    ResponseHomeCategory(
      json['imageEN'] as String?,
      json['imageAR'] as String?,
      (json['packagesCategories'] as List<dynamic>?)
          ?.map(
              (e) => ResponsePackageCatgory.fromJson(e as Map<String, dynamic>))
          .toList(),
      json['packageCount'] as int?,
      json['soldItemsSum'] as int?,
      json['id'] as int?,
      json['name'] as String?,
      json['orderIndex'] as int?,
    );

Map<String, dynamic> _$ResponseHomeCategoryToJson(
        ResponseHomeCategory instance) =>
    <String, dynamic>{
      'imageEN': instance.imageEn,
      'imageAR': instance.imageAr,
      'packagesCategories': instance.packagesCategories,
      'packageCount': instance.packageCount,
      'soldItemsSum': instance.soldItemsSum,
      'id': instance.id,
      'name': instance.name,
      'orderIndex': instance.orderIndex,
    };

ResponseHomeLabs _$ResponseHomeLabsFromJson(Map<String, dynamic> json) =>
    ResponseHomeLabs(
      json['id'] as int?,
      json['nameEn'] as String?,
      json['nameAr'] as String?,
      json['image'] as String?,
      (json['fbServiceAvg'] as num?)?.toDouble(),
      (json['fbServiceCount'] as num?)?.toDouble(),
      json['contactEmail'] as String?,
      json['numberOfProducts'] as int?,
      json['certificates'] as int?,
      json['labsNumber'] as int?,
      (json['partnersCertificatesImages'] as List<dynamic>?)
          ?.map((e) =>
              PartnersCertificatesImages.fromJson(e as Map<String, dynamic>))
          .toList(),
      json['hotline'] as String?,
      json['phone'] as String?,
    );

Map<String, dynamic> _$ResponseHomeLabsToJson(ResponseHomeLabs instance) =>
    <String, dynamic>{
      'id': instance.id,
      'nameEn': instance.nameEn,
      'nameAr': instance.nameAr,
      'image': instance.image,
      'hotline': instance.hotline,
      'phone': instance.phone,
      'fbServiceAvg': instance.fbServiceAvg,
      'fbServiceCount': instance.fbServiceCount,
      'contactEmail': instance.contactEmail,
      'numberOfProducts': instance.numberOfProducts,
      'certificates': instance.certificate,
      'labsNumber': instance.labsNumber,
      'partnersCertificatesImages': instance.certificates,
    };

PartnersCertificatesImages _$PartnersCertificatesImagesFromJson(
        Map<String, dynamic> json) =>
    PartnersCertificatesImages(
      certificateId: json['certificateId'] as int?,
      certificateName: json['certificateName'] as String?,
      images: json['images'] as String?,
    );

Map<String, dynamic> _$PartnersCertificatesImagesToJson(
        PartnersCertificatesImages instance) =>
    <String, dynamic>{
      'certificateId': instance.certificateId,
      'certificateName': instance.certificateName,
      'images': instance.images,
    };

ResponsePartnersCertificatesImages _$ResponsePartnersCertificatesImagesFromJson(
        Map<String, dynamic> json) =>
    ResponsePartnersCertificatesImages(
      json['id'] as int?,
      json['certificateName'] as String?,
      json['image'] as String?,
      json['orderIndex'] as int?,
    );

Map<String, dynamic> _$ResponsePartnersCertificatesImagesToJson(
        ResponsePartnersCertificatesImages instance) =>
    <String, dynamic>{
      'id': instance.id,
      'certificateName': instance.name,
      'orderIndex': instance.orderIndex,
      'image': instance.image,
    };

ResponseHomePackages _$ResponseHomePackagesFromJson(
        Map<String, dynamic> json) =>
    ResponseHomePackages(
      id: json['id'] as int?,
      nameEn: json['nameEn'] as String?,
      nameAr: json['nameAr'] as String?,
      ownerPartner: json['ownerPartner'] == null
          ? null
          : ResponseOwnerPartner.fromJson(
              json['ownerPartner'] as Map<String, dynamic>),
      referencePrice: (json['referencePrice'] as num?)?.toDouble(),
      referenceTAT: json['referenceTAT'] as int?,
      imageEN: json['imageEN'] as String?,
      imageAR: json['imageAR'] as String?,
      tahliliCode: json['tahliliCode'] as String?,
      providedBy: json['providedBy'] as int?,
      minPrice: (json['minPrice'] as num?)?.toDouble(),
    );

Map<String, dynamic> _$ResponseHomePackagesToJson(
        ResponseHomePackages instance) =>
    <String, dynamic>{
      'id': instance.id,
      'nameEn': instance.nameEn,
      'nameAr': instance.nameAr,
      'ownerPartner': instance.ownerPartner,
      'referencePrice': instance.referencePrice,
      'referenceTAT': instance.referenceTAT,
      'imageEN': instance.imageEN,
      'imageAR': instance.imageAR,
      'tahliliCode': instance.tahliliCode,
      'providedBy': instance.providedBy,
      'minPrice': instance.minPrice,
    };

ResponseOwnerPartner _$ResponseOwnerPartnerFromJson(
        Map<String, dynamic> json) =>
    ResponseOwnerPartner(
      id: json['id'] as int?,
      nameEn: json['nameEn'] as String?,
      nameAr: json['nameAr'] as String?,
      hotline: json['hotline'] as String?,
      fbNurseAvg: (json['fbNurseAvg'] as num?)?.toDouble(),
      fbServiceAvg: (json['fbServiceAvg'] as num?)?.toDouble(),
      image: json['image'] as String?,
      phone: json['phone'] as String?,
      taxNumber: json['taxNumber'] as String?,
    );

Map<String, dynamic> _$ResponseOwnerPartnerToJson(
        ResponseOwnerPartner instance) =>
    <String, dynamic>{
      'id': instance.id,
      'nameEn': instance.nameEn,
      'nameAr': instance.nameAr,
      'hotline': instance.hotline,
      'fbNurseAvg': instance.fbNurseAvg,
      'fbServiceAvg': instance.fbServiceAvg,
      'image': instance.image,
      'phone': instance.phone,
      'taxNumber': instance.taxNumber,
    };

ResponseHomeFeedback _$ResponseHomeFeedbackFromJson(
        Map<String, dynamic> json) =>
    ResponseHomeFeedback(
      patientId: json['patientId'] as int?,
      image: json['image'] as String?,
      gender: json['gender'] as String?,
      userId: json['userId'] as int?,
      patientNameEn: json['patientNameEn'] as String?,
      patientNameAr: json['patientNameAr'] as String?,
      dateAndTime: json['dateAndTime'] as String?,
      rate: json['rate'] as int?,
      title: json['title'] as String?,
      showInHomePage: json['showInHomePage'] as bool?,
      feedback: json['feedback'] as String?,
    );

Map<String, dynamic> _$ResponseHomeFeedbackToJson(
        ResponseHomeFeedback instance) =>
    <String, dynamic>{
      'patientId': instance.patientId,
      'image': instance.image,
      'gender': instance.gender,
      'userId': instance.userId,
      'patientNameEn': instance.patientNameEn,
      'patientNameAr': instance.patientNameAr,
      'dateAndTime': instance.dateAndTime,
      'rate': instance.rate,
      'title': instance.title,
      'showInHomePage': instance.showInHomePage,
      'feedback': instance.feedback,
    };

ResponseCoupon _$ResponseCouponFromJson(Map<String, dynamic> json) =>
    ResponseCoupon(
      description: json['description'] as String?,
      notificationMessage: json['notificationMessage'] as String?,
      maxUse: json['maxUse'] as int?,
      websiteURL: json['websiteURL'] as String?,
      videoURL: json['videoURL'] as String?,
      couponsPackages: (json['couponsPackages'] as List<dynamic>?)
          ?.map((e) =>
              ResponseCouponsPackages.fromJson(e as Map<String, dynamic>))
          .toList(),
      couponsTests: (json['couponsTests'] as List<dynamic>?)
          ?.map((e) => ResponseCouponsTests.fromJson(e as Map<String, dynamic>))
          .toList(),
      couponsCategories: json['couponsCategories'] as List<dynamic>?,
      couponsClassifications: json['couponsClassifications'] as List<dynamic>?,
      couponsNotificationTypes:
          json['couponsNotificationTypes'] as List<dynamic>?,
      couponsPartners: (json['couponsPartners'] as List<dynamic>?)
          ?.map((e) =>
              ResponseCouponsPartners.fromJson(e as Map<String, dynamic>))
          .toList(),
      id: json['id'] as int?,
      title: json['title'] as String?,
      noOfUses: json['noOfUses'] as int?,
      startDate: json['startDate'] as String?,
      endDate: json['endDate'] as String?,
      image: json['image'] as String?,
      percentage: json['percentage'] as int?,
      maxDiscount: json['maxDiscount'] as int?,
      showInHomePage: json['showInHomePage'] as bool?,
      tahliliPercentage: json['tahliliPercentage'] as int?,
    );

Map<String, dynamic> _$ResponseCouponToJson(ResponseCoupon instance) =>
    <String, dynamic>{
      'description': instance.description,
      'notificationMessage': instance.notificationMessage,
      'maxUse': instance.maxUse,
      'websiteURL': instance.websiteURL,
      'videoURL': instance.videoURL,
      'couponsPackages': instance.couponsPackages,
      'couponsTests': instance.couponsTests,
      'couponsCategories': instance.couponsCategories,
      'couponsClassifications': instance.couponsClassifications,
      'couponsNotificationTypes': instance.couponsNotificationTypes,
      'couponsPartners': instance.couponsPartners,
      'id': instance.id,
      'title': instance.title,
      'noOfUses': instance.noOfUses,
      'startDate': instance.startDate,
      'endDate': instance.endDate,
      'image': instance.image,
      'percentage': instance.percentage,
      'maxDiscount': instance.maxDiscount,
      'showInHomePage': instance.showInHomePage,
      'tahliliPercentage': instance.tahliliPercentage,
    };

ResponseCouponsPackages _$ResponseCouponsPackagesFromJson(
        Map<String, dynamic> json) =>
    ResponseCouponsPackages(
      json['CouponId'] as int?,
      json['PackageId'] as int?,
    );

Map<String, dynamic> _$ResponseCouponsPackagesToJson(
        ResponseCouponsPackages instance) =>
    <String, dynamic>{
      'CouponId': instance.couponId,
      'PackageId': instance.packageId,
    };

ResponseCouponsPartners _$ResponseCouponsPartnersFromJson(
        Map<String, dynamic> json) =>
    ResponseCouponsPartners(
      json['CouponId'] as int?,
      json['PartnerId'] as int?,
    );

Map<String, dynamic> _$ResponseCouponsPartnersToJson(
        ResponseCouponsPartners instance) =>
    <String, dynamic>{
      'CouponId': instance.couponId,
      'PartnerId': instance.partnerId,
    };

ResponseCouponsTests _$ResponseCouponsTestsFromJson(
        Map<String, dynamic> json) =>
    ResponseCouponsTests(
      json['CouponId'] as int?,
      json['TestId'] as int?,
    );

Map<String, dynamic> _$ResponseCouponsTestsToJson(
        ResponseCouponsTests instance) =>
    <String, dynamic>{
      'CouponId': instance.couponId,
      'TestId': instance.testId,
    };

ResponseSearch _$ResponseSearchFromJson(Map<String, dynamic> json) =>
    ResponseSearch(
      abb: json['abb'] as String?,
      tags: json['tags'] as String?,
      partnerItemId: json['partnerItemId'] as int?,
      itemType: json['itemType'] as String?,
      itemId: json['itemId'] as int?,
      partnerId: json['partnerId'] as int?,
      price: (json['price'] as num?)?.toDouble(),
      priceBeforeDiscount: (json['priceBeforeDiscount'] as num?)?.toDouble(),
      partnerNameEn: json['partnerNameEn'] as String?,
      partnerNameAr: json['partnerNameAr'] as String?,
      nameEn: json['nameEn'] as String?,
      nameAr: json['nameAr'] as String?,
      classificationId: json['classificationId'] as String?,
      categoryId: json['categoryId'] as String?,
      partnerRating: (json['partnerRating'] as num?)?.toDouble(),
      certificateIds: json['certificateIds'] as String?,
      numOfTests: json['numOfTests'] as int?,
      tat: json['tat'] as int?,
      image: json['image'] as String?,
      imageEN: json['imageEN'] as String?,
      imageAR: json['imageAR'] as String?,
      partnerImage: json['partnerImage'] as String?,
      nurseFees: (json['nurseFees'] as num?)?.toDouble(),
      minDistance: (json['minDistance'] as num?)?.toDouble(),
      certificates: (json['certificates'] as List<dynamic>?)
          ?.map((e) => ResponsePartnersCertificatesImages.fromJson(
              e as Map<String, dynamic>))
          .toList(),
      description: json['description'] as String?,
    );

Map<String, dynamic> _$ResponseSearchToJson(ResponseSearch instance) =>
    <String, dynamic>{
      'abb': instance.abb,
      'tags': instance.tags,
      'partnerItemId': instance.partnerItemId,
      'itemType': instance.itemType,
      'itemId': instance.itemId,
      'partnerId': instance.partnerId,
      'price': instance.price,
      'priceBeforeDiscount': instance.priceBeforeDiscount,
      'partnerNameEn': instance.partnerNameEn,
      'partnerNameAr': instance.partnerNameAr,
      'nameEn': instance.nameEn,
      'nameAr': instance.nameAr,
      'classificationId': instance.classificationId,
      'categoryId': instance.categoryId,
      'description': instance.description,
      'partnerRating': instance.partnerRating,
      'certificateIds': instance.certificateIds,
      'numOfTests': instance.numOfTests,
      'tat': instance.tat,
      'image': instance.image,
      'imageEN': instance.imageEN,
      'imageAR': instance.imageAR,
      'partnerImage': instance.partnerImage,
      'nurseFees': instance.nurseFees,
      'minDistance': instance.minDistance,
      'certificates': instance.certificates,
    };

ResponseItemsCompare _$ResponseItemsCompareFromJson(
        Map<String, dynamic> json) =>
    ResponseItemsCompare(
      productId: json['productId'] as int?,
      productName: json['productName'] as String?,
      itemTypeId: json['itemTypeId'] as int?,
      itemTypeName: json['itemTypeName'] as String?,
      image: json['image'] as String?,
      partnerNameEn: json['partnerNameEn'] as String?,
      partnerNameAr: json['partnerNameAr'] as String?,
      numberOfTests: json['numberOfTests'] as int?,
      tat: json['tat'] as int?,
      price: json['price'] as String?,
      abbreviation: json['abbreviation'] as String?,
      includedTests: (json['includedTests'] as List<dynamic>?)
          ?.map(
              (e) => ResponseIncludedTests.fromJson(e as Map<String, dynamic>))
          .toList(),
      includedMarker: (json['includedMarker'] as List<dynamic>?)
          ?.map(
              (e) => ResponseIncludedMarker.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ResponseItemsCompareToJson(
        ResponseItemsCompare instance) =>
    <String, dynamic>{
      'productId': instance.productId,
      'productName': instance.productName,
      'itemTypeId': instance.itemTypeId,
      'itemTypeName': instance.itemTypeName,
      'image': instance.image,
      'partnerNameEn': instance.partnerNameEn,
      'partnerNameAr': instance.partnerNameAr,
      'numberOfTests': instance.numberOfTests,
      'tat': instance.tat,
      'price': instance.price,
      'abbreviation': instance.abbreviation,
      'includedTests': instance.includedTests,
      'includedMarker': instance.includedMarker,
    };

ResponseIncludedTests _$ResponseIncludedTestsFromJson(
        Map<String, dynamic> json) =>
    ResponseIncludedTests(
      testNameEn: json['testNameEn'] as String?,
      testNameAr: json['testNameAr'] as String?,
      includedMarker: (json['includedMarker'] as List<dynamic>?)
          ?.map(
              (e) => ResponseIncludedMarker.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ResponseIncludedTestsToJson(
        ResponseIncludedTests instance) =>
    <String, dynamic>{
      'testNameEn': instance.testNameEn,
      'testNameAr': instance.testNameAr,
      'includedMarker': instance.includedMarker,
    };

ResponseIncludedMarker _$ResponseIncludedMarkerFromJson(
        Map<String, dynamic> json) =>
    ResponseIncludedMarker(
      marker: json['marker'] as String?,
    );

Map<String, dynamic> _$ResponseIncludedMarkerToJson(
        ResponseIncludedMarker instance) =>
    <String, dynamic>{
      'marker': instance.marker,
    };

ResponseUserPackages _$ResponseUserPackagesFromJson(
        Map<String, dynamic> json) =>
    ResponseUserPackages(
      id: json['id'] as int?,
      numOfTests: json['numOfTests'] as int?,
      nameEn: json['nameEn'] as String?,
      nameAr: json['nameAr'] as String?,
      imageEN: json['imageEN'] as String?,
      imageAR: json['imageAR'] as String?,
      targetedGender: json['targetedGender'] == null
          ? null
          : ResponseLookup.fromJson(
              json['targetedGender'] as Map<String, dynamic>),
      packagesAges: (json['packagesAges'] as List<dynamic>?)
          ?.map((e) => ResponsePackagesAge.fromJson(e as Map<String, dynamic>))
          .toList(),
      tahliliCode: json['tahliliCode'] as String?,
      providedBy: json['providedBy'] as int?,
      minPrice: json['minPrice'] as num?,
    );

Map<String, dynamic> _$ResponseUserPackagesToJson(
        ResponseUserPackages instance) =>
    <String, dynamic>{
      'id': instance.id,
      'numOfTests': instance.numOfTests,
      'nameEn': instance.nameEn,
      'nameAr': instance.nameAr,
      'imageEN': instance.imageEN,
      'imageAR': instance.imageAR,
      'targetedGender': instance.targetedGender,
      'packagesAges': instance.packagesAges,
      'tahliliCode': instance.tahliliCode,
      'providedBy': instance.providedBy,
      'minPrice': instance.minPrice,
    };

ResponseHomeAds _$ResponseHomeAdsFromJson(Map<String, dynamic> json) =>
    ResponseHomeAds(
      id: json['id'] as int?,
      adsAreaId: json['adsAreaId'] as int?,
      startDate: json['startDate'] as String?,
      endDate: json['endDate'] as String?,
      clicksCount: json['clicksCount'] as int?,
      impressions: json['impressions'] as int?,
      imageEN: json['imageEN'] as String?,
      imageAR: json['imageAR'] as String?,
      adsArea: json['adsArea'] == null
          ? null
          : ResponseAdsArea.fromJson(json['adsArea'] as Map<String, dynamic>),
      url: json['url'] as String?,
    );

Map<String, dynamic> _$ResponseHomeAdsToJson(ResponseHomeAds instance) =>
    <String, dynamic>{
      'id': instance.id,
      'adsAreaId': instance.adsAreaId,
      'startDate': instance.startDate,
      'endDate': instance.endDate,
      'clicksCount': instance.clicksCount,
      'impressions': instance.impressions,
      'imageEN': instance.imageEN,
      'imageAR': instance.imageAR,
      'adsArea': instance.adsArea,
      'url': instance.url,
    };

ResponseAdsArea _$ResponseAdsAreaFromJson(Map<String, dynamic> json) =>
    ResponseAdsArea(
      size: json['size'] as String?,
      id: json['id'] as int?,
      name: json['name'] as String?,
      orderIndex: json['orderIndex'] as int?,
    );

Map<String, dynamic> _$ResponseAdsAreaToJson(ResponseAdsArea instance) =>
    <String, dynamic>{
      'size': instance.size,
      'id': instance.id,
      'name': instance.name,
      'orderIndex': instance.orderIndex,
    };

ResponseIndividualTests _$ResponseIndividualTestsFromJson(
        Map<String, dynamic> json) =>
    ResponseIndividualTests(
      json['id'] as int?,
      json['name'] as String?,
      json['image'] as String?,
      json['orderIndex'] as int?,
      json['numberOfTests'] as int?,
    );

Map<String, dynamic> _$ResponseIndividualTestsToJson(
        ResponseIndividualTests instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'image': instance.image,
      'orderIndex': instance.orderIndex,
      'numberOfTests': instance.numberOfTests,
    };

ResponsePackageDetails _$ResponsePackageDetailsFromJson(
        Map<String, dynamic> json) =>
    ResponsePackageDetails(
      id: json['id'] as int?,
      partnerId: json['partnerId'] as int?,
      packageId: json['packageId'] as int?,
      price: (json['price'] as num?)?.toDouble(),
      tat: (json['tat'] as num?)?.toDouble(),
      showInDeals: json['showInDeals'] as bool?,
      priceBeforeDiscount: (json['priceBeforeDiscount'] as num?)?.toDouble(),
      package: json['package'] == null
          ? null
          : ResponsePackage.fromJson(json['package'] as Map<String, dynamic>),
      partner: json['partner'] == null
          ? null
          : ResponsePartner.fromJson(json['partner'] as Map<String, dynamic>),
      dealEndDate: json['dealEndDate'] as String?,
      imageEN: json['imageEN'] as String?,
      imageAR: json['imageAR'] as String?,
    );

Map<String, dynamic> _$ResponsePackageDetailsToJson(
        ResponsePackageDetails instance) =>
    <String, dynamic>{
      'id': instance.id,
      'partnerId': instance.partnerId,
      'packageId': instance.packageId,
      'price': instance.price,
      'tat': instance.tat,
      'showInDeals': instance.showInDeals,
      'priceBeforeDiscount': instance.priceBeforeDiscount,
      'package': instance.package,
      'partner': instance.partner,
      'dealEndDate': instance.dealEndDate,
      'imageEN': instance.imageEN,
      'imageAR': instance.imageAR,
    };

ResponseTestDetails _$ResponseTestDetailsFromJson(Map<String, dynamic> json) =>
    ResponseTestDetails(
      id: json['id'] as int?,
      price: (json['price'] as num?)?.toDouble(),
      tat: (json['tat'] as num?)?.toDouble(),
      priceBeforeDiscount: (json['priceBeforeDiscount'] as num?)?.toDouble(),
      image: json['image'] as String?,
      partnerId: json['partnerId'] as int?,
      testId: json['testId'] as int?,
      test: json['test'] == null
          ? null
          : ResponseTests.fromJson(json['test'] as Map<String, dynamic>),
      partner: json['partner'] == null
          ? null
          : ResponsePartner.fromJson(json['partner'] as Map<String, dynamic>),
      crelioId: json['crelioId'] as int?,
    );

Map<String, dynamic> _$ResponseTestDetailsToJson(
        ResponseTestDetails instance) =>
    <String, dynamic>{
      'id': instance.id,
      'price': instance.price,
      'tat': instance.tat,
      'priceBeforeDiscount': instance.priceBeforeDiscount,
      'image': instance.image,
      'partnerId': instance.partnerId,
      'testId': instance.testId,
      'test': instance.test,
      'partner': instance.partner,
      'crelioId': instance.crelioId,
    };

ResponsePartnerCount _$ResponsePartnerCountFromJson(
        Map<String, dynamic> json) =>
    ResponsePartnerCount(
      testCount: json['testCount'] as int?,
      packageCount: json['packageCount'] as int?,
    );

Map<String, dynamic> _$ResponsePartnerCountToJson(
        ResponsePartnerCount instance) =>
    <String, dynamic>{
      'testCount': instance.testCount,
      'packageCount': instance.packageCount,
    };
