import 'package:json_annotation/json_annotation.dart';

import '../home/response_home.dart';

part 'response_auth.g.dart';

@JsonSerializable()
class ResponseOtp {
  @JsonKey(name: 'userId')
  final String? userId;
  @JsonKey(name: 'token')
  final String? token;
  @JsonKey(name: 'refreshTokenExpiration')
  final String? refreshTokenExpiration;
  @JsonKey(name: 'isPhoneNumberConfirmed')
  final bool? isPhoneNumberConfirmed;

  ResponseOtp(
      {this.userId,
      this.token,
      this.refreshTokenExpiration,
      this.isPhoneNumberConfirmed});

      factory ResponseOtp.fromJson(Map<String, dynamic> json) =>
      _$ResponseOtpFromJson(json);
}

@JsonSerializable()
class ResponseRegister {
  @JsonKey(name: "statusCode")
  final int statusCode;
  @JsonKey(name: "message")
  final String message;
  @JsonKey(name: "id")
  final int id;

  ResponseRegister(this.statusCode, this.message, this.id);

  factory ResponseRegister.fromJson(Map<String, dynamic> json) =>
      _$ResponseRegisterFromJson(json);
}

@JsonSerializable()
class ResponsePatient {
 @JsonKey(name: 'id')
  int? id;
  @JsonKey(name: 'firstName')
  String? firstName;
  @JsonKey(name: 'lastName')
  String? lastName;
  @JsonKey(name: 'idNumber')
  String? idNumber;
  @JsonKey(name: 'birthDate')
  String? birthDate;
  @JsonKey(name: 'phone')
  String? phone;
  @JsonKey(name: 'gender')
  ResponseLookup? gender;
  @JsonKey(name: 'image')
  String? image;
  @JsonKey(name: 'userId')
  String? userId;
  @JsonKey(name: 'genderId')
  int? genderId;
  @JsonKey(name: 'nationalityId')
  int? nationalityId;
  @JsonKey(name: 'languageId')
  int? languageId;
  @JsonKey(name: 'email')
  String? email;
  @JsonKey(name: 'nationality')
  ResponseLookup? nationality;
  @JsonKey(name: 'language')
  ResponseLookup? language;
  @JsonKey(name: 'fbAvg')
  num ?fbAvg;
  @JsonKey(name: 'middleName')
  String? middleName;
  @JsonKey(name: 'relationshipId')
  int? relationshipId;
  @JsonKey(name: 'walletCredit')
  double? walletCredit;
  @JsonKey(name: 'walletMoney')
  double? walletMoney;

  ResponsePatient(
      {this.id,
      this.firstName,
      this.lastName,
      this.idNumber,
      this.birthDate,
      this.phone,
      this.gender,
      this.image,
      this.userId,
      this.genderId,
      this.nationalityId,
      this.languageId,
      this.email,
      this.nationality,
      this.language,
      this.fbAvg,
      this.middleName,
      this.relationshipId,
      this.walletCredit,
      this.walletMoney});
  factory ResponsePatient.fromJson(Map<String, dynamic> json) =>
      _$ResponsePatientFromJson(json);
}
