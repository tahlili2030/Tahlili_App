// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'response_auth.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ResponseOtp _$ResponseOtpFromJson(Map<String, dynamic> json) => ResponseOtp(
      userId: json['userId'] as String?,
      token: json['token'] as String?,
      refreshTokenExpiration: json['refreshTokenExpiration'] as String?,
      isPhoneNumberConfirmed: json['isPhoneNumberConfirmed'] as bool?,
    );

Map<String, dynamic> _$ResponseOtpToJson(ResponseOtp instance) =>
    <String, dynamic>{
      'userId': instance.userId,
      'token': instance.token,
      'refreshTokenExpiration': instance.refreshTokenExpiration,
      'isPhoneNumberConfirmed': instance.isPhoneNumberConfirmed,
    };

ResponseRegister _$ResponseRegisterFromJson(Map<String, dynamic> json) =>
    ResponseRegister(
      json['statusCode'] as int,
      json['message'] as String,
      json['id'] as int,
    );

Map<String, dynamic> _$ResponseRegisterToJson(ResponseRegister instance) =>
    <String, dynamic>{
      'statusCode': instance.statusCode,
      'message': instance.message,
      'id': instance.id,
    };

ResponsePatient _$ResponsePatientFromJson(Map<String, dynamic> json) =>
    ResponsePatient(
      id: json['id'] as int?,
      firstName: json['firstName'] as String?,
      lastName: json['lastName'] as String?,
      idNumber: json['idNumber'] as String?,
      birthDate: json['birthDate'] as String?,
      phone: json['phone'] as String?,
      gender: json['gender'] == null
          ? null
          : ResponseLookup.fromJson(json['gender'] as Map<String, dynamic>),
      image: json['image'] as String?,
      userId: json['userId'] as String?,
      genderId: json['genderId'] as int?,
      nationalityId: json['nationalityId'] as int?,
      languageId: json['languageId'] as int?,
      email: json['email'] as String?,
      nationality: json['nationality'] == null
          ? null
          : ResponseLookup.fromJson(
              json['nationality'] as Map<String, dynamic>),
      language: json['language'] == null
          ? null
          : ResponseLookup.fromJson(json['language'] as Map<String, dynamic>),
      fbAvg: json['fbAvg'] as num?,
      middleName: json['middleName'] as String?,
      relationshipId: json['relationshipId'] as int?,
      walletCredit: (json['walletCredit'] as num?)?.toDouble(),
      walletMoney: (json['walletMoney'] as num?)?.toDouble(),
    );

Map<String, dynamic> _$ResponsePatientToJson(ResponsePatient instance) =>
    <String, dynamic>{
      'id': instance.id,
      'firstName': instance.firstName,
      'lastName': instance.lastName,
      'idNumber': instance.idNumber,
      'birthDate': instance.birthDate,
      'phone': instance.phone,
      'gender': instance.gender,
      'image': instance.image,
      'userId': instance.userId,
      'genderId': instance.genderId,
      'nationalityId': instance.nationalityId,
      'languageId': instance.languageId,
      'email': instance.email,
      'nationality': instance.nationality,
      'language': instance.language,
      'fbAvg': instance.fbAvg,
      'middleName': instance.middleName,
      'relationshipId': instance.relationshipId,
      'walletCredit': instance.walletCredit,
      'walletMoney': instance.walletMoney,
    };
