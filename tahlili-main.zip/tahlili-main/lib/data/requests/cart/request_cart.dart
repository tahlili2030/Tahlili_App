class RequestCart{
  final int patientId;
  final int ?partnerTestId;
  final int? partnerPackageId;
  final int ?labId;
  final int ?addressId;
  final String vistDate;

  RequestCart(this.patientId, this.partnerTestId, this.partnerPackageId, this.vistDate, this.labId, this.addressId,);
}