import 'dart:io';

class RequestAddress {
  final String userId;
  final String name;
  final String address;
  final String location;
  final int cityId;
  final int districtId;
  final double longitude;
  final double latitude;
  final bool defaultAddress;

  RequestAddress(
      this.userId,
      this.name,
      this.address,
      this.location,
      this.cityId,
      this.districtId,
      this.longitude,
      this.latitude,
      this.defaultAddress);
}

class RequestPrescriptions {
  final int patientId;
  final String date;
  final String description;

  RequestPrescriptions(this.patientId, this.date, this.description);
}

class RequestComplaints {
  final int patientId;
  final int complaintsTypeId;
  final String description;

  RequestComplaints(
    this.patientId,
    this.complaintsTypeId,
    this.description,
  );
}

class RequestAddProfile {
  final String idNumber;
  final String firstName;
  final String middleName;
  final String lastName;
  final int genderId;
  final int nationalityId;
  final int languageId;
  final String birthDate;
  final String userId;
  final String phone;
  final bool copyOrdersAddressToProfile;

  RequestAddProfile(
      {required this.phone,
      required this.idNumber,
      required this.firstName,
      required this.middleName,
      required this.lastName,
      required this.genderId,
      required this.nationalityId,
      required this.languageId,
      required this.birthDate,
      required this.userId,
      required this.copyOrdersAddressToProfile});
}

class RequestUploadFile {
  final String id;
  final String entityName;
  final bool isPdf;
  final File file;

  RequestUploadFile(this.id, this.entityName, this.isPdf, this.file);
}

class RequestEditProfile {
  final String idNumber;
  final String firstName;
  final String middleName;
  final String lastName;
  final int genderId;
  final int nationalityId;
  final int relationShipId;
  final int languageId;
  final String birthDate;
  final String phone;

  RequestEditProfile({
    required this.phone,
    required this.relationShipId,
    required this.idNumber,
    required this.firstName,
    required this.middleName,
    required this.lastName,
    required this.genderId,
    required this.nationalityId,
    required this.languageId,
    required this.birthDate,
  });
}

class RequestRefund {
  final int patientId;
  final double amount;
  final String date;

  RequestRefund(this.patientId, this.amount, this.date);
}
