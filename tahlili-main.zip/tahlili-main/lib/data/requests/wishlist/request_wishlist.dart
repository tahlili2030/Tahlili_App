class RequestWishlist {
  final int patientId;
  final int? partnerPackageId;
  final int? partnerTestId;

  RequestWishlist(this.patientId, this.partnerPackageId, this.partnerTestId);
}
