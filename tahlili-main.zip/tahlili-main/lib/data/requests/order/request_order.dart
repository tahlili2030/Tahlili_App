class RequestQuickOrder {
  final int patientId;
  final String patientUserId;
  final bool useWallet;
  final bool isTest;
  final String prefearedDate;
  final String prefearedTime;
  final int paymnetTypeId;
  final int itemId;
  final String couponName;
  final bool? isMale;
  final int? addressId;
  final int? labId;

  RequestQuickOrder(
      {required this.patientId,
      required this.patientUserId,
      required this.useWallet,
      required this.isTest,
      required this.prefearedDate,
      required this.prefearedTime,
      required this.paymnetTypeId,
      required this.itemId,
      required this.couponName,
      this.isMale,
      this.addressId,
      this.labId});
}

class RequestTele {
  final int? departmentId;
  final int? doctorId;
  final int patientId;
  final String notes;
  final String visitDateTime;
  final bool isInstant;

  RequestTele(this.departmentId, this.doctorId, this.patientId, this.notes,
      this.visitDateTime, this.isInstant);
}

class RequestOrderData {
  final int labId;
  final int itemId;
  final String packageName;
  final double price;
  final bool isTest;

  RequestOrderData(
      this.labId, this.packageName, this.price, this.itemId, this.isTest);
}

class RequestOrder {
  final String? couponName;
  final int paymentTypeId;
  final String patientUserId;
  final bool useWallet;
  final bool? isMale;

  RequestOrder(this.couponName, this.paymentTypeId, this.patientUserId,
      this.useWallet, this.isMale);
}
