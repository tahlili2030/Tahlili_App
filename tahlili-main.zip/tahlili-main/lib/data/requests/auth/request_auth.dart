class RequestLogin {
  final String phoneNumber;

  RequestLogin(this.phoneNumber);
}

class RequestRegister {
  final String phone;
  final String email;
  final String idNumber;
  final String nationalityID;
  final String fName;
  final String lName;
  final String genderID;
  final String languageID;
  final String birhthDate;
  final String userID;

  RequestRegister({required this.phone, required this.email, required this.idNumber, required this.nationalityID, required this.fName, required this.lName, required this.genderID, required this.languageID, required this.birhthDate, required this.userID});
}

class RequestOtp {
  final String phone;
  final String otp;

  RequestOtp({required this.phone, required this.otp});
}
