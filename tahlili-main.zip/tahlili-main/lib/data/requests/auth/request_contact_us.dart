class RequestContactUs {
final  String firstName;
final  String lastName;
 final String email;
final  String phone;
 final String description;

  RequestContactUs(this.firstName, this.lastName, this.email, this.phone, this.description);
}
