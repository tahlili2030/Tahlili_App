class RequestPatientHisotry{
  final int patientId;
  final int testId;
  final int packageId;

  RequestPatientHisotry(this.patientId, this.testId, this.packageId);
}